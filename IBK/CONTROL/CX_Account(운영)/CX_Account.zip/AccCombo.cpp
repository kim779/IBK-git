// AccCombo.cpp : implementation file
//

#include "stdafx.h"
#include "CX_Account.h"
#include "AccCombo.h"
#include "AccountCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAccCombo
static WNDPROC m_pWndProc = NULL;
CRect rComboImageRect;
static CAccCombo *m_pComboBox = NULL;

CAccCombo::CAccCombo(CAccountCtrl* pAccountCtrl)
	: m_bGroup(FALSE)
	, m_bGroupList(TRUE)
	, m_nGroupKey(-1)
	, m_pParentAccountCtrl(pAccountCtrl)
{
    m_pComboBox = this;
    m_hListBox = NULL;
}

CAccCombo::~CAccCombo()
{
}

BEGIN_MESSAGE_MAP(CAccCombo, CComboBox)
	//{{AFX_MSG_MAP(CAccCombo)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_CTLCOLORLISTBOX, OnCtlColorListBox)
	ON_MESSAGE(WM_DELETE_COMBODATE, OnDeleteMouseButton)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAccCombo message handlers

void CAccCombo::AddAccString(CString strAcc)
{
	m_strAccArray.Add(strAcc);
	AddString(strAcc);
}

void CAccCombo::DeleteAllAccArray()
{
	m_strAccArray.RemoveAll();
	ResetContent();
}

CString CAccCombo::GetListCtrlText(int nIndex)
{
	if(m_strAccArray.GetSize() == nIndex)
		return "";

	return m_strAccArray.GetAt(nIndex);
}

void CAccCombo::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	CString strColour;
	CDC dcContext;
 	CRect rItemRect( lpDrawItemStruct->rcItem );
	CBrush brFrameBrush;
 	int iItem = lpDrawItemStruct->itemID;
	CRect rBlockRect( rItemRect );
	COLORREF crNormal = GetSysColor( COLOR_WINDOW );
	COLORREF crSelected = GetSysColor( COLOR_HIGHLIGHT );
	COLORREF crText = GetSysColor( COLOR_WINDOWTEXT );

	if( !dcContext.Attach( lpDrawItemStruct->hDC ) )
		return;
	
	brFrameBrush.CreateStockObject( BLACK_BRUSH );
	rComboImageRect = rItemRect;
	rComboImageRect.top = rItemRect.top + 2;
	rComboImageRect.left = rItemRect.right - 15;

	if(m_strAccArray.GetSize() == 0)
	{
		dcContext.Detach();
		return;
	}

	if( iItem != -1)
		strColour.Format("%s", m_strAccArray[iItem]);
	else
		strColour = "";

	if( lpDrawItemStruct->itemState & ODS_SELECTED ) // ���콺 ���� �׸� ǥ��
	{
		dcContext.SetTextColor(	( 0x00FFFFFF & ~( crText ) ) );
		dcContext.SetBkColor( crSelected );
		dcContext.FillSolidRect( &rBlockRect, crSelected );
		if(strColour != "" && strColour != STR_ALL_DELECT && m_bGroup == FALSE) 
			DrawIconEx(dcContext, rComboImageRect.left, rComboImageRect.top, AfxGetApp()->LoadIcon(IDR_LIST_DELETE),
					   12,12,0,NULL,DI_NORMAL);
		else  // "��ü ����"�� X ǥ�� �� ��
			DrawIconEx(dcContext, rComboImageRect.left, rComboImageRect.top, AfxGetApp()->LoadIcon(IDR_LIST_NULL),
			           12,12,0,NULL,DI_NORMAL);
	}
	else
	{
		dcContext.SetTextColor( crText );
		
		if(strColour != STR_ALL_DELECT) 
		{
			dcContext.SetBkColor( crNormal );
			dcContext.FillSolidRect( &rBlockRect, crNormal );
		}
		else // "��ü ����"�� ȸ������
		{
			dcContext.SetBkColor(GetSysColor(COLOR_ACTIVEBORDER));
			dcContext.FillSolidRect( &rBlockRect, GetSysColor(COLOR_ACTIVEBORDER));
		}
		DrawIconEx(dcContext, rComboImageRect.left, rComboImageRect.top, AfxGetApp()->LoadIcon(IDR_LIST_NULL),
				   12,12,0,NULL,DI_NORMAL);
	}

	// draw text and block.
	if( iItem != -1 )
	{
		dcContext.SetBkMode( TRANSPARENT );
		dcContext.TextOut( rItemRect.left+3, rItemRect.top+2,	strColour );
	}
	
	dcContext.Detach();
}

extern "C" LRESULT FAR PASCAL ComboBoxListBoxProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
    switch (nMsg)
    {
	case WM_LBUTTONDOWN:
        {
			CRect rc;
            GetClientRect(hWnd, rc);
			
            CPoint pt;
            pt.x = LOWORD(lParam);
            pt.y = HIWORD(lParam);

			if(rComboImageRect.PtInRect(pt) && m_pComboBox->GetSafeHwnd()) // ���� �̹����� Ŭ�� ���� ��
			{
				m_pComboBox->SendMessage(WM_DELETE_COMBODATE, 0 , 0);
				return 0;
			}
		}
	}
	
    return CallWindowProc(m_pWndProc, hWnd, nMsg, wParam, lParam);
}


void CAccCombo::DeleteAllAcc() 
{
	int nCount = m_strAccArray.GetSize();
	CString strAccString;

	for(int nIndex=0;nIndex<nCount;nIndex++)
	{
		strAccString = m_strAccArray.GetAt(nIndex);
		if(strAccString != STR_ALL_DELECT)
			m_pParentAccountCtrl->AddDeleteAccList(strAccString.Mid(0,ACC_NUMBER_LEN));
	}
}

LRESULT CAccCombo::OnDeleteMouseButton(WPARAM, LPARAM lParam) 
{
	int nSel;
	CString nSelStr;
	nSel = GetCurSel();

	nSelStr = GetListCtrlText(nSel);
	if(nSelStr == "" || m_bGroup == TRUE)
		return 0L;

	if(nSelStr == STR_ALL_DELECT)
	{
		DeleteAllAcc();
		SendMessage(CB_SHOWDROPDOWN, FALSE);
		return 0L;
	}

	if(m_pParentAccountCtrl && GetCount())
	{
		m_pParentAccountCtrl->AddDeleteAccList(nSelStr.Mid(0,ACC_NUMBER_LEN));
		m_pParentAccountCtrl->DeleteAcc(nSel);
	}

	return 0L;
}

LRESULT CAccCombo::OnCtlColorListBox(WPARAM, LPARAM lParam) 
{
    if (m_hListBox == NULL)
    {
        HWND hWnd = reinterpret_cast<HWND>(lParam);
		
        if (hWnd != 0 && hWnd != m_hWnd)
        {
            // Save the listbox handle
            m_hListBox = hWnd;
			
            // Do the subclassing
            m_pWndProc = reinterpret_cast<WNDPROC>(GetWindowLong(m_hListBox, GWL_WNDPROC));
			SetWindowLong(m_hListBox, GWL_WNDPROC, reinterpret_cast<long>(ComboBoxListBoxProc));
        }
    }
	
    return Default();
}

void CAccCombo::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{

	return;
}
