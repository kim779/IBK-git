// CX_Account.h : main header file for the CX_ACCOUNT DLL
//

#if !defined(AFX_CX_ACCOUNT_H__4F9DB886_02BE_4843_ABDD_6CE6EC1B0BB2__INCLUDED_)
#define AFX_CX_ACCOUNT_H__4F9DB886_02BE_4843_ABDD_6CE6EC1B0BB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCX_AccountApp
// See CX_Account.cpp for the implementation of this class
//

class CCX_AccountApp : public CWinApp
{
public:
	CCX_AccountApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCX_AccountApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CCX_AccountApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CX_ACCOUNT_H__4F9DB886_02BE_4843_ABDD_6CE6EC1B0BB2__INCLUDED_)
