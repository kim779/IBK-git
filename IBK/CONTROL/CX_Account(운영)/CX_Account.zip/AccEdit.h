#if !defined(AFX_ACCEDIT_H__88CF954A_3E5E_4B61_AF88_0BB596759D3D__INCLUDED_)
#define AFX_ACCEDIT_H__88CF954A_3E5E_4B61_AF88_0BB596759D3D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AccEdit.h : header file
//

#include "OXMaskedEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CAccEdit window

class CAccEdit : public COXMaskedEdit
{
// Construction
public:
	CAccEdit();

// Attributes
public:
	inline BOOL GetEditMode() { return m_bEditMode; };
	inline void SetEditMode(BOOL bEditMode) { m_bEditMode = bEditMode; };

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAccEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAccEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAccEdit)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	void    Update                      (int nSelectionStart=0) ;  // UpdateInsertionPoint is automatic.

private:
	BOOL m_bEditMode;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACCEDIT_H__88CF954A_3E5E_4B61_AF88_0BB596759D3D__INCLUDED_)
