#if !defined(AFXCAccountCTRL_H__66CEA6C2_4AF2_4A89_95B2_921A493E8656__INCLUDED_)
#define AFXCAccountCTRL_H__66CEA6C2_4AF2_4A89_95B2_921A493E8656__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AccountCtrl.h : header file
//

#include "AccCombo.h"
#include "AccEdit.h"
#include "Account.h"

class CParam
{
public:
	int			key;			// screen key
	CString		name;			// control symbol name
	CRect		rect;			// control rect
	CString		fonts;			// font name
	int			point;			// font point
	int			style;			// font style
	DWORD		tRGB;			// text color index
	DWORD		pRGB;			// paint color index
	CString		options;		// properties
};

//=================================================================================================
class CGroup
{
public:
	CString m_strGrSortNum;	// �׷��Ϸù�ȣ
	CString m_strGrName;	// �׷��
	CString m_strAccntCnt;	// ���°���
	CString	m_strGroupID;	// �׷���̵�
	CArray <CAccount *, CAccount *>	m_arrAccount;
public:
	CGroup()
	{
		m_strGrSortNum = _T("");
		m_strGrName = _T("");
		m_strAccntCnt = _T("");
		m_strGroupID = _T("");
		m_arrAccount.RemoveAll();
	};

	~CGroup()
	{
		_RemoveAr();
	};

	CGroup(CGroup const &other)
	{
		Copy(other);
	};

	inline	void _RemoveAr()
	{
		for (int ii = 0; ii < m_arrAccount.GetSize(); ii++)
		{
			CAccount* pAccount = m_arrAccount.GetAt(ii);
			if (pAccount)
			{
				delete pAccount;
				pAccount = NULL;
			}
		}
		m_arrAccount.RemoveAll();
	};

	inline Copy(CGroup const &other)
	{
		m_strGrSortNum = other.m_strGrSortNum;
		m_strGrName = other.m_strGrName;
		m_strAccntCnt = other.m_strAccntCnt;
		m_strGroupID = other.m_strGroupID;

		CAccount* pAccount = NULL;
		CAccount* pNewAccount = NULL;
		for (int ii = 0; ii < other.m_arrAccount.GetSize(); ii++)
		{
			pAccount = other.m_arrAccount.GetAt(ii);
			if (pAccount)
			{
				pNewAccount = new CAccount();
				pNewAccount->Copy(*pAccount);
				m_arrAccount.Add(pNewAccount);
			}
		}
	};

	inline TrimData()
	{
		m_strGrSortNum.TrimRight();
		m_strGrName.TrimRight();
		m_strAccntCnt.TrimRight();
		m_strGroupID.TrimRight();
	}
};


/////////////////////////////////////////////////////////////////////////////
// CAccountCtrl window

class CAccountCtrl : public CWnd
{
// Construction
public:
	CAccountCtrl(CWnd* pParent, _param* pParam);

// Attributes
public:
	CToolTipCtrl	*m_pTipCtrl;
// Operations
public:
	BOOL Initialize(BOOL bDLL);
	void AccountInputComplete(CString strAccount);
	void ShowAccountList(BOOL bGroup);
	void PushTab();

private:
	BOOL CreateFont();
	BOOL IsValidAcc(CString strAccount, BOOL bOrderCheck = TRUE);
	BOOL IsFirstValidAcc(CString strAccount, BOOL bOrderCheck = TRUE);
	BOOL SendTR(CString strName, BYTE type, CString strData, BYTE key);

	COLORREF GetIndexColor(int nColor);

	CString GetLedger(CString strTR, char chType, CString strSvcn, CString strLastKey = _T(""));
	CString GetPassword(CString strAccount);
	CString Parser(CString &strSrc, CString strSub);
	CString PopAccHistory();
	CString Variant(int nComm, CString strData = _T(""));

	CAccount* FindAccountInfo(CString strAccount, BOOL bAll = TRUE);
	void LoadButtonImage();
	void LoadHistoryAcc();
	void LoadGroupAcc();
	void ParseAccntName(char* pBuf);
	void ParseGroupList(char* pBuf);
	void PushAccHistory(CString strAcc, CString strPassword, CString strAccName);
	void PushDeleteAccHistory();
	void QueryAccntName(CString strData);
	void QueryGroupList();
	void ResizeCtrl(int cx, int cy);
	void ResizeEdit(int cx, int cy);
	void SafeRemoveAccArray(CArray<CAccount*, CAccount*>* pArr);
	void SetButtonState(CPoint point, int nMouseState);
	void SetParam(_param *pParam);
	void SetFont(CFont* pFont, BOOL bRedraw = TRUE);
	void ShowGroupList();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAccountCtrl)
	public:
	virtual void OnFinalRelease();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	void PushDeleteAllAccHistory();
	BOOL IsNumber(CString str);
	void DeleteAcc(int nDeleteIndex);
	BOOL IsValidAccComplete(CString strAccount, CString depth, BOOL bOrderCheck);
	bool viewtype;
	void AppendAccHistory(CString strAcc, CString strPassword, CString strAccName);
	void AddDeleteAccList(CString strAcc);
	void DeleteDeleteAccList(CString strAcc);
	CFont* getAxFont(CString fName, int point, int style);

	void InitAllowDepth();
	BOOL GetAllowAllAcc(CString dep);
	void SaveHistory();
	virtual ~CAccountCtrl();
	CString GetAcntTypeName(CString tp);

	// Generated message map functions
protected:
	//{{AFX_MSG(CAccountCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnComboSelChange();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg LPARAM OnMouseLeave(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CAccountCtrl)
	afx_msg long _GetBackColor();
	afx_msg void _SetBackColor(long nNewValue);
	afx_msg BSTR _GetData();
	afx_msg void _SetData(LPCTSTR lpszNewValue);
	afx_msg BSTR _GetDept();
	afx_msg long _GetForeColor();
	afx_msg void _SetForeColor(long nNewValue);
	afx_msg BSTR _GetGroup();
	afx_msg void _SetGroup(LPCTSTR lpszNewValue);
	afx_msg BSTR _GetName();
	afx_msg BSTR _GetPassword();
	afx_msg BOOL _GetTabStop();
	afx_msg void _SetTabStop(BOOL bNewValue);
	afx_msg short _GetType();
	afx_msg BOOL _GetVisible();
	afx_msg void _SetVisible(BOOL bNewValue);
	afx_msg void _Empty();
	afx_msg void _SetFocus();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()

private:
	int GetOnlySise();
	int onlysise;
	CWinApp* m_axis;
	void SetAccountType();
	BOOL m_bDLL;
	BOOL m_bEditMode;
	BOOL m_bOrderEnable;
	BOOL m_bFireEvent;
	BOOL m_bInit;
	BOOL m_bMultiClick;
	BOOL m_bTrackLeave;
	BOOL m_bQueryName;
	BOOL m_bUseAlias;
	BOOL m_bDelete;
	BOOL m_bGroup;

	CAccCombo* m_pCombo;
	CAccEdit* m_pEdit;

	CArray<CAccount*, CAccount*> m_arrAllAcc;
	CArray<CAccount*, CAccount*> m_arrHistoryAcc;
	CArray<CAccount*, CAccount*> m_arrGroupAcc;
	CArray<CAccount*, CAccount*> m_arrDelectAcc;  // ����ڿ� ���� ������ ���� ����Ʈ
	CArray<CGroup*, CGroup*> m_arrGroupList;

	COLORREF m_clrBackColor;
	COLORREF m_clrForeColor;
	COLORREF m_clrBorderColor;
	COLORREF m_clrEditBackColor;

	CFont* m_pFont;

	CMenu* m_pGroupList;

	CSize m_szG;
	CSize m_szArrow;

	CString m_strAccName;
	CString m_strPassword;
	CString m_strRoot;
	CString m_strUser;
	CString m_strRet;
	CString m_strTempDomino;

	CStringArray allow_depth;

	CStringArray m_arrAccType;

	CWnd* m_pParent;

	HBITMAP m_hAccArrow;
	HBITMAP m_hAccArrow_DN;
	HBITMAP m_hAccArrow_EN;

	HBITMAP m_hG;
	HBITMAP m_hG_DN;
	HBITMAP m_hG_EN;
	HBITMAP m_hG_S;
	HBITMAP m_hG_S_DN;
	HBITMAP m_hG_S_EN;

	HBITMAP m_hArrow;
	HBITMAP m_hArrow_DN;
	HBITMAP m_hArrow_EN;

	int m_nSelectGroup;

	CParam m_Param;

	UINT m_nAppearance;
	UINT m_nBorderStyle;
	UINT m_nStateG;
	UINT m_nStateArrow;
	UINT m_nType;
	
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFXCAccountCTRL_H__66CEA6C2_4AF2_4A89_95B2_921A493E8656__INCLUDED_)
