// AccountCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "CX_Account.h"
#include "AccountCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_COMBO			0x80000001
#define IDC_EDIT			0x80000002

#define DROPDOWNHEIGHT		300
#define MARGIN				2
#define CTRLGAP				0

#define APPEARANCE_FLAT		0
#define APPEARANCE_3D		1

#define BORDERSTYLE_NONE	0
#define BORDERSTYLE_FIXED	1

#define COLOR_BORDER		65
#define COLOR_FORE			69
#define COLOR_BACK			64
#define COLOR_EDITBACK		68

#define ST_GNORMAL			0
#define ST_GDOWN			1
#define ST_GOVER			2
#define ST_ARROWNORMAL		0
#define ST_ARROWDOWN		1
#define ST_ARROWOVER		2

#define MS_NORMAL			0
#define MS_DOWN				1
#define MS_OVER				2

#define ACC_DEPT			3
#define ACC_TYPE			2
#define ACC_NO				6
#define ACC_LENGTH			ACC_DEPT + ACC_TYPE + ACC_NO + 2

#define TABSPACE			" "

#define PP_SYM				"ANSM"

#define SEL_ST				0
#define SEL_FU				1
#define SEL_BC				2

#define SC_ACCLISTBYGROUP	102		// �׷������ȸ

#define TT_INIT				1000
#define TT_QUERYACCNM		1001
#define TT_GETINIT			1002
#define TRKEY_GROUP			255
#define TRKEY_ACCNTNAME		254
#define ONLY_SISE 			'9'		//���� �ü���ȸ����ܸ� ���̵� ���� "9" �� ����

typedef struct _IAccnm
{
	char szIn[5];
	char szAccount[20];
} IACCNM, *PIACCNM;

#define L_IAccnm	sizeof(_IAccnm)

typedef struct _OAccnm
{
	char szOut[5];
	char szAccount[20];
	char szAccntNm[40];
} OACCNM, *POACCNM;

#define L_OAccnm	sizeof(_OAccnm)

/////////////////////////////////////////////////////////////////////////////
// CAccountCtrl

CAccountCtrl::CAccountCtrl(CWnd* pParent, _param* pParam)
	: m_bDLL(FALSE)
	, m_bEditMode(FALSE)
	, m_bFireEvent(FALSE)
	, m_bInit(FALSE)
	, m_bMultiClick(FALSE)
	, m_bOrderEnable(TRUE)
	, m_bQueryName(FALSE)
	, m_bTrackLeave(FALSE)
	, m_bUseAlias(FALSE)
	, m_nSelectGroup(0)
	, m_pCombo(NULL)
	, m_pEdit(NULL)
	, m_pFont(NULL)
	, m_pGroupList(NULL)
	, m_pParent(pParent)
	, m_strPassword(_T(""))
	, m_strRoot(_T(""))
	, m_strUser(_T(""))
	, m_strRet(_T(""))
	, m_hG(NULL)
	, m_hG_DN(NULL)
	, m_hG_EN(NULL)
	, m_hArrow(NULL)
	, m_hArrow_DN(NULL)
	, m_hArrow_EN(NULL)
	, m_nAppearance(APPEARANCE_FLAT)
	, m_nBorderStyle(BORDERSTYLE_FIXED)
	, m_nStateG(ST_GNORMAL)
	, m_nStateArrow(ST_ARROWNORMAL)
	, m_nType(SEL_ST)
	, m_pTipCtrl(NULL)
	, m_strTempDomino(_T("")
	)
{
	EnableAutomation();
	
	SetParam(pParam);
//	m_clrForeColor = GetSysColor(COLOR_WINDOWTEXT);
//	m_clrBackColor = GetSysColor(COLOR_WINDOW);
	m_clrBorderColor = GetSysColor(COLOR_WINDOWFRAME);
	m_clrEditBackColor = RGB(255, 255, 255);
	
	SetAccountType();
}

CAccountCtrl::~CAccountCtrl()
{
	if (m_pCombo)	delete m_pCombo;
	if (m_pEdit)		delete m_pEdit;

	SafeRemoveAccArray(&m_arrAllAcc);
	SafeRemoveAccArray(&m_arrGroupAcc);
	SafeRemoveAccArray(&m_arrHistoryAcc);
}

void CAccountCtrl::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.
	
	CWnd::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(CAccountCtrl, CWnd)
	//{{AFX_MSG_MAP(CAccountCtrl)
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_CBN_SELCHANGE(IDC_COMBO, OnComboSelChange)
	ON_WM_TIMER()
	ON_WM_SETFOCUS()
	ON_WM_KEYDOWN()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
	ON_MESSAGE(WM_USER, OnMessage)
END_MESSAGE_MAP()


BEGIN_DISPATCH_MAP(CAccountCtrl, CWnd)
//{{AFX_DISPATCH_MAP(CAccountCtrl)
	DISP_PROPERTY_EX(CAccountCtrl, "BackColor", _GetBackColor, _SetBackColor, VT_I4)
	DISP_PROPERTY_EX(CAccountCtrl, "Data", _GetData, _SetData, VT_BSTR)
	DISP_PROPERTY_EX(CAccountCtrl, "Dept", _GetDept, SetNotSupported, VT_BSTR)
	DISP_PROPERTY_EX(CAccountCtrl, "ForeColor", _GetForeColor, _SetForeColor, VT_I4)
	DISP_PROPERTY_EX(CAccountCtrl, "Group", _GetGroup, _SetGroup, VT_BSTR)
	DISP_PROPERTY_EX(CAccountCtrl, "Name", _GetName, SetNotSupported, VT_BSTR)
	DISP_PROPERTY_EX(CAccountCtrl, "Password", _GetPassword, SetNotSupported, VT_BSTR)
	DISP_PROPERTY_EX(CAccountCtrl, "TabStop", _GetTabStop, _SetTabStop, VT_BOOL)
	DISP_PROPERTY_EX(CAccountCtrl, "Type", _GetType, SetNotSupported, VT_I2)
	DISP_PROPERTY_EX(CAccountCtrl, "Visible", _GetVisible, _SetVisible, VT_BOOL)
	DISP_FUNCTION(CAccountCtrl, "Empty", _Empty, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CAccountCtrl, "SetFocus", _SetFocus, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IAccountCtrl to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {06ED8B27-3CFC-4A5E-B6D9-526FADC718A7}
static const IID IID_IAccountCtrl =
{ 0x6ed8b27, 0x3cfc, 0x4a5e, { 0xb6, 0xd9, 0x52, 0x6f, 0xad, 0xc7, 0x18, 0xa7 } };

BEGIN_INTERFACE_MAP(CAccountCtrl, CWnd)
	INTERFACE_PART(CAccountCtrl, IID_IAccountCtrl, Dispatch)
END_INTERFACE_MAP()

long CAccountCtrl::_GetBackColor() 
{
	return (long)m_clrBackColor;
}

void CAccountCtrl::_SetBackColor(long nNewValue) 
{
	m_clrBackColor = nNewValue;
	Invalidate();
}

BSTR CAccountCtrl::_GetData() 
{
	CString strResult(_T(""));

	if (m_pEdit)
		strResult = m_pEdit->GetInputData();

	return strResult.AllocSysString();
}

void CAccountCtrl::_SetData(LPCTSTR lpszNewValue) 
{
	if (m_pEdit)
	{
		m_pEdit->SetInputData(lpszNewValue);
		AccountInputComplete(lpszNewValue);
		/*
		if (m_pParent && m_bInit)
		{
			m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange)), 
							(long)m_Param.name.operator LPCTSTR());
		}
		*/
	}
}

BSTR CAccountCtrl::_GetDept() 
{
	CString strResult(_T(""));

	if (m_pEdit)
		strResult = m_pEdit->GetInputData();

	if (strResult.GetLength() == ACC_DEPT + ACC_TYPE + ACC_NO)
		strResult = strResult.Left(ACC_DEPT);
	else
		strResult.Empty();

	return strResult.AllocSysString();
}

long CAccountCtrl::_GetForeColor() 
{
	return (long)m_clrForeColor;
}

void CAccountCtrl::_SetForeColor(long nNewValue) 
{
	m_clrForeColor = nNewValue;
	Invalidate();
}


BSTR CAccountCtrl::_GetGroup() 
{
	CString strResult(_T(""));

	if (m_nSelectGroup > 0)
		strResult = m_arrGroupList.GetAt(m_nSelectGroup)->m_strGrName;
	else
		strResult = _T("��ü");

	return strResult.AllocSysString();
}

void CAccountCtrl::_SetGroup(LPCTSTR lpszNewValue) 
{
	BOOL bFind = FALSE;
	int nCount = m_arrGroupList.GetSize();
	CGroup* pGroup = NULL;

	for (int i = 0; i < nCount; i++)
	{
		pGroup = m_arrGroupList.GetAt(i);

		if (pGroup->m_strGrName == lpszNewValue)
		{
			m_nSelectGroup = i + 1;
			return;
		}
	}
}

BSTR CAccountCtrl::_GetName() 
{
	CString strResult(_T(""));
	
	if (!m_strAccName.IsEmpty())
		strResult = m_strAccName;
	else if (m_pEdit)
	{	
		BOOL bFind = FALSE;
		CString strAcc = m_pEdit->GetInputData();
		strAcc.TrimLeft();
		strAcc.TrimRight();

		if (!strAcc.IsEmpty())
		{			
			CAccount* pAcc = FindAccountInfo(strAcc);

			if (pAcc)
			{
				if (m_bUseAlias)
					strResult = pAcc->m_strAccntNick.IsEmpty() ? pAcc->m_strAccntName : pAcc->m_strAccntNick;//pAcc->m_strAccntName;
				else
					strResult = pAcc->m_strAccntName;
			}
		}
	}

	return strResult.AllocSysString();
}

BSTR CAccountCtrl::_GetPassword()
{
	CString strResult(_T(""));

	if (m_pEdit)
	{	
		BOOL bFind = FALSE;
		CString strAcc = m_pEdit->GetInputData();	
		strAcc.TrimLeft();
		strAcc.TrimRight();

		if (!strAcc.IsEmpty())
		{
			CAccount* pAcc = FindAccountInfo(strAcc);

			if (pAcc)
			{
				if (pAcc->m_strPassword.IsEmpty())
				{
					strResult = GetPassword(strAcc);
					pAcc->m_strPassword = strResult;
				}
				else
					strResult = pAcc->m_strPassword;
			}
		}
	}

	return strResult.AllocSysString();
}

BOOL CAccountCtrl::_GetTabStop() 
{
	LONG nStyle = GetWindowLong(this->GetSafeHwnd(), GWL_STYLE);

	return nStyle & WS_TABSTOP;
}

void CAccountCtrl::_SetTabStop(BOOL bNewValue) 
{
	LONG dwStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE);

	if (bNewValue)
		dwStyle |= (LONG) WS_TABSTOP;
	else
		dwStyle &= ~((LONG) WS_TABSTOP);

	SetWindowLong(GetSafeHwnd(), GWL_STYLE, dwStyle);
}

short CAccountCtrl::_GetType() 
{
	return m_nType;
}

BOOL CAccountCtrl::_GetVisible() 
{
	return IsWindowVisible();
}

void CAccountCtrl::_SetVisible(BOOL bNewValue) 
{
	ShowWindow(bNewValue ? SW_SHOW : SW_HIDE);
}

void CAccountCtrl::_Empty() 
{
	if (m_pEdit)
		m_pEdit->EmptyData(TRUE);

	if (m_pParent && m_bInit)
	{
		m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange/*Change*/)), 
						(long)m_Param.name.operator LPCTSTR());
	}
}

void CAccountCtrl::_SetFocus()
{
	SetFocus();
}

/////////////////////////////////////////////////////////////////////////////
// CAccountCtrl message handlers

BOOL CAccountCtrl::Initialize(BOOL bDLL)
{
	
	CRect rcClient;

	m_bDLL = bDLL;
	
	m_strRoot = Variant(homeCC);
	m_strUser = Variant(userCC);

	

	InitAllowDepth();  //�� ���� ���� �����μ� �ʱ�ȭ
	
	m_pCombo = new CAccCombo;
	m_pEdit = new CAccEdit;
	
	
	

	if (!m_pCombo->Create(CBS_DROPDOWNLIST | WS_CHILD | WS_VISIBLE | WS_VSCROLL, 
		CRect(0, 0, 0, DROPDOWNHEIGHT), this, IDC_COMBO))
	{
		TRACE("Create Failed AccCombo\n");
		return FALSE;
	}
	
	if (!m_pEdit->Create(WS_CHILD | WS_VISIBLE, CRect(0, 0, 0, 0), this, IDC_EDIT))
	{
		TRACE("Create Failed AccEdit\n");
		return FALSE;
	}

	char szMask[ACC_LENGTH + 1];
	memset((void*)szMask, _T('#'), ACC_LENGTH);
	
	szMask[ACC_DEPT] = _T('-');
	szMask[ACC_DEPT + ACC_TYPE + 1] = _T('-');
	szMask[ACC_LENGTH] = NULL;

	m_pEdit->SetMask(szMask);
	m_pEdit->SetInsertMode(TRUE);

	LoadButtonImage();
	
	if (CreateFont())
		SetFont(m_pFont);

	CString strUserPath;
	strUserPath.Format("%s\\user\\%s\\%s.ini", m_strRoot, Variant(nameCC), Variant(nameCC));

	if (GetPrivateProfileInt(_T("Account"), _T("UseAlias"), 0, (LPCTSTR)strUserPath) == 1)
		m_bUseAlias = TRUE;
/*
	CString strKey = m_Param.name;
	strKey.TrimLeft();
	strKey.TrimRight();

	char szHistory[1024] = { 0, };
	CString strHistory(_T(""));
	GetPrivateProfileString(_T("AccountHistory"), (LPCTSTR)strKey, _T(""), szHistory, 128, (LPCTSTR)strUserPath);
	strHistory = szHistory;
	strHistory.TrimRight();
	strHistory.TrimLeft();
*/
	CString strData = Variant(accountCC);
	
	
	if (!(long)m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, orderCC), 0L))
	{
		m_bEditMode = TRUE;
		
		if (!(long)m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, orderCCx), 0L))
			m_bOrderEnable = FALSE;
	}

	m_pEdit->SetEditMode(m_bEditMode);

	CString strKey = m_Param.name;
	strKey.TrimLeft();
	strKey.TrimRight();

	char szHistory[10000] = { 0, };
	CString strHistory(_T(""));
	if (strKey.Find("AN2") == -1) strKey = "AN98";
	GetPrivateProfileString(_T("AccountHistory"), (LPCTSTR)strKey, _T(""), szHistory, 10000, (LPCTSTR)strUserPath);
	strHistory = szHistory;
	strHistory.TrimRight();
	strHistory.TrimLeft();
    
	onlysise = GetOnlySise();
	
	CAccount* pAcc = NULL;
	CString strName(_T(""));
	
	while (!strData.IsEmpty())
	{
		//TRACE("==========================================\n");
		CString strAccInfo(_T(""));
		strAccInfo = Parser(strData, _T("\n"));
		pAcc = new CAccount;
		pAcc->m_strAccntNum = Parser(strAccInfo, _T("\t"));
		//TRACE(pAcc->m_strAccntNum + "\n");
		pAcc->m_strPassword = Parser(strAccInfo, _T("\t"));
		//TRACE(pAcc->m_strPassword + "\n");
		pAcc->m_strAccntName = Parser(strAccInfo, _T("\t"));
		strName = Parser(strAccInfo, _T("\t"));
		pAcc->m_strAccntName = Parser(strName, _T("|"));
		pAcc->m_strAccntNick = Parser(strName, _T("|"));
		pAcc->m_bDelegation = atoi((LPCTSTR)Parser(strName, _T("|")));

		pAcc->TrimData();
		//   2008.07.22 �����
		//if (!IsValidAcc(pAcc->m_strAccntNum))
		if (!IsFirstValidAcc(pAcc->m_strAccntNum))
		{
			delete pAcc;
			continue;
		}
		

//		if (!strLastAcc.IsEmpty() && pAcc->m_strAccntNum == strLastAcc)
//			m_arrAllAcc.InsertAt(0, pAcc);
//		else
			m_arrAllAcc.Add(pAcc);

			
	}
	//=====�����ü��ܸ� ���ӿ� ���̵��� ���
	/*
	CString tmp;
	tmp.Format("[%c] [%d]", m_strUser[0], onlysise);
	MessageBox(tmp);
	*/
	CString dtmp;
	dtmp.Format("[%s] %d", m_strUser, onlysise);
	//if (onlysise == 1) MessageBox("�ü���ȸ ���� �����Դϴ�.");

	if (((m_strUser[0] == ONLY_SISE) &&(IsNumber(m_strUser))) || onlysise == 1 || m_strUser == "##ibk9")
	{

		m_bEditMode = FALSE;
		m_bOrderEnable = FALSE;
		m_pEdit->SetEditMode(m_bEditMode);
		
		m_arrAllAcc.RemoveAll();
	}

  //==========================================
//	CString tmps;
//	tmps.Format("%d",m_arrAllAcc.GetSize());
	//TRACE("��ü ���� ũ��: "+tmps);
	SetTimer(TT_INIT, 10, NULL);
//	QueryGroupList();

	return TRUE;
}

CString CAccountCtrl::Variant(int nComm, CString strData /* = _T("") */)
{
	CString strRet(_T(""));
	char* pRet = NULL;
	
	pRet = (char*)m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, nComm), (LPARAM)(LPCTSTR)strData);
	
	if ((long)pRet > 1)
		strRet = pRet;
	
	return strRet;
}

void CAccountCtrl::LoadButtonImage() 
{
	CString strImgName;
	CString strImgDir(m_strRoot);
	strImgDir += _T("\\image");
	
	strImgName.Format("%s\\G.bmp", strImgDir);
	m_hG = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\G_DN.bmp", strImgDir);
	m_hG_DN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\G_EN.bmp", strImgDir);
	m_hG_EN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	strImgName.Format("%s\\G_S.bmp", strImgDir);
	m_hG_S = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\G_S_DN.bmp", strImgDir);
	m_hG_S_DN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\G_S_EN.bmp", strImgDir);
	m_hG_S_EN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\Arrow.bmp", strImgDir);
	m_hArrow = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\Arrow_DN.bmp", strImgDir);
	m_hArrow_DN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	strImgName.Format("%s\\Arrow_EN.bmp", strImgDir);
	m_hArrow_EN = (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance, strImgName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	BITMAP bmpG;
	BITMAP bmpArrow;
	
	::GetObject(m_hG, sizeof(BITMAP), &bmpG);
	::GetObject(m_hArrow, sizeof(BITMAP), &bmpArrow);
	
	m_szG.cx = bmpG.bmWidth;
	m_szG.cy = bmpG.bmHeight;
	m_szArrow.cx = bmpArrow.bmWidth;
	m_szArrow.cy = bmpArrow.bmHeight;
}

void CAccountCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	ResizeCtrl(cx, cy);	

}

void CAccountCtrl::ResizeCtrl(int cx, int cy)
{
	if (!m_pCombo)
		return;
	
	CFont* pFont = m_pCombo->GetFont();


	int nHeight = 0;
	int nEditWidth = 0;
	
	if (pFont)
	{
		LOGFONT lf;
		pFont->GetLogFont(&lf);
		nHeight = abs(lf.lfHeight) + 7;
	}
	else
		nHeight = cy;
	
	m_pCombo->MoveWindow(0, 0 - (nHeight - cy), 0, nHeight);
	m_pCombo->SetDroppedWidth(cx+60);
	
	nEditWidth = cx - (m_szG.cx + m_szArrow.cx) - CTRLGAP - (cy - MARGIN);
	ResizeEdit(nEditWidth, cy);
}

void CAccountCtrl::ResizeEdit(int cx, int cy)
{
	if (!m_pEdit)
		return;
	
	CRect rcEdit;
	int nFtHeight = 0;
	
	int sz;

	sz = (int)((cy/2)-1)<(cx/8 - MARGIN)?((cy/2)-1):(cx/8 - MARGIN) ;
	m_Param.point = sz;
	CFont* pFont = getAxFont(m_Param.fonts, m_Param.point, m_Param.style);
	m_pEdit->SetFont(pFont);
		
	if (pFont)
	{
		LOGFONT lf;
		pFont->GetLogFont(&lf);
		
		nFtHeight = abs(lf.lfHeight);
	}
	else
		nFtHeight = cy;

	rcEdit.SetRect(MARGIN, cy / 2 - nFtHeight / 2, cx - MARGIN, cy / 2 + nFtHeight / 2);


	
	m_pEdit->MoveWindow(rcEdit);

}

void CAccountCtrl::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CDC dcMem;
	CRect rcClient;
	CRect rcCombo;
	CRect rcButton;
	CSize sz = m_szG + m_szArrow;
	HBITMAP hG, hArrow;
	
	GetClientRect(&rcClient);
	
	dcMem.CreateCompatibleDC(&dc);
	dc.FillSolidRect(rcClient, m_clrBackColor);
	dcMem.FillSolidRect(rcClient, m_clrBackColor);
	
	rcCombo = rcButton = rcClient;
	rcCombo.right = rcCombo.right - sz.cx - CTRLGAP;
	rcButton.left = rcCombo.right + CTRLGAP;
	
	// DrawBorder
	if (m_nBorderStyle == BORDERSTYLE_FIXED)
	{
		if (m_nAppearance == APPEARANCE_FLAT)
		{
			CPen* pPen = new CPen(PS_SOLID, 1, m_clrBorderColor);
			CPen* pOldPen = dc.SelectObject(pPen);
			
			CBrush* pBrush = new CBrush(m_clrEditBackColor);
			CBrush* pOldBrush = dc.SelectObject(pBrush);
			
			dc.Rectangle(rcCombo);
			dc.SelectObject(pOldPen);
			dc.SelectObject(pOldBrush);
			
			pPen->DeleteObject();
			delete pPen;
			
			pBrush->DeleteObject();
			delete pBrush;
		}
		else
			dc.DrawEdge(rcCombo, EDGE_SUNKEN, BF_RECT);
	}
	
	// DrawDownArrow
	COLORREF clrBack = RGB(128, 128, 128);
	COLORREF clrArrow = RGB(224, 224, 224);
	
	CPoint pt[3];
	CRect rcArrowBack, rcArrow;
	
	rcArrowBack = rcCombo;
	rcArrowBack.DeflateRect(0, 3, 3, 3);
	rcArrowBack.left = rcArrowBack.right - rcArrowBack.Height();
	
	rcArrow = rcArrowBack;
	rcArrow.DeflateRect(3, rcArrow.Height() * 2 / 5);
	rcArrow.OffsetRect(1, 0);
	rcArrow.right = rcArrow.left + (rcArrow.Width() / 2) * 2 - 1;
	rcArrow.bottom = rcArrow.top + rcArrow.Width() / 2;
	
	CPen penBtn(PS_SOLID, 1, clrBack);
	CPen penArrow(PS_SOLID, 1, clrArrow);
	CBrush brushBtn(clrBack);
	CBrush brushArrow(clrArrow);
	
	CPen* pOldPen = dc.SelectObject(&penBtn);
	CBrush* pOldBrush = dc.SelectObject(&brushBtn);
	
	dc.FillRect(&rcArrowBack, &brushBtn);
	dc.MoveTo(rcArrowBack.left, rcArrowBack.top + 1);
	dc.LineTo(rcArrowBack.left, rcArrowBack.bottom-1);
	dc.MoveTo(rcArrowBack.right-1, rcArrowBack.top+1);
	dc.LineTo(rcArrowBack.right-1, rcArrowBack.bottom-1);
	
	dc.SelectObject(&penArrow);
	dc.SelectObject(&brushArrow);
	
	pt[0].y = rcArrow.bottom;
	pt[1].y = rcArrow.top;
	pt[2].y = rcArrow.top;
	pt[0].x = rcArrow.left + (rcArrow.Width() / 2);
	pt[1].x = rcArrow.right - 1;
	pt[2].x = rcArrow.left;
	dc.Polygon(pt, 3);
	
	dc.SelectObject(pOldPen);
	dc.SelectObject(pOldBrush);
	
	if (m_hG == NULL || m_hG_DN == NULL || m_hG_EN == NULL || 
		m_hArrow == NULL || m_hArrow_DN == NULL || m_hArrow_EN == NULL)
		return;
	
	switch (m_nStateG)
	{
	case ST_GNORMAL:	hG = m_nSelectGroup == 0 ? m_hG : m_hG_S;		break;
	case ST_GDOWN:		hG = m_nSelectGroup == 0 ? m_hG_DN : m_hG_S_DN;	break;
	case ST_GOVER:
	default:			hG = m_nSelectGroup == 0 ? m_hG_EN : m_hG_S_EN;	break;
	}
	
	switch (m_nStateArrow)
	{
	case ST_ARROWNORMAL:	hArrow = m_hArrow;	break;
	case ST_ARROWDOWN:		hArrow = m_hArrow_DN;	break;
	case ST_ARROWOVER:
	default:				hArrow = m_hArrow_EN;	break;
	}
	
	CBitmap* pOldBitmap = dcMem.SelectObject(CBitmap::FromHandle(hG));
	dc.StretchBlt(rcButton.left, 0, m_szG.cx, rcButton.Height(), &dcMem, 0, 0, m_szG.cx, m_szG.cy, SRCCOPY);
	
	dcMem.SelectObject(CBitmap::FromHandle(hArrow));
	dc.StretchBlt(rcButton.left + m_szG.cx, 0, m_szArrow.cx, rcButton.Height(), &dcMem, 0, 0, m_szArrow.cx, m_szArrow.cy, SRCCOPY);
	
	

	dcMem.SelectObject(pOldBitmap);
}

void CAccountCtrl::SetButtonState(CPoint point, int nMouseState)
{
	if (nMouseState == MS_NORMAL)
	{
		m_nStateG = m_nStateArrow = nMouseState;
		Invalidate();
		return;
	}
	
	UINT nStateG, nStateArrow;
	
	CRect rc;
	GetClientRect(&rc);
	
	rc.left = rc.right - (m_szG.cx + m_szArrow.cx);
	rc.right = rc.left + m_szG.cx;
	
	if (rc.PtInRect(point))
	{
		nStateG = nMouseState;
		nStateArrow = ST_ARROWNORMAL;
		
		if (m_nStateG != nStateG || m_nStateArrow != nStateArrow)
		{
			m_nStateG = nStateG;
			m_nStateArrow = nStateArrow;
			Invalidate();
		}
		
		m_bMultiClick = FALSE;
	}
	else
	{
		rc.left = rc.right;
		rc.right = rc.left + m_szArrow.cx;
		
		if (rc.PtInRect(point))
		{
			nStateG = ST_GNORMAL;
			nStateArrow = nMouseState;
			
			if (m_nStateG != nStateG || m_nStateArrow != nStateArrow)
			{
				m_nStateG = nStateG;
				m_nStateArrow = nStateArrow;
				Invalidate();
			}
			
			if (nMouseState == MS_DOWN)
				m_bMultiClick = TRUE;
		}
		else
			m_bMultiClick = FALSE;
	}
}

void CAccountCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rcClient, rcArrow, rcList, rcGroup;
	GetClientRect(&rcClient);
	
	rcArrow = rcClient;
	rcArrow.right = rcArrow.right - (m_szG.cx + m_szArrow.cx) - CTRLGAP;
	rcArrow.DeflateRect(0, 3, 2, 3);
	rcArrow.left = rcArrow.right - rcArrow.Height();
	
	if (rcArrow.PtInRect(point))
		ShowAccountList(FALSE);
	else
	{
		SetButtonState(point, MS_DOWN);

		rcList = rcClient;
		rcList.left = rcList.right - m_szArrow.cx;

		rcGroup = rcList;
		rcGroup.right = rcList.left;
		rcGroup.left = rcGroup.right - m_szG.cx;

		if (rcList.PtInRect(point))
			ShowGroupList();
		else if (rcGroup.PtInRect(point))
			ShowAccountList(TRUE);
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CAccountCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rcButton;
	GetClientRect(&rcButton);
	rcButton.left = rcButton.right - (m_szG.cx + m_szArrow.cx);
	BOOL bIn = rcButton.PtInRect(point);

	if (!m_bTrackLeave && bIn) 
	{
         TRACKMOUSEEVENT tme;
         tme.cbSize = sizeof(tme);
         tme.hwndTrack = m_hWnd;
         tme.dwFlags = TME_LEAVE;
         _TrackMouseEvent(&tme);
         m_bTrackLeave = TRUE;
		 SetButtonState(point, MS_OVER);
    }
	else if (m_bTrackLeave && bIn)
	{
		CRect rc = rcButton;

		if (m_nStateG == ST_GOVER)
			rc.left = rc.right - m_szArrow.cx;
		else if (m_nStateArrow == ST_ARROWOVER)
			rc.right = rc.left + m_szG.cx;

		if (rc.PtInRect(point) && (m_nStateG == ST_GOVER || m_nStateArrow == ST_ARROWOVER))
			SetButtonState(point, MS_OVER);
	}
	else if (m_bTrackLeave && !bIn)
	{
		m_bTrackLeave = FALSE;
		SetButtonState(CPoint(0, 0), MS_NORMAL);
	}

	CWnd::OnMouseMove(nFlags, point);
}

LPARAM CAccountCtrl::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	m_bTrackLeave = FALSE;
	SetButtonState(CPoint(0, 0), MS_NORMAL);
	
	return 0;
}

void CAccountCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CRect rcButton;
	GetClientRect(&rcButton);
	rcButton.left = rcButton.right - (m_szG.cx + m_szArrow.cx);

	if (m_bTrackLeave && rcButton.PtInRect(point))
	{
		CRect rc = rcButton;
		SetButtonState(point, MS_OVER);
	}

	CWnd::OnLButtonUp(nFlags, point);
}

CString CAccountCtrl::Parser(CString &strSrc, CString strSub)
{
	CString strTemp(_T(""));

	if (strSrc.Find(strSub) == -1)
	{
		strTemp = strSrc;
		strSrc.Empty();
			return strTemp;
	}
	else
	{
		strTemp = strSrc.Left(strSrc.Find(strSub));
		strSrc = strSrc.Mid(strSrc.Find(strSub) + strSub.GetLength());
		return strTemp;
	}

	return _T("");
}

void CAccountCtrl::SetFont(CFont* pFont, BOOL bRedraw /* = TRUE */)
{
	CWnd::SetFont(pFont, bRedraw);

	m_pEdit->SetFont(pFont, bRedraw);
	m_pCombo->SetFont(pFont, bRedraw);

	CRect rcClient;
	GetClientRect(&rcClient);
	ResizeCtrl(rcClient.Width(), rcClient.Height());
}

BOOL CAccountCtrl::CreateFont()
{
	struct _fontR fontR;

	fontR.name = (LPSTR)(LPCTSTR)m_Param.fonts;
	fontR.point = m_Param.point;
	fontR.italic = false;
	fontR.bold = FW_NORMAL;

	m_pFont = (CFont*)m_pParent->SendMessage(WM_USER, MAKEWPARAM(getFONT, 0), (LPARAM)&fontR);

	return m_pFont == NULL ? FALSE : TRUE;
}

void CAccountCtrl::ShowAccountList(BOOL bGroup)
{
	//=====�����ü��ܸ� ���ӿ� ���̵��� ���
	if (((m_strUser[0] == ONLY_SISE) &&(IsNumber(m_strUser))) || onlysise == 1 || m_strUser == "##ibk9") return;



	CArray<CAccount*, CAccount*>* pArr = NULL;
	CAccount* pAcc = NULL;
	int nCount = 0;
	CString strItem(_T(""));

	if (bGroup)
	{
		if (m_nSelectGroup == 0)
			pArr = &m_arrAllAcc;
		else
		{
			if (m_pCombo->GetGroupKey() != m_nSelectGroup)
				LoadGroupAcc();

			pArr = &m_arrGroupAcc;
		}

		m_pCombo->SetGroupKey(m_nSelectGroup);
	}
	else
	{
		LoadHistoryAcc();
		pArr = &m_arrHistoryAcc;
	}

	m_pCombo->ResetContent();
	nCount = pArr->GetSize();
	
	for (int i = 0; i < nCount; i++)
	{
		pAcc = pArr->GetAt(i);
		strItem = pAcc->m_strAccntNum;
		strItem.Insert(ACC_DEPT, _T("-"));
		strItem.Insert(ACC_DEPT + ACC_TYPE + 1, _T("-"));
		strItem += TABSPACE;
		if (m_bUseAlias)
			strItem += pAcc->m_strAccntNick.IsEmpty() ? pAcc->m_strAccntName : pAcc->m_strAccntNick;//pAcc->m_strAccntName;
		else
			strItem += GetAcntTypeName(pAcc->m_strAccntNum.Mid(3,2))+pAcc->m_strAccntName;
		
		m_pCombo->AddString(strItem);
	}
	
	m_pCombo->SetGroupList(bGroup);

	if (m_pCombo->GetCount() == 0)
		m_pCombo->AddString(_T(""));

	m_pCombo->SetGroup(bGroup);
	m_pCombo->ShowDropDown();
}

void CAccountCtrl::ShowGroupList()
{
	if (((m_strUser[0] == ONLY_SISE) &&(IsNumber(m_strUser))) || onlysise == 1 || m_strUser == "##ibk9") return;
	CRect  rcGroupList;
	int nCount = 0;
	CGroup* pGroup;

	if (!m_pGroupList)
	{
		m_pGroupList = new CMenu;
		m_pGroupList->CreatePopupMenu();

		m_pGroupList->AppendMenu(MF_STRING, 0, "��ü");
		
		nCount = m_arrGroupList.GetSize();

		if (nCount > 0)
			m_pGroupList->AppendMenu(MF_SEPARATOR);

		for (int i = 0; i < nCount; i++)
		{
			pGroup = m_arrGroupList.GetAt(i);
			m_pGroupList->AppendMenu(MF_STRING, i + 1, (LPCTSTR)pGroup->m_strGrName);
		}
	}

	GetWindowRect (&rcGroupList);
	rcGroupList.left = rcGroupList.right - m_szArrow.cx;

	m_nSelectGroup = m_pGroupList->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD,
								rcGroupList.left, rcGroupList.bottom, this);

	Invalidate();
}

void CAccountCtrl::OnComboSelChange()
{
	CString strText(_T(""));
	int nIndex = m_pCombo->GetCurSel();

	if (nIndex == -1)
		return;

	m_pCombo->GetLBText(nIndex, strText);

	if (strText.IsEmpty())
		return;

	CAccount* pAcc = NULL;

	if (m_pCombo->GetGroup())
	{
		if (m_nSelectGroup == 0)
			pAcc = m_arrAllAcc.GetAt(nIndex);
		else
			pAcc = m_arrGroupAcc.GetAt(nIndex);
	}
	else
		pAcc = m_arrHistoryAcc.GetAt(nIndex);

	if (pAcc)
	{
		if (m_bUseAlias)
			m_strAccName = pAcc->m_strAccntNick.IsEmpty() ? pAcc->m_strAccntName : pAcc->m_strAccntNick;//pAcc->m_strAccntName;
		else
			m_strAccName = pAcc->m_strAccntName;

		PushAccHistory(pAcc->m_strAccntNum, pAcc->m_strPassword, m_strAccName);
	}
	
	if (!m_pEdit)
		return;

	if (!strText.IsEmpty())
		m_pEdit->SetInputData(strText);

	CString strAccount = m_pEdit->GetInputData();

	if (strAccount.GetLength() == 11)
		m_strPassword = GetPassword(strAccount);
	
	

	if (m_pParent && m_bInit)
	{
		m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange/*Change*/)), 
						(long)m_Param.name.operator LPCTSTR());
//		PushTab();
	}
	
	SaveHistory();
	SetFocus();
}

void CAccountCtrl::LoadHistoryAcc()
{
	m_arrHistoryAcc.RemoveAll();

	CString strPop = PopAccHistory();
	CString strData(_T(""));
	CAccount* pAcc = NULL;
	bool bfirst = false;

	while (!strPop.IsEmpty())
	{
		pAcc = new CAccount;
		strData = Parser(strPop, _T("|"));
	
		pAcc->m_strAccntNum = Parser(strData, _T("\t"));
		pAcc->m_strPassword = Parser(strData, _T("\t"));
		pAcc->m_strAccntName = Parser(strData, _T("\t"));

		pAcc->TrimData();

		if (!IsValidAcc(pAcc->m_strAccntNum, FALSE))
		{
			delete pAcc;
			continue;
		}
		/*
		if (!bfirst)
		{
			bfirst = true;
			//pAcc->m_strAccntNum;
			//MessageBox(pAcc->m_strAccntNum);
			m_pEdit->SetInputData(pAcc->m_strAccntNum);
			AccountInputComplete(pAcc->m_strAccntNum);
		}
		*/

		//   2008.07.22 �����
		//m_arrHistoryAcc.InsertAt(0, pAcc);
		m_arrHistoryAcc.Add(pAcc);
	}
}

void CAccountCtrl::PushAccHistory(CString strAcc, CString strPassword, CString strAccName)
{
	CString strData(_T(""));
	CString strPush(_T(""));
	CString strPop = PopAccHistory();
	CString strPushKey(_T(""));

	strPushKey.Format("%s%d", PP_SYM, m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, groupCCx), 0));
	strPushKey.TrimRight();

	strData.Format("%s\t%s\t%s\t%s|", strPushKey, strAcc, strPassword, strAccName);

	if (strPop.IsEmpty())
	{
		strPush = strData;
	}
	else
	{
		int nStartPos = strPop.Find((LPCTSTR)strAcc);
		int nEndPos = -1;

		if (nStartPos != -1)
		{
			nEndPos = strPop.Find(_T("|"), nStartPos);

			if (nEndPos != -1)
				strPop.Delete(nStartPos, nEndPos - nStartPos + 1);
		}

		strPush = strData + strPop;
	}

	Variant(pushCC, strPush);
}

CString CAccountCtrl::PopAccHistory()
{
	CString strPopKey(_T(""));

	strPopKey.Format("%s%d", PP_SYM, m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, groupCCx), 0));
	strPopKey.TrimRight();

	return Variant(popCC, strPopKey);
}

void CAccountCtrl::QueryGroupList()
{
	struct _gmid gmid;
	gmid.xflg = _T('1');
	sprintf(gmid.usrid, _T("%-12s"), m_strUser);
	sprintf(gmid.grec, _T("0000"));

	switch(m_nType)
	{
	case SEL_ST:
		gmid.sflag = '1';				// ���� ��ȸ
		break;
	case SEL_FU:
		gmid.sflag = '2';				// �����ɼ� ��ȸ
		break;
	default:							// ���� ������ �ܿ��� �׷���� ��������
		return;
	}

	CString strData((char*)&gmid, L_gmid);
	int ret = SendTR(_T("PIDOSETA"), NULL, strData, (BYTE)TRKEY_GROUP);
}

void CAccountCtrl::LoadGroupAcc()
{
	if (m_nSelectGroup == 0)
		return;

	m_arrGroupAcc.RemoveAll();

	CGroup* pGroup = m_arrGroupList.GetAt(m_nSelectGroup - 1);
	
//	int nCount = atoi((LPCTSTR)pGroup->m_strAccntCnt);
	int nCount = pGroup->m_arrAccount.GetSize();

	for (int i = 0; i < nCount; i++)
	{
		CAccount* pAcc = pGroup->m_arrAccount.GetAt(i);

		if (!pAcc->m_strAccntNum.IsEmpty())
			if (IsValidAcc(pAcc->m_strAccntNum))
				m_arrGroupAcc.Add(pAcc);
	}
}

BOOL CAccountCtrl::IsValidAcc(CString strAccount, BOOL bOrderCheck)
{
	if (!m_bOrderEnable && bOrderCheck)
		return FALSE;

	strAccount.Remove(_T('-'));
	strAccount.TrimLeft();
	strAccount.TrimRight();

	if (strAccount.IsEmpty() || strAccount.GetLength() != 11)
		return FALSE;

	BOOL bValid = FALSE;
	CString strType = strAccount.Mid(3, 2);
	int nCount = 0;

	nCount = m_arrAccType.GetSize();

	for (int i = 0; i < nCount; i++)
	{
		if (strType == m_arrAccType.GetAt(i))
		{
			bValid = TRUE;
			break;
		}
	}

	if (!bValid)
		return bValid;

	BOOL bList = FALSE;
	nCount = m_arrAllAcc.GetSize();
	CAccount* pAcc = NULL;

	for (i = 0; i < nCount; i++)
	{
		pAcc = m_arrAllAcc.GetAt(i);
		if (strAccount == pAcc->m_strAccntNum)
		{
			bList = TRUE;
			break;
		}
	}
	// ������ ��ȸ �μ� Ȥ�� ���� üũ
	CString strDept;
	if (m_bEditMode) //�����̶�� ������ȣ�޾ƿ�
	{
		strDept = Variant(deptCC);
		strDept.TrimLeft();
		strDept.TrimRight();
	}
	if (GetAllowAllAcc(strDept))  //��ü ��� ���� ����Ʈ üũ
	{
		if (strAccount.GetLength() >= 3 && strDept.GetLength() >= 3)
			bList = TRUE;
	}
	else if (m_bEditMode && m_bOrderEnable && !bList)	// �����̸鼭 ���� ���°� �ƴ� ���
	{
		// ������ �Է��� ���¸��� �μ��ڵ尡 �����ϸ� ���� ���°� �ƴϴ��� True
		
		if (strAccount.GetLength() >= 3 && strDept.GetLength() >= 3)
		{
			if (strAccount.Left(3) == strDept.Left(3))
				bList = TRUE;
		}
	}

	if (bValid && bList)
		return TRUE;
	else
		return FALSE;
}

void CAccountCtrl::SafeRemoveAccArray(CArray<CAccount*, CAccount*>* pArr)
{
	int nCount = pArr->GetSize();
	CAccount* pAcc = NULL;

	for(int i = 0; i < nCount; i++)
	{
		pAcc = pArr->GetAt(i);
		delete pAcc;
	}

	pArr->RemoveAll();
}

CString CAccountCtrl::GetPassword(CString strAccount)
{
	CString strPassword(_T(""));
	
	if (strAccount.GetLength() == 11)
		strPassword = Variant(passCC, strAccount);

	return strPassword;
}

void CAccountCtrl::AccountInputComplete(CString strAccount)
{
	if (strAccount.IsEmpty())
		return;
/*
	if (!IsValidAcc(strAccount, FALSE))
	{
		Variant(guideCC, "��ȿ���� ���� �����Դϴ�. �ٽ� �Է��Ͻʽÿ�.");
		m_pEdit->SetInputData(_T(""));
		m_pEdit->SetSel(0, -1);
		m_pEdit->SetFocus();
		return;
	}
*/
	if (strAccount.GetLength() == 11)
		m_strPassword = GetPassword(strAccount);
	else
		m_strPassword.Empty();

	if (m_pParent && m_bInit && m_bEditMode)
	{
		m_bFireEvent = TRUE;

		CAccount* pAcc = FindAccountInfo(strAccount, FALSE);

		if (pAcc == NULL || pAcc->m_strAccntName.IsEmpty())
		{
			QueryAccntName(strAccount);
			SetTimer(TT_QUERYACCNM, 10000, NULL);

			return;
		}

		m_strAccName = pAcc->m_strAccntName;
		
		PushAccHistory(strAccount, _T(""), m_strAccName);
	}

	m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange/*Change*/)), 
							(long)m_Param.name.operator LPCTSTR());
	SaveHistory();

//	PushTab();
}

CAccount* CAccountCtrl::FindAccountInfo(CString strAccount, BOOL bAll)
{
	CAccount* pAcc = NULL;
	CArray<CAccount*, CAccount*>* pArrAcc;

	pArrAcc = bAll ? &m_arrAllAcc : & m_arrHistoryAcc;

	int nCount = pArrAcc->GetSize();
		
	for (int i = 0; i < nCount; i++)
	{
		pAcc = pArrAcc->GetAt(i);
			
		if (pAcc->m_strAccntNum == strAccount)
			return pAcc;
	}

	return NULL;
}

LRESULT CAccountCtrl::OnMessage(WPARAM wParam, LPARAM lParam)
{
	int len = 0;
	int key = 0;

	switch(LOBYTE(LOWORD(wParam))) 
	{
	case DLL_INIT:
		/*
		if (!Initialize(FALSE))
		{
			TRACE("AccountCtrl Initialize Failed\n");
			return 0;
		}
		*/
		//SetTimer(TT_GETINIT, 500, NULL);
	case DLL_INB:
		{
			m_strRet = m_pEdit->GetInputData();
			if (m_pEdit)
				return (long)(LPCTSTR)m_strRet;
			return 0;
		}
		break;

	case DLL_OUB:
		
		if (HIWORD(wParam))
		{
				struct _gmod* gmod = (_gmod*)lParam;

				if (gmod->okgb == _T('Y'))
					ParseGroupList((char *)lParam);
				else if (gmod->okgb != _T('N'))
				{
					if (strlen((char *)lParam) == 11)
					{
						if (m_bInit)
							m_pEdit->SetInputData((char *)lParam);
						else
							m_strTempDomino = CString((char*)lParam);
					}
					else
						ParseAccntName((char *)lParam);
				}
		}


//			CString strData = (char *)lParam;
//			int nLength = strData.GetLength();
//			int n = L_ledgerH + L_IAccnm + L_OAccnm;
//
//			TRACE("%s\n", strData);
//			if (nLength == L_ledgerH + L_IAccnm + L_OAccnm)
//				
//			else
//			{
			
//			}

		break;

	case DLL_ALERT:
		break;
	case DLL_TRIGGER:
		{
			CString strTrigger((char*)lParam);
		}
		break;
	case DLL_DOMINO:
		{
			CString strDomino((char*)lParam);
		}
		break;
	case DLL_SETPAL:
		break;
	case DLL_GUIDE:
		break;
	case DLL_SETFONT:
	{
		m_Param.point = HIWORD(wParam);
		CString tmp = CString((char*)lParam);
		if (!tmp.IsEmpty())
			m_Param.fonts = tmp;
		Invalidate();
	}
	}



	return FALSE;
}

void CAccountCtrl::ParseGroupList(char* pBuf)
{
	struct _gmod* gmod = (_gmod*)pBuf;

	if (gmod->okgb != _T('Y'))
		return;

	int nGrec = atoi(CString(gmod->grec, sizeof(gmod->grec)));

	if (nGrec == 0)
		return;

	CString strTemp;
	int nAccCount = 0;
	pBuf += L_gmod;
	CString tmp;
	for (int i = 0; i < nGrec; i++)
	{
		_group* group = (_group *)pBuf;
		
		CGroup* gpSave = new CGroup();
		gpSave->m_strGroupID = CString(group->gpid, sizeof(group->gpid));
		gpSave->m_strGrSortNum = CString(group->seqn, sizeof(group->seqn));
		gpSave->m_strGrName = CString(group->gnam, sizeof(group->gnam));
		gpSave->m_strAccntCnt = CString(group->nrec, sizeof(group->nrec));
		nAccCount = atoi(gpSave->m_strAccntCnt);

		pBuf += L_group;
		for (int j = 0; j < nAccCount; j++)
		{
			_accn *accn = (_accn *)pBuf;
			
			CAccount *acSave = new CAccount;
			acSave->m_strSortNum = CString(accn->seqn, sizeof(accn->seqn));
			acSave->m_strAccntNum = CString(accn->accn, sizeof(accn->accn));
			acSave->m_strAccntName = CString(accn->acnm, sizeof(accn->acnm));
			strTemp = CString(accn->rate, sizeof(accn->rate));
			strTemp.TrimRight();
			acSave->m_strAllocRate.Format("%.f", atof(strTemp));
			acSave->m_strAccntNick = CString(accn->alis, sizeof(accn->alis));

			if (!m_bOrderEnable)
				acSave->m_strPassword = CString(accn->pass, sizeof(accn->pass));
			else
				acSave->m_strPassword = Variant(passCC, acSave->m_strAccntNum);

			acSave->m_strPriAcc = accn->prea;
			acSave->m_strAllocMulti =  CString(accn->multi, sizeof(accn->multi));

			acSave->TrimData();
			gpSave->m_arrAccount.Add(acSave);
			pBuf += L_accn;
		}

		gpSave->TrimData();
		m_arrGroupList.Add(gpSave);
	}
}

BOOL CAccountCtrl::SendTR(CString strName, BYTE type, CString strData, BYTE key)
{
	CString trData = "";
	
	struct _userTH udat;
	
	memset((void*)&udat, 0, sizeof(udat));	
	strcpy(udat.trc, strName);
	udat.stat = type | US_KEY;

	if (m_bDLL)
		udat.key = (BYTE)TRKEY_GROUP;
	else
	{
		udat.key = m_Param.key;

		trData = (BYTE)TRKEY_GROUP;
		trData += m_Param.name;
		trData += _T("\t");
	}

	trData += CString((char *)&udat, L_userTH);
	trData += strData;

	int nRet = m_pParent->SendMessage(WM_USER, MAKEWPARAM(invokeTRx, strData.GetLength()), (LPARAM)(LPCTSTR)trData);
	return nRet;
}

void CAccountCtrl::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == TT_INIT)
	{
		KillTimer(TT_INIT);
		m_bInit = TRUE;
		
		if (m_bOrderEnable)
			QueryGroupList();

		CString strUserPath;
		strUserPath.Format("%s\\user\\%s\\%s.ini", m_strRoot, Variant(nameCC), Variant(nameCC));

		CString strKey = m_Param.name;
		strKey.TrimLeft();
		strKey.TrimRight();
		
		char szHistory[10000] = { 0, };
		CString strHistory(_T(""));
		if (strKey.Find("AN2") == -1) strKey = "AN98";
		GetPrivateProfileString(_T("AccountHistory"), (LPCTSTR)strKey, _T(""), szHistory, 10000, (LPCTSTR)strUserPath);
		strHistory = szHistory;
		strHistory.TrimRight();
		strHistory.TrimLeft();
		
		CAccount* pAcc = NULL;
		int nPos = -1;
		
		CString strLastAcc(_T(""));
		CString strLastName(_T(""));
		CString strLastNick(_T(""));
		CString strLast(_T(""));
		
		if (!strHistory.IsEmpty())
		{
			while (!strHistory.IsEmpty())
			{
				strLast = Parser(strHistory, _T("\t"));
				strLastAcc = Parser(strLast, _T("|"));
				strLastName = Parser(strLast, _T("|"));
				strLastNick = Parser(strLast, _T("|"));
				
				//PushAccHistory(strLastAcc, _T(""), strLastName);
				AppendAccHistory(strLastAcc, _T(""), strLastName);
			}
		}
		
		


		LoadHistoryAcc();

		

		
		CString strAccount(_T(""));
		//MessageBox(strLastAcc);
		if (m_pEdit)
		{
			if (m_strTempDomino.IsEmpty())	// ���̳� �����Ͱ� �ִ��� Ȯ��
			{
				if (m_arrHistoryAcc.GetSize() > 0)
				{
					//pAcc = m_arrHistoryAcc.GetAt(m_arrHistoryAcc.GetSize()-1);
					//MessageBox(pAcc->m_strAccntNum);
					pAcc = m_arrHistoryAcc.GetAt(0);
				}
				else if (m_bOrderEnable && m_arrAllAcc.GetSize() > 0)
					pAcc = m_arrAllAcc.GetAt(0);
				
				if (pAcc)
					strAccount = pAcc->m_strAccntNum;
			}
			else
			{
				strAccount = m_strTempDomino;
			}
			CString  tmp;
			tmp.Format("%d, %s" ,m_arrHistoryAcc.GetSize()-1, strAccount);
			//MessageBox(tmp);
			m_pEdit->SetInputData(strAccount);
			AccountInputComplete(strAccount);
		}


		m_clrBorderColor = GetIndexColor(COLOR_BORDER);
//		m_clrForeColor = GetIndexColor(COLOR_FORE);
//		m_clrBackColor = GetIndexColor(COLOR_BACK);
		m_clrEditBackColor = GetIndexColor(COLOR_EDITBACK);

		CDC* pDC = m_pEdit->GetDC();
		pDC->SetTextColor(m_clrForeColor);
		ReleaseDC(pDC);

		Invalidate();
	}
	else if (nIDEvent == TT_QUERYACCNM)
	{
		KillTimer(TT_QUERYACCNM);

		if (m_strAccName.IsEmpty())
		{
			Variant(guideCC, "���¸� ��ȸ ����.  �����ڿ��� ���ǹٶ��ϴ�.");
			m_pEdit->SetInputData(_T(""));
			m_pEdit->SetSel(0, -1);
			m_pEdit->SetFocus();
		}
		else if (m_strAccName.Compare("NONAME!"))
		{
			m_strAccName = "";
			m_pEdit->SetInputData(_T(""));
			m_pEdit->SetSel(0, -1);
			m_pEdit->SetFocus();
		}
		else if (m_bFireEvent)
		{
			if (m_pEdit)
			{
				CString strAccount = m_pEdit->GetInputData();

				if (!strAccount.IsEmpty() && !m_strAccName.IsEmpty())
				{
					PushAccHistory(m_pEdit->GetInputData(), _T(""), m_strAccName);
				
					m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange/*Change*/)), 
						(long)m_Param.name.operator LPCTSTR());
					SaveHistory();

//					PushTab();
				}
			}
		}
	}
	else if(nIDEvent == TT_GETINIT)
	{
		/*
		KillTimer(TT_GETINIT);
		if (!Initialize(FALSE))
		{
			TRACE("AccountCtrl Initialize Failed\n");
			//return 0;
		}
		*/

	}

	CWnd::OnTimer(nIDEvent);
}

void CAccountCtrl::SetParam(_param *pParam)
{
	m_Param.key = pParam->key;
	m_Param.name = CString(pParam->name, pParam->name.GetLength());
	m_Param.rect = CRect(pParam->rect.left, pParam->rect.top, pParam->rect.right, pParam->rect.bottom);
	m_Param.fonts = CString(pParam->fonts, pParam->fonts.GetLength());
	m_Param.point = pParam->point;
	m_Param.style = pParam->style;
	m_clrForeColor = m_Param.tRGB = pParam->tRGB;
	m_clrBackColor = m_Param.pRGB = pParam->pRGB;
	m_Param.options = CString(pParam->options, pParam->options.GetLength());
}

CString CAccountCtrl::GetLedger(CString strTR, char chType, CString strSvcn, CString strLastKey /* = _T("") */)
{
	struct _ledgerH ledger;
	FillMemory(&ledger, L_ledgerH, ' ');

	switch (chType)
	{
	case 'I':
		chType = '2';	break;
	case 'U':
		chType = '3';	break;
	case 'D':
		chType = '4';	break;
	case 'Q':
	default:
		chType = '1';
	}

	m_pParent->SendMessage(WM_USER, ledgerDLL, (LPARAM)&ledger);

	if (!strLastKey.IsEmpty())
		CopyMemory(&ledger.next, strLastKey, strLastKey.GetLength());

	return CString((char*)&ledger, L_ledgerH);
}

void CAccountCtrl::QueryAccntName(CString strAccount)
{
	struct _ledgerH ledger;

	FillMemory(&ledger, L_ledgerH, ' ');

	m_pParent->SendMessage(WM_USER, ledgerDLL, (LPARAM)&ledger);
	
	CopyMemory(&ledger.svcd, _T("SACMQ902"), sizeof(ledger.svcd));
	CopyMemory(&ledger.usid, (LPCTSTR)m_strUser, m_strUser.GetLength());
	CopyMemory(&ledger.brno, strAccount.Left(ACC_DEPT), ACC_DEPT);
	CopyMemory(&ledger.rcnt, _T("0000"), sizeof(ledger.rcnt));
	
	ledger.fkey[0] = 'C';
	ledger.mkty[0] = '3';
	ledger.odrf[0] = '1';
	
	IACCNM iaccnm;
	FillMemory(&iaccnm, L_IAccnm, ' ');
	CopyMemory(&iaccnm.szIn, _T("00001"), sizeof(iaccnm.szIn));
	CopyMemory(&iaccnm.szAccount, (LPCTSTR)strAccount, strAccount.GetLength());

/*	struct _userTH udat;
	strcpy(udat.trc, _T("pibopbxq"));
	udat.key = m_Param.key;
	udat.stat = US_ENC | US_KEY;

	CString strData(_T(""));

	strData += TRKEY_ACCNTNAME;
	strData += m_Param.name;
	strData += _T("\t");
	strData += CString((char *)&udat, L_userTH);
	strData += CString((char*)&ledger, L_ledgerH);
	strData += CString((char*)&iaccnm, L_IAccnm);
*/
	struct _userTH udat;
	
	memset((void*)&udat, 0, sizeof(udat));
	strcpy(udat.trc, _T("pibopbxq"));
	udat.stat = US_ENC | US_KEY;

	CString strData(_T(""));

	if (m_bDLL)
		udat.key = (BYTE)TRKEY_ACCNTNAME;
	else
	{
		udat.key = m_Param.key;

		strData = (BYTE)TRKEY_ACCNTNAME;
		strData += m_Param.name;
		strData += _T("\t");
	}

	strData += CString((char *)&udat, L_userTH);
	strData += CString((char*)&ledger, L_ledgerH);
	strData += CString((char*)&iaccnm, L_IAccnm);

	m_strAccName.Empty();

	static int nCount = 0;
	nCount++;

	//TRACE("[Invoke Account Name %02d : %s\n", nCount, strData);

	m_pParent->SendMessage(WM_USER, MAKEWPARAM(invokeTRx, L_IAccnm + L_ledgerH), (LPARAM)(LPCTSTR)strData);
}

void CAccountCtrl::ParseAccntName(char *pBuf)
{
	CString strData = pBuf;
	CString Depth_Num;
	BOOL bSucc = TRUE;

	pBuf = pBuf + L_ledgerH + L_IAccnm;

	POACCNM oaccnm = (POACCNM)pBuf;
	m_strAccName = CString(oaccnm->szAccntNm, sizeof(oaccnm->szAccntNm));
	m_strAccName.TrimLeft();
	m_strAccName.TrimRight();
	Depth_Num = m_strAccName.Mid(0,3);
	
	if (!IsValidAccComplete(CString(oaccnm->szAccount, sizeof(oaccnm->szAccount)), Depth_Num, FALSE))
	{
		KillTimer(TT_QUERYACCNM);
		Variant(guideCC, "��ȿ���� ���� �����Դϴ�. �ٽ� �Է��Ͻʽÿ�.");
		m_pEdit->SetInputData(_T(""));
		m_pEdit->SetSel(0, -1);
		m_pEdit->SetFocus();
		m_strAccName.Empty();
		Invalidate(true);
		//m_strAccName = "NONAME!";
		return;
	}
	m_strAccName = m_strAccName.Mid(3);


	if (m_strAccName.IsEmpty())
	{
		m_pEdit->SetInputData(_T(""));
		m_pEdit->SetSel(0, -1);
		bSucc = FALSE;
	}

	m_bQueryName = TRUE;

	if (m_bFireEvent)
	{
		KillTimer(TT_QUERYACCNM);

		if (m_pEdit)
			PushAccHistory(m_pEdit->GetInputData(), _T(""), m_strAccName);

		m_pParent->SendMessage(WM_USER, MAKEWPARAM(eventDLL, MAKEWORD(m_Param.key, evOnChange/*Change*/)), 
							(long)m_Param.name.operator LPCTSTR());

//		if (bSucc)
//			PushTab();
	}
	SaveHistory();
	//TRACE("%s\n", oaccnm->szOut);
	//TRACE("%s\n", oaccnm->szAccount);
	//TRACE("%s\n", oaccnm->szAccntNm);
}

COLORREF CAccountCtrl::GetIndexColor(int nColor)
{
	if (nColor & 0x02000000)
		return nColor;

	return m_pParent->SendMessage(WM_USER, MAKEWPARAM(getPALETTE, 0), (LPARAM)nColor);
}

void CAccountCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CWnd::OnSetFocus(pOldWnd);
	
	if (pOldWnd != m_pEdit)
 		m_pEdit->SetFocus();
}

void CAccountCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CAccountCtrl::PushTab()
{
	SetFocus();
	m_pParent->PostMessage(WM_KEYDOWN, VK_TAB, 0);
}

void CAccountCtrl::SetAccountType()
{
	if (m_Param.name == _T("AN10"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("11"));
	}
	else if (m_Param.name == _T("AN30"))
	{
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
	}
	else if (m_Param.name == _T("AN11"))
		m_arrAccType.Add(_T("50"));
	else if (m_Param.name == _T("AN12"))
		m_arrAccType.Add(_T("51"));
	else if (m_Param.name == _T("AN13"))
		m_arrAccType.Add(_T("52"));
	else if (m_Param.name == _T("AN14"))
		m_arrAccType.Add(_T("60"));
	else if (m_Param.name == _T("AN15"))
		m_arrAccType.Add(_T("70"));
	else if (m_Param.name == _T("AN24"))
	{
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
	}
	else if (m_Param.name == _T("AN20"))
	{
		m_arrAccType.Add(_T("20"));
		m_arrAccType.Add(_T("21"));
	}
	else if (m_Param.name == _T("AN50"))
		m_arrAccType.Add(_T("53"));
	else if (m_Param.name == _T("AN99"))
		m_arrAccType.Add(_T("00"));
	else if (m_Param.name == _T("AN01"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("11"));
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
		m_arrAccType.Add(_T("50"));
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
		m_arrAccType.Add(_T("60"));
		m_arrAccType.Add(_T("70"));
	}
	else if (m_Param.name == _T("AN16"))
	{
		m_arrAccType.Add(_T("50"));
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
	}
	else if (m_Param.name == _T("AN17"))
	{
		m_arrAccType.Add(_T("60"));
		m_arrAccType.Add(_T("70"));
	}
	else if (m_Param.name == _T("AN21"))
		m_arrAccType.Add(_T("20"));
	else if (m_Param.name == _T("AN22"))
		m_arrAccType.Add(_T("21"));
	else if (m_Param.name == _T("AN19"))
		m_arrAccType.Add(_T("10"));
	else if (m_Param.name == _T("AN18"))
	{
		m_arrAccType.Add(_T("11"));
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("30"));
	}
	else if (m_Param.name == _T("AN31"))
		m_arrAccType.Add(_T("30"));
	else if (m_Param.name == _T("AN32"))
		m_arrAccType.Add(_T("31"));
	else if (m_Param.name == _T("AN33"))
		m_arrAccType.Add(_T("32"));
	else if (m_Param.name == _T("AN34"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
	}
	else if (m_Param.name == _T("AN35"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("52"));
	}
	else if (m_Param.name == _T("AN1A"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("11"));
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
	}
	else if (m_Param.name == _T("AN1B"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
	}
	else if (m_Param.name == _T("AN00"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("11"));
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
		m_arrAccType.Add(_T("50"));
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
		m_arrAccType.Add(_T("60"));
		m_arrAccType.Add(_T("70"));
		m_arrAccType.Add(_T("20"));
		m_arrAccType.Add(_T("21"));
		m_arrAccType.Add(_T("53"));
		m_arrAccType.Add(_T("00"));
	}
	else if (m_Param.name == _T("AN98"))
	{
		m_arrAccType.Add(_T("10"));
		m_arrAccType.Add(_T("11"));
		m_arrAccType.Add(_T("30"));
		m_arrAccType.Add(_T("31"));
		m_arrAccType.Add(_T("32"));
		m_arrAccType.Add(_T("50"));
		m_arrAccType.Add(_T("51"));
		m_arrAccType.Add(_T("52"));
		m_arrAccType.Add(_T("60"));
		m_arrAccType.Add(_T("70"));
		m_arrAccType.Add(_T("20"));
		m_arrAccType.Add(_T("21"));
		m_arrAccType.Add(_T("53"));
	}
}

void CAccountCtrl::OnDestroy() 
{
	CString strKey = m_Param.name;
	strKey.TrimLeft();
	strKey.TrimRight();

	CString strUserPath;
	strUserPath.Format("%s\\user\\%s\\%s.ini", m_strRoot, Variant(nameCC), Variant(nameCC));

	CAccount* pAcc = NULL;
	
	CString strSaveData(_T(""));
	CString strAccInfo(_T(""));

	LoadHistoryAcc();

	int nCount = m_arrHistoryAcc.GetSize();

	if (nCount == 0)
	{
		if (m_pEdit)
		{
			CString strAccount = m_pEdit->GetInputData();
			pAcc = FindAccountInfo(strAccount);

			if (pAcc)
				strSaveData.Format("%s|%s|%s", pAcc->m_strAccntNum, pAcc->m_strAccntName, pAcc->m_strAccntNick);
			else
				strSaveData.Format("%s|%s|", strAccount, m_strAccName);
		}
	}
	else
	{
		for (int i = 0; i < nCount; i++)
		{
			pAcc = m_arrHistoryAcc.GetAt(i);

			if (pAcc)
				strAccInfo.Format("%s|%s|%s", pAcc->m_strAccntNum, pAcc->m_strAccntName, pAcc->m_strAccntNick);

			if (i < nCount - 1)
				strAccInfo += _T("\t");

			strSaveData += strAccInfo;
		}
	}

	if (m_pTipCtrl)
	{
		delete m_pTipCtrl; 
		m_pTipCtrl = NULL;
	}
	if (strKey.Find("AN2") == -1) strKey = "AN98";
	WritePrivateProfileString(_T("AccountHistory"), (LPCTSTR)strKey, (LPCTSTR)strSaveData, (LPCTSTR)strUserPath);
	

	CWnd::OnDestroy();
}

void CAccountCtrl::SaveHistory()
{
	CString strKey = m_Param.name;
	strKey.TrimLeft();
	strKey.TrimRight();

	CString strUserPath;
	strUserPath.Format("%s\\user\\%s\\%s.ini", m_strRoot, Variant(nameCC), Variant(nameCC));

	CAccount* pAcc = NULL;
	
	CString strSaveData(_T(""));
	CString strAccInfo(_T(""));
	CString tmp(_T(""));

	LoadHistoryAcc();

	int nCount = m_arrHistoryAcc.GetSize();

	if (nCount == 0)
	{
		if (m_pEdit)
		{
			CString strAccount = m_pEdit->GetInputData();
			pAcc = FindAccountInfo(strAccount);

			if (pAcc)
			{
				if (strAccount.GetLength() == 11)
					strSaveData.Format("%s|%s|%s", pAcc->m_strAccntNum, pAcc->m_strAccntName, pAcc->m_strAccntNick);
			}
			else
			{
				if (strAccount.GetLength() == 11)
					strSaveData.Format("%s|%s|", strAccount, m_strAccName);
			}
		}
	}
	else
	{
		for (int i = 0; i < nCount; i++)
		{
			pAcc = m_arrHistoryAcc.GetAt(i);

			if (pAcc)
			{
				tmp = pAcc->m_strAccntNum;
				if (tmp.GetLength() != 11) continue;

				strAccInfo.Format("%s|%s|%s", pAcc->m_strAccntNum, pAcc->m_strAccntName, pAcc->m_strAccntNick);
			}
			if (i < nCount - 1)
				strAccInfo += _T("\t");

			strSaveData += strAccInfo;
		}
	}
	if (strKey.Find("AN2") == -1) strKey = "AN98";
	WritePrivateProfileString(_T("AccountHistory"), (LPCTSTR)strKey, (LPCTSTR)strSaveData, (LPCTSTR)strUserPath);
}

//������ ��ȸ ���� �������� üũ   2008.07.22 �߰���
BOOL CAccountCtrl::GetAllowAllAcc(CString dep)
{
	bool bRet =  false;
	int nCount = allow_depth.GetSize();
	CString tmp;
	for( int i=0; i<nCount; i++ )
	{
		tmp = allow_depth.GetAt(i);
		if (tmp == dep)
		{
			bRet = true;
			break;
		}
	}
	return bRet;
}

//�� ���� ���� �����μ� �ʱ�ȭ   2008.07.22 �߰���
void CAccountCtrl::InitAllowDepth()
{
	allow_depth.RemoveAll();
	allow_depth.Add("903");		//�����
	allow_depth.Add("908");		//����������
	allow_depth.Add("911");		//������������
	allow_depth.Add("914");		//�ع�������
	allow_depth.Add("915");		//������
	allow_depth.Add("916");		//�ݼ���
	//allow_depth.Add("812");		//���ο�����
	//allow_depth.Add("920");		//IT��ȹ��

}

//�ʱ�ȭ�� ��ȿ���� üũ   2008.07.22 �߰���
BOOL CAccountCtrl::IsFirstValidAcc(CString strAccount, BOOL bOrderCheck)
{
	if (!m_bOrderEnable && bOrderCheck)
		return FALSE;

	strAccount.Remove(_T('-'));
	strAccount.TrimLeft();
	strAccount.TrimRight();

	if (strAccount.IsEmpty() || strAccount.GetLength() != 11)
		return FALSE;

	BOOL bValid = FALSE;
	CString strType = strAccount.Mid(3, 2);
	int nCount = 0;

	nCount = m_arrAccType.GetSize();

	for (int i = 0; i < nCount; i++)
	{
		if (strType == m_arrAccType.GetAt(i))
		{
			bValid = TRUE;
			break;
		}
	}

	return bValid;

}

int CAccountCtrl::GetOnlySise()
{
/*	
	int vals = AfxGetApp()->GetProfileInt(WORKSTATION, "OnlySise", 4);
	CString str; str.Format("%d",vals);
	
	CWnd* m_main = AfxGetMainWnd();
	if(m_main == NULL) MessageBox("NULL");
*/
	
	HKEY hKey;
	
	//char strKeyPath[255];
	//unsigned char  Value;
	DWORD Value;
	Value = 0;
	/*
	#ifdef _DEBUG
		const char* defaultRegKey = "SOFTWARE\\IBK\\AXIS Workstation V03.00\\Workstation";
	#else  // _RELEASE
		const char* defaultRegKey = "SOFTWARE\\IBK��������MAC\\AXIS Workstation V03.00\\Workstation";
	#endif // _DEBUG
	*/
	//const char* defaultRegKey = "SOFTWARE\\IBK��������MAC\\AXIS Workstation V03.00\\Workstation";
	CWnd* m_main = AfxGetMainWnd();
	CString str_title;
	m_main->GetWindowText(str_title);
	CString tmp;

	if (str_title == "IBK����")
	{
		//MessageBox("Dev");
		tmp = "SOFTWARE\\IBK\\AXIS Workstation V03.00\\Workstation";
	}
	else
	{
		//MessageBox("Real");
		tmp = "SOFTWARE\\IBK��������MAC\\AXIS Workstation V03.00\\Workstation";
	}	
	
	//const char* defaultRegKey = "SOFTWARE\\IBK\\AXIS Workstation V03.00\\Workstation";
	
	//const char* defaultRegKey = "SOFTWARE\\IBK\\AXIS Workstation V03.00\\Workstation";
    //sprintf(strKeyPath, defaultRegKey);
	
	
	DWORD dwType = REG_DWORD;
	DWORD dwSize = sizeof(DWORD);
	if (RegOpenKeyEx(HKEY_CURRENT_USER, (CString)tmp, 0, KEY_READ,&hKey) == ERROR_SUCCESS)
    {
		
		if (RegQueryValueEx(hKey, "OnlySise",0, &dwType, (LPBYTE)&Value, &dwSize) == ERROR_SUCCESS) 
		{
/*				
			CString tmp;
			tmp.Format("OnlySise = [%d]",Value);
			MessageBox(tmp);
*/			
			return Value;
		}
		else
		{
/*			
			CString tmp;
			tmp.Format("OnlySise = [%d]",Value);
			MessageBox(tmp);
			MessageBox("Failed");
*/			
			return 0;
		}
		

	}
	else
		return 0;

	RegCloseKey(hKey);
	

    //return Value;
}

CFont* CAccountCtrl::getAxFont(CString fName, int point, int style)
{
	struct _fontR fontR;
	fontR.name = (LPSTR)fName.operator LPCTSTR();
	fontR.point = point;
	fontR.italic = false;
	fontR.bold = 0;
	switch(style)
	{
	case 0: // none
	case 1: // none
		break;
	case 2: // italic
		fontR.italic = true;
		break;
	case 3: // bold
		fontR.bold = FW_BOLD;
		break;
	case 4: // both
		fontR.italic = true;
		fontR.bold = FW_BOLD;
		break;
	}
	return (CFont*)m_pParent->SendMessage(WM_USER, getFONT, (long)&fontR);
}

void CAccountCtrl::AppendAccHistory(CString strAcc, CString strPassword, CString strAccName)
{
	CString strData(_T(""));
	CString strPush(_T(""));
	CString strPop = PopAccHistory();
	
	CString strPushKey(_T(""));

	strPushKey.Format("%s%d", PP_SYM, m_pParent->SendMessage(WM_USER, MAKEWPARAM(variantDLL, groupCCx), 0));
	strPushKey.TrimRight();

	strData.Format("%s\t%s\t%s|", strAcc, strPassword, strAccName);
	
	if (strPop.IsEmpty())
	{
		strPush = strData;
	}
	else
	{
		int nStartPos = strPop.Find((LPCTSTR)strAcc);
		int nEndPos = -1;

		if (nStartPos != -1)
		{
			nEndPos = strPop.Find(_T("|"), nStartPos);

			if (nEndPos != -1)
				strPop.Delete(nStartPos, nEndPos - nStartPos + 1);
		}

		strPush = strPop+strData;
	}
	//TRACE(strPush+"\n");

	strPush = strPushKey + "\t" + strPush;
	Variant(pushCC, strPush);
}

LRESULT CAccountCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	MSG msg;
	msg.hwnd = m_hWnd;
	msg.message = message;
	msg.wParam = wParam;
	msg.lParam = lParam;

	
	if (message >= WM_MOUSEFIRST && message <= WM_MOUSELAST)
	{

		unsigned int location = lParam;
		int x, y, tmp;
		x = location&0xFFFF;
		y = (location>>16)&0xFFFF;

		CRect rc;
		GetClientRect(&rc);
		
		if (m_pTipCtrl == NULL)
		{
			m_pTipCtrl = new CToolTipCtrl;
			m_pTipCtrl->Create(this);
		}
		CString strTip;
		tmp = rc.bottom-3;
		if ((x > 127))
		{
			strTip.Format("�׷� ���� ����Ʈ");
			m_pTipCtrl->AddTool(this, (LPCTSTR)strTip, &rc, GetDlgCtrlID());
			m_pTipCtrl->Activate(TRUE);
			m_pTipCtrl->RelayEvent(&msg);
		}
		else if ((x < 127) && (x >=125))
		{
			m_pTipCtrl->DelTool(this);
			m_pTipCtrl->Activate(FALSE);
		}
		else if ((x >= 105) && (x < 120))
		{
			strTip.Format("��ü ���� ����Ʈ");
			m_pTipCtrl->AddTool(this, (LPCTSTR)strTip, &rc, GetDlgCtrlID());
			m_pTipCtrl->Activate(TRUE);
			m_pTipCtrl->RelayEvent(&msg);
		}
		else if ((x < 105) && (x >=103))
		{
			m_pTipCtrl->DelTool(this);
			m_pTipCtrl->Activate(FALSE);
		}
		else if ((x < 103))
		{
			strTip.Format("������ ���� �����丮");
			m_pTipCtrl->AddTool(this, (LPCTSTR)strTip, &rc, GetDlgCtrlID());
			m_pTipCtrl->Activate(TRUE);
			m_pTipCtrl->RelayEvent(&msg);
			
		}
	}

/*
		}
		else
		{
			m_pTipCtrl->DelTool(this);
			m_pTipCtrl->Activate(FALSE);
		}
*/


	
	return CWnd::WindowProc(message, wParam, lParam);
}

BOOL CAccountCtrl::IsValidAccComplete(CString strAccount, CString depth, BOOL bOrderCheck)
{
	if (!m_bOrderEnable && bOrderCheck)
		return FALSE;

	strAccount.Remove(_T('-'));
	strAccount.TrimLeft();
	strAccount.TrimRight();
	
	if (strAccount.IsEmpty() || strAccount.GetLength() != 11)
		return FALSE;
	
	BOOL bValid = FALSE;
	CString strType = strAccount.Mid(3, 2);
	int nCount = 0;
	
	nCount = m_arrAccType.GetSize();
	
	for (int i = 0; i < nCount; i++)
	{
		if (strType == m_arrAccType.GetAt(i))
		{
			bValid = TRUE;
			break;
		}
	}
	
	if (!bValid)
		return bValid;
	
	BOOL bList = FALSE;
	nCount = m_arrAllAcc.GetSize();
	CAccount* pAcc = NULL;
	
	for (i = 0; i < nCount; i++)
	{
		pAcc = m_arrAllAcc.GetAt(i);
		if (strAccount == pAcc->m_strAccntNum)
		{
			bList = TRUE;
			break;
		}
	}
	// ������ ��ȸ �μ� Ȥ�� ���� üũ
	CString strDept;
	if (m_bEditMode) //�����̶�� ������ȣ�޾ƿ�
	{
		strDept = Variant(deptCC);
		strDept.TrimLeft();
		strDept.TrimRight();
	}
	if (GetAllowAllAcc(strDept))  //��ü ��� ���� ����Ʈ üũ
	{
		if (strAccount.GetLength() >= 3 && strDept.GetLength() >= 3)
			bList = TRUE;
	}
	else if (m_bEditMode && m_bOrderEnable && !bList)	// �����̸鼭 ���� ���°� �ƴ� ���
	{
		// ������ �Է��� ���¸��� �μ��ڵ尡 �����ϸ� ���� ���°� �ƴϴ��� True
		
		if (strAccount.GetLength() >= 3 && strDept.GetLength() >= 3)
		{
			if (strAccount.Left(3) == strDept.Left(3))
				bList = TRUE;
		}
	}
	//TRACE(strDept+" <==> "+depth);
	if ((bValid && bList) || (strDept == depth))
		return TRUE;
	else
		return FALSE;
}

bool CAccountCtrl::IsNumber(CString str)
{
    BOOL bRet = TRUE;
    int nLen = str.GetLength();
    for( int i=0 ; i < nLen ; ++i)
    {
        if( isdigit(str.GetAt(i)) == FALSE)
        {
            bRet = FALSE;
            break;
        }
    }
    return bRet;
}

CString CAccountCtrl::GetAcntTypeName(CString tp)
{
	CString ret="";
	tp.TrimLeft(); tp.TrimRight();
	if(tp.GetLength() != 2 || tp.IsEmpty()) return "";
	if(IsNumber(tp))
	{
		switch(atoi(tp))
		{
		case 0 :
			ret = "����    ";
			break;
		case 10 :
			ret = "��Ź    ";
			break;
		case 11 :
			ret = "ELW���� ";
			break;
		case 20 :
			ret = "�����ɼ�";
			break;
		case 21 :
			ret = "�ɼ�����";
			break;
		case 30 :
			ret = "�Ϲ�����";
			break;
		case 31 :
			ret = "��������";//"��������������";
			break;
		case 32 :
			ret = "��������";//"���ݿ����������";
			break;
		case 50 :
			ret = "�ڻ����";//"�ڻ��������";
			break;
		case 51 :
			ret = "CMA���� ";
			break;
		case 52 :
			ret = "RP����  ";
			break;
		case 53 :
			ret = "��������";
			break;	
		case 60 :
			ret = "WRAP    ";
			break;
		case 70 :
			ret = "��Ź    ";
			break;
		}
	}

	if (ret.GetLength()==4) 
	{

	}
	else if(IsDBCSLeadByte(ret[7])) ret = ret.Mid(0,8);
	else ret = ret.Mid(0, 7);
	
	CString tmp;
	for(int dd=1; dd<(10-ret.GetLength()); dd++)
	{
		tmp = tmp + " ";
	}	
	tmp = ret + tmp;
	//ret.Format("%s\t",ret);
	return tmp;
}
