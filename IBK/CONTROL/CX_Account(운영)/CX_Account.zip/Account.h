// Account.h: interface for the CAccount class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACCOUNT_H__A7C7BEFF_FEF6_4395_AE58_4BCD9FF310D5__INCLUDED_)
#define AFX_ACCOUNT_H__A7C7BEFF_FEF6_4395_AE58_4BCD9FF310D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAccount  
{
public:
	CString m_strPriAcc;		//��ǥ���±���
	CString m_strSortNum;		//�����Ϸù�ȣ
	CString m_strAccntNum;		//���¹�ȣ
	CString m_strAccntName;		//�����̸�
	CString	m_strPassword;		//���º��
	CString m_strAllocRate;		//��������
	CString	m_strAllocMulti;	//�¼�
	CString m_strAccntNick;		//���º�Ī
	BOOL	m_bDelegation;		//����
public:
	CAccount()
	{
		m_strPriAcc = _T("");
		m_strSortNum = _T("");
		m_strAccntNum = _T("");
		m_strAccntName = _T("");
		m_strPassword = _T("");
		m_strAllocRate = _T("");
		m_strAllocMulti = _T("");
		m_strAccntNick = _T("");
		m_bDelegation = FALSE;
	};
	
	CAccount(CAccount const &other)
	{
		Copy(other);
	};
	
	~CAccount() {}
	
	inline Copy(CAccount const &other)
	{
		m_strPriAcc = other.m_strPriAcc;
		m_strSortNum = other.m_strSortNum;
		m_strAccntNum = other.m_strAccntNum;
		m_strAccntName = other.m_strAccntName;
		m_strPassword = other.m_strPassword;
		m_strAllocRate = other.m_strAllocRate;
		m_strAllocMulti = other.m_strAllocMulti;
		m_strAccntNick = other.m_strAccntNick;
	};
	
	inline TrimData()
	{
		m_strPriAcc.TrimRight();
		m_strSortNum.TrimRight();
		m_strAccntNum.TrimRight();
		m_strAccntName.TrimRight();
		m_strPassword.TrimRight();
		m_strAllocRate.TrimRight();
		m_strAllocMulti.TrimRight();
		m_strAccntNick.TrimRight();
	}
};

#endif // !defined(AFX_ACCOUNT_H__A7C7BEFF_FEF6_4395_AE58_4BCD9FF310D5__INCLUDED_)
