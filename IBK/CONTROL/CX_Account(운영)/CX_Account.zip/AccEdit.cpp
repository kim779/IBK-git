// AccEdit.cpp : implementation file
//

#include "stdafx.h"
#include "CX_Account.h"
#include "AccEdit.h"
#include "AccountCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAccEdit

CAccEdit::CAccEdit()
	: m_bEditMode(TRUE)
{
}

CAccEdit::~CAccEdit()
{
}


BEGIN_MESSAGE_MAP(CAccEdit, COXMaskedEdit)
	//{{AFX_MSG_MAP(CAccEdit)
	ON_WM_CREATE()
	ON_WM_CHAR()
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
	ON_WM_SETFOCUS()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAccEdit message handlers

int CAccEdit::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (COXMaskedEdit::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	return 0;
}

void CAccEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (!m_bEditMode)
		return;
	
	COXMaskedEdit::OnChar(nChar, nRepCnt, nFlags);

	CString strAccount = GetInputData();
	
	strAccount.TrimLeft();
	strAccount.TrimRight();

	int nStart, nEnd;

	GetSel(nStart, nEnd);

	if ((strAccount.GetLength() == 11 && nStart == 13 && nEnd == 13) ||
		(strAccount.GetLength() == 11 && nChar == 0x0D))
		((CAccountCtrl*)GetParent())->AccountInputComplete(strAccount);
}

void CAccEdit::OnKillFocus(CWnd* pNewWnd) 
{
	COXMaskedEdit::OnKillFocus(pNewWnd);

	TRACE("%d\n", pNewWnd->GetSafeHwnd());
	
	CString strAccount = GetInputData();

	strAccount.TrimLeft();
	strAccount.TrimRight();

//	if (strAccount.GetLength() == 11)
//		((CAccountCtrl*)GetParent())->AccountInputComplete(strAccount);
}

void CAccEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == VK_TAB)
		((CAccountCtrl*)GetParent())->PushTab();

	if (!m_bEditMode)
		return;
	
	COXMaskedEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CAccEdit::OnSetFocus(CWnd* pOldWnd) 
{
	COXMaskedEdit::OnSetFocus(pOldWnd);
	
//	if (!m_bEditMode)
		SetSel(0, -1);
}

void CAccEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{	
	COXMaskedEdit::OnLButtonDown(nFlags, point);

	if (!m_bEditMode)
		SetSel(0, -1);
}
