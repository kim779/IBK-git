#if !defined(AFX_SISEWND_H__272490AF_159F_4D0C_9C9F_C5805935D3F8__INCLUDED_)
#define AFX_SISEWND_H__272490AF_159F_4D0C_9C9F_C5805935D3F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Common.h"
#include "grid/GridCtrl.h"
#include "AxisExt.h"

class CSiseWnd : public CGridCtrl, public CAxisExt
{
// Construction
public:
	CSiseWnd(CWnd *pParent);
	BOOL Create(const RECT& rect, CWnd* parent, UINT nID, DWORD dwStyle = WS_CHILD | WS_BORDER | WS_TABSTOP | WS_VISIBLE , DWORD dwExStyle = 0);
	void SetData(SiseData *psd);
	void SetRealData(RealData *rp);
	void SetRealData( DWORD* data );
	void Clear();
	void ChangeTheme();
protected:
	void SetSiseGrid();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSiseWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSiseWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSiseWnd)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnNcPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SISEWND_H__272490AF_159F_4D0C_9C9F_C5805935D3F8__INCLUDED_)
