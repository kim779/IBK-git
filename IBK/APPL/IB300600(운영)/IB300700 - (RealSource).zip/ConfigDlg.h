#if !defined(AFX_CONFIGDLG_H__C5BDAC0A_5CD2_45BB_A7D5_4BD5C9269F22__INCLUDED_)
#define AFX_CONFIGDLG_H__C5BDAC0A_5CD2_45BB_A7D5_4BD5C9269F22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AxisExt.h"

class CConfigDlg : public CDialog
{
public:
	CConfigDlg(CWnd* pParent, CString profile, CAxisExt *pAxisExt);   // standard constructor

public:
	CString m_profile;
	CAxisExt *m_pAxisExt;

	//{{AFX_DATA(CConfigDlg)
	enum { IDD = IDD_CONFIG_DLG };
	UINT	m_rsvd_width;
	UINT	m_jumn_width;
	UINT	m_size_width;
	UINT	m_remain_width;
	UINT	m_hoga_width;
	UINT	m_rate_width;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CConfigDlg)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnOdrConfirm();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGDLG_H__C5BDAC0A_5CD2_45BB_A7D5_4BD5C9269F22__INCLUDED_)
