//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IB191000.rc
//
#define IDD_DIALOG1                     1000
#define IDD_CONFIG_DLG                  1000
#define IDC_ODR_CONFIRM                 1000
#define IDC_SHOW_RATE                   1001
#define IDD_MULTI_DLG                   1001
#define IDC_SHOW_BEFORE                 1002
#define IDD_CONFIRM_DLG                 1002
#define IDC_SHOW_RSVD                   1003
#define IDD_ACCTCONFIRM_DLG             1003
#define IDC_SPACEORDER                  1004
#define IDD_DIALOG_MARKET               1004
#define IDC_EXTENTORDER                 1005
#define IDC_RCLICKCANCEL                1006
#define IDR_IB300500                    1007
#define IDC_ED_RSVD                     1007
#define IDR_IB191000                    1008
#define IDC_LIST_OWN                    1009
#define IDC_LIST_OWN2                   1010
#define IDC_STATIC_BOX                  1010
#define IDC_STATIC_CONF                 1011
#define IDC_CHECK_MARKET                1012
#define IDC_ED_JUMN                     1013
#define IDC_STATIC_CONF2                1013
#define IDC_ED_REMAIN                   1014
#define IDC_ED_SIZE                     1015
#define IDC_ED_HOGA                     1016
#define IDC_ED_RATE                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1005
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           1009
#endif
#endif
