// IB191000.h : main header file for the IB191000 DLL
//

#if !defined(AFX_IB191000_H__24DA0C26_416F_4DB2_90D3_B2AC215A9EB0__INCLUDED_)
#define AFX_IB191000_H__24DA0C26_416F_4DB2_90D3_B2AC215A9EB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "IB191000_i.h"

/////////////////////////////////////////////////////////////////////////////
// CIB191000App
// See IB191000.cpp for the implementation of this class
//

class CIB191000App : public CWinApp
{
public:
	CIB191000App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIB191000App)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIB191000App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL InitATL();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IB191000_H__24DA0C26_416F_4DB2_90D3_B2AC215A9EB0__INCLUDED_)
