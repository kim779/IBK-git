#if !defined(AFX_CODECTRL_H__E8738F3A_52EE_4B4D_A881_EFAE3E7AC903__INCLUDED_)
#define AFX_CODECTRL_H__E8738F3A_52EE_4B4D_A881_EFAE3E7AC903__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AxisExt.h"

class CCodeCtrl : public CWnd, public CAxisExt
{
// Construction
public:
	CCodeCtrl(CWnd *pParent, LPCSTR type, int key);
	CWnd *m_pCtrl;
	CString GetCode() { return GetCtrlProperty("Data"); }
	void    SetCode(LPCSTR code) { SetCtrlProperty("Data", _variant_t(code)); }
	CString GetName();

protected:
	void CreateControl();
	void ErrorBox( LPCSTR msg );
	void ChangeFont( LPCSTR font, int point );
	CString GetCtrlProperty( LPCSTR prop_name );
	void SetCtrlProperty( _bstr_t prop_name, _variant_t &var );
	
protected:
	LPCSTR m_type;
	int m_key;
	HINSTANCE m_hInst;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCodeCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCodeCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCodeCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnUser( WPARAM wParam, LPARAM lParam );
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODECTRL_H__E8738F3A_52EE_4B4D_A881_EFAE3E7AC903__INCLUDED_)
