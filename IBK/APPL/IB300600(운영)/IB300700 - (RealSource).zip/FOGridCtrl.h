#if !defined(AFX_FOGRIDCTRL_H__62EFBCBA_3900_4E9B_8F02_B3FE162F20C5__INCLUDED_)
#define AFX_FOGRIDCTRL_H__62EFBCBA_3900_4E9B_8F02_B3FE162F20C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Common.h"
#include "AxisExt.h"
#include "GridCtrlExt.h"
#include <map>
#include <set>

using namespace std;

#define COLUMN_SIZE		(10)
#define DEF_ROW_SIZE	(1000)

typedef enum {
	IDX_ASK_RSVD = 0,
	IDX_ASK_JUMUN,
	IDX_ASK_BEFORE,
	IDX_ASK_SIZE,
	IDX_HOGA,
	IDX_RATE,
	IDX_BID_SIZE,
	IDX_BID_BEFORE,
	IDX_BID_JUMUN,
	IDX_BID_RSVD
} FOGRID_IDX;

bool operator<(const CCellID &lsh, const CCellID &rsh);
bool operator<(CCellID &lsh, CCellID &rsh);

class CFOGridCtrl : public CGridCtrlExt, public CAxisExt
{
// Construction
public:
	CFOGridCtrl(CWnd *pParent);

public:
	void SetGridHeader();
	void SetGridBody();
	BOOL Create(const RECT& rect, CWnd* parent, UINT nID, DWORD dwStyle = WS_CHILD | WS_BORDER | WS_TABSTOP | WS_VISIBLE , DWORD dwExStyle = 0);
// Operations
public:
	int GetRequireWidth();
	void ShowRate(bool bShowRate);
	void ShowBefore(bool bShowBefore);
	void ShowRsvd(bool bShowRsvd);
	void SetData(SiseData *psd);
	void SetRealData(RealData *rp);
	void SetRealData( DWORD* data );
	void SetCurrToCenter();
	void SetMdgaToCenter();
	void Clear();
	void SetMicheg(PriceMichegMap *pmm);
	BOOL IsMouseOut() { return m_bOutMouse; }
	void CheckExpand();
	void SetHogaFix(BOOL bFixed);
	void SetWidths(int rsvd, int jumun, int cnt, int vol, int hoga, int rate);
	void GetWidths(int *rsvd, int *jumun, int *cnt, int *vol, int *hoga, int *rate);
	BOOL IsMarketOrder(CCellID id);

protected:
	int m_pdir;
	CCellID m_pid;
	COLORREF m_crNormalBk, m_crYellowBk;
	CCellID m_CurCell;
	bool m_bShowBefore, m_bShowRate, m_bShowRsvd, m_bExpandHoga;

	BOOL m_bOutMouse, m_bHogaFix;
	CRect m_rcClient;

	set<CCellID> m_JumnCells;
	int m_MdgaCell[MAX_FHOGA], m_MsgaCell[MAX_FHOGA];
	map<int, int> m_mapHogaRow;
	LOGFONT m_BLogFont;

	int m_HeadWidth[COLUMN_SIZE];
	LPCSTR m_HeadText[COLUMN_SIZE];
protected:
	SiseData *m_pSiseData;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOGridCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFOGridCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFOGridCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOGRIDCTRL_H__62EFBCBA_3900_4E9B_8F02_B3FE162F20C5__INCLUDED_)
