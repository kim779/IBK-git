#if !defined(AFX_AXWND_H__B65C2E7A_1A7A_4871_A94D_49D7BC0EF414__INCLUDED_)
#define AFX_AXWND_H__B65C2E7A_1A7A_4871_A94D_49D7BC0EF414__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../../h/axisfire.h"

class CAxisExt
{
public:
	CAxisExt(CWnd *pParent);

protected:
	CWnd *m_pParent;

public:
	int      Variant(int cmd, int data);
	LPCTSTR  Variant(int cmd, LPCTSTR data);
	CFont*   GetAxFont(LPCTSTR name, int point, bool italic, int bold);
	CBitmap* GetAxBitmap(LPCTSTR path);
	HBITMAP  GetAxHBitmap(LPCTSTR path);
	COLORREF GetIndexColor(int index);
	CPen*    GetAxPen(COLORREF clr, int width, int style);
	CBrush*  GetAxBrush(COLORREF clr);
	BOOL     SendTR(LPCSTR name, byte type, LPCSTR data, int dlen, int key);
public:
	virtual ~CAxisExt();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AXWND_H__B65C2E7A_1A7A_4871_A94D_49D7BC0EF414__INCLUDED_)
