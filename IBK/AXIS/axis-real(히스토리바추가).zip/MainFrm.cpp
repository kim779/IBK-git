// MainFrm.cpp : implementation of the CMainFrame class
//
#include "stdafx.h"
#include "axis.h"
#include "../h/ledger.h"
#include "comdef.h"
#include "mmsystem.h"

#include "MainFrm.h"
#include "childFrm.h"
#include "axisdoc.h"
#include "axisview.h"
#include "axscrollview.h"
#include "axtabview.h"
#include "Dtconnect.h"
#include "LogoDlg.h"
#include "axmsg.hxx"
#include "axMisc.h"
#include "GPop.h"
#include "MPop.h"
#include "fname.h"
#include "lockdlg.h"
#include "screendlg.h"
#include "ExitD.h"
#include "PrinterSettings.h"
#include "conclusion.h"
#include "econclusion.h"
#include "KobaElwNotify.h"
#include "ManageInfo.h"
#include "alarm.h"
#include "ndib.h"
#include "NPalette.h"
#include "passdlg.h"
#include "Chaser.h"
#include "NClock.h"
#include "Infofile.h"
#include "SChild.h"
#include "ProgramDlg.h"
#include "AccTool.h"
#include "AccSave.h"
#include "NewsViewer.h"
#include "Stoploss.h"
#include "TTip.h"
#include "HelpOK.h"
#include "StopWarn.h"
#include "SUiPreDef.h"
#include "dtInfo.h"
#include "dlgMisuAlarm.h"
#include "sysInfo.h"
#include "TestInfoDlg.h"
#include "BkWnd.h"
#include "trsmain.h"
#include "Info_Interest.h"
#include "SecureDlg.h"
//#include "PhonePad.h"
// custom toolbar include
#include "Wininet.h"
#include "APIHookEx.h"
#include "ImageNotice.h"

#include "../dll/sm/smheader.h"
#include "../dll/sm/TransparentMgr.h"
#include "../dll/axiscp/cpheader.h"
#include "XZip.h"
#include "XUnzip.h"

#include <io.h>
#include <math.h>
#include <fcntl.h>
#include <winspool.h>
#include <Windows.h>
#include <winuser.h>
#include <windef.h>
#define COMPILE_MULTIMON_STUBS
#include "multimon.h"
#include <Tlhelp32.h>		// process���
#include <WinAble.h>
#include <afxinet.h>
#include <uxtheme.h>
//#include <Vsstyle.h>
//#include <Vssym32.h>
//** macho add begin
#include "Helper.h"
#include "AccountConfig.h"
#include "MapHelper.h"
#include "DuplicateLoginConfirmDlg.h"

#include "EmpPassChangeDlg.h"
#include "EmpPassChangeNotifyDlg.h"
//** macho add end

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static CRect	g_monRc(0, 0, 0, 0);
static CMainFrame* m_pMain = NULL;


#pragma	comment(lib, "Winmm.lib")
#pragma	comment(lib, "SUiPre.lib")

//** macho begin 2008-03-20
#define CALLCENTER1		"(IBK hot Line : 1588-0030, 1544-0050)"
#define CALLCENTER2		"(IBK hot Line : 1544-0050, 1588-0030)"
#define IBK_HOME_URL	"www.ibks.com"
#define IDC_BTN_LOGO    12345
#define SDIHEIGHT	84//79
#define SETUPFILE	"axisensetup.ini"
#define TICKSETUP	"axisticker.ini"
#define MAXARRAY	1000
#define	dnACTION	2
#define saveFILE "portfolio.ini"
#define tempFILE "portfolio.ini.tmp"

#define	UPMAXSIZE	1024*16
#define TM_DNINTEREST 9050
#define TM_SLIDE	9051

const char* CBTN_CLOSE	= "â�ݱ�";
const char* CBTN_MAX	= "�ִ�ȭ";
const char* CBTN_MIN	= "�ּ�ȭ";
const char* CBTN_RESTORE= "â����";

//** macho end

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
#define WM_NCMOUSELEAVE		0x02A2
#define WM_REFRESH813		WM_USER+2428
#define WM_SECUREDLG		WM_USER+2429

void WriteLog( LPCSTR log, ... )
{
#if 0
	FILE *fp = fopen( Axis::home + "\\exe\\axis.log", "a+");
	if (!fp) return;
	
	CTime time = CTime::GetCurrentTime();
	fprintf(fp, (LPCSTR)time.Format("[%Y-%m-%d %H:%M:%S] "));
	
	va_list argptr;
	va_start(argptr, log);
	vfprintf(fp, log, argptr);
	va_end(argptr);
	fprintf(fp, "\n");
	
	fclose(fp);
#endif
}

BOOL DeleteDirectory( LPCTSTR lpDirPath )
{
	if( lpDirPath == NULL )
		return FALSE;
	
	BOOL bRval = FALSE;
	int nRval = 0;
	CString szNextDirPath = _T("");
	CString szRoot = _T("");
	CFileFind find;
	
	// ������ ���� �ϴ� �� Ȯ�� �˻�
	bRval = find.FindFile( lpDirPath );
	
	if( bRval == FALSE )
		return bRval;
	
	while( bRval )
	{
		bRval = find.FindNextFile();
		
		if( find.IsDots() == TRUE )
			continue;
		
		if( find.IsDirectory() )
		{
			szNextDirPath.Format(_T("%s\\*.*") , find.GetFilePath() );
			DeleteDirectory( szNextDirPath );
		}
		else
		{
			::DeleteFile( find.GetFilePath() );
		}
	}
	szRoot = find.GetRoot();
	find.Close();
	bRval = RemoveDirectory( szRoot );         	
	return bRval;
}

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_NCACTIVATE()
	ON_WM_NCPAINT()
	ON_WM_MEASUREITEM()
	ON_WM_ACTIVATE()
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
	ON_WM_NCCALCSIZE()
	ON_WM_NCHITTEST()
	ON_WM_GETMINMAXINFO()
	ON_WM_COPYDATA()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(ID_APP_BASE, ID_APP_END, OnAppDummy)
	ON_COMMAND_RANGE(ID_MENU_BASE, ID_MENU_END, OnAppDummy)
	ON_UPDATE_COMMAND_UI_RANGE(ID_APP_BASE, ID_APP_END, OnUpdateRunCommand)
	ON_MESSAGE(WM_AXIS, OnAXIS)
	ON_MESSAGE(WM_USER, OnUSER)
	ON_MESSAGE(WM_CHILDMSG, OnCHILDMSG)
	ON_MESSAGE(WM_CHASER, OnCHASER)
	ON_MESSAGE(WM_ELOG, OnELOG)
	ON_MESSAGE(WM_TRAYEVENT, OnTrayEvent)
	ON_MESSAGE(WM_APPLYACC, OnApplyACC)
	ON_MESSAGE(WM_SAVEACC, OnSaveACC)
	ON_MESSAGE(WM_AXISCLOSE, OnAxisClose)
	ON_MESSAGE(WM_PHONEPAD, OnPhonePad)
	ON_MESSAGE(WM_REFRESH813, OnRefresh813)
	ON_MESSAGE(WM_SECUREDLG, OnSecureDlg)
	ON_MESSAGE(WM_HOTKEY, OnHotKey)
	ON_MESSAGE(WM_SECURETOOLS, OnSecureChange)
	ON_MESSAGE(WD_MINICLOSE, OnMiniClose)
	ON_MESSAGE(WD_HTSCLOSEFORMINI, OnHTSCloseFMini)
	ON_MESSAGE(WX_HOTTRADE, OnHotTrade)
END_MESSAGE_MAP()

BEGIN_EVENTSINK_MAP(CMainFrame, CFrameWnd)
	//{{AFX_EVENTSINK_MAP(CFrameWnd)
	ON_EVENT(CMainFrame, -1, 1, OnFireRec, VTS_I4 VTS_I4 VTS_I4)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

BOOL CALLBACK MyInfoEnumProc(HMONITOR hMonitor,  HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData)
{
	MONITORINFO lpmi ;
	memset(&lpmi,0,sizeof(MONITORINFO));
	lpmi.cbSize = sizeof(MONITORINFO);
	if(!GetMonitorInfo(hMonitor,  &lpmi ))
		return FALSE;

	if (g_monRc.left  > lpmi.rcWork.left)	g_monRc.left   = lpmi.rcWork.left;
	if (g_monRc.top   > lpmi.rcWork.top)	g_monRc.top    = lpmi.rcWork.top;
	if (g_monRc.right < lpmi.rcWork.right)	g_monRc.right  = lpmi.rcWork.right;
	if (g_monRc.bottom< lpmi.rcWork.bottom)	g_monRc.bottom = lpmi.rcWork.bottom;
	return TRUE;
}

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode == HC_ACTION)
	{
		MSG*	msg = (MSG *) lParam;
		switch (msg->message)
		{
		case WM_LBUTTONDOWN:
			m_pMain->HideGuide();
		case WM_KEYDOWN:
		case WM_KEYUP:			
		case WM_MOUSEMOVE:
		case WM_MBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_MBUTTONUP:
		case WM_RBUTTONUP:
			if (!m_pMain->m_block)
			{
				if (m_pMain->m_idletime > 0)
				{
					m_pMain->KillTimer(TM_IDLE);
					m_pMain->SetTimer(TM_IDLE, m_pMain->m_idletime*60000, NULL);
				}
			}
			break;
		}

		int	index = 0;
		switch (msg->message)
		{
		case WM_KEYDOWN:
			if (msg->wParam == VK_RETURN)
			{
				if (!(msg->lParam & 0x1000000))	// center enter key
				{
					if (m_pMain->TransKey(msg->wParam))
						return TRUE;
				}
			}
			if (msg->wParam == VK_TAB && (GetKeyState(VK_CONTROL) & 0x8000))
			{
				//m_pMain->MDINextChild();
				return TRUE;
			}
			if (msg->wParam == VK_F8/*byte('P')*/ && (GetKeyState(VK_CONTROL) & 0x8000))
			{
				//m_pMain->update_ticker(0,"S0000	047	1	014	506727	048	20100527	301	 	015	���� �ѹ� ��ǥ `�̴��� ����ѱ���` ����                                                                                 	016	20100527110009    273724	041	13	042	9	044	173339	022	 	045	�ι�/����	046	�췲	");
				//���е���� ��й�ȣ �о��
				if(!Axis::isCustomer)
				{	
					
					//m_pMain->ReadPhonePad(0);
					m_pMain->RunPhonePad();
					/*
					if (!m_pMain->m_phone_dlgs)
					{
						m_pMain->m_phone_dlgs = new CPhonePad(NULL);
						m_pMain->m_phone_dlgs->DoModal();
						m_pMain->m_phone_dlgs = NULL;
					}
					*/
					
					return TRUE;
				}
			}
			break;
		case WM_SYSKEYDOWN:
			switch (msg->wParam)
			{
			case 49:case 50:case 51:case 52:case 53:case 54:
				if (!(GetKeyState(VK_MENU) & 0x8000))	
					break;
				m_pMain->Change_VsKey(msg->wParam - 49);
				return TRUE;
			}
			break;
		default:
			break;
		}
	}
	return CallNextHookEx(m_pMain->m_hHook, nCode, wParam, lParam);
}

// protect input for check readding 
LRESULT CALLBACK viewProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	CView* view = (CView *)GetWindowLong(hwnd, GWL_USERDATA);
	if (view == NULL)	return 0;
	switch (msg)
	{
		// for check reader
	case WM_KEYUP: case WM_KEYDOWN: case WM_CHAR:
		if (m_pMain->m_view)	
			return TRUE;
		break;
	}

	return ::CallWindowProc((long (__stdcall *)(HWND, UINT, WPARAM, LPARAM))m_pMain->m_callproc, hwnd, msg, wParam, lParam);
}

bool axiscall(int msg, WPARAM wParam, LPARAM lParam)
{
	if (m_pMain == (CMainFrame *) 0) return false;
	//TRACE("[%d]\n",msg);
	CString		tmpS;
	switch (msg)
	{
	case AXI_CHANGEVIEW:	
		//OutputDebugString("AXI_CHANGEVIEW\n");
		return (m_pMain->m_mapHelper->ChangeChild((char *)lParam, TRIGGERN, wParam) 
									? true : false);
	case AXI_SETACCOUNT:		
		return (m_pMain->SetToolAccount((char *)lParam, wParam) 
									? true : false);
	case AXI_CHANGEPOPUP:		
		return m_pMain->m_mapHelper->CreatePopup((char *)lParam, TRIGGERN, winK_POPUP, 
			1, 0, CPoint(-1, -1), false)
									? true : false;
	case AXI_SELCLIST:			return m_pMain->select_SName((char *)lParam);
	case AXI_CHANGEFOCUS:	
		{
			int nFlag = (int)lParam;

			if(nFlag == 0)
				m_pMain->Setfocus_Child(wParam);
			else
				m_pMain->Setfocus_Child(wParam,TRUE);
		}
		break;
	case AXI_ACTIVEMAP:			break;
	case AXI_SHOWHELP:	
		m_pMain->m_helpKey = (int) wParam;
		m_pMain->PostMessage(WM_AXIS, MAKEWPARAM(axSHOWHELP, 0), 0);
		break;
	case AXI_APPSWITCH:	m_pMain->AppSwitch();			break;
	case AXI_NEWSLIST:	m_pMain->show_Newslist(wParam, lParam);	break;
	case AXI_CHANGEBAR2:
		if (!wParam)	
			m_pMain->change_Skin();
		else		
			m_pMain->change_VirtualScreen((int) lParam);
		break;
	case AXI_SETTRIGGER:		m_pMain->set_Trigger((int) wParam, (int) lParam);	break;
	case AXI_RESTORE:			m_pMain->restore((int) wParam);		break;
	case AXI_HOTKEY:			return m_pMain->HotKey(wParam, lParam);
	case AXI_CONSEE:			m_pMain->process_ConSee((int) lParam);	break;
	case AXI_SMCALL:			m_pMain->SmCall((int) lParam);		break;
	case AXI_FUNCKEY:			m_pMain->funcKey(LOWORD(wParam), (int) lParam);		break;
	case AXI_TABCHANGE:
		m_pMain->ChangeTabView((LPCSTR)lParam, (int)wParam);
		break;
	case AXI_SHOWDEAL:			m_pMain->ShowConclusion();		break;
	case AXI_BAR2ACTION:		m_pMain->Action(wParam, lParam);	break;
	case AXI_SETALL:			m_pMain->childAll((char *) lParam);	break;
	case AXI_GETMAPNUM:			m_pMain->GetDispN((char *) lParam);	break;
	case AXI_APPENDALLMAP:		m_pMain->AppendAllMap();		break;
	case AXI_SENDTICKINFO:		m_pMain->sendTicInfo();			break;		// lwj 2007.09.10 ƼĿ ����ȸ�� ����
	case AXI_INPUTSCREENNO:		return m_pMain->InputScreenNo((char *)lParam) ? true : false;
	case AXI_EDITUSERTOOL:		m_pMain->EditTool();			break;
	case AXI_TICKSETUP:			m_pMain->SetTicker();			break;
	case AXI_GETCAPTIONINFO:	m_pMain->GetCaptionInfo(wParam, lParam);break;
	case AXI_HIDECAPTIONBUTTON:	m_pMain->HideChildButton((int) lParam);		break;
	case AXI_EACHTICKER:		m_pMain->SettingEticker((int) lParam);	break;
	case AXI_LINKOPEN:			m_pMain->LinkOPEN((int) wParam, (char *) lParam);	break;
	case AXI_STOPLOSS:			m_pMain->StopLoss();			break;
	case AXI_FOSTOPLOSS:		m_pMain->FOStopLoss();			break;
	case AXI_HELPCOM:			m_pMain->RunHelpCom();			break;
	case AXI_REPORT:			m_pMain->ErrReport("����� ��ֽŰ�");	break;
	case AXI_CLOSECHILD:
		if (lParam) // ����â ���� ���â �ݱ��� ���
		{
			m_pMain->Setfocus_Child(wParam); 
			m_pMain->m_mapHelper->closeAllWithoutThis();  //** ����â�� ������ ��� â �ݱ�.
		}
		else
		{
			m_pMain->m_mapHelper->closeChild((int) wParam);	// cej
		}
		break;
	case AXI_CLOSESCREEN:		m_pMain->DeleteAllScreen(false);	break;		// cej
	case AXI_MINIMIZESCREEN:
		{
			//AfxMessageBox("Minimize All");
			m_pMain->m_mapHelper->minimizeAll(false);
		}
		break;
	case AXI_CUSTOMER:			return m_pMain->m_bCustomer;		break;		// cej
	case AXI_SHOWTICKER:		m_pMain->show_Ticker(lParam);		
		break;
	case AXI_HIDETICKER:		m_pMain->hide_Ticker(lParam);
		break;
	case AXI_PRINTSCREEN:		m_pMain->SendMessage(WM_COMMAND, ID_APP_PRINT, 0);	break;
	case AXI_GETVOIDRECT:		m_pMain->VoidRect((CRect*)lParam);			break;
	case AXI_MDINEXT:			m_pMain->MDINextChild();		break;
	case AXI_LASTMAPS:			m_pMain->SetLastMaps((char*)wParam, (char*)lParam);	break;
	case AXI_GETSCRBUTTONPOS:	m_pMain->GetScrButtonPos((int)wParam, (LPRECT)lParam); break;
	case AXI_RECALCLAYOUT:		m_pMain->RecalcFrame();
	case AXI_ROTATEVIEW:		m_pMain->RotateView((int)lParam);
	case AXI_CHANGETRIGGER:		m_pMain->SendTrigger((char*)wParam); break;
	case AXI_DELHISTORY	:		m_pMain->deleteHistory((char*)wParam); break;
	case AXI_DELHISTORYALL:		m_pMain->deleteAllHistory(); break;

		default:				break;
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_pMain				= (CMainFrame *) 0;
	m_resourceHelper	= ResourceHelper();
	m_mapHelper			= new CMapHelper(this);
	m_axConnect = NULL;
	m_logodlg = NULL;
	m_TotalAcc = NULL;

	srand( (unsigned)time( NULL ) );
	m_rndkey = rand();
	
	m_preFontSize = 0;
	bBackFont     = false;
	
	m_hjcode.RemoveAll();
	m_fjcode.RemoveAll();
	m_ojcode.RemoveAll();
	m_pjcode.RemoveAll();
	m_upcode.RemoveAll();
	m_elwbase.RemoveAll();

	loadingHJcode();
	loadingFJcode();
	loadingOJcode();
	loadingPJcode();
	loadingUPcode();
	loadingELWcode();
	
	// �ٸ�ID�� ������, 20060117
	m_bReconnect = false;

	m_hMRadar	= NULL;
	m_mapN		= _T("");
	m_update	= false;
	m_fullmode	= false;
	m_bExit		= true;
	m_runAxis	= false;
	m_noActive	= true;
	m_block		= false;
	m_forceClose	= false;
	m_bSDI		= false;
	m_saveALLVS	= true;
	//m_saveALLVS	= false;
	m_blinkbar	= true;
	m_bCustomer	= true;
	m_bSound	= false;
	m_activeCap	= FALSE;
	m_nInfoPos      = 2;
	m_bDelayIn	= false;
	m_sLastMapInfo.Empty();
	m_sDelayData.Empty();
	m_nDelayPeak	= 0;

	m_bHome = m_bEnd = TRUE;
	m_bdnInterest = true;

	m_maxChild	= 16;
	m_fontSize	= 9;

	m_idletime	= 0;
	m_posChild	= 0;
	m_toolStatus	= 0;
	m_SDIHEIGHT	= 0;
	m_activeKey	= 0;
	m_downI		= -1;
	m_appMode	= MODE_MDI;
	m_nBkMode	= BKMODE_NORMAL;

	m_conKIND	= CON_NONE;
	m_conHISTORY	= 0;
	m_conAUTOTIME	= 0;
	for (int ii = 0; ii < MAXSOUND; ii++)
		m_waveF[ii]   = _T("");
	
	m_connectBy	= byNONE;
	m_step		= axNONE;

	m_vsN		= V_SCREEN1;
	m_axis		= AfxGetApp();
	Axis::home		= m_axis->GetProfileString(ENVIRONMENT, ROOTDIR);
	int	position= m_axis->GetProfileInt(ENVIRONMENT, CHILDPOS, 0);

	//**Axis::isCustomer = m_axis->GetProfileInt(WORKSTATION, "cust", 0); // 0: employee 1: customer

	m_regkey	= ((CAxisApp*)m_axis)->m_regkey;
	m_axMisc	= new CAxMisc(Axis::home, m_regkey);
	m_axGuide	= new CAxGuide(LOWORD(position), Axis::home);
	m_MClient	= new CMDIClient(axiscall);
	m_wizard	= NULL;
	m_tMenu		= NULL;
	m_bar0		= NULL;
	m_bar1		= NULL;
	m_bar2		= NULL;
	m_bar3		= NULL;
	m_tInfo1	= NULL;
	m_tInfo2	= NULL;
	m_tInfo3	= NULL;
	m_smain		= NULL;
	m_sdibar	= NULL;
	m_axConnect	= NULL;
	m_logodlg   = NULL;
	m_TotalAcc	= NULL;
	m_modal		= NULL;
	m_WBWnd		= NULL;
	m_hHook		= NULL;
	m_view		= NULL;
	m_conclusion	= NULL;
	m_kobanotify	= NULL;
	m_Econclusion	= NULL;
	m_mngInfo	= NULL;
	m_smcall	= NULL;
	m_Nclock	= NULL;
	m_infofile	= NULL;
	m_wb		= NULL;
	m_chaser	= NULL;
	m_accTool	= NULL;
	m_accSave	= NULL;
	m_category	= NULL;
	m_newsviewer	= NULL;
	m_stoploss	= NULL;
	m_foStoploss	= NULL;
	m_tip		= NULL;
	m_misuAlarm	= NULL;
	m_pDoctor	= NULL;
	m_info_interest = NULL;
	m_EmpPassChangeDlg = NULL;

	m_printsetup = new CPrinterSettings();
	m_printsetup->CopyDefaultMfcPrinter();
	m_tabviewlist.RemoveAll();
	m_waitlist.RemoveAll();

	for (ii = V_SCREEN1; ii <= V_SCREEN6; ii++)	m_hooklist[ii].RemoveAll();
	for (ii = V_SCREEN1; ii <= V_SCREEN6; ii++)	m_sdiZORDER[ii].RemoveAll();
	m_progK = ((CAxisApp *) m_axis)->m_progK;

	/**
	if (((CAxisApp *) m_axis)->m_mode == MD_DEV)	m_dev = true;
	if (((CAxisApp *) m_axis)->m_exeName.IsEmpty())	m_dev = true;
	**/

	for (ii = 0; ii < MBMP_CNT; ii++)
		m_arRc.Add(CRect(0, 0, 0, 0));

	m_szRTime = _T("");

	m_saveTitle = _T("");
	m_bRTSQueue = false;

	m_bFirstOpen = true;		// 20070627 kwon
	m_bLastClose = false;		// 20070627 kwon
	m_sysInfo = new CSysInfo;	// 20070627 kwon
	m_sysInfo->Init();			// 20070627 kwon
	m_ipAddr = _T("");		
	m_sWin = _T("");
	m_sCpu = _T("");
	m_sMem = _T("");

	m_winVer = 0;			// 20070724
	m_minSaveRC.SetRectEmpty();

	m_matchToolBar = FALSE;
	m_matchToolCount = 3;

	m_theme = GetMyThemeName();
	m_bfitdual = false;

	m_bKobaElwNotify = false;

	m_slideMsg = "";

	m_bInit = FALSE;

	m_groupBymapN.RemoveAll();
}

CMainFrame::~CMainFrame()
{
	if (m_hMNews) FreeLibrary(m_hMNews);
	if (m_hDRFN) FreeLibrary(m_hDRFN);

	ExitWebBrowser();

	m_hjcode.RemoveAll();
	m_fjcode.RemoveAll();
	m_ojcode.RemoveAll();
	m_pjcode.RemoveAll();
	m_upcode.RemoveAll();
	m_elwbase.RemoveAll();

	if (m_hHook)	UnhookWindowsHookEx(m_hHook);

	if (m_MClient)	delete m_MClient;
	if (m_tMenu)	delete m_tMenu;
	if (m_bar0)	delete m_bar0;
	if (m_bar1)	delete m_bar1;
	if (m_bar2)	delete m_bar2;
	if (m_bar3) delete m_bar3;
	if (m_tInfo1)	delete m_tInfo1;
	if (m_tInfo2)	delete m_tInfo2;
	if (m_tInfo3)	delete m_tInfo3;
	if (m_smain)	delete m_smain;
	if (m_bitmapBtn) delete m_bitmapBtn;
	if (m_sdibar)	delete m_sdibar;

	if (m_axConnect)	delete m_axConnect;
	if (m_logodlg)		delete m_logodlg;
	if (m_TotalAcc)		delete m_TotalAcc;
	if (m_axMisc)		delete m_axMisc;
	if (m_wizard)		delete m_wizard;
	if (m_axGuide)		delete m_axGuide;
	if (m_printsetup)	delete m_printsetup;
	if (m_conclusion)	delete m_conclusion;
	if (m_kobanotify)	delete m_kobanotify;
	if (m_misuAlarm)	delete m_misuAlarm;
	if (m_Econclusion)	delete m_Econclusion;
	if (m_mngInfo)		delete m_mngInfo;
	if (m_smcall)		delete m_smcall;
	if (m_Nclock)		delete m_Nclock;
	if (m_chaser)		delete m_chaser;
	if (m_accTool)		delete m_accTool;
	if (m_newsviewer)	delete m_newsviewer;
	if (m_stoploss)		delete m_stoploss;
	if (m_foStoploss)	delete m_foStoploss;
	if (m_tip)		delete m_tip;
	if (m_pDoctor)		delete m_pDoctor;
	
	m_groupBymapN.RemoveAll();

	m_tabviewlist.RemoveAll();
	m_waitlist.RemoveAll();

	for (int ii = V_SCREEN1; ii <= V_SCREEN6; ii++)
		m_hooklist[ii].RemoveAll();

	for (ii = V_SCREEN1; ii <= V_SCREEN6; ii++)
		m_sdiZORDER[ii].RemoveAll();
		
	delete m_sysInfo;		// 20070627 kwon

	delete m_mapHelper;

#ifdef USE_AHNLAB_SECUREBROWSER
	uninitSBSDK();
	uninitAOSSDK();
#endif
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	Axis::mainWnd  = this;
	Axis::SetSkin(GetSkinName());

	//	elog member for axisreport
	m_reportCaption.Format("��ֽŰ� 119 for %s", m_regkey);	
	GetClassName(m_hWnd, m_classN, sizeof(m_classN));

	GetWindowPlacement(&m_switchpl);

	m_tip = new CTTip(this);
	if (!m_tip->Create(NULL, "CTTip", WS_CHILD|WS_BORDER, CRect(0, 0, 0, 0), GetDesktopWindow(), (int) m_tip))
	{
		delete m_tip;
		m_tip = NULL;
	}
	else	
		m_tip->ModifyStyleEx(0, WS_EX_TOOLWINDOW);
	m_BackGroundKey = -1;
	ModifyStyle(0, WS_SYSMENU);
	AfxInitRichEdit();
	MakeExpectSymbolTable();
	
	int result = Initialize();
	/*
	HANDLE handle;
    handle=GetCurrentProcess();
	SetPriorityClass(handle, HIGH_PRIORITY_CLASS);
	*/
	/** alarm test
			CAlarm	dlg;
			dlg.SetMsg("Test");
			dlg.DoModal();
	**/

	ResourceHelper()->LoadIcon();
	SetIcon(ResourceHelper()->GetIcon(), TRUE);

#ifdef USE_AHNLAB_SECUREBROWSER
	if (initAOSSDK())
		initSBSDK();
#endif

	return result;
}

// 2006.7.24 ����ȣ => ���������� ���� �ɺ� ���̺�
void CMainFrame::MakeExpectSymbolTable()
{
	// 20070608 kosdaq50->kosdaq��ó�� ����
	char*	sym[] = {"X5001", "X0001", "X2001", "XQSTR", "XQ001", "XQ002"};
	int	ncnt = sizeof(sym)/sizeof(char*);
	CString	str = _T("");
	
	for (int ii = 0 ; ii < ncnt ; ii++ )
	{
		str.Format("%s", sym[ii]);
		str = str.Mid(1);
		str = "K" + str;
		m_mapExpectSymbol.SetAt(sym[ii], str);
	}
}

void CMainFrame::SendTrigger(CString code)
{
	CString sdat;
	sdat = "1301\t"+code;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
}

void CMainFrame::deleteHistory(CString code)
{
	CString strRet(_T(""));
	long rc;
	
	CString sdat;
	sdat = "1301\t"+code;
	
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(delHISTORY, 0), (LPARAM)(LPCTSTR)sdat);
	
	strRet = rc ? (char *)rc : _T("");

	m_bar3->del_Button(code);
}

void CMainFrame::deleteAllHistory()
{
	CString strRet(_T(""));
	long rc;
	
	CString sdat;
	sdat = "1301\t000000";
	
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(delHISTORY, 0), (LPARAM)(LPCTSTR)sdat);
	
	strRet = rc ? (char *)rc : _T("");

	m_bar3->del_AllButton();

	CreateHistoryBar();
}

CString CMainFrame::ReplaceExpectSymbol(CString sym)
{
	CString	ret = _T("");
	
	m_mapExpectSymbol.Lookup(sym, ret);
	return ret;
}


BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style &= ~(WS_SYSMENU |FWS_ADDTOTITLE);
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg) 
{
	if (m_tMenu && m_tMenu->PreTranslateMsg(pMsg))
		return TRUE;

	return CMDIFrameWnd::PreTranslateMessage(pMsg);
}

LRESULT CMainFrame::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	CWindowDC dc(this);
	CRect	rc;
	int	nItem;
	CPoint	point = CPoint(LOWORD(lParam), HIWORD(lParam));

	switch (message)
	{
	case WM_SYNCPAINT:
		break;
	case WM_NCLBUTTONDOWN:
		switch (wParam)
		{
		case HTCAPTION:
			GetCursorPos(&point);
			nItem = GetSelectItem(point);
			
			m_downI = -1;
			if (nItem != -1)
			{
				
				rc = m_arRc.GetAt(nItem);
				/*
				if (Axis::isVista)
				{
					rc.left    += VistaFrame;
					rc.right   += VistaFrame;
					rc.top     += VistaFrame;
					rc.bottom  += VistaFrame;
				}
				*/
				//***rc.OffsetRect(XGAP, YGAP);
				switch (nItem)
				{
				case MIDX_HOME:	case MIDX_FULL:	case MIDX_DUAL:
				case MIDX_MIN:	case MIDX_MAX:	case MIDX_CLOSE:
				case MIDX_RESTORE:
					m_downI = nItem;
					m_action = nItem;

					DrawBitmapByMask(&dc, nItem, rc, true);
					break;
				case MIDX_VS1:	case MIDX_VS2:	case MIDX_VS3:
				case MIDX_VS4:	case MIDX_VS5:	case MIDX_VS6:
					m_action = nItem;
					PostMessage(WM_AXIS, MAKEWPARAM(axCAPTION, (int) m_action), -1);
					break;
				default:
					break;
				}
				return TRUE;
			}
			break;
		case HTCLOSE:
		case HTMAXBUTTON:
		case HTMINBUTTON:
			GetCursorPos(&point);
			nItem = GetSelectItem(point);
			m_downI = -1;
			if (nItem != -1)
			{
				rc = m_arRc.GetAt(nItem);
				//***rc.OffsetRect(XGAP, YGAP);
				switch (nItem)
				{
				case MIDX_HOME:	case MIDX_FULL:	case MIDX_DUAL:
				case MIDX_MIN:	case MIDX_MAX:	case MIDX_CLOSE:
				case MIDX_RESTORE:
					m_downI = nItem;
					m_action = nItem;
					DrawBitmapByMask(&dc, nItem, rc, true);
					break;
				case MIDX_VS1:	case MIDX_VS2:	case MIDX_VS3:
				case MIDX_VS4:	case MIDX_VS5:	case MIDX_VS6:
					m_action = nItem;
					PostMessage(WM_AXIS, MAKEWPARAM(axCAPTION, (int) m_action), -1);
					break;
				default:
					break;
				}
				return TRUE;
			}
			return TRUE;
		}
		break;
	case WM_NCMOUSEMOVE:
		switch (wParam)
		{
		case HTCLOSE:
		case HTMAXBUTTON:
		case HTMINBUTTON:
			return TRUE;
		}
		break;
	case WM_NCLBUTTONDBLCLK:
		if (wParam == HTCAPTION)
		{
			GetCursorPos(&point);
			nItem = GetSelectItem(point);
			switch (nItem)
			{
			case -1:
				break;
			case MIDX_ICON: case MIDX_CLOSE:
				PostMessage(WM_SYSCOMMAND, SC_CLOSE);
			default:
				return TRUE;
			}
		}
		break;
	}
	return CMDIFrameWnd::WindowProc(message, wParam, lParam);
}

BOOL CMainFrame::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	CPoint		pt;
	int		nItem;
	CRect		rc;
	CWindowDC	dc(this);

	if (m_downI != -1)	
	{
		switch (message)
		{
		case WM_LBUTTONUP:	// WM_NCLBUTTONUP process
			GetCursorPos(&pt);
			nItem = GetSelectItem(pt);
			if (nItem == m_downI)
			{ 
				m_action = nItem;
				PostMessage(WM_AXIS, MAKEWPARAM(axCAPTION, (int) m_action), -1);
			}

			rc = m_arRc.GetAt(m_downI);
			/*
			if (Axis::isVista)
			{
				rc.left    += VistaFrame;
				rc.right   += VistaFrame;
				rc.top     += VistaFrame;
				rc.bottom  += VistaFrame;
			}
			*/
			//***rc.OffsetRect(XGAP, YGAP);
			DrawBitmapByMask(&dc, m_downI, rc);

			m_action = -1;
			m_downI = -1;
			break;
		case WM_NCMOUSEMOVE:
			break;
		case WM_MOUSEMOVE:
			GetCursorPos(&pt);
			nItem = GetSelectItem(pt);
			if (nItem == m_downI)
			{
				rc = m_arRc.GetAt(nItem);
				/*
				if (Axis::isVista)
				{
					rc.left    += VistaFrame;
					rc.right   += VistaFrame;
					rc.top     += VistaFrame;
					rc.bottom  += VistaFrame;
				}
				*/
	
				//***rc.OffsetRect(XGAP, YGAP);
				switch (nItem)
				{
				case MIDX_HOME:	case MIDX_FULL:	case MIDX_DUAL:
				case MIDX_MIN:	case MIDX_MAX:	case MIDX_CLOSE:
				case MIDX_RESTORE:
					DrawBitmapByMask(&dc, nItem, rc, true);
					break;
				default:
					break;
				}
			}
			else
			{
				rc = m_arRc.GetAt(m_downI);
				/*
				if (Axis::isVista)
				{
					rc.left    += VistaFrame;
					rc.right   += VistaFrame;
					rc.top     += VistaFrame;
					rc.bottom  += VistaFrame;
				}
				*/
				//***rc.OffsetRect(XGAP, YGAP);
				DrawBitmapByMask(&dc, m_downI, rc);
			}

			ShowToolTip(nItem, pt);
			break;
		}
	}

	switch (message)
	{
	case WM_MOUSEMOVE:
	//case WM_NCMOUSEMOVE:
		GetCursorPos(&pt);
		nItem = GetSelectItem(pt);
		ShowToolTip(nItem, pt);
		break;
	}
	return CMDIFrameWnd::OnSetCursor(pWnd, nHitTest, message);
}

void CMainFrame::ShowToolTip(int nIndex, CPoint pt)
{
	if (nIndex < 0 || !m_tip)	return;
	//if (!(GetStyle() & WS_CAPTION))	return;
	
	CString		tipS;

	switch (nIndex)
	{
	case MIDX_HOME:	tipS =  _T("Ȩ������");		break;
	case MIDX_FULL:	tipS =  _T("��üȭ��");		break;
	case MIDX_DUAL:	tipS =  _T("�������");	break;
	default:
		if (nIndex >= MIDX_VS1 && nIndex <= MIDX_VS6)
		{
			int index = nIndex - MIDX_VS1;
			tipS.Format("����ȭ�� %d(ALT+%d)", index + 1, index + 1);
			tipS += GetScreenList(index);
		}
		else
		{
			m_tip->HideTips();
			return;
		}
		break;
	}

	CRect	wRc;
	CRect	tipRc = m_arRc.GetAt(nIndex);

	GetWindowRect(wRc);
	tipRc.OffsetRect(wRc.left, wRc.top);
	m_tip->ShowTips(tipRc, wRc, tipS);
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
BOOL CMainFrame::OnNcActivate(BOOL bActive) 
{
	CMDIFrameWnd::OnNcActivate(bActive);
	m_activeCap = bActive;
	OnNcPaint();
	if (Axis::isVista) Invalidate(); // for VISTA
	return TRUE;//*/return CMDIFrameWnd::OnNcActivate(bActive);
}

void CMainFrame::OnNcPaint() 
{
	if (Axis::isVista) VistaFrame = GetSystemMetrics(SM_CXFRAME)-3;

	DrawFrame();
}

void CMainFrame::RedrawVS(bool bMinus /* = false */)
{
	int	ncnt = m_arMDI[m_vsN].GetCount() + m_arSDI[m_vsN].GetCount();
	if (bMinus)
	{
		if (ncnt == 0)
			DrawFrame();
	}
	else
	{
		if (ncnt)
			DrawFrame();
	}
}


const int szFrame = 3;

void CMainFrame::DrawFrame() 
{
	CWindowDC dc(this);
	SetRegion();

	DrawFrame(&dc);

	CRect wrc, rc;

	GetWindowRect(&wrc);
	rc = wrc;
	rc.OffsetRect(-rc.TopLeft());
	
	
	

	if (!m_bSDI)
	{
		class SideDraw {
		public:
			SideDraw(CDC* dc, CRect& rc, CPoint offset, CDialogBar* bar, CBitmap* bmp, BOOL stretch = FALSE, int hoff = 0)
			{
				CRect wrc;

				bar->GetWindowRect(&wrc);
				wrc.OffsetRect(-offset);

				CDC mdc;
				mdc.CreateCompatibleDC(dc);
				CBitmap* oldBmp = mdc.SelectObject(bmp);

				BITMAP bm;
				bmp->GetBitmap(&bm);

				if (stretch)
				{
					dc->StretchBlt(rc.left, wrc.top, szFrame, wrc.Height(), &mdc, 0, 0, bm.bmWidth, 
						bm.bmHeight-hoff, SRCCOPY);

					dc->StretchBlt(rc.right - szFrame, wrc.top, szFrame, wrc.Height(), &mdc, 0, 0, bm.bmWidth, 
						bm.bmHeight-hoff, SRCCOPY);
				}
				else
				{
					dc->BitBlt(rc.left, wrc.top, szFrame, wrc.Height(), &mdc, 0, 0, SRCCOPY);
					dc->BitBlt(rc.right-szFrame, wrc.top, szFrame, wrc.Height(), &mdc, 0, 0, SRCCOPY);
				}
				mdc.SelectObject(oldBmp);
			}
		};

		if (m_tMenu)
		{
			SideDraw(&dc, rc, wrc.TopLeft(), m_tMenu, Axis::GetBitmap("MENUBACK"));			
		}

		if (m_bar1 && m_bar1->IsWindowVisible())
		{
			SideDraw(&dc, rc, wrc.TopLeft(), m_bar1, Axis::GetBitmap("Band"));
		}

		if (m_tInfo3 && m_tInfo3->IsWindowVisible())
		{
			SideDraw(&dc, rc, wrc.TopLeft(), m_tInfo3, Axis::GetBitmap("BAR_BG"), TRUE);
		}

		if (m_bar2 && m_bar2->IsWindowVisible())
		{
			if( m_bar2->GetBarStyle() & CBRS_ALIGN_TOP )
				SideDraw(&dc, rc, wrc.TopLeft(), m_bar2, Axis::GetSkinBitmap("BAR_BG"), TRUE);
			else
				SideDraw(&dc, rc, wrc.TopLeft(), m_bar2, Axis::GetSkinBitmap("�ϴ�_BAR_BG"), TRUE);
		}

		if (m_bar3 && m_bar3->IsWindowVisible())
		{
			if( m_bar3->GetBarStyle() & CBRS_ALIGN_TOP )
				SideDraw(&dc, rc, wrc.TopLeft(), m_bar3, Axis::GetSkinBitmap("BAR_BG"), TRUE);
			else
				SideDraw(&dc, rc, wrc.TopLeft(), m_bar3, Axis::GetSkinBitmap("�ϴ�_BAR_BG"), TRUE);
		}

		if (m_tInfo2 && m_tInfo2->IsWindowVisible())
		{
			SideDraw(&dc, rc, wrc.TopLeft(), m_tInfo2, m_tInfo2->GetBackImage(), TRUE);
		}
		if (m_tInfo1 && m_tInfo1->IsWindowVisible())
		{
			SideDraw(&dc, rc, wrc.TopLeft(), m_tInfo1, m_tInfo1->GetBackImage(), TRUE);
		}

		drawTitle(&dc);
	}
	DrawBorder(&dc);
}

BOOL CMainFrame::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	int	index = LOWORD(wParam);
	if (index < ID_MENU_BASE || index > ID_MENU_END)
	{
		if (runCommand(LOWORD(wParam), lParam))
			return TRUE;
		return CMDIFrameWnd::OnCommand(wParam, lParam);
	}
	if (index == IDC_BTN_LOGO)
	{
// 		CRect rc;
// 		GetWindowRect(rc);
// 		if (m_logodlg)
// 		{
// 			if (m_logodlg->IsWindowVisible())
// 			{
// 				m_logodlg->ShowWindow(SW_HIDE);
// 				
// 			}else{
// 
// 				if( m_bar1->IsWindowVisible() )
// 					m_logodlg->Initialize();
// 				else
// 					m_logodlg->Initialize(true);
// 
// 
// 				//m_logodlg->MoveWindow(rc.left+7,rc.top+3,199,600);  //parent �� ���� ���� �ƴҶ�
// 				
// 				//m_logodlg->SetParent(this);
// 				//m_logodlg->MoveWindow(7,22,199,600);
// 				m_logodlg->ShowWindow(SW_SHOWNA);
// 				//m_logodlg->SetForegroundWindow();
// 			}
// 		}
		CallRecommendedBoard();
	}

// 	CString s;
// 	s.Format("[USER SCREEN INDEX : %d]\n",index);
	// 	OutputDebugString(s);

//	save_laststat();

	m_mapHelper->ChangeChild(index);
	return TRUE;
}

void CMainFrame::CallRecommendedBoard()
{
	m_mapHelper->CreateChild("IB0000X1", 0);
}

void CMainFrame::OnAppDummy() {}

bool CMainFrame::runCommand(int comm, LPARAM lParam)
{
	BOOL	visible = FALSE;
	CString	str;

	switch (comm)
	{
	case ID_SCREENNUM:	SetHome();	break;	// set home
	case ID_STAFF_PWD:
		m_mapHelper->ChangeChild("IB985000");
		break;
	case ID_SETACCOUNT:
		{
			visible = !(m_TotalAcc->GetStyle() & WS_VISIBLE);
			ShowControlBar(m_TotalAcc, visible, FALSE);
		}
		break;
	case ID_CLEARCHART:	ClearGex();	break;		// ��Ʈ�ʱ�ȭ��� �߰� 2011.03.02 by LKM
	case ID_ESCAPEWINODW: 
		{
			m_mapHelper->closeChild();	
		}
		break;	// esc key
		
	case ID_SHOWTRACER:	showChaser();	break;	// alt + F1
	case ID_FULLNAME:	showfname();	break;	// alt + F2
	case ID_RELOADMAP:
		if (Axis::devMode)
		{
			CWnd *child = refleshMap(m_activeKey);
			if (child)
			{
				child->Invalidate();
				child->SetFocus();
			}
		}
		break;	// alt + F3
	case ID_FIRSTTAB:	// end key
		if (m_bEnd)
			AppSwitch();
		break;
	case ID_APP_TOTALSETUP: TotalSetup(); break;
	case ID_APP_RECOM:	CallRecommendedBoard();	break;
	case ID_APP_ESETUP:		TotalSetup(IDD_ESETUP); break;
	case ID_APP_MNGSETUP:	TotalSetup(IDD_MNGSETUP); break;
	case ID_APP_ORDERSETUP: TotalSetup(IDD_ORDER_SETUP); break;
	case ID_APP_THEMESETUP: TotalSetup(IDD_IMAGESETUP); break;
	case ID_APP_TICKERSETUP:TotalSetup(IDD_SETTICKINFO); break;
	case ID_APP_EDITHOTKEY:	TotalSetup(IDD_HOTKEY); break;
	case ID_APP_EDITTOOL:	TotalSetup(IDD_TSETUP); break;
	case ID_APP_TOOLBARSETUP: TotalSetup(IDD_FUNCTIONS); break;
	case ID_APP_CHEGEQUAL: TotalSetup(IDD_EQUALIZER); break;

	//** macho begin
	//**case ID_APP_ACCSETTING:	AccSetting();	break;
	case ID_APP_ACCTGROUP:
		AcctGroupConfig(); 
		break;
	case ID_APP_ACCTPASSWORD:
		AcctPasswordConfig();
		break;
	/**
	case ID_APP_ACCTALIAS:
		AcctAliasConfig();
		break;
	**/
	//** macho end
	case ID_APP_FOCONF: RunFOConfig(); break;	
	case ID_APP_HELPCOM:	RunHelpCom();	break;
	case ID_APP_CALC:
		ExecuteCalculator();
		break;
	case ID_APP_TRSEARCH:
		{
			CTrSearch	dlg(m_tMenu, axiscall);
			dlg.setPos(m_bar1->GetPos(1));
			if (dlg.DoModal() == IDOK)
				m_mapHelper->ChangeChild(dlg.getTR());
		}
		break;
	case ID_APP_USERSCREEN_SAVE:	
		saveUserScreen();	
		break;
	case ID_APP_USERPROGRAM:
		{
			CProgramDlg	dlg;
			if (dlg.DoModal() == IDOK)
				appendUserToolMenu();
		}
		break;
	case ID_APP_LINKEXCEL:
		m_mapHelper->ChangeChild(MAPN_LINKEXCEL);
		break;
	case ID_APP_CATCH:
		m_mapHelper->ChangeChild(MAPN_SISECATCH);
		break;
	case ID_VIEW_KOBAELW_SCREEN:
		m_mapHelper->ChangeChild((LPCSTR)lParam);
		break;
	case ID_APP_USETUPUPLOAD:	ProcessInfofile();	break;
	case ID_APP_USETUPDOWN:		ProcessInfofile(false);	break;
	case ID_APP_SAVEBMP_A:		
		saveImg(1);		
		break;
	case ID_APP_SAVEBMP:		
		saveImg();		
		break;
	case ID_APP_PRINT_SETUP:	m_printsetup->PrinterSetup(this);	break;
	case ID_APP_PRINT:
		if (m_progK == PK_BUSINESS && m_connectBy == byTCP)
		{
			SYSTEMTIME	lTime;
			CString		time;
			GetLocalTime(&lTime);
			time.Format(" %02d:%02d:%02d", lTime.wHour, lTime.wMinute, lTime.wSecond);
			GetWindowText(str);
			str += time;
		}
		m_printS = str;
		PostMessage(WM_CANCELMODE);
		PostMessage(WM_AXIS, MAKEWPARAM(axPRINTIMG, 0));
		break;
	case ID_APP_STOCK_STOPLOSS:
		StopLoss();
		break;
	case ID_APP_FO_STOPLOSS:
		FOStopLoss();
		break;
	case ID_APP_LOCK:	LockProg();	break;
	case ID_APP_RECONNECT:
		{
			/*
			if (Axis::devMode)
			{
				MessageBox("������������ �����Ǵ� ����Դϴ�.", "IBK��������", MB_OK);
				
			}
			else
			*/
			{
				HWND	hWnd = m_hWnd;
				CString	msg, title;
				msg.LoadString(ST_MSG_RECONNECT_OTHERUSER);
				title.LoadString(ST_TEXT_RECONNECT_OTHERUSER);

				if (Axis::MessageBox(this, msg, MB_ICONQUESTION | MB_YESNO) == IDYES)
					ChangeUser();
			}
		}
		break;
	case ID_APP_CONNECT:	// 2007.07.05 ��������
		m_mapHelper->ChangeChild(MAPN_MULTICONNECT);
		break;
	case ID_VIEW_DB1:
		visible = !(m_bar1->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_bar1, visible, FALSE);
			
		saveToolStatus();

		ChangeLogo();	
		break;
	case ID_VIEW_SCLIST:
		visible = !(m_bar2->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_bar2, visible, FALSE);
		if (visible && (m_bar0->GetStyle() & WS_VISIBLE))
			ShowControlBar(m_bar0, TRUE, FALSE);
		saveToolStatus();
		SetSDIChangeHeight();
		
		break;
	case ID_VIEW_TICKER1:
		visible = !(m_tInfo1->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_tInfo1, visible, FALSE);
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	case ID_VIEW_TICKER2:
		visible = !(m_tInfo2->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_tInfo2, visible, FALSE);
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	case ID_VIEW_TICKER3:
		if (!m_tInfo3)
			break;
		visible = !(m_tInfo3->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_tInfo3, visible, FALSE);
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	case ID_VIEW_JCONTROL:
		visible = !(m_bar0->GetStyle() & WS_VISIBLE);
		ShowControlBar(m_bar0, visible, FALSE);
		break;
	case ID_VIEW_ACCTOOL:
		visible = !(m_accTool->GetStyle() & WS_VISIBLE);
		m_accTool->ShowWindow(visible ? SW_SHOW : SW_HIDE);
		break;
	case ID_VIEW_MDI:
		if (m_appMode != MODE_MDI)
			ChangeMDI();
		break;
	case ID_VIEW_SDI:
		// 20070117
		if (m_appMode != MODE_SDI)
		{
			if (m_appMode == MODE_TRAY)
			{
				TrayCmd(TRAY_HIDEICON);
				ShowWindow(SW_SHOW);
			}
			else
				ChangeSDI();
		}
		//if (m_appMode != MODE_SDI)
		//	ChangeSDI();
		break;
	case ID_VIEW_TRAY:
		if (m_appMode != MODE_TRAY)
			ChangeTRAY();
		break;
	case ID_VIEW_VSCREEN1:	change_VirtualScreen(V_SCREEN1);	break;
	case ID_VIEW_VSCREEN2:	change_VirtualScreen(V_SCREEN2);	break;
	case ID_VIEW_VSCREEN3:	change_VirtualScreen(V_SCREEN3);	break;
	case ID_VIEW_VSCREEN4:	change_VirtualScreen(V_SCREEN4);	break;
	case ID_VIEW_VSCREEN5:	change_VirtualScreen(V_SCREEN5);	break;
	case ID_VIEW_VSCREEN6:	change_VirtualScreen(V_SCREEN6);	break;
	case ID_VIEW_FULLSCREEN:fullScreenMode(!m_fullmode);		break;
	case ID_VIEW_CASCADE:	MDICascade();				break;
	case ID_VIEW_TILE_HORZ:	MDITile(MDITILE_HORIZONTAL);		break;
	case ID_VIEW_TILE_VERT:	MDITile(MDITILE_VERTICAL);		break;
	case ID_VIEW_CLOCK:
		{
			if (m_Nclock)
			{
				if (m_Nclock->GetStyle() & WS_VISIBLE)
					m_Nclock->ShowWindow(SW_HIDE);
				else
				{
					CRect	rect, rcClock;
					CPoint	pt;
					GetWindowRect(rect);
					pt = rect.CenterPoint();
					m_Nclock->GetWindowRect(rcClock);
					pt.x -= rcClock.Width() / 2;
					pt.y = rect.top + rcClock.Height();					
					m_Nclock->SetWindowPos(&wndTopMost, pt.x, pt.y, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOACTIVATE);		
					m_Nclock->SetMini(FALSE);
					m_Nclock->ShowWindow(SW_SHOW);
					SetFocus();
				}
			}
		}
		break;

	case ID_APP_CLOSEA:	
		m_mapHelper->closeChild();	
		break;
	case ID_APP_CLOSEALLWITHOUTTHIS: 
		m_mapHelper->closeAllWithoutThis(); 
		break;
	case ID_APP_CLOSEALL:	
		m_mapHelper->closeAll();	
		break;
	default:
		return false;
	}

	return true;
}

void CMainFrame::OnUpdateRunCommand(CCmdUI* pCmdUI)
{
	BOOL	enable = TRUE;
	switch (pCmdUI->m_nID)
	{
	//case ID_APP_USERSCREEN_SAVE:
	case ID_APP_STOCK_STOPLOSS:
	case ID_APP_FO_STOPLOSS:
		enable = !m_bOnlySise;
		break;
	case ID_APP_SAVEBMP_A:
	case ID_APP_SAVEBMP:
	case ID_APP_PRINT:
		pCmdUI->Enable(MDIGetActive() != NULL);
		return;
	case ID_VIEW_DB1:
		if (m_bSDI)	enable = false;
		pCmdUI->SetCheck(m_bar1->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_SCLIST:
		if (m_bSDI)	enable = false;
		pCmdUI->SetCheck(m_bar2->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_TICKER1:
		if (m_bSDI)	enable = false;
		pCmdUI->SetCheck(m_tInfo1->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_TICKER2:
		if (m_bSDI)	enable = false;
		pCmdUI->SetCheck(m_tInfo2->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_TICKER3:
		if (m_bSDI)	enable = false;
		if (!m_tInfo3) 
			break;
		pCmdUI->SetCheck(m_tInfo3->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_JCONTROL:
		pCmdUI->SetCheck(m_bar0->GetStyle() & WS_VISIBLE);
		break;
	case ID_SETACCOUNT:
		pCmdUI->SetCheck(m_TotalAcc->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_ACCTOOL:
		/**
		pCmdUI->Enable(FALSE);
		return;
		**/
		if (!m_accTool)
		{
			pCmdUI->Enable(FALSE);
			return;
		}
		pCmdUI->SetCheck(m_accTool->GetStyle() & WS_VISIBLE);
		break;
	case ID_VIEW_MDI:
		pCmdUI->SetCheck(m_appMode == MODE_MDI);
		break;
	case ID_VIEW_SDI:
		pCmdUI->SetCheck(m_appMode == MODE_SDI);
		break;
	case ID_VIEW_TRAY:
		pCmdUI->SetCheck(m_appMode == MODE_TRAY);
		break;
	case ID_VIEW_VSCREEN1:
		pCmdUI->SetCheck(m_vsN == V_SCREEN1);
		break;
	case ID_VIEW_VSCREEN2:
		pCmdUI->SetCheck(m_vsN == V_SCREEN2);
		break;
	case ID_VIEW_VSCREEN3:
		pCmdUI->SetCheck(m_vsN == V_SCREEN3);
		break;
	case ID_VIEW_VSCREEN4:
		pCmdUI->SetCheck(m_vsN == V_SCREEN4);
		break;
	case ID_VIEW_VSCREEN5:
		pCmdUI->SetCheck(m_vsN == V_SCREEN5);
		break;
	case ID_VIEW_VSCREEN6:
		pCmdUI->SetCheck(m_vsN == V_SCREEN6);
		break;
	case ID_APP_CLOSEA:
	case ID_APP_CLOSEALLWITHOUTTHIS:
	case ID_APP_CLOSEALL:
		if (m_bSDI)
			if (!m_arSDI[m_vsN].GetCount())
				enable = false;
		else
			if (!m_arMDI[m_vsN].GetCount())
				enable = false;
		break;
	case ID_VIEW_FULLSCREEN:
		if (m_bSDI)	enable = false;
		pCmdUI->SetCheck(m_fullmode);
		break;
	case ID_VIEW_CASCADE:
	case ID_VIEW_TILE_HORZ:
	case ID_VIEW_TILE_VERT:
		if (!MDIGetActive())	
			enable = false;
		break;
	case ID_VIEW_CLOCK:
		if (m_Nclock && m_Nclock->GetSafeHwnd())
		{
			pCmdUI->SetCheck(m_Nclock->GetStyle() & WS_VISIBLE);
		}
		break;
	default:	
		break;
	}

	pCmdUI->Enable(enable);
}

void CMainFrame::OnClose() 
{
	CString file;


	const char* noticeMapName = "IB780100";
	CProfile pout(pkUserConfig);
	CWnd* wnd = FindWindow(NULL,"�ǽð��ؿ�����");
	if (wnd)
	{
		pout.Write(noticeMapName, "OnLoad", 1);
	}
	else
	{
		pout.Write(noticeMapName, "OnLoad", 0);
	}
	if (!m_mapHelper->closeX())	
		return;

//#ifdef NDEBUG
	if (m_bExit && m_runAxis)	//	exit window
	{
		if (((CAxisApp *) m_axis)->m_progK != 'R')
		{
			CExitD exit(NULL, IsNewExitImage());
			exit.SetTime(m_connectT);
			UINT modalResult = exit.DoModal();
			if (modalResult == IDCANCEL)
				return;
			//UploadFile();
			//SendConfig();
		}
	}
	TRY
	{
		file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, "AccList.dat");
		::DeleteFile(file);
		file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, "GrpList.dat");
		::DeleteFile(file);
	}
	CATCH (CFileException, e) 
	{
	}
	END_CATCH;
//#endif 

//	((CAxisApp*)m_axis)->protectKey(Axis::home, false);

	if (m_MClient->m_pBkMapWnd)
	{
		((CBkWnd*)m_MClient->m_pBkMapWnd)->SendMessage(WM_CLOSE, 0, 0);
		delete m_MClient->m_pBkMapWnd;
		m_MClient->m_pBkMapWnd = NULL;
	}

	m_bLastClose = true;	// 20070627 kwon
	KillTimer(TM_SCRLOG);	// 20070710 cej

	FreeFirewall();
	
	DeleteChaser();
	saveExitMap();
	save_history();

	// 2010.09.03 ������ ȭ���� Report by warship
	save_scr_counter();
	scr_counter_report();

	removeOpenedList();	// 20070627 kwon
	
	int		key;
	CSChild*	schild;
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		for (POSITION pos = m_arSDI[vsN].GetStartPosition(); pos; )
		{
			m_arSDI[vsN].GetNextAssoc(pos, key, schild);
			schild->SendMessage(WM_CLOSE);
		}

		// dtitle m_arSDI[vsN].RemoveAll();
		RemoveAllChild(vsN, true);
		
	}
	
	m_mapHelper->closeAll();
	for (int ii = 0; ii < m_arHide.GetSize(); ii++)
	{
		CChildFrame* child = m_arHide.GetAt(ii);
		if (child && child->GetSafeHwnd())
			child->SendMessage(WM_CLOSE);
	}

	//	code register screen
	BOOL	rc;
	if (m_category)
	{
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_CODE);
	}

	//	acc toolbar
	if (m_accTool)
	{
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_ACCTOOL);
	}

	//	news viewer
	if (m_newsviewer)
	{
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_NEWSVIEWER);
	}

	//	Stoploss
	if (m_stoploss)
	{
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_STOPLOSS);
	}

	//	����Stoploss
	if (m_foStoploss)
	{
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_FOSTOPLOSS);
	}

	m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);

	if (m_MClient)	m_MClient->UnsubclassWindow();

	if (/*m_bExit && */m_runAxis/* && !m_bSDI*/)
	{
		CRect	wRc;
		GetWindowRect(wRc);
		
		int screenX = GetSystemMetrics(SM_CXVIRTUALSCREEN);
		int screenY = GetSystemMetrics(SM_CYVIRTUALSCREEN);

		int	x  = wRc.left;
		int	y  = wRc.top;
		int	cx = wRc.Width();
		int	cy = wRc.Height();

		const char* information = INFORMATION;
		m_axis->WriteProfileInt(information, "SDI", m_bSDI ? 1 : 0);
		m_axis->WriteProfileInt(information, "win_x", x);
		m_axis->WriteProfileInt(information, "win_y", y);
		m_axis->WriteProfileInt(information, "win_cx", cx);
		m_axis->WriteProfileInt(information, "win_cy", cy);
		m_axis->WriteProfileInt(information, "toolstatus", m_toolStatus);

		if (m_Nclock && m_Nclock->GetSafeHwnd())
		{
			CRect	wRc;
			m_Nclock->GetWindowRect(wRc);

			m_axis->WriteProfileInt(information, "clock_visible", m_Nclock->GetStyle() & WS_VISIBLE ? 1 : 0);
			m_axis->WriteProfileInt(information, "clock_mini", m_Nclock->IsMini() ? 1 : 0);
			m_axis->WriteProfileInt(information, "clock_x", wRc.left);
			m_axis->WriteProfileInt(information, "clock_y", wRc.top);
		}
	}

	KillTimer(TM_PRNIMG);

	if (m_bReconnect)
	{
		m_axMisc->RunVers(verUSERID);
		m_bReconnect = false;
	}

	CMDIFrameWnd::OnClose();
}

LONG CMainFrame::OnAXIS(WPARAM wParam, LPARAM lParam)
{
	BOOL		rc;
	char		wb[128];
	int		value, key;
	CChildFrame*	child;
	CStringArray	arr;
	CString		tmps = _T(""), title = _T("");

	switch (LOWORD(wParam))
	{
	case axSTART:	// start step
		if (HIWORD(wParam) && m_step != axNONE)
		{
			m_step = axNONE;
			m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);
		}

		switch (m_step)
		{
		case axNONE:	m_connectBy = m_axis->GetProfileInt(INFORMATION, CONNECTBY, byNONE);break;
		case axOPENPPP:	break;
		case axOPENSIGN:
			SetEncriptFile();
			m_axConnect->SetChoice(false);
			PostMessage(WM_AXIS, MAKEWPARAM(axSIGNON, 0));		return 0;
		default:return 0;
		}
		
		if (!getConnectInfo(tmps, value))
		{
			Axis::MessageBox(this, "��ġ������ Ȯ���ϼ���", MB_ICONINFORMATION);
			return 0;
		}

		strcpy(wb, tmps);
		m_step = axOPENRSM;

		//**if (value != 15101)	sprintf(wb, GetConnectIP(tmps));
		//**m_ip.Format("%s", wb); 

		/**
		char	macaddr[20], ip[16];
		memset(macaddr, 0x00, sizeof(macaddr));
		memset(ip, 0x00, sizeof(ip));
		GetMacAddr(wb, macaddr);

		m_ip = get_glb_addr(ip, macaddr);
		**/
		
		m_ip = tmps;
		m_port.Format("%d", value);
		//AfxMessageBox(m_port);
		((CAxisApp*)m_axis)->m_conIP = m_ip;
		if (/*(m_ip.Left(3) == "172")*/(m_ip == "172.16.202.106") || (m_ip == "172.16.205.20") || (m_ip == "211.255.204.134")|| (m_ip == "211.255.204.131") || m_ip=="172.16.205.30" || m_ip=="211.255.204.136")
			Axis::devMode = TRUE;

		/**
		{
			CString sUserID = "";
			if (m_axConnect)
				sUserID = m_axConnect->GetUserID();
			if ((m_regkey.Find("����") >= 0 && AfxGetApp()->GetProfileInt(WORKSTATION, "OnlyGuest", 0)) ||
				(sUserID.GetLength() == 8 && !sUserID.Left(5).CompareNoCase("GUEST")))
			{
				m_ip = "ibk.com";
			}
		}
		**/
		

		// ���� ��ư Ŭ���ÿ�. ���ҽ� �ٿ�� ����.
		if (AfxGetApp())
		{
			if (AfxGetApp()->GetProfileInt(WORKSTATION, "GetAllResource", 0))
			{
				CString	path, filename;
				path.Format("%s\\%s\\", Axis::home, TABDIR);
				filename.Format("%s\\%s", path, "infoAXIS");
				::DeleteFile(filename);
				filename.Format("%s\\%s", path, "infoRSC");
				::DeleteFile(filename);
				AfxGetApp()->WriteProfileInt(WORKSTATION, "GetAllResource", 0);
			}
		}
		

		m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, (long)wb, value);
		if (rc)
		{
			m_axMisc->GetGuide(AE_CONNECT, tmps);
			m_axConnect->SetGuide(tmps);
		}
		else
		{
			m_step = axNONE;
			m_axConnect->SetProgress(false);
			m_axConnect->SetStatus(SM_EXIT);
		}
		
		
		break;

	case axRUN:	break;
	case axAXIS:
		{
			m_bInit = TRUE;
			OutputDebugString("OnAxis-axAXIS - Step 1\n");
			int screenX = GetSystemMetrics(SM_CXVIRTUALSCREEN);
			int screenY = GetSystemMetrics(SM_CYVIRTUALSCREEN);
			int x  = m_axis->GetProfileInt(INFORMATION, "win_x", 0);
			int y  = m_axis->GetProfileInt(INFORMATION, "win_y", 0);
			int cx = m_axis->GetProfileInt(INFORMATION, "win_cx", 0);
			int cy = m_axis->GetProfileInt(INFORMATION, "win_cy", 0);

			if (m_bSDI)
			{
				SetWindowPos(&wndTop, x, y, cx, m_SDIHEIGHT, SWP_SHOWWINDOW);
			}
			else
			{
				if (cx <= 300 || cy <= 100)
				{
					SetWindowPlacement(&m_switchpl);
					m_axis->m_nCmdShow = SW_SHOWMAXIMIZED;
					ShowWindow(m_axis->m_nCmdShow);
				}
				else	
				{
					SetWindowPos(&wndTop, x, y, cx, cy, SWP_SHOWWINDOW);
				}
			}

			UpdateWindow();
			if (m_axConnect->GetUserID().CompareNoCase("guest"))
			{
				if (AfxGetApp())
					AfxGetApp()->WriteProfileString(WORKSTATION, "BackUserID", m_axConnect->GetUserID());
			}
			if (m_axConnect)
			{
				delete m_axConnect;
				m_axConnect = NULL;
			}

			WriteLog("OnAxis-axAXIS - Step 3");

			ClearRepositoryLog();

			endWorkstation();
			
			WriteLog("OnAxis-axAXIS - Step 4");

			if (m_bdnInterest)
				dnloadAction();
			
			WriteLog("OnAxis-axAXIS - Step 5");

			OpenAnnouncement();

			WriteLog("OnAxis-axAXIS - Step 6");
			SetHome();

			WriteLog("OnAxis-axAXIS - Step 7");

			checkOpenedList();	// 20070627 kwon

			WriteLog("OnAxis-axAXIS - Step 8");

			checkDelayList();	// 20071205 won

			WriteLog("OnAxis-axAXIS - Step 9");

			m_tInfo1->RedrawWindow();

			// 2010.06.01 �������α׷��� ��� �����Ǿ��� ��� && �����ϰ��
			BOOL pcFirewall = AfxGetApp()->GetProfileInt(INFORMATION, "PCFirewall", 0);
			BOOL pcKeyProtect = AfxGetApp()->GetProfileInt(ENVIRONMENT, "KeyProtect", 0);
			if ( (!pcFirewall || !pcKeyProtect) && Axis::isCustomer )
			{
				load_secure_agree(pcFirewall, pcKeyProtect);
			}

			WriteLog("OnAxis-axAXIS - Step 10");

			// 2010.06.01 ����� OS�� Report�Ѵ�.
			// 2012.02.13 ����ö���� ���� ����.BY DUKKI
			//os_report();

			WriteLog("OnAxis-axAXIS - Step 11");

			// 2010.09.03 ���� Ethernet Card�� MAC�� Report �Ѵ�.
			//mac_report();

			// 2010.09.27 ���ӽ� ���� ȭ��Counter ������ �ε��Ѵ�.
			// 2012.03.22 ����ö���� ���� ����.BY DUKKI
			load_scr_counter();

			// 2010.07.21 ����ó�� Hotkey �ε�
			LoadHotkeySetting();

			WriteLog("OnAxis-axAXIS - Step 12");

			// �������� üũ
			//sendTR("PIHONOTI", "Y", 1, US_PASS, 'l');

			WriteLog("OnAxis-axAXIS - Step 13");

			m_bInit = FALSE;
		}
		break;
	case axSIGNON:	signOn();			break;
	case axCLOSEV:	axCloseV(HIWORD(wParam));	break;
	case axRELOAD:	refleshMap(m_activeKey);	break;
	case axFOCUS:
		m_activeKey = HIWORD(wParam);
		{
			int	key = 0;
			CChildFrame*	pChild = NULL;
			CSChild*	sChild = NULL;
			for ( int ii = 0 ; ii < 6 ; ii++ )
			{
				POSITION	pos = m_arMDI[ii].GetStartPosition();
				while (pos)
				{
					m_arMDI[ii].GetNextAssoc(pos, key, pChild);
					pChild->RedrawCaption();
				}

				pos = m_arSDI[ii].GetStartPosition();
				while (pos)
				{
					m_arSDI[ii].GetNextAssoc(pos, key, sChild);
					sChild->RedrawCaption();
				}
			}
		}
		//**TRACE("=================================================axFocus[%d]====================================================\n", m_activeKey);
		axFocus(m_activeKey);
		break;
	case axGUIDE:
		if (lParam)	displayGuide((char *)lParam);
		else
		{
			m_axMisc->GetGuide(HIWORD(wParam), tmps);
			displayGuide(tmps);
		}
		break;
	case axTRIGGER:
		value = 0;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&value, (BYTE *)(VTS_I4 VTS_I4),
					setGID, (long)MAKELONG((WORD)lParam, HIWORD(wParam)));
		break;
	case axSCREEN:		return modifyWorkspace(HIWORD(wParam) ? false : true, (char *)lParam, m_saveALLVS);
	case axMODAL:		loadMap(HIWORD(wParam), (int)lParam);		break;
	case axDEVICE:
		if (m_modal)	key = m_modal->m_vwKEY;
		else
		{
			bool	match = false;
			CGPop*	pop;		
			for (POSITION pos = m_arGPOP.GetStartPosition(); pos;)
			{
				m_arGPOP.GetNextAssoc(pos, key, pop);
				if (!pop->m_active)	continue;
				match = true;
			}

			if (!match)
			{
				child = (CChildFrame *) MDIGetActive();
				if (!child)	return 0;
				key = child->m_key;
			}
		}
		if (m_wizard)
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&value,
						(BYTE *)(VTS_I4 VTS_I4), MAKELONG(devEV, key), 0);
		break;
	case axURL:
		{
			CProfile profile(pkLink);
			CString url(profile.GetString("LINKINFOMATION", HIWORD(wParam) ? "ECN": "EMERGENCY"));
			Trim(url);
			if (url.IsEmpty())
				return 0L;
			PopupWeb(url);
		}
		break;
	case axWRITEIMG:	writeImg(Axis::home, HIWORD(wParam));	break;
	case axPRINTIMG:	printImg(m_printS);			break;
	case axSHOWHELP:	HelpLink(m_helpKey);			break;
	case axALARM:
		if (m_runAxis)
		{
			CAlarm	dlg;
			dlg.SetMsg(m_alarmMsg);
			dlg.DoModal();
		}
		break;
	case axDIALOG:
		{
			tmps = m_alarmMsg;
			switch (HIWORD(wParam))
			{
			default:	break;
			case 0x96:	break;
			case 0x97:	displayMsgBox("�������� �˸�", tmps);	break;
			}
		}
		break;
	case axKONG:	break;
	case axCAPTION:
		key = (int) lParam;
		actionCaption(key, HIWORD(wParam));
		break;
	case axLINKEDIT:
		{
			int	nType = HIWORD(wParam);
			switch (nType)
			{
			case 0:
				{
					CLink	dlg(m_tMenu, (char *)lParam);
					if (dlg.DoModal() == IDOK)
					{
					}
				}
				break;
			}
		}
		break;
	case axChaserON:	CreateChaser();	break;
	case axChaserOFF:	DeleteChaser();	break;
	case axGetActiveKey:	return m_activeKey;
	case axMRADAR:
		{
			switch (HIWORD(wParam))
			{
			case 0 :	// ����������
				return (LONG)(char*)(const char*)m_ip;
			case 1 :	// ����ȭ�� ��ȣ
				return (LONG)m_vsN;
			case 2 :	// ���̺귯�� �ν��Ͻ�
				if (m_hMRadar == NULL)
				{
					m_hMRadar = LoadLibrary("MRTick.dll");					
				}
				
				return (LONG)m_hMRadar;
			}			
		}
		break;
	case axTEST:		
		ShowMngInfo(Format("%s\t%d\t%s\t%d\t%s\t%s\t", 
					MNG_FLAG, NO_CHECK+1, MNG_KIND, HIWORD(wParam), MNG_MSG, (char*)lParam));
		break;	
	case axFixedFrame:	// ����ȣ fixed�ɼ�
		{
			key = HIWORD(wParam);
			CSize	size(LOWORD(lParam), HIWORD(lParam));
			int	nCx, nCy, gapX, gapY, viewType;
			gapX  = GetSystemMetrics(SM_CXFRAME) * 2;
			gapX += GetSystemMetrics(SM_CXBORDER) * 2;

			gapY  = GetSystemMetrics(SM_CYFRAME) * 2;
			gapY += GetSystemMetrics(SM_CYBORDER) * 2;

			CChildFrame*	child;
			if (!m_arMDI[m_vsN].Lookup(key, child))
			{
				CSChild*	schild;
				if (!m_arSDI[m_vsN].Lookup(key, schild))
					break;

				if ((schild->m_vwTYPE & vtypeMSK) != vtypeWND)
					gapY += XCAP_HEIGHT;
				if (schild->IsTabView())	
					gapY +=	TABH;

				viewType = schild->m_vwTYPE & vtypeMSK;
				nCx = size.cx + gapX;
				nCy = size.cy + gapY;
				schild->SetSize(nCx, nCy);
				
				schild->m_fixH = true;
				schild->m_fixW = true;
				
				CView*	view = schild->GetActiveView();
				schild->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
				if (viewType == vtypeSCR)
					((CAxScrollView *)view)->SetSizeView(size.cx, size.cy);
				if (schild->IsTabView())	
					((CAxTabView *) view)->SizeWindow(size);
				break;
			}

			if ((child->m_vwTYPE & vtypeMSK) != vtypeWND)	gapY += XCAP_HEIGHT;
			if (child->IsTabView())	
				gapY +=	TABH;

			viewType = child->m_vwTYPE & vtypeMSK;
			nCx = size.cx + gapX;
			nCy = size.cy + gapY;
			child->SetSize(nCx, nCy);
			
			child->m_fixH = true;
			child->m_fixW = true;
			
			CView*	view = child->GetActiveView();
			child->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
			if (viewType == vtypeSCR)
				((CAxScrollView *)view)->SetSizeView(size.cx, size.cy);
			if (child->IsTabView())	
				((CAxTabView *)view)->SizeWindow(size);	
		}
		break;
	case axRTSQueue:	// 20070621
		// RTS �׽�Ʈ
		{
			long	rc = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
								(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(getRTS, 0), 0);
			return rc;
		}

		break;
	case axMinMaxInfo:
		return SetChildMinMaxInfo(HIWORD(wParam), (MINMAXINFO*)lParam);
	case axMenuMode:
		return SetMenuMode(HIWORD(wParam), lParam);
	case axIsDLL:
		return m_mapHelper->IsDLL((LPCTSTR)lParam);
	case axSkinChange :
		{
			m_pMain->change_Skin();
			//AfxMessageBox("SKIN CHANGE!!!");

		}
		break;
	case axToolbarHide :
		{
			OutputDebugString("axToolbarHide\n");
			BOOL	visible = FALSE;

			visible = !(m_bar1->GetStyle() & WS_VISIBLE);
			ShowControlBar(m_bar1, visible, FALSE);
			
			saveToolStatus();
			
			ChangeLogo();
		}
		break;
	}

	return 0;
}

LONG CMainFrame::OnUSER(WPARAM wParam, LPARAM lParam)
{
	switch (LOWORD(wParam))
	{
	case MMSG_GETPASSWORD:
		return (LRESULT)(LPCTSTR)GetUserPassword();
	case MMSG_GETCERTPASSWORD:
		return (LRESULT)(LPCTSTR)GetCertPassword();
	case MMSG_APPLYSETUP:
		return ApplySetup(lParam);
	case MMSG_SCREENOPEN:
		//AfxMessageBox((char *)lParam);
		return m_pMain->InputScreenNo((char *)lParam) ? true:false;
	case MMSG_SAVEINTEREST:
		{				
			//CString tmp = CString((char*)lParam, HIWORD(wParam));
			sendTR("PIDOMYST", (char *)lParam, HIWORD(wParam), US_PASS, 'S');
		}
		return true;
	case MMSG_NEWINTEREST:
		{
			const char* trust = (char *)lParam;//"IB202201appendCODE\t005930\n";
			m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
		}
		return true;
	}
	return 0;
}

int CMainFrame::OnFireRec(int type, WPARAM wParam, LPARAM lParam)
{
	BOOL	rc;
	CString	str, msg, title, logs;

	if (m_forceClose)	return 0;
	switch (type)
	{
	case FEV_OPEN:
		if (!lParam)
		{
			if (m_axConnect && IsWindow(m_axConnect->m_hWnd))
				m_axConnect->SetGuide(_T("������ ����Ǿ����ϴ�."));
			str = m_axis->GetProfileString(INFORMATION, "Port");
			if (atoi(str) == portEmployee)
				m_bCustomer = false;
			m_axis->WriteProfileInt(INFORMATION, "ConnectBy", Axis::isCustomer ? 0 : 1);
			break;
		}
	case FEV_CLOSE:
		m_bExit = false;
		m_forceClose = true;

		m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);
		PostMessage(WM_AXISCLOSE);
		break;

	case FEV_RUN:
//run:
		if (lParam)
		{
			if (m_update)	break;

			m_update = true;
			m_axMisc->GetGuide(AE_UPDATE, str);
			m_axConnect->SetProgress(false);
			m_axConnect->SetGuide(str);
			
			m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
						(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);
			Sleep(300);
			if (!m_axMisc->RunVers(verUPDATE, m_axConnect->GetUserID(), m_axConnect->GetPassword(), m_axConnect->GetCPass()))
			{
				m_axMisc->GetGuide(AE_EUPDATE, str);
				m_axConnect->SetGuide(str);
				Sleep(700);
			}
			m_axConnect->EndDialog(IDCANCEL);
			
			return 0;
		}
		else
		{
			SetForegroundWindow();
			signOn();
			
		}
		break;

	case FEV_SIZE:
		m_axMisc->GetGuide(AE_COMPONENT, msg);
		m_axConnect->SetGuide(msg);
		if (m_axConnect)
		{
			m_axConnect->SetProgress(true);
			m_axConnect->SetTotal((char *)lParam);
		}
		break;

	case FEV_ANM:	
		//update_ticker((int)wParam, (char *)lParam);
		update_ticker((int)wParam, (struct _alertR*)lParam);
		break;

	case FEV_AXIS:

		switch (LOWORD(wParam))
		{	
		case newHISTORY:
			{
				m_bar3->del_AllButton();
				
				CreateHistoryBar();
			}
			break;
		case runAXIS:
			//FixUserConfigDirectory();
			CheckEncryptDirectory();
			CheckSoundConfig();
			CheckNewsSetting();
			ConfigFrame();
			
			if (m_step != axDONE)
			{
				m_step = axDONE;

				GetLocalTime(&m_connectT);
				convertIndex();
				ConfigTicker();

				m_runAxis = true;
				sendRTime();
				sendTicInfo();
				m_axConnect->SetFrameRun();
				m_axConnect->PostMessage(WM_CLOSE);
			}


			break;
		case newVIEW:			
			return create_Newview(HIWORD(wParam), (char *)lParam);
		case renVIEW:
			if (HIWORD(wParam) & winK_POPUP)
				return m_mapHelper->ChangePopup((char *)lParam, TRIGGERN, HIWORD(wParam));
			else	
				return m_mapHelper->ChangeChild((char *)lParam, TRIGGERN, HIWORD(wParam));
			break;
		case delVIEW:
			if (HIWORD(wParam) & winK_POPUP)
			{
				CMPop*	Mpop;
				CGPop*	Gpop;
				if (m_arMPOP.Lookup(HIWORD(wParam), Mpop))
					Mpop->EndDialog(IDCANCEL);
				else if (m_arGPOP.Lookup(HIWORD(wParam), Gpop))
					Gpop->SendMessage(WM_CLOSE, 0, 0);
			}
			else
				m_mapHelper->closeChild(HIWORD(wParam));
			break;
		case htmlVIEW:	// key : HIWORD(wParam), html : lParam
			str = (char *) lParam;
			if (m_runAxis)	
				RunWebBrowser(str);
			else		
				ShellExecute(NULL, _T("open"), str, NULL,NULL, SW_SHOWNORMAL);
			break;
		case titleVIEW:	
			setTitle(HIWORD(wParam), (char *)lParam);
			break;
		case autoVIEW:	// ### : HIWORD(wParam) : cnt, items : lParam
			setCodeReg(HIWORD(wParam), (char *) lParam);
			break;
		case mapNAME:			break;
		case waitPAN:
			if (lParam)	beginWait(HIWORD(wParam));
			else		endWait(HIWORD(wParam));			
			break;
		case hangulPAN:	// key : HIWORD(wParam), hangul : lParam
		case doublePAN:	// key : HIWORD(wParam), double : lParam
			break;
		case alarmPAN:	// dialog ? : HIWORD(wParam), text : lParam
			if (HIWORD(wParam))
			{
				str = parseData((char *) lParam);
				if (!str.IsEmpty())
				{
					m_alarmMsg = str;
					PostMessage(WM_AXIS, MAKEWPARAM(axALARM, 0), 0);
				}
			}
			else	displayGuide((char *) lParam);
			break;
		case noticePAN:	// text : lParam
			ConclusionNotice((char *) lParam, str);
			break;
		case dialogPAN:	// type : HIWORD(wParam), data  : lParam
			str = (char *) lParam;
			switch (HIWORD(wParam))
			{
			default:
			case 0x01:
			case 0x02:
				break;
			case 0x96:	// ��ް��� -> ��� ���� �ٿ�ε�� ����(������ ���Ŀ�)! 2010.07.21 by LKM
				ProcessRexp( (struct rexp_mid*)lParam );
				break;
			case 0x97:	// �ߺ������..............
				m_alarmMsg = str;
				PostMessage(WM_AXIS, MAKEWPARAM(axDIALOG, HIWORD(wParam)), lParam);
				break;
			case 0x99:
				m_bExit = false;
				m_forceClose = true;
				m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc, (BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);
				
				if (str.GetLength()>0)
				{
					switch(str.GetAt(0))
					{
					case '$':		// ������ ���θ� ���� �ʰ� ����
						Axis::MessageBox(this, str.Mid(1), MB_OK);
						break;
					default:		// ������ ���θ� ����, ������/���� ��Ŵ
						if (Axis::MessageBox(this, str, MB_ICONQUESTION | MB_OKCANCEL) == IDOK)
							m_axMisc->RunVers(verRETRY, Axis::userID, m_pass, m_cpass);
						
					}
				}
				PostMessage(WM_CLOSE);
				break;
			case 0x98:
				{
					
					m_bExit = false;
					m_forceClose = true;
					Sleep(1000);
					m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
								(BYTE *)(VTS_I4 VTS_I4 VTS_I4), loginAXIS, 0, -1);

					HWND	hWnd = m_hWnd;

					Axis::MessageBox(this, str +
						"\n�������Ӽ����� �Ʒ�ȭ�鿡�� ���������մϴ�."
						"\n        [8211] �������� ����/����" );
					
					PostMessage(WM_CLOSE);
				}
				break;
			}
			break;
		case sizeVIEW:	
			changeSize(HIWORD(wParam), CSize(LOWORD(lParam), HIWORD(lParam)));
			break;
		case userINFO:	
			GetWindowText(title);
			if (title.Find("IBK hot Line") == -1)
			{
				str = (m_rndkey%2) ? CALLCENTER1 : CALLCENTER2;
				title += str;
				m_saveTitle = title;
				m_titleS = title;
			
				SetWindowText(title);
				
			}

			if (title.Find("����������") == -1)
			{
				str.Format("   ���������� : %s", (char *) lParam);
				title += str;
				m_saveTitle = title;
				m_titleS = title;
				SetWindowText(title);
			}					
			break;
		case printVIEW:
			{
				//�α��ν� �÷����� ������ ����Ʈ �޼��� ������ ������ ���� ���� �߻�
				//m_printS =(char *) lParam;
				//AfxMessageBox("printVIEW");
				//PostMessage(WM_AXIS, MAKEWPARAM(axPRINTIMG, 0));
			}
			break;
		case initVIEW:
			{
				//AfxMessageBox("initVIEW");
				actionCaption(m_activeKey, IDX_FONTX);
			}
			break;
		case copyVIEW:
			{
				actionCaption(m_activeKey, IDX_COPY);
				//m_activeKey
			}
			break;
		case printVIEWx:
			{
				PostMessage(WM_AXIS, MAKEWPARAM(axPRINTIMG, 0));
			}
			break;
		case menuAXIS:		
			break;
		case linkVIEW:
			{
				CLink	dlg(m_tMenu, (char *)lParam);
				if (dlg.DoModal() == IDOK)
				{
				}
			}
			break;
		case closeAXIS:
			//HIWORD(wParam) = true  �϶� Reboot�Ͽ� Login Dialog ���·�..
			//HIWORD(wParam) = false �϶� Axis ����
			if (HIWORD(wParam))
				m_axMisc->RunVers(verRETRY);
			m_bExit = false;
			PostMessage(WM_CLOSE);
			break;
		case nameVIEW:	
			SetAMap(HIWORD(wParam), (char *) lParam);	
			break;
		case accnINFO:
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(applyACC, 0), 0);
			break;
		//** temp case menuVIEW:	SetSearchMap((char *) lParam);	break;
		case userPASS:	sprintf((char *) lParam, m_pass, m_pass.GetLength());	break;
		case captionVIEW: //** HIWORD(wParam): key, lParam: string buffer
			strcpy((char*)lParam, GetChildWindowCaption(HIWORD(wParam))); 
			break;
		default :
			
				//CString tmp; tmp.Format("[%d]", LOWORD(wParam));
				//AfxMessageBox(tmp);
			break;

			
		}
		break;

	case FEV_STAT:
		if (m_axConnect) {
			m_axConnect->SetProgress((char *)lParam, (int)wParam);
			//**TRACE("FEV_STAT: %s (%d)\n", (char*)lParam, wParam);
		}
		break;
	case FEV_ERROR:
		switch (m_step)
		{
		case axOPENRSM:
			if (m_axConnect)
				m_axConnect->SetProgress((char*)lParam, (int)wParam, TRUE);
			break;
		case axOPENSIGN:
			if (lParam && m_axConnect)
			{
				{	// ���� �ߺ������� ���.
					CString msg((const char*)lParam);
					if (msg.GetLength() > 4 && atoi(msg.Left(4)) == 3192)
					{
						CDuplicateLoginConfirmDlg dlg(this, msg);
						dlg.DoModal();
						
						switch (dlg.GetResult())
						{
						case IDIGNORE:
							m_axConnect->m_forceLogin = 2;
							break;
						case IDOK:
							m_axConnect->m_forceLogin = 1;
							break;
						case IDCANCEL:
							m_step = axNONE;
							m_axConnect->SetStatus(SM_EXIT);
							return 0;
						}

						m_step = axNONE;
						m_axConnect->SetStatus(SM_NO);
						m_axConnect->DoRun();
						return 0;
					}

				}
				
				{
					// 2011.08.02 ��й�ȣ ������ ��� ���� �ð��� ����(����Ƚ��ǥ�⸦���ؼ�)
					CString emsg = (char*)lParam;
					int ecod = atoi(emsg.Left(4));
					do {
						if (ecod==4368 && Axis::isCustomer)
						{
							int pos[2], nTotal, nRemain;
							
							pos[0] = emsg.Find("ȸ");
							if (pos[0]==-1) break;
							nTotal = atoi(emsg.Mid(pos[0]-1,1));

							pos[1] = emsg.Find("ȸ", pos[0]+2);
							if (pos[1]==-1) break;
							nRemain = atoi(emsg.Mid(pos[1]-1,1));

							emsg.Format("���Ӻ�й�ȣ�� %dȸ �߸��Է��ϼ̽��ϴ�.", nTotal-nRemain);
							// 3ȸ �̻� ����
							if (nRemain==0)
							{
								CString mmsg;
								mmsg.Format(
									"���Ӻ�й�ȣ�� ��%dȸ �߸��Է��Ͽ� ����� �����Ǿ����ϴ�.\n\n"
									"Ȩ������ Ȥ�� ������ �����Ͽ� ����Ƚ���� �ʱ�ȭ �Ͻñ� �ٶ��ϴ�.", nTotal);
								m_axConnect->ShowMessageBox(mmsg, "IBK��������", MB_OK|MB_ICONERROR);
							}
							else if ((nTotal-nRemain)>=3)
							{
								CString mmsg;
								mmsg.Format("%s\n\n�� %dȸ ������ ��������˴ϴ�.", emsg, nTotal);
								m_axConnect->ShowMessageBox(mmsg, "IBK��������", MB_OK|MB_ICONERROR);
							}
						}
						else if (ecod==9998)
						{
							CString path;
							path.Format("%s\\%s\\NOTICE_POPUP.BMP", Axis::home, IMAGEDIR);
							CImageNotice dlg(this, path);
							dlg.DoModal();
						}
						else if (ecod==9999)
						{
							emsg = emsg.Mid(5);
							m_axConnect->ShowMessageBox(emsg, "IBK��������", MB_OK|MB_ICONERROR);
						}
						else
						{
							//emsg = emsg;
						}
					} while(FALSE);
					m_axConnect->SetGuide(emsg);
				}

				if (wParam)
				{
					m_axConnect->SetChoice(true);
					m_axConnect->ClearPassword();
				}
				else
				{
					m_step = axNONE; // ?
					m_axConnect->SetStatus(SM_EXIT);
				}
			}
			break;
		case axOPENWSH:
			if (lParam)
			{
				m_step = axNONE;	// ?
				if (m_axConnect)	break;
				m_axConnect->SetGuide((char*)lParam);
				m_axConnect->SetStatus(SM_EXIT);
			}
			break;
		case axNONE:
		case axDONE:
			if (lParam) 
			{
				if (LOWORD(wParam))
				{
					if (HIWORD(wParam) == '4')	// messagebox
						m_axMisc->MsgBox((char *)lParam);
					else
					{
						if (m_axConnect)
							m_axConnect->SetGuide((char*)lParam);
						else	displayGuide((char *) lParam);
					}
				}
				else
				{
					if (m_axConnect)
						m_axConnect->SetGuide((char*)lParam);
					else	displayGuide((char *) lParam);
				}
			}
			break;

		}
		break;
	case FEV_GUIDE:
		m_axMisc->GetGuide((int)lParam, str);
		switch (m_step)
		{
		case axDONE:
			if (LOWORD(wParam))
			{
				if (HIWORD(wParam) == '4')	// messagebox
					m_axMisc->MsgBox(str);

				if (LOWORD(wParam) & 0x80)	displayGuide(str);
				else				displayGuide(str);
			}
			else
			{
				if ((int) lParam != 6)
					displayGuide(str);
			}
			break;
		case axOPENSIGN:
		case axOPENWSH:
			if (m_axConnect)	
				m_axConnect->SetChoice(false);
		default:
			if (m_axConnect)
			{
				m_axConnect->SetChoice(true);
				if (LOWORD(wParam)) m_axConnect->SetGuide((char*)lParam);
				else m_axConnect->SetGuide(str);
			}
			break;
		}
		break;
	case FEV_FMX:	processFMX(wParam, lParam);	break;	
	case FEV_VERS:	processMapVersionInfo(wParam, lParam); break;
	default:	break;
	}
	return 0;
}

int CMainFrame::Initialize()
{
	if (m_regkey.Find("����") >= 0 && !m_axis->GetProfileInt(INFORMATION, "staff_change_flag", 0))
	{
		m_axis->WriteProfileInt(INFORMATION, "staff_change_flag", 1);
		m_axis->WriteProfileString(INFORMATION, "Server", "172.16.205.20");
	}
	CloseChaserAPP();
//	m_hHook = SetWindowsHookEx(WH_GETMESSAGE, KeyboardProc, 
//			AfxGetInstanceHandle(), GetCurrentThreadId());
	m_pMain = (CMainFrame *) this;

	m_saveTitle = m_axMisc->m_regkey;
	SetWindowText(m_saveTitle);

	m_titleS = m_saveTitle;
	::SetWindowLong(m_hWndMDIClient, GWL_EXSTYLE, ::GetWindowLong(m_hWndMDIClient, GWL_EXSTYLE) & ~WS_EX_CLIENTEDGE);
	::SetWindowPos(m_hWndMDIClient, NULL, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOREDRAW|SWP_FRAMECHANGED);
	m_MClient->SubclassWindow(m_hWndMDIClient);
	m_MClient->m_nBkMode = m_nBkMode;
	registerControl();
	m_axGuide->Create(this);

	CString backupID(Axis::userID);
	SetUserInfo();
	if (!backupID.IsEmpty())
		Axis::userID = backupID;

	m_axConnect = new CDtconnect(this, Axis::userID, IsNewLoginImage((m_regkey.Find("����") >= 0)));
	
	m_logodlg = new CLogoDlg(this);
	m_logodlg->Create(NULL, "CLogoDlg", WS_CHILD|WS_BORDER|WS_OVERLAPPEDWINDOW, CRect(0, 0, 0, 0), this, -1);

	m_wizard = new CWnd();

	if (!m_wizard->CreateControl("AxisWizard.WizardCtrl.IBK", NULL, WS_CHILD, CRect(0,0,0,0), this, -1))
	{
		delete m_wizard;
		m_wizard = NULL;
		return -1;
	}

	if (m_axis->GetProfileInt(ENVIRONMENT, "KeyProtect", 0))
	{
		((CAxisApp*)m_axis)->protectKey(Axis::home, true);
	}
	if (m_axMisc->m_regkey == "IBK")
		SetWindowText("IBK����");
	else if (m_axMisc->m_regkey == "IBK_STAFF")
		SetWindowText("[����]IBK����");
	else if (m_axMisc->m_regkey == "IBKMAC_STAFF")
		SetWindowText("[����]IBK hot Trading");
	else
		SetWindowText("IBK hot Trading");
	return 0;
}

void CMainFrame::CreateTB()
{
	
	
	ModifyStyle(WS_CAPTION, 0);

	m_bitmapBtn = new CBmpButton();
	if(!m_bitmapBtn->Create("", BS_BITMAP/*BS_OWNERDRAW*/, CRect(5,-1, 76,57), this, IDC_BTN_LOGO))
	{
		delete m_bitmapBtn;
		m_bitmapBtn = NULL;
		return;
	}
	m_bitmapBtn->SetImgBitmap(Axis::GetSkinBitmap("LOGO",true), 1);
	m_bitmapBtn->ShowWindow(SW_HIDE);
	

	
	SetMenu(NULL);
	m_sdibar = new CSdibar(axiscall);
	if (!m_sdibar->Create(this, IDD_SDIBAR, WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_LEFT, IDD_SDIBAR))
	{
		delete m_sdibar;
		m_sdibar = NULL;
		return;
	}
	
	m_tMenu = new CTMenu(this, 22);
	if (!m_tMenu->Create(this, IDD_TMENU, WS_DLGFRAME|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_TOP, IDD_TMENU))
	//if (!m_tMenu->Create(this, IDD_TMENU, WS_DLGFRAME|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, IDD_TMENU))
	{
		delete m_tMenu;
		m_tMenu = NULL;
		return;
	}
	//m_tMenu->SetWindowPos(NULL,80,0,1000,21, SWP_SHOWWINDOW);

	m_bar1 = new CDbar1(axiscall);
	if (!m_bar1->Create(this, IDD_DBAR1, WS_DLGFRAME|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_TOP, IDD_DBAR1))
	{
		delete m_bar1;
		m_bar1 = NULL;
		return;
	}

	//m_bar1->SetWindowPos(NULL,20,40,1000,100, SWP_SHOWWINDOW);
	
	m_bar1->set_MenuInfo(m_tMenu);
	
	int btn_tmp = 0;
	

	m_smain = new CSmain(axiscall);
	if (!m_smain->Create(this, IDD_SMAIN, WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_BOTTOM, IDD_SMAIN))
	{
		delete m_smain;
		m_smain = NULL;
		return;
	}

	m_tInfo2 = new CTInfo2(axiscall);
	if (!m_tInfo2->Create(this, IDD_INFO2, WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_BOTTOM, IDD_INFO2))
	{
		delete m_tInfo2;
		m_tInfo2 = NULL;
		return;
	}
	

	m_tInfo1 = new CTInfo1(axiscall);
	if (!m_tInfo1->Create(this, IDD_INFO1, WS_CLIPCHILDREN|WS_CLIPSIBLINGS|CBRS_ALIGN_BOTTOM, IDD_INFO1))
	{
		delete m_tInfo1;
		m_tInfo1 = NULL;
		return;
	}

#if 0
	DWORD dwListBarStyle = m_axis->GetProfileInt(INFORMATION, "listbar_pos", CBRS_ALIGN_BOTTOM);
#else
	DWORD dwListBarStyle = m_axis->GetProfileInt(INFORMATION, "listbar_pos", 0);
	if (dwListBarStyle==0)
	{
		CProfile p(pkUserSetup);
		dwListBarStyle = (DWORD)p.GetDouble(INFORMATION, "listbar_pos", CBRS_ALIGN_BOTTOM);
	}
	else
	{
		m_axis->WriteProfileInt(INFORMATION, "listbar_pos", 0);
		CProfile(pkUserSetup).Write(INFORMATION, "listbar_pos", (double)dwListBarStyle);
	}
#endif
	m_bar2 = new CDbar2(axiscall);
	if (!m_bar2->Create(this, IDD_DBAR2, WS_CHILD|WS_DLGFRAME|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|dwListBarStyle, IDD_DBAR2))
	{
		delete m_bar2;
		m_bar2 = NULL;
		return;
	}

	m_bar3 = new CDbar3(axiscall);
	if (!m_bar3->Create(this, IDD_DBAR2, WS_CHILD|WS_DLGFRAME|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|dwListBarStyle, IDD_DBAR3))
	{
		delete m_bar3;
		m_bar3 = NULL;
		return;
	}
	
	m_tInfo3 = new CTInfo3(axiscall);
	if (!m_tInfo3->Create(this, IDD_INFO3, WS_CLIPCHILDREN | WS_CLIPSIBLINGS | CBRS_ALIGN_BOTTOM, IDD_INFO3))
	{
		delete m_tInfo3;
		m_tInfo3 = NULL;
		return;
	}
	m_tInfo3->SetCols(m_matchToolCount);
	m_tInfo3->make_Ctrl();

	m_tMenu->SetBarStyle(m_tMenu->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_tMenu->EnableDocking(CBRS_ALIGN_TOP);
	
	m_tMenu->InitMenu(IDR_MAINFRAME, ID_MENU_BASE);
	
	
	if (Axis::isCustomer)
	{
		
		CMenuXP*	mainM = (CMenuXP*) m_tMenu->GetPopupMenu(0);
		//�����̸� ������й�ȣ ���� �޴� ����

		mainM->DeleteMenu(ID_STAFF_PWD, MF_BYCOMMAND);
		

		MENUITEMINFO	info;
		memset(&info, 0, sizeof(MENUITEMINFO));
		info.cbSize = sizeof(MENUITEMINFO);
		info.fMask = MIIM_DATA | MIIM_TYPE;
		mainM->GetMenuItemInfo(mainM->GetMenuItemID(1), &info);		// ���¼��� �ؽ�Ʈ ����.
		
		CMenuXPItem *pData = (CMenuXPItem *)info.dwItemData;
		/**
		pData->m_strText = _T("���¼���");
		**/

		mainM = (CMenuXP*) m_tMenu->GetPopupMenu(-1);

		mainM->GetMenuItemInfo(mainM->GetMenuItemID(6), &info);		// �������� ����.
		mainM->RemoveMenu(6, MF_BYPOSITION);
		pData = (CMenuXPItem *)info.dwItemData;
		if ((info.fType & MFT_OWNERDRAW) && pData && pData->IsMyData())
			delete pData;
		
		
		mainM = (CMenuXP*) m_tMenu->GetPopupMenu(0);
		memset(&info, 0, sizeof(MENUITEMINFO));
		info.cbSize = sizeof(MENUITEMINFO);
		info.fMask = MIIM_DATA | MIIM_TYPE;
		mainM->GetMenuItemInfo(mainM->GetMenuItemID(3), &info);
		
		CMenuXPItem *pData2 = (CMenuXPItem *)info.dwItemData;
		//AfxMessageBox(pData2->m_strText);
		
		pData2->m_strText = "��ȸ���¼���";
		
		//if (pData2) delete pData2;
		
		
	}
	makeUserScreenMenu();
	appendUserToolMenu();

	EnableDocking(CBRS_ALIGN_ANY);

	m_bar1->SetBarStyle(m_bar1->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_bar1->EnableDocking(CBRS_ALIGN_TOP);
	m_bar1->make_Ctrl();
	
	m_bar2->SetBarStyle(m_bar2->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_bar2->EnableDocking(CBRS_ALIGN_BOTTOM|CBRS_ALIGN_TOP);
	m_bar2->make_Ctrl();
	
	m_bar3->SetBarStyle(m_bar2->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_bar3->EnableDocking(CBRS_ALIGN_BOTTOM|CBRS_ALIGN_TOP);
	m_bar3->make_Ctrl();
	
	m_sdibar->SetBarStyle(m_sdibar->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	if (m_tInfo3)
		m_tInfo3->SetBarStyle(m_tInfo3->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_tInfo1->SetBarStyle(m_tInfo1->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_tInfo2->SetBarStyle(m_tInfo2->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);

	m_smain->SetBarStyle(m_smain->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC);
	m_smain->make_Ctrl();

	

	m_bar0 = new CCoolDialogBar(this, axiscall);
	if (!m_bar0->Create(this, IDD_DBAR0))
	{
		delete m_bar0;
		m_bar0 = NULL;
		return;
	}
	
	m_bar0->make_Ctrl();
	m_bar0->SetBarStyle(m_bar0->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_DYNAMIC|CBRS_ALIGN_LEFT);

	m_bar0->EnableDocking(CBRS_ALIGN_LEFT);
	DockControlBar(m_bar0);
	ShowControlBar(m_bar0, FALSE, FALSE);

	m_TotalAcc = new CAcntDialogBar(this, axiscall, m_wizard);
	
	m_TotalAcc->SetAuthInfo(Axis::userID, m_pass);
	if (!m_TotalAcc->Create(this, IDD_TOTALACC))
	{
		//AfxMessageBox("Failed");
		delete m_TotalAcc;
		m_TotalAcc = NULL;
		return;
	}

	m_TotalAcc->SetBarStyle(m_TotalAcc->GetBarStyle()|CBRS_TOOLTIPS|CBRS_FLYBY|CBRS_SIZE_FIXED|CBRS_ALIGN_RIGHT);
	m_TotalAcc->EnableDocking(CBRS_ALIGN_RIGHT);
	
	DockControlBar(m_TotalAcc);
	
	ShowControlBar(m_TotalAcc, FALSE, FALSE);
	
	
#if 1
	m_bSDI = m_axis->GetProfileInt(INFORMATION, "SDI", 0) ? true : false;
	if (m_bSDI)
		m_appMode = MODE_SDI;
	else	
		m_appMode = MODE_MDI;
	
	loadToolStatus();
	if (m_bSDI)
	{
		m_toolStatus = m_axis->GetProfileInt(INFORMATION, "toolstatus", TOOLSTATUS_SDI);

		ModifyStyle(WS_CAPTION, 0);
		ShowControlBar(m_tMenu, FALSE, FALSE);
		ShowControlBar(m_bar0, FALSE, FALSE);
		ShowControlBar(m_bar1, FALSE, FALSE);
		
		ShowControlBar(m_bar2, FALSE, FALSE);
		ShowControlBar(m_sdibar, TRUE, FALSE);
		ShowControlBar(m_smain, TRUE, FALSE);
		
		SetSDIChangeHeight();
		ChangeLogo();
		if (m_bitmapBtn) m_bitmapBtn->ShowWindow(SW_HIDE);

	}
	else
	{
		m_toolStatus = m_axis->GetProfileInt(INFORMATION, "toolstatus", TOOLSTATUS_MDI);
		
		ShowControlBar(m_sdibar, FALSE, FALSE);
		ShowControlBar(m_smain, FALSE, FALSE);
		
		
		
	}
#else
	if (!m_bSDI)
	{
		ShowControlBar(m_sdibar, FALSE, FALSE);
		ShowControlBar(m_smain, FALSE, FALSE);
	}
	loadToolStatus();
	SetToolStatus();
#endif
	RecalcLayout();
}

bool CMainFrame::Start(CString user)
{	
	if (!user.IsEmpty())
	{
		int	pos  = user.Find('\t');
		if (pos >= 0)
		{
			Axis::userID = user.Left(pos++);
			user = user.Mid(pos);
			pos  = user.Find('#');
			if (pos == -1)
			{
				m_pass = user;
			}
			else
			{
				m_pass = user.Left(pos++);
				m_cpass = user.Mid(pos);
			}
		}
		Axis::userID.TrimLeft(); 
		Axis::userID.TrimRight();
		m_pass.TrimLeft(); 
		m_pass.TrimRight();
		m_cpass.TrimLeft(); 
		m_cpass.TrimRight();

		if (!Axis::userID.IsEmpty())	
			m_axConnect->SetUserID(Axis::userID);
		if (!m_pass.IsEmpty())	
			m_axConnect->SetPassword(m_pass);
		if (!m_cpass.IsEmpty())	
			m_axConnect->SetCPass(m_cpass);
	}

	LoadSecureTools();
	
	m_axConnect->SetProgK(m_progK);
	if (m_regkey.Find("����") >= 0)
		m_axConnect->SetStaff(true);

	if (m_regkey.Find("STAFF") >= 0)
	{
		m_axConnect->SetStaff(true);
		Axis::isCustomer = false;
		
	}else
	{
		Axis::isCustomer = true;
	}

	if (m_axConnect)
	{
		UINT modalResult = IDCANCEL;
		try
		{
			modalResult = m_axConnect->DoModal();
		}
		catch (...) {
			CDebug::Out("Exception on Connect Dialog");
		}


		if (modalResult == IDCANCEL)
		{
			//**m_mapHelper->DirectClose();
			return false;
		}
	}
	return true;
}

void CMainFrame::UnregisterControl()
{
return;
	char*	control[] = { "axWizard.ocx", "axSock.ocx", "axComCtl.ocx", "axXecure.ocx", "axCertify.ocx", NULL };
	CString	path;
	HINSTANCE hLib;

	for (int ii = 0; control[ii] != NULL; ii++)
	{
		path.Format("%s\\%s\\%s", Axis::home, RUNDIR, control[ii]);
		hLib = LoadLibrary(path);
		if (hLib < (HINSTANCE)HINSTANCE_ERROR)
		{
			TRACE("LoadLibrary error....[%s] error=[%d]\n", path, GetLastError());
			continue;
		}

		FARPROC	lpDllEntryPoint;
		(FARPROC &)lpDllEntryPoint = GetProcAddress(hLib, _T("DllUnRegisterServer"));
		if (lpDllEntryPoint == NULL)
		{
			FreeLibrary(hLib);
			continue;
		}

		(*lpDllEntryPoint)();
		FreeLibrary(hLib);
	}
}

void CMainFrame::registerControl()
{
	UnregisterControl();

	char*	control[] = { "axWizard.ocx", "axSock.ocx", "axComCtl.ocx", "axXecure.ocx", "axCertify.ocx", "vbscript.dll", "IBKSConnector.ocx", NULL };
	CString	path;
	HINSTANCE hLib;

	for (int ii = 0; control[ii] != NULL; ii++)
	{
		path.Format("%s\\%s\\%s", Axis::home, RUNDIR, control[ii]);

		if (control[ii]=="vbscript.dll")
			path = control[ii];

		hLib = LoadLibrary(path);
		if (hLib < (HINSTANCE)HINSTANCE_ERROR)
		{
			TRACE("LoadLibrary error....[%s] error=[%d]\n", path, GetLastError());
			continue;
		}

		FARPROC	lpDllEntryPoint;
		(FARPROC &)lpDllEntryPoint = GetProcAddress(hLib, _T("DllRegisterServer"));
		if (lpDllEntryPoint == NULL)
		{
			FreeLibrary(hLib);
			continue;
		}

		(*lpDllEntryPoint)();
		FreeLibrary(hLib);
	}
}

BOOL CMainFrame::getConnectInfo(CString& ips, int& port)
{
	CString Port = m_axis->GetProfileString(INFORMATION, "Port");
	//** macho temp   ips = m_axis->GetProfileString(INFORMATION, "Server");

	char	wb[128], macaddr[20], ip[16];
	memset(macaddr, 0x00, sizeof(macaddr));
	memset(ip, 0x00, sizeof(ip));
	GetMacAddr(wb, macaddr);

	if (m_ipAddr.IsEmpty())
		GetLocalIP();
	memcpy(ip, m_ipAddr, m_ipAddr.GetLength());
	//((CAxisApp*)m_axis)->m_forceIP = "211.255.204.34";
	if (((CAxisApp*)m_axis)->m_forceIP.IsEmpty() == FALSE)
	{
		ips = ((CAxisApp*)m_axis)->m_forceIP;
		port = ((CAxisApp*)m_axis)->m_forcePort;

		Axis::isCustomer = !(port == portEmployee);

		if (Axis::isCustomer && port == portEmployee)
			port = portCustomer;
		if (!Axis::isCustomer && ((port == portCustomer)||(port ==portProxy)))
			port = portEmployee;
		
		if (m_axConnect)
		{
			if ((Axis::userID.Find("##ibk")==-1) && (Axis::userID.Find("##opuser")==-1))
			{
				if (m_axConnect->IsNumber(Axis::userID))
					port = portEmployee;
				else if ((port != portCustomer)&&(port !=portProxy))
					port = portCustomer;
				Axis::isCustomer = !(port == portEmployee);
			}
		}
		/*
		CString tmp;
		tmp.Format("port: %d(%s)", port, Axis::userID);
		AfxMessageBox(tmp);
		*/
		
  }
	else
	{
		if (Port.IsEmpty())	
			Port.Format("%d", portEmployee);

		port = atoi(Port);	

		if (Axis::isCustomer && port == portEmployee)
			port = portCustomer;

		if (!Axis::isCustomer)// && ((port == portCustomer)||(port ==portProxy)))
			port = portEmployee;

		m_axis->WriteProfileInt(WORKSTATION, "cust", Axis::isCustomer ? 1: 0);

		ips = get_glb_addr(ip, (LPSTR)(LPCTSTR)m_ipAddr);

		if (ips.IsEmpty())
			ips = m_axis->GetProfileString(INFORMATION, "URL");

		//**m_axis->WriteProfileString(INFORMATION, "Server", ips);	// ����Ǹ� ��������


		if (ips.IsEmpty())	
			return FALSE;

	}
	
	return TRUE;
}

void CMainFrame::load_start_notice( BOOL bReload )
{
	CString file;
	file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, SETUPFILE);

	const char* noticeMapName;

	int nStartScreen =  GetPrivateProfileInt("SCREEN", "STARTSCREEN", 1, file );

	nStartScreen = 0;

	if( nStartScreen )
	{
 		closeMapByName("IB7700");	
 
		CProfile profile(pkPalette);
		CString pal = profile.GetString(GENERALSN, "Palette");
		
		pal.MakeUpper();
		if (pal == "BLUE")
			noticeMapName = "IB770050";
		else if (pal == "GREEN")
			noticeMapName = "IB770060";
		else if (pal == "BROWN")
			noticeMapName = "IB770070";
		else if (pal == "VIOLET")
			noticeMapName = "IB770080";
		else if (pal == "GRAY")
			noticeMapName = "IB770090";
		else
			noticeMapName = "IB770050";
		if (!IsExistMap(noticeMapName) || bReload )
		{
			CProfile p(pkUserConfig);
			CString date(p.GetString(noticeMapName, "DATE", "20080601"));
			//if (atoi(date) < atoi(CTime::GetCurrentTime().Format("%Y%m%d")))
				m_mapHelper->ChangeChild(noticeMapName, 1, 0, CenterPOS);
		}

		
		CWnd* wnd = FindWindow(NULL,"�ǽð��ؿ�����");
		if (!wnd)
		{
			noticeMapName = "IB780100";
			CProfile pout(pkUserConfig);
			int piout = pout.GetInt(noticeMapName, "OnLoad", 0);
			if (piout > 0)
			{
				m_mapHelper->ChangeChild(noticeMapName, 1, 0, CenterPOS);

			}
		}
		
	}
	/*else
	{
		if(bReload)
			closeMapByName("IB7700");	
	}*/	
}

void CMainFrame::closeMapByName(CString strName)
{
	int key;
	POSITION pos;

	CChildFrame* child;

	for( int i = 0; i < 6; i++ )
	{
		pos = m_arMDI[i].GetStartPosition();
		while( pos )
		{
			m_arMDI[i].GetNextAssoc( pos, key, child );
			if( child->m_mapN.Find("IB7700") >= 0 )
			{
				m_mapHelper->closeChild( key );
				break;
			}
		}
	}
}

void CMainFrame::endWorkstation()
{
	WriteLog("endWorkstation - Step 1");
	m_dept = Variant(getDEPT);
	m_bar1->setDept(m_dept);
	//CString str = Variant(accountCC);

	if ( (m_dept != "813") && (m_dept != "828") && m_dept != "812")
	{
		CMenuXP*	mainM = (CMenuXP*) m_tMenu->GetPopupMenu(0);
		//�����̸� ������й�ȣ ���� �޴� ����
		mainM->DeleteMenu(ID_SETACCOUNT, MF_BYCOMMAND);
	}
	else
	{
		// 811 ���ο�����
		// 813, 828 �Ļ���ǰ���� 1/2��
// 		if (m_dept != "812")
// 			ShowControlBar(m_TotalAcc, TRUE, FALSE);

		if (m_dept == "813")
			ShowControlBar(m_TotalAcc, TRUE, FALSE);
	}
	
	Axis::SetSkin(GetSkinName());

	WriteLog("endWorkstation - Step 2");

	ChangeLogo();

	WriteLog("endWorkstation - Step 3");

	m_bOnlySise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0);
	deleteNewsfile();
	m_hHook = SetWindowsHookEx(WH_GETMESSAGE, KeyboardProc, 
			AfxGetInstanceHandle(), GetCurrentThreadId());
	m_resourceHelper->ChangeRES(Axis::skinName);
	ResourceHelper()->ChangeRES(Axis::skinName);

	WriteLog("endWorkstation - Step 4");

	m_axMisc->LoadGuide();
	m_bar0->set_MenuInfo(m_tMenu, Axis::user);
	m_smain->set_MenuInfo(m_tMenu);
	m_bar1->Change_Skin(Axis::skinName);
	m_bar2->Change_Skin(Axis::skinName);
//	m_bar3->Change_Skin(Axis::skinName);
	m_smain->Change_Skin(Axis::skinName);

	WriteLog("endWorkstation - Step 5");

	if (!m_bExit)	
		return;

	WriteLog("endWorkstation - Step 6");
	
	preload_screen();

	// ������ �н����� �����۾�
	// axlogon -> misf �� SBPLI301�� [�α��κ�й�ȣ����] �÷���([W]arning, e[X]pired)
	// IB0000AA ���� misf�÷��׸� ini���Ͽ� ����
	// ���ο��� �ش� �÷��׸� �о� �Ʒ��� ���� ó���Ѵ�.
	if (!Axis::isCustomer)
	{
		CProfile pk(pkUserSetup);
		CString val = pk.GetString("LOGIN", "MISF", "0");
		if (val=="X" || val=="W")
		{
			CEmpPassChangeNotifyDlg dlg(this, (val=="X") ? PNT_MUST : PNT_ADVISE);
			if (dlg.DoModal()==IDOK)
			{
				// ����Ǿ������ ������ ������ �Ѵ�.
				m_EmpPassChangeDlg = new CEmpPassChangeDlg(this, (val=="X") ? FALSE : TRUE);
				m_EmpPassChangeDlg->DoModal();
				delete m_EmpPassChangeDlg;
				m_EmpPassChangeDlg = NULL;
			}
		}
	}

	WriteLog("endWorkstation - Step 7");
	load_tabview();

	WriteLog("endWorkstation - Step 8");
	load_history();
	
	WriteLog("endWorkstation - Step 9");
	if (! m_bdnInterest)
	{
		
		WriteLog("endWorkstation - Step 10-1");
		load_eninfomation();
	
		WriteLog("endWorkstation - Step 10-2");
	

		//** �ſ��������� ���� ���� ���� ȭ��

		//if (m_bCustomer)
		{
			const char* trust = "IB820850";
			if (!IsExistMap(trust))
			{
				//CString date(p.GetString(noticeMapName, "DATE", "20080601"));
				//if (atoi(date) < atoi(CTime::GetCurrentTime().Format("%Y%m%d")))
				m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
			}
		}
		
			WriteLog("endWorkstation - Step 10-3");
			
			//** �ʱ�������� OPEN
			//AfxMessageBox(Axis::skinName);	
			load_start_notice();

			WriteLog("endWorkstation - Step 10-4");
	}

// 	const char* trust = "IB0000X8";
// 	if (!IsExistMap(trust))
// 	{
// 		//CString date(p.GetString(noticeMapName, "DATE", "20080601"));
// 		//if (atoi(date) < atoi(CTime::GetCurrentTime().Format("%Y%m%d")))
// 		m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
// 	}
	

	load_mngSetup();

	WriteLog("endWorkstation - Step 11");

	load_hkey();

	WriteLog("endWorkstation - Step 12");
	
	SetConclusion();

	WriteLog("endWorkstation - Step 13");

	m_smcall = new CSmcall();
	m_smcall->Set_Infomation(axiscall, m_tMenu);

	WriteLog("endWorkstation - Step 14");

	if (m_Nclock)
	{
		CRect fullRc = GetFullRect(), clockRc;
		int	x = m_axis->GetProfileInt(INFORMATION, "clock_x", 0);
		int	y = m_axis->GetProfileInt(INFORMATION, "clock_y", 0);

		m_Nclock->GetClientRect(&clockRc);
		clockRc.OffsetRect(x, y);

		clockRc.IntersectRect(clockRc, fullRc);
		if (clockRc.IsRectEmpty())
		{
			x = y = 0;
		}

		if (m_axis->GetProfileInt(INFORMATION, "clock_visible", 0))
			m_Nclock->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOACTIVATE);
		else	
			m_Nclock->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_HIDEWINDOW|SWP_NOSIZE);

		if (m_axis->GetProfileInt(INFORMATION, "clock_mini", 0))
			m_Nclock->SetMini(TRUE);
	}

	WriteLog("endWorkstation - Step 15");
#ifdef NDEBUG
	PostMessage(WM_ELOG);
	if (!m_bCustomer && m_accTool)
		m_accTool->ShowWindow(SW_SHOW);
#endif

	SetForegroundWindow();

	WriteLog("endWorkstation - Step 16");

	CChildFrame*	child = NULL;
	child = load_hidescreen(MAPN_SISECATCH1);
	m_arHide.Add(child);

	WriteLog("endWorkstation - Step 17");

	m_winVer = m_cpu.GetPlatform();	

	m_bar2->ShowInformation();

	WriteLog("endWorkstation - Step 19");	

	if (! m_bdnInterest)
	{	
		const char* trust = "IB770000";
		m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
	}	

	WriteLog("endWorkstation - Step 20");
	
	ProcessInitMap();	

	WriteLog("endWorkstation - Step 21");

	CreateHistoryBar();
	
	SetTimer(TM_INITSIZE, 1000, NULL);
}

void CMainFrame::signOn()
{
	/*
	::MessageBox(m_axConnect->m_hWnd,"KRX(�ѱ��ŷ���) ������ �ý��� �������� ���� ��� ���� �̿��� ���ѵ˴ϴ�.\n���� �Ͻ�: 3�� 21(��) 20:00 ~ 3�� 23��(��) 07:00", "IBK��������", MB_OK);
	
	if (Axis::isCustomer)
	{
		PostMessage(WM_CLOSE);
		return;
	}
	*/

	//SetEncriptFile();
	m_axConnect->SetGuide(_T("��������� Ȯ�� �� �Դϴ�."));

	BOOL	rc = FALSE;
	CString	str;
	char	wb[128], encPass[10];

	ZeroMemory(encPass, sizeof(encPass));
	struct	_signM {
		char	user[12];
		char	pass[10];
		char	dats[10];
		char	cpas[30];
		char	uips[15];
		char	madr[16];
	} signM;


	m_step = axOPENSIGN;
	Axis::userID = m_axConnect->GetUserID();
	m_pass = m_axConnect->GetPassword();
	m_cpass  = m_axConnect->GetCPass();

// 	CString cpass;
// 	cpass.Format("%s%c",m_cpass,'0x00');
// 	
// 	m_cpass = cpass;

	CopyMemory(encPass, m_pass, m_pass.GetLength());
//#ifndef	ENCTEST
//	if (false && m_connectBy == byTCP)
//#endif
	{
		long	ret = 0;
		sprintf(wb, "%s\t%s", m_pass, Axis::userID);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
					(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(encPASS, modeUID), (LPARAM) wb);
		CString ss = (char *) ret;
		memset(encPass, ' ', sizeof(encPass));
		CopyMemory(encPass, ss, ss.GetLength());
	}
	str = m_axConnect->GetSignInfo();
	
	m_axConnect->SetProgress(false);
	m_axConnect->SetStatus(SM_WSH);
	m_axConnect->SetChoice(false);

	//ZeroMemory(&signM, sizeof(struct _signM));
	memset(&signM, ' ', sizeof(struct _signM));
	CopyMemory(signM.user, Axis::userID, Axis::userID.GetLength());
	CopyMemory(signM.pass, encPass, sizeof(encPass));
	CopyMemory(signM.dats, str, str.GetLength());
	CopyMemory(signM.cpas, m_cpass, m_cpass.GetLength());
	//�����������(AXCERTIFY.OCX) ���� �� �ι��� �������� �߰�
	signM.cpas[m_cpass.GetLength()] = '\0';

	if (m_ipAddr.IsEmpty())
	{
		GetLocalIP();
	}
	//**AfxMessageBox(m_ipAddr);
	CopyMemory(signM.uips, m_ipAddr, m_ipAddr.GetLength());
	
	char	macaddr[20], ip[16];
	memset(macaddr, 0x00, sizeof(macaddr));
	memset(ip, 0x00, sizeof(ip));
	memcpy(ip, signM.uips, sizeof(signM.uips));

	GetMacAddr(ip, macaddr);
	memcpy(signM.madr, macaddr, strlen(macaddr));

	int nBytes = sizeof(_signM);
	CopyMemory(wb, (char *)&signM, nBytes);
	wb[nBytes] = '\0';

	if (m_ip.IsEmpty())
	{
		CString glbip(get_glb_addr(macaddr, ip));
		if (!glbip.IsEmpty())
			m_ip = glbip;
	}

	memcpy(signM.uips, (const char*)m_ip, m_ip.GetLength());
	
	m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), signUSER, (long)wb, nBytes);

	if (!rc)
	{
		m_step = axNONE;
		m_axConnect->SetChoice(true);
		m_axMisc->GetGuide(AE_ESIGNON, str);
		m_axConnect->SetGuide(str);
	}
}

void CMainFrame::setTitle(int key, CString title)
{
	CString	mapN = _T("");
	int	pos = title.Find('\t');
	if (pos != -1)
	{
		mapN = title.Left(pos++);
		title = title.Mid(pos);
	}

	if (key & winK_POPUP)
	{
		if (!m_arMPOP.IsEmpty())
		{
			CMPop*	Mpop;
			if (m_arMPOP.Lookup(key, Mpop))
			{
				if (!mapN.IsEmpty())
					Mpop->m_mapN = mapN;
				SetSCN((CWnd*) Mpop, key, Mpop->m_mapN, title);
				return;
			}
		}

		CGPop* Gpop;
		if (!m_arGPOP.Lookup(key, Gpop))	return;
		SetSCN((CWnd*) Gpop, key, Gpop->m_mapN, title);
	}
	else
	{
		bool		match = false;
		CSChild*	schild;
		CChildFrame*	child;
		
		for (int vsN = V_SCREEN1; vsN <= V_SCREEN6 && !match; vsN++)
		{
			if (!m_arMDI[vsN].Lookup(key, child))
				continue;
			
			match = true;
			if (!mapN.IsEmpty())
			{
				child->SetMapName(axiscall, mapN);
				m_bar1->set_Maps(mapN);
				m_bar2->change_Info(key, mapN, m_tMenu);
				
				if (!ExistMenu(mapN))
				{
					CString	string = child->m_xcaption.GetTitle();
					m_bar2->change_ButtonText(key, string, vsN);
				}
				/*
				if ((CString(child->m_mapN).Mid(0,6) == "IB7700") && (CString(child->m_mapN).Mid(0,8) != "IB770000"))
				{
					if (!ExistMenu(mapN.Left(L_MAPN)))
					{
						CString	string = child->m_xcaption.GetTitle();
						m_bar2->change_ButtonText(key, string, vsN);
					}
				}else{
					if (!ExistMenu(mapN.Left(L_MAPN-2)+"00"))
					{
						CString	string = child->m_xcaption.GetTitle();
						m_bar2->change_ButtonText(key, string, vsN);
					}
					
				}
				*/
				
			}
			SetSCN((CWnd*) child, key, child->m_mapN, title);
		}

		if (!match)
		{
			for (vsN = V_SCREEN1; vsN <= V_SCREEN6 && !match; vsN++)
			{
				if (!m_arSDI[vsN].Lookup(key, schild))
					continue;
				match = true;
				SetSCN((CWnd*) schild, key, schild->m_mapN, title, true);
			}
		}
	}
}

void CMainFrame::SetSCN(CWnd* wnd, int key, CString mapN, CString title, bool bSDI)
{
	if (!wnd->GetSafeHwnd() || title.IsEmpty())
		return;

	title.TrimLeft();

	CString orgTitle(title);

	CString mapTitle(m_tMenu->GetDesc(mapN));
	CString tmp;
	CString sc_gb(_T(""));
	//AfxMessageBox(m_tMenu->GetDesc(mapN));
	if (!Axis::isCustomer) sc_gb = " - ������";
	//if (Axis::devMode == true) tmp = "(���߿�) ";
	if (Axis::devMode) tmp = "(���߿�) ";
	
	if (mapTitle.Left(6) != mapN.Left(6))
		title = Format("[%s] "+tmp+"%s", m_tMenu->GetDispN(mapN), m_tMenu->GetDesc(mapN));
	title += sc_gb;
	if (WK_NORM <= key && key < WK_POPUP)
	{
		if (bSDI)
			((CSChild*)wnd)->m_xcaption.SetTitle(title);
		else	
			((CChildFrame*)wnd)->m_xcaption.SetTitle(title);
	}
	else
	{
		wnd->SetWindowText(orgTitle);
	}

	CString	mpN = m_tMenu->GetDispN(mapN);

	if (m_tMenu->IsMappinged(mapN))
	{
		long	rc = 0;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setSCN, key), (LPARAM)(const char*)mpN);
	}
}

int CMainFrame::create_Newview(int actkey, char* data)
{
	int	 key, position;
	CString	 mapN;
	CPoint	 point;
	_userWH* userWH;
	
	userWH = (struct _userWH *)data;
	mapN   = CString(userWH->maps);
	
	if (ExceptionProcess(mapN))	return 1;
	if (userWH->pos.x == -1)
		position = userWH->pos.y;
	else	position = -1;
	point = CPoint(userWH->pos.x, userWH->pos .y);

	switch (userWH->type)
	{
	case typeVIEW:
		key = m_mapHelper->CreateChild(mapN, userWH->group, userWH->key, position, point);
		if (position != -1)	
			positionWindow(actkey, key, position);
		return key;
	case typeMODAL:
		return m_mapHelper->CreateModal(mapN, userWH->group, userWH->key, position, actkey, point);
	case typePOPUP:
		return m_mapHelper->CreatePopup(mapN, userWH->group, userWH->key, position, actkey, point);
	case typePOPUPX:
		return m_mapHelper->CreatePopup(mapN, userWH->group, userWH->key, position, actkey, point, true);
	case typePOPUPXN:
		return m_mapHelper->CreatePopup(mapN, userWH->group, userWH->key, position, actkey, point, true, true);
	}
	return 0;
}

void CMainFrame::loadMap(int key, int size)
{
	if (!m_modal)	return;
	key = m_modal->m_vwKEY;
	m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_modal->m_wnd, m_modal->m_vwTYPE, key);
	m_modal->m_vwKEY = key;
	m_arMPOP.SetAt(key, m_modal);
 
	if (m_modal->m_wpos >= CenterPOS)
		positionWindow(m_modal->m_actW, m_modal, m_modal->m_wpos, false);

	BOOL	rc = FALSE;
	m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, m_modal->m_mapN, size, false/*true*/);
	if (!rc)	m_modal->PostMessage(WM_CLOSE, 0, 0);
}

void CMainFrame::Setfocus_Child(int key,bool bVS)
{
// 	CChildFrame*	child;
// 	m_activeKey = key;
// 	if (!m_arMDI[m_vsN].Lookup(key, child))
// 	{
// 		CSChild*	schild;
// 		if (m_arSDI[m_vsN].Lookup(key, schild))
// 		{
// 			if (schild->m_bIconic)
// 				schild->PostMessage(WM_SYSCOMMAND, SC_RESTORE);//actionSCaption(schild->m_key, IDX_RESTORE);
// 			else	
// 				schild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
// 		}
// 	}
// 	else
// 	{
// 		if (child->m_bIconic)
// 			child->actionCaption(IDX_RESTORE, CPoint(0, 0));
// 		else	
// 			child->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
// 	}

	CChildFrame*	child;
	BOOL bTabChange = FALSE;

	if(bVS == FALSE)
	{
		if(m_activeKey != key)
		{
			bTabChange = TRUE;
		}
	}
	else
	{
		bTabChange = TRUE;
	}

	m_activeKey = key;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild*	schild;
		CRect wRc;
		if (m_arSDI[m_vsN].Lookup(key, schild))
		{
			if (schild->m_bIconic)
			{
				schild->PostMessage(WM_SYSCOMMAND, SC_RESTORE);//actionSCaption(schild->m_key, IDX_RESTORE);
			}
			else	
			{
				if(bTabChange != TRUE)
				{
					//�ּ�ȭ ���¿��� �ٽ� �����ϰ� ����
					CPoint sp(-1, -1);

					if (!schild->m_xcaption.IsMax())
					{
						schild->GetWindowRect(wRc);
						schild->m_restoreRc.CopyRect(&wRc);
					}

					schild->PostMessage(WM_SYSCOMMAND, SC_MINIMIZE);
				}
				else
				{
					schild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
				}
				schild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
			}
		}
	}
	else
	{
// 		CString s;
// 		s.Format("[MAPNAME:%s]\n",child->m_mapN);
// 		OutputDebugString(s);
		if (child->m_bIconic)
		{
			child->actionCaption(IDX_RESTORE, CPoint(0, 0));
		}
		else	
		{	
			if(bTabChange != TRUE)
			{
				//�ּ�ȭ ���¿��� �ٽ� �����ϰ� ����
				CPoint sp(-1, -1);

				sp = getMinimizePos(child->m_key);
				child->actionCaption(IDX_MIN, sp);
				MDINext();
			}
			else
			{
				child->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
			}
			child->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		}
	}
}

void CMainFrame::showfname()
{
	if (!Axis::devMode && !IsSuperUser())	
		return;

	CFname	dlg;
	if (dlg.DoModal() == IDOK)
	{
		CString mapN = dlg.GetMapName();
		if (mapN.GetLength() == L_MAPN)
			m_mapHelper->ChangeChild(mapN);
	}
}

void CMainFrame::WriteFile(char* pBytes, int nBytes)
{
#if 0
	CFile		Dfile;
	DWORD		pos;
	CString		filename, time;

	filename.Format("%s\\log", Axis::home);
	BOOL bExist = Dfile.Open(filename, CFile::modeReadWrite);//CFile::modeCreate|CFile::modeReadWrite);
	if (!bExist)
	{
		Dfile.Open(filename, CFile::modeCreate|CFile::modeReadWrite);
		Dfile.Write(pBytes, nBytes);
	}
	else
	{
		pos = Dfile.SeekToEnd();
		Dfile.Seek((long) pos, CFile::begin);
		Dfile.Write(pBytes, nBytes);
	}
	Dfile.Close();
#endif
}

void CMainFrame::write_err()
{
	CString	err;
	DWORD	dw = GetLastError();
	err.Format("[GDI_ERROR] [%u]\n", dw);
	WriteFile((char *)(const char*)err, err.GetLength());
}

void CMainFrame::update_ticker(int kind, struct _alertR* alertR)
{
	CString s;
// 	s.Format("FEV_ANM : %s\n",alertR->code);
// 	OutputDebugString(s);

	CString symbol;

	symbol = alertR->code;

// 	s.Format("FEV_ANM : %s\n",symbol);
// 	OutputDebugString(s);

	DWORD* data;

	for(int i=0;i<alertR->size;i++)
	{
		data = (DWORD*)alertR->ptr[i];

		CString	str;
		if (!symbol.IsEmpty() && (symbol.GetAt(0) == 'X' || symbol.GetAt(0) == 'x'))
		{
			// 		OutputDebugString("================================================================\n");
			// 		OutputDebugString(dat);
			// 		OutputDebugString("\n");
			// 		OutputDebugString("================================================================\n");
			
			// �������� ���� �߰�
			if (symbol.CompareNoCase(SYM_MNG) == 0)
			{
				//#ifdef	_DEBUG
				//CTime time;
				//time = CTime::GetCurrentTime();
				//TRACE("update_ticker[%02d:%02d:%02d] kind[%d] sym[%s] dat[%.200s]\n", time.GetHour(), time.GetMinute(), time.GetSecond(), kind, symbol, dat);
				//#endif
				ShowMngInfo(data);
				return;
			}
			else
			{
				str = ReplaceExpectSymbol(symbol);
				if (!str.IsEmpty())
					symbol = str;
			}
		}
		if (symbol == "DRQNA")	// ôô�ڻ�
		{
			ShowDoctorInfo(data);
			return;
		}
		//tmps = dat.Mid(pos);
		
		if (kind != 0)
		{
			if (kind == 6)
			{
				const char* szNewsRTS = "S0000";
				
				
				if (m_tInfo1)	
					m_tInfo1->ProcessRTS(szNewsRTS, data);
				if (m_tInfo2)	
					m_tInfo2->ProcessRTS(szNewsRTS, data);
			}
			return;
		}
		//TRACE("%s\t%s\n",symbol,dat);
		// RTS process
		if (m_tInfo1)	
			m_tInfo1->ProcessRTS(symbol, data);
		if (m_tInfo2)	
			m_tInfo2->ProcessRTS(symbol, data);
	}
}

void CMainFrame::update_ticker(int kind, CString dat)
{
	CString	symbol, tmps;
	int	pos = dat.Find('\t');
	//TRACE(dat+"\n");	
	symbol = dat.Left(pos++);
// 	CString s;
// 	s.Format("FEV_ANM : %s	%s\n",symbol,dat);
// 	OutputDebugString(s);

	CString	str;
	if (!symbol.IsEmpty() && (symbol.GetAt(0) == 'X' || symbol.GetAt(0) == 'x'))
	{
// 		OutputDebugString("================================================================\n");
// 		OutputDebugString(dat);
// 		OutputDebugString("\n");
// 		OutputDebugString("================================================================\n");

		// �������� ���� �߰�
		if (symbol.CompareNoCase(SYM_MNG) == 0)
		{
//#ifdef	_DEBUG
//CTime time;
//time = CTime::GetCurrentTime();
//TRACE("update_ticker[%02d:%02d:%02d] kind[%d] sym[%s] dat[%.200s]\n", time.GetHour(), time.GetMinute(), time.GetSecond(), kind, symbol, dat);
//#endif
			ShowMngInfo(dat.Mid(pos));
			return;
		}
		else
		{
			str = ReplaceExpectSymbol(symbol);
			if (!str.IsEmpty())
				symbol = str;
		}
	}
	if (symbol == "DRQNA")	// ôô�ڻ�
	{
		ShowDoctorInfo(dat.Mid(pos));
		return;
	}
	tmps = dat.Mid(pos);

	if (kind != 0)
	{
		if (kind == 6)
		{
			const char* szNewsRTS = "S0000";
			
			
			if (m_tInfo1)	
				m_tInfo1->ProcessRTS(szNewsRTS, dat);
			if (m_tInfo2)	
				m_tInfo2->ProcessRTS(szNewsRTS, dat);
		}
		return;
	}
	//TRACE("%s\t%s\n",symbol,dat);
	// RTS process
	if (m_tInfo1)	
		m_tInfo1->ProcessRTS(symbol, tmps);
	if (m_tInfo2)	
		m_tInfo2->ProcessRTS(symbol, tmps);
}

void CMainFrame::show_Newslist(WPARAM wParam, LPARAM lParam)
{
	int	id = LOWORD(wParam);
	CPoint	point = CPoint(HIWORD(lParam), LOWORD(lParam));

//	m_news->SetList(id, Axis::user, point);
}

void CMainFrame::ShowNews()
{
	m_mapHelper->CreateChild("IB771000", 0);	
}

void CMainFrame::change_Skin()
{
	Axis::SetSkin(GetSkinName());

	// ���ҽ� ���ε� 
	Axis::ReloadSkin();

	ChangeLogo();
	m_bitmapBtn->Invalidate();

	DrawFrame();
	change_BackGround();
	change_Resource();

	if (m_conclusion)	
		m_conclusion->ChangePalette();
	if (m_kobanotify)
		m_kobanotify->ChangePallete();
	if (m_Econclusion)	
		m_Econclusion->ChangePalette();
	if (m_mngInfo)		
		m_mngInfo->ChangePalette();
	if (m_pDoctor)		
		m_pDoctor->ChangePalette();

	m_bar0->change_BandInfo();
	m_bar1->Change_Skin(Axis::skinName);
	m_bar2->Change_Skin(Axis::skinName);
//	m_bar3->Change_Skin(Axis::skinName);
	m_smain->Change_Skin(Axis::skinName);

	//m_logodlg->	
	
	long	rv = 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, 
				(void *)&rv, (BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setPAL, 0), 0);

	//load_start_notice( true );
}

void CMainFrame::change_VirtualScreen(int index)
{
	if (index == m_vsN)	return;

	displayChild(m_vsN, false);
	displayChild(m_vsN, false, true);

	m_vsN = index;

	m_activeKey = 0;

	m_bar2->change_VirtualScreen(index);
	m_smain->change_VirtualScreen(index);
	
	displayChild(m_vsN, true);
	displayChild(m_vsN, true, true);

	long	rc = 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setVID, 0), MAKELONG(0, index));

	OnNcPaint();
}

void CMainFrame::change_BackGround()
{
	m_MClient->change_Color(Axis::skinName, m_resourceHelper->GetColor(-1));
}

void CMainFrame::set_Trigger(int key, int triggerN)
{
	set_Trigger(key, triggerN, m_vsN);	
}

void CMainFrame::set_Trigger(int key, int triggerN, int vsN)
{
	if (vsN == -1)	vsN = m_vsN;
	int		ret, group = triggerN;
	CChildFrame*	child;

	if (!m_arMDI[vsN].Lookup(key, child))	
		return;

	child->m_xcaption.SetGroup(triggerN);

	if (triggerN == ALL_GROUP)
		group = -1;

	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
			(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, group));

	child->m_xcaption.SetGroup(triggerN);
	child->PostMessage(WM_NCPAINT, 1, 0);

// 	CString s;
// 	s.Format("MAP NAME : %s	GROUP : %d\n",child->m_mapN,triggerN);
// 	OutputDebugString(s);
	CString strGroup;
	strGroup.Format("%d",triggerN);
 	m_groupBymapN.SetAt(child->m_mapN,strGroup);

	//m_groupBymapN.SetAt(child->m_mapN,triggerN);
}

void CMainFrame::set_STrigger(int key, int triggerN, int vsN)
{
	if (vsN == -1)	vsN = m_vsN;
	int		ret, group = triggerN;

	CSChild*	child;
	if (m_arSDI[vsN].Lookup(key, child))
	{
		child->m_xcaption.SetGroup(triggerN);
		if (triggerN == ALL_GROUP)
			group = -1;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
				(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, group));

		child->m_xcaption.SetGroup(triggerN);

		CString strGroup;
		strGroup.Format("%d",triggerN);
 		m_groupBymapN.SetAt(child->m_mapN,strGroup);
		//m_groupBymapN.SetAt(child->m_mapN,triggerN);
	}
}

void CMainFrame::restore(int key)
{
	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))	
		return;

	child->SetWindowPos(NULL, 0, 0, child->GetSize().cx, child->GetSize().cy, SWP_NOMOVE);
}

bool CMainFrame::sendTR(char* datB, int datL)
{
	BOOL	rc = FALSE;
	m_wizard->InvokeHelper(DI_TRX, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), (long)datB, datL);

	return (rc ? true : false);
}

bool CMainFrame::sendTR(CString trN, char* datB, int datL, BYTE stat, int key)
{
	if (datL <= 0)	return false;

	char*	wb;
	BOOL	rc  = FALSE;
	struct	_userTH* userTH;

	wb = new char[L_userTH+datL+1];
	ZeroMemory(wb, L_userTH+datL+1);
	userTH = (struct _userTH *)wb;
	CopyMemory(userTH->trc, (char *)(const char*)trN, trN.GetLength());
	
	userTH->stat = stat;	
	userTH->key  = key;
	CopyMemory(&wb[L_userTH], datB, datL);

	m_wizard->InvokeHelper(DI_TRX, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), (long)wb, datL);
	delete[] wb;

	return (rc ? true : false);
}

void CMainFrame::positionWindow(int actkey, int poskey, int pos, bool child)
{
	CWnd* posW;
	if (pos < LtopPOS)	return;
	if (!m_arMDI[m_vsN].Lookup(poskey, (CChildFrame *&) posW))
		return;
	positionWindow(actkey, posW, pos, child);
}

void CMainFrame::positionWindow(int actkey, CWnd* posW, int pos, bool child)
{
	CWnd* actW = NULL;

	if (pos < LtopPOS || (actkey == 0 && pos > CenterPOS))
	{
		posW->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE);
		return;
	}

	if (actkey & 0x80)	;
	else	m_arMDI[m_vsN].Lookup(actkey, (CChildFrame *&) actW);

	if (!actW && pos > CenterPOS)
	{
		posW->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_SHOWWINDOW|SWP_NOSIZE);
		return;
	}
	positionWindow(actW, posW, pos, child);
}

void CMainFrame::positionWindow(CWnd* actW, CWnd* posW, int pos, bool child)
{
	if (pos < LtopPOS || !posW || !::IsWindow(posW->GetSafeHwnd()))
		return;

	CRect	rect, clientRc;
	CPoint	point;

	switch (pos)
	{
	case LtopPOS:case RtopPOS:case LbottomPOS:case RbottomPOS:case CenterPOS:
	case LtopLup:case LtopRup:case LtopLdown:case LtopRdown:case RtopLup:
	case RtopRup:case RtopLdown:case RtopRdown:case LbottomLup:case LbottomRup:
	case LbottomLdown:case LbottomRdown:case RbottomLup:case RbottomRup:case RbottomLdown:
	case RbottomRdown:case CenterView:	break;
	default:pos = CenterPOS;		break;
	}

	if (actW)
	{
		actW->GetWindowRect(&rect);
		if (child)
			m_MClient->ScreenToClient(&rect);
	}

	switch (pos / 10)
	{
	case 0:
		posW->GetWindowRect(&rect);
		if (child)	m_MClient->GetClientRect(&clientRc);
		else		m_MClient->GetWindowRect(&clientRc);

		switch (pos)
		{
		case LtopPOS:
			point.x = clientRc.left;
			point.y = clientRc.top;
			break;

		case RtopPOS:
			point.x = clientRc.right - rect.Width();
			point.y = clientRc.top;
			break;

		case LbottomPOS:
			point.x = clientRc.left;
			point.y = clientRc.bottom - rect.Height();
			break;

		case RbottomPOS:
			point.x = clientRc.right - rect.Width();
			point.y = clientRc.bottom - rect.Height();
			break;

		case CenterPOS:
		default:
			posW->CenterWindow(m_MClient);
			return;
		}
		//posW->ShowWindow(SW_HIDE);
		posW->MoveWindow(point.x, point.y, rect.Width(), rect.Height());
		
		return;

	case 9:	// CenterView
		posW->CenterWindow(actW);
		return;

	case 1:	// Ltop
		point = CPoint(rect.left,  rect.top);		break;
	case 2:	// Rtop
		point = CPoint(rect.right, rect.top);		break;
	case 3:	// Lbottom
		point = CPoint(rect.left,  rect.bottom);	break;
	case 4:	// Rbottom
		point = CPoint(rect.right, rect.bottom);	break;
	}

	posW->GetWindowRect(&rect);
//	m_axMDIClient->ScreenToClient(&rect);
	switch (pos % 10)
	{
	case 1:	// Lup
		point.x -= rect.Width();
		point.y -= rect.Height();	break;

	case 2:	// Rup
		point.y -= rect.Height();	break;

	case 3:	// Ldown
		point.x -= rect.Width();	break;

	case 4:	// Rdown
		break;
	}

	if (child)	
		posW->MoveWindow(point.x, point.y, rect.Width(), rect.Height());
	else		
		posW->SetWindowPos(NULL, point.x, point.y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_SHOWWINDOW);
}

bool CMainFrame::Agree_Duplication(CString mapN,bool bDup)
{
	int		key;
	POSITION	pos;
	WINDOWPLACEMENT	pl;
	if (m_bSDI)	
		return !FindSDIMap(mapN);
	else
	{
		CChildFrame*	pChild;
		for (pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
		{
			m_arMDI[m_vsN].GetNextAssoc(pos, key, pChild);
			if (getSMap(pChild->m_mapN.Left(L_MAPN)) != getSMap(mapN.Left(L_MAPN)))
				continue;
			if (IsAgreeDuplicate(mapN.Left(L_MAPN)))
				continue;
			if (IsSelectMap(mapN))	loadDomino(pChild->m_key,  mapN);

			if (m_screenNew && bDup == false)
			{
				int		value;
				long		rc = 0;
				CRect		sdiRc, mdiRc;
				CPoint		sp(-1, -1);
				CString		mapname;
				WINDOWPLACEMENT	pl;

				pChild->GetWindowPlacement(&pl);
				value = GetSystemMetrics(SM_CYCAPTION);
				value += GetSystemMetrics(SM_CXFRAME);
				value += GetSystemMetrics(SM_CXBORDER);
				sp = CPoint(pl.rcNormalPosition.left, pl.rcNormalPosition.top);
				sp.Offset(value, value);
				
// 				value = pChild->m_xcaption.GetGroup();
// 				switch (value)
// 				{
// 				case 0:/*none group*/
// 				case 99:/*all group*/	break;
// 				case 1:case 2: case 3:case 4: case 5:
// 					value++;
// 					if (value > 5)	value = 1;
// 					break;
// 				default:	
// 					value = 1;	break;
// 				}		
				CString strValue = "";
				
				if(!m_groupBymapN.Lookup(pChild->m_mapN,strValue))
				{
					strValue = 1;
				}
				
				if(strValue == "")
				{
					strValue = 1;
				}
				
// 				CString s;
// 				s.Format("RUN MAP NAME : %s	GROUP : %d\n",pChild->m_mapN,strValue);
// 				OutputDebugString(s);
				
				value = atoi(strValue);
				
				if(value == 5)
				{
					value = 1;
				}
				else
				{
					value += 1;
				}

				m_mapHelper->CopyScreen(pChild->m_mapN, value, pChild->m_xcaption.GetFontSize(), sp);
				return false;
			}
		
			pChild->GetWindowPlacement(&pl);
			if (pl.showCmd & SW_SHOWMINIMIZED)
			{
				pl.showCmd = SW_RESTORE;
				pChild->SetWindowPlacement(&pl);
			}
			else
			{
				if ((CString(mapN).Mid(0,6) == "IB7700") && (CString(mapN).Mid(0,8) != "IB770000"))
					return false;
				CString	data = mapN.Mid(L_MAPN);
				if (!data.IsEmpty())
				{
					while (!data.IsEmpty())
					{
						CString	dat;
						int	po = data.Find('\n');
						if (po == -1)
						{
							dat = data;
							data.Empty();
						}
						else
						{
							dat = data.Left(po++);
							data = data.Mid(po);
						}

						m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
						(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)dat);
					}
				}
				pChild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
			}
			return false;
		}

		if (FindSDIMap(mapN))	
			return false;
	}

	return true;
}

// bool CMainFrame::Agree_Duplication(CString mapN)
// {
// 	CString s;
// 	s.Format("RUN MAP NAME : %s		%d\n",mapN,m_vsN);
// 	OutputDebugString(s);
// 	int		key;
// 	POSITION	pos;
// 	WINDOWPLACEMENT	pl;
// 	CPoint		sp(-1, -1);
// 	if (m_bSDI)	
// 		return !FindSDIMap(mapN);
// 	else
// 	{
// 		OutputDebugString("PROCESS====================\n");
// 		CChildFrame*	pChild;
// 		for (pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
// 		{
// 			OutputDebugString("PROCESS11====================\n");
// 			m_arMDI[m_vsN].GetNextAssoc(pos, key, pChild);
// 			OutputDebugString("PROCESS22====================\n");
// 			if (getSMap(pChild->m_mapN.Left(L_MAPN)) != getSMap(mapN.Left(L_MAPN)))
// 				continue;
// 			OutputDebugString("PROCESS33====================\n");
// 			if (IsAgreeDuplicate(mapN.Left(L_MAPN)))
// 				continue;
// 			OutputDebugString("PROCESS44====================\n");
// 			if (IsSelectMap(mapN))	loadDomino(pChild->m_key,  mapN);
// 
// 			s.Format("RUN MAP NAME 2: %s\n",mapN);
// 			OutputDebugString(s);
// 
// 			if (m_screenNew)
// 			{
// 				if (pl.showCmd & SW_SHOWMINIMIZED)
// 				{
// 
// 				}
// 				else
// 				{
// 					int		value;
// 					long		rc = 0;
// 					CRect		sdiRc, mdiRc;
// 					//CPoint		sp(-1, -1);
// 					CString		mapname;
// 					WINDOWPLACEMENT	pl;
// 
// 					pChild->GetWindowPlacement(&pl);
// 					value = GetSystemMetrics(SM_CYCAPTION);
// 					value += GetSystemMetrics(SM_CXFRAME);
// 					value += GetSystemMetrics(SM_CXBORDER);
// 					sp = CPoint(pl.rcNormalPosition.left, pl.rcNormalPosition.top);
// 					sp.Offset(value, value);
// 				}				
// 			}
// 			else
// 			{
// 				if (pl.showCmd & SW_SHOWMINIMIZED)
// 				{
// 					pl.showCmd = SW_RESTORE;
// 					pChild->SetWindowPlacement(&pl);
// 				}
// 				else
// 				{
// 					if ((CString(mapN).Mid(0,6) == "IB7700") && (CString(mapN).Mid(0,8) != "IB770000"))
// 						return false;
// 					CString	data = mapN.Mid(L_MAPN);
// 					if (!data.IsEmpty())
// 					{
// 						while (!data.IsEmpty())
// 						{
// 							CString	dat;
// 							int	po = data.Find('\n');
// 							if (po == -1)
// 							{
// 								dat = data;
// 								data.Empty();
// 							}
// 							else
// 							{
// 								dat = data.Left(po++);
// 								data = data.Mid(po);
// 							}
// 
// 							m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
// 							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)dat);
// 						}
// 					}
// 					pChild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
// 				}
// 				return false;
// 			}
// 		}
// 
// 		if(m_screenNew)
// 		{
// 			CString strValue = "";
// 			int		value;
// 			
// 			if(!m_groupBymapN.Lookup(pChild->m_mapN,strValue))
// 			{
// 				strValue = 1;
// 			}
// 			
// 			if(strValue == "")
// 			{
// 				strValue = 1;
// 			}
// 			
// 			value = atoi(strValue);
// 			
// 			if(value == 5)
// 			{
// 				value = 1;
// 			}
// 			else
// 			{
// 				value += 1;
// 			}
// 			
// 			m_mapHelper->CopyScreen(pChild->m_mapN, value, pChild->m_xcaption.GetFontSize(), sp);
// 			return false;
// 		}
// 
// 		if (FindSDIMap(mapN))	
// 			return false;
// 	}
// 
// 	return true;
// }

bool CMainFrame::select_SName(CString input)
{
	CStringArray	array;
	if (!m_tMenu)		
		return false;

	if (m_tMenu->GetSelectList(input, array))
	{
		m_bar1->set_List(array);
		m_smain->set_List(array);
		return true;
	}

	CString	msg;
	msg.LoadString(ST_MSG_NOTHING_SELECTED);
	displayGuide(msg);
	return false;
}

void CMainFrame::changeSize(int key, CSize size)
{
	if (size.cx == 0 && size.cy == 0)	
		return;

	int	nCx, nCy, gapX, gapY, viewType;
	/**
	gapX  = GetSystemMetrics(SM_CXFRAME) * 2;
	gapX += GetSystemMetrics(SM_CXBORDER) * 2;

	gapY  = GetSystemMetrics(SM_CYFRAME) * 2;
	gapY += GetSystemMetrics(SM_CYBORDER) * 2;
	**/
	gapX = 5 * 2 - 4;
	//**gapY = CAPTION_HEIGHT + 5 * 2;
	gapY = CAPTION_HEIGHT + 4;

	m_fit = true;
	if (key & winK_POPUP)
	{
		CMPop*	Mpop;
		CGPop*	Gpop;
		if (m_arMPOP.Lookup(key, Mpop))
		{
			if ((Mpop->m_vwTYPE & vtypeMSK) ==vtypeWND)
				Mpop->ModifyStyle(WS_CAPTION, 0, SWP_NOZORDER|SWP_DRAWFRAME);
			else	
				gapY += GetSystemMetrics(SM_CYCAPTION);

			nCx = size.cx + GetSystemMetrics(SM_CXFRAME) * 2;
			nCy = size.cy + GetSystemMetrics(SM_CYFRAME) * 2;
			nCy += GetSystemMetrics(SM_CYCAPTION);
			Mpop->SetSize(size.cx, size.cy);
			if (Mpop->GetSafeHwnd())
				Mpop->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
		}
		else if (m_arGPOP.Lookup(key, Gpop))
		{
			if ((Gpop->m_vwTYPE & vtypeMSK) == vtypeWND)
				Gpop->ModifyStyle(WS_CAPTION, 0, SWP_DRAWFRAME);
			else	
				gapY += GetSystemMetrics(SM_CYCAPTION);

			nCx = size.cx;// + gapX;
			nCy = size.cy;// + gapY;
			Gpop->SetSize(nCx, nCy);
			Gpop->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
		}
		return;
	}
	/*
	CString tmp; tmp.Format("%d, %d", size.cx, size.cy);
	AfxMessageBox(tmp);
	*/

	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild*	schild;
		if (!m_arSDI[m_vsN].Lookup(key, schild))
			return;

		if (schild->IsTabView())	
			gapY +=	TABH;

		gapY -= 6;

		viewType = schild->m_vwTYPE & vtypeMSK;
		if (viewType == vtypeRSZ)
		{
			if (size.cx == 0)
			{
				
				nCy = size.cy + gapY;
				schild->SetSize(schild->GetSize().cx, nCy);
				schild->m_fixW = true;
				schild->m_fixH = false;
			}
			else if (size.cy == 0)
			{
				nCx = size.cx + gapX;
				schild->SetSize(nCx, schild->GetSize().cy);
				schild->m_fixW = false;
				schild->m_fixH = true;
			}
			else
			{
				nCx = size.cx + gapX;
				nCy = size.cy + gapY;
				schild->SetSize(nCx, nCy);
			}
		}
		else
		{
			nCx = size.cx + gapX;
			nCy = size.cy + gapY+4;
			schild->SetSize(nCx, nCy);
		}

		CView*	view = schild->GetActiveView();
		schild->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
		if (viewType == vtypeSCR)
			((CAxScrollView *)view)->SetSizeView(size.cx, size.cy);
		if (schild->IsTabView())	
			((CAxTabView *) view)->SizeWindow(size);
		return;
	}

	if (child->IsTabView())	
		gapY +=	TABH;

	viewType = child->m_vwTYPE & vtypeMSK;
	if (viewType == vtypeRSZ)
	{
		/*
		CString tmp; tmp.Format("%d, %d", size.cx, size.cy);
		AfxMessageBox(tmp);
		*/
		if (size.cx == 0)
		{
			nCx = child->GetSize().cx;
			nCy = size.cy + gapY;
			child->SetSize(nCx, nCy);
			child->m_fixW = true;
			child->m_fixH = false;
		}
		else if (size.cy == 0)
		{
			nCx = size.cx + gapX;
			nCy = child->GetSize().cy;
			child->SetSize(nCx, nCy);
			child->m_fixW = false;
			child->m_fixH = true;
		}
		else
		{
			nCx = size.cx + gapX;
			nCy = size.cy + gapY;
			//nCx = size.cx + 2;
			//nCy = size.cy + CAPTION_HEIGHT + 4;
			child->SetSize(nCx, nCy);
		}
	}
	else
	{
		nCx = size.cx + gapX;
		nCy = size.cy + gapY;
		
		child->SetSize(nCx, nCy);
	}

	CView*	view = child->GetActiveView();
	
	if (child->m_bIconic) 
	{
		
		child->SetWindowPos(NULL, child->m_restoreRc.left, child->m_restoreRc.top, child->m_restoreRc.Width(),
				child->m_restoreRc.Height(), SWP_SHOWWINDOW);
		child->SetRestore();
		return;
	}
	child->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);

	if (viewType == vtypeSCR)
		((CAxScrollView *)view)->SetSizeView(size.cx, size.cy);
	if (child->IsTabView())	
		((CAxTabView *)view)->SizeWindow(size);
}

void CMainFrame::firstTabOrder()
{
	long		rc = 0;
	CChildFrame*	child = (CChildFrame*) MDIGetActive();
	if (!child)	return;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(homeEV, child->m_key), 0);
}

bool CMainFrame::HotKey(WPARAM wParam, LPARAM lParam)
{
	CString mapN(m_tMenu->GetMap(CString((const char*)lParam)));
	
	m_mapHelper->ChangeChild(mapN);
	return true;
}

LONG CMainFrame::OnCHILDMSG(WPARAM wParam, LPARAM lParam)
{
	CString	info = m_bar1->screenInfo();
	CString desc = m_tMenu->GetDesc(info);

	info += "\t" + desc;
	CopyMemory((char *)lParam, info, info.GetLength());
	return 0;
}

void CMainFrame::LockProg()
{
	bool	visblebar = false;
	m_block = true;
	CLockDlg lockDlg(NULL, Axis::userID, m_pass);
	ShowWindow(SW_HIDE);
	ShowSingleWindows(FALSE);

	bool	bConclusion = false, bKobaElw = false;
	if (m_conclusion->GetStyle() & WS_VISIBLE)
	{
		bConclusion = true;
		m_conclusion->ShowWindow(SW_HIDE);
	}
	if (m_kobanotify->GetStyle() & WS_VISIBLE)
	{
		bKobaElw = true;
		m_kobanotify->ShowWindow(SW_HIDE);
	}

	KillTimer(TM_IDLE);
	

	lockDlg.DoModal();
	if (bConclusion)
		m_conclusion->ShowWindow(SW_SHOW);
	if (bKobaElw)
		m_kobanotify->ShowWindow(SW_SHOW);
	
	m_noActive = false;
	ShowWindow(SW_SHOW);
	ShowSingleWindows(TRUE);
	m_noActive = true;
	m_block = false;

	if (m_idletime > 0)
		SetTimer(TM_IDLE, m_idletime*60000, NULL);
}

void CMainFrame::CreateHistoryBar()
{
	CString strRet(_T(""));
	long rc;

	CString symbol = "1301";

	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(getHISTORY, 0), (LPARAM)(LPCTSTR)symbol);

	strRet = rc ? (char *)rc : _T("");

	CString s;
	s.Format("MAIN HISTORY : %s\n",strRet);
	OutputDebugString(s);

	//CArray<_JCode, _JCode> arr;
	CString	str;
	int	find;
	
	while (TRUE) {
		find = strRet.Find('\t');
		// 				s.Format("SETEDITDATA HISTORY : %s\n",history);
		// 				OutputDebugString(s);
		
		if (find < 1) 
		{
			//OutputDebugString("NOT FOUND\n");
			break;
		}
		
		str = strRet.Left(find);
		strRet.Delete(0, find + 1);
		
		find = str.Find(" ");
		if (find > 0) {
			//_JCode jCodeH;
			CString code = str.Left(find);
			CString name = str.Mid(find + 1);
			// 					s.Format("US HIS : [%s]	[%s]\n",jCodeH.Code,jCodeH.Name);
			//  					OutputDebugString(s);

			//arr.Add(jCodeH);

			m_bar3->add_History(code,name);
		}
	}
}

void CMainFrame::createUserScreen(int key)
{
	char	wb[512];
	CString	file, tmps;

	tmps = Axis::user;
	file.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, tmps, tmps);

	tmps.Format("%02d", key);
	DWORD dwRc = GetPrivateProfileString("ROOT", tmps, "", wb, sizeof(wb), file);
	if (dwRc <= 0)	return;

	tmps = wb;
	createUserScreen(tmps);
}

void CMainFrame::createUserScreen(CString mapN, bool allVS)
{
	int	pos, key, trigger, sdi;
	char	wb[512];
	CString	file, tmps, tmpx;
	CString	data, mapName;
	WINDOWPLACEMENT wndpl;
	
	tmps = Axis::user;
	file.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, tmps, tmps);
	
	//m_mapHelper->closeAll(false);
	m_mapHelper->closeAll(true);
	
	DWORD dwRc;
	CArray	< int , int > ary;

	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6 && allVS; vsN++)
	{
		if (vsN == m_vsN)	continue;
		ary.Add(vsN);
	}
	ary.Add(m_vsN);
	
	bool	showChild = false;
	for (;ary.GetSize();)
	{
		vsN = ary.GetAt(0);
		ary.RemoveAt(0);
		
		if (allVS)
		{
			long	rc = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setVID, 0), MAKELONG(0, vsN));
		}
		
		if (!ary.GetSize())	showChild = true;
		for (int ii = 1; ; ii++)
		{
			tmpx.Format("%d%02d", allVS ? vsN : 0, ii);
			dwRc = GetPrivateProfileString(mapN, tmpx, "", wb, sizeof(wb), file);
			if (dwRc <= 0)	break;
			
			data  = wb;
			data.Replace(";", "\n");

			CString strTag;

			for (int jj = 0; jj < 15; jj++)
			{
			
				
				pos = data.Find('|');
				if (pos < 0)
				{
					tmpx = data;
					data.Empty();
				}
				else
				{
					tmpx = data.Left(pos);
					data = data.Mid(pos+1);
				}
				
				
				tmpx.TrimLeft(); tmpx.TrimRight();
				switch (jj)
				{
				case 0:	mapName = tmpx;					break;	// mapN
				case 1:	sdi = atoi(tmpx);				break;	// 0 - mdi, 1 - sdi
				case 2:	wndpl.length  = atoi(tmpx);			break;	// WINDOWPLACEMENT.length
				case 3:	wndpl.flags   = atoi(tmpx);			break;	// .flags
				case 4:	wndpl.showCmd = atoi(tmpx);			break;	// .showCmd
				case 5:	wndpl.ptMinPosition.x = atoi(tmpx);		break;	// .ptMinPosition.x
				case 6:	wndpl.ptMinPosition.y = atoi(tmpx);		break;	// .ptMinPosition.y
				case 7:	wndpl.ptMaxPosition.x = atoi(tmpx);		break;	// .ptMaxPosition.x
				case 8:	wndpl.ptMaxPosition.y = atoi(tmpx);		break;	// .ptMaxPosition.y
				case 9:	wndpl.rcNormalPosition.left = atoi(tmpx);	break;	// .rcNormalPosition.left
				case 10:wndpl.rcNormalPosition.top  = atoi(tmpx);	break;	// .rcNormalPosition.top
				case 11:wndpl.rcNormalPosition.right  = atoi(tmpx);	break;	// .rcNormalPosition.right
				case 12:wndpl.rcNormalPosition.bottom = atoi(tmpx);	break;	// .rcNormalPosition.bottom
				case 13:trigger = atoi(tmpx);				break;	// trigger Group
				case 14:							// symbol data
					if (!tmpx.IsEmpty())
					{
						int pos;
						pos = tmpx.Find(";");
						if ( pos >= 0)
						{
							mapName += tmpx.Left(pos);
						}
						
						strTag = tmpx;
						strTag.TrimRight();
						strTag.TrimLeft();
					}
					break;
				}
			}
			
			if (ExceptMap(mapName.Left(L_MAPN)))	continue;
			
			if (sdi || m_bSDI)
				key = m_mapHelper->CreateSDI(mapName, trigger, wndpl, showChild, vsN);
			else
				key = m_mapHelper->CreateChild(mapName, trigger, wndpl, showChild, vsN, strTag);
			
			{
				// for test �ʷε� �ȵǴ����� �׽�Ʈ!
				DWORD count = 0;
				MSG msg;
				Invalidate(TRUE);

				while(PeekMessage(&msg, m_hWnd, 0, 0, PM_REMOVE)==TRUE)
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
					if (++count%20==0) break;
				}
			}
		}
	}
}

void CMainFrame::saveUserScreen()
{
	char	wb[1024*4];
	CString	file, filex, path;
	CString	tmps, tmpx, str;

	tmps = Axis::user;
	//MessageBox(Axis::home);
	file.Format("%s\\%s\\%s\\%s.ini",  Axis::home, USRDIR, tmps, tmps);
	filex.Format("%s\\%s\\%s\\%s.tmp", Axis::home, USRDIR, tmps, tmps);

	CScreenDlg dlg(this, Axis::home);
	dlg.DoModal();

// last screen
	GetPrivateProfileSection("LASTSTAT", wb, sizeof(wb), file);
	WritePrivateProfileSection("LASTSTAT", wb, filex);
// first screen for all virtual screen
	GetPrivateProfileSection("STARTVSMAP", wb, sizeof(wb), file);
	WritePrivateProfileSection("STARTVSMAP", wb, filex);

	DeleteFile(filex);
	makeUserScreenMenu();
}

void CMainFrame::makeUserScreenMenu()
{
	
	char	wb[512];
	int	count;
	CString	file, tmps, value;

	tmps = Axis::user;
	file.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, tmps, tmps); 

	CMenuXP*	mainM = (CMenuXP*) m_tMenu->GetPopupMenu(0);
	CMenuXP*	thisM = (CMenuXP*) mainM->GetSubMenu(UMENUN);	// fix menu position
	if (!thisM)	
		return;

	count = (int)thisM->GetMenuItemCount();
	for (int ii = 0; ii < count - 2; ii++)
	{
		MENUITEMINFO	info;
		memset(&info, 0, sizeof(MENUITEMINFO));
		info.cbSize = sizeof(MENUITEMINFO);
		info.fMask = MIIM_DATA | MIIM_TYPE;
		thisM->GetMenuItemInfo(thisM->GetMenuItemID(2), &info);
		
		thisM->RemoveMenu(2, MF_BYPOSITION);
		CMenuXPItem *pData = (CMenuXPItem *)info.dwItemData;
		if ((info.fType & MFT_OWNERDRAW) && pData && pData->IsMyData())
			delete pData;
	}

	CMapStringToString	ary;
	for (ii = 1; ; ii++)
	{
		tmps.Format("%02d", ii);
		DWORD dwRc = GetPrivateProfileString("ROOT", tmps, "", wb, sizeof(wb), file);
		if (dwRc <= 0)
			break;

		tmps = wb;
		if (ary.Lookup(tmps, value))
			continue;
		ary.SetAt(tmps, "1");
		tmps.TrimLeft(); tmps.TrimRight();
		thisM->AppendMenuX(MF_STRING|MF_ENABLED, ID_MENU_USER+ii, tmps);
	}
	ary.RemoveAll();
}

bool CMainFrame::modifyWorkspace(bool add, CString keys, bool allvs)
{
	int	pos, key, index;
	CString	mpN, tmps, data, info;

	CProfile profile(pkUserSetup);

	if (add)
	{
		pos  = keys.Find('=');
		tmps = keys.Left(pos);
		keys = keys.Mid(pos+1);
		profile.Write("ROOT", tmps, keys);

		WINDOWPLACEMENT	wndpl;
		CArray	<int, int>	aryK;

		wndpl.length = sizeof(WINDOWPLACEMENT);
		profile.WriteSection(keys, "");
		
		CChildFrame*	child  = NULL;
		CSChild*	schild = NULL;
		for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
		{
			if (!allvs && vsN != m_vsN)	continue;

			for (int ii = m_hooklist[vsN].GetSize() - 1; 0 <= ii; ii--)
			{
				key = m_hooklist[vsN].GetAt(ii);
				aryK.Add(key);
			}
			CMapStringToString mapDRFN;
			mapDRFN.RemoveAll();

			for (index = 1, ii = 0; ii < aryK.GetSize(); ii++)
			{
				key = aryK.GetAt(ii);
				if (!m_arMDI[vsN].Lookup(key, child))	continue;
				if (ExceptMap(child->m_mapN))		continue;

				mpN.Format("%s", child->m_mapN.Left(L_MAPN));
				if (!ExistMenu(mpN))	continue;

				data.Empty();
				child->GetWindowPlacement(&wndpl);
				getScreenData(child->m_key, data);				
				// dll data append.........
				if (m_mapHelper->IsDLL(child->m_mapN))
				{
					CWnd* base = child->GetActiveView()->GetWindow(GW_CHILD);
					if (base)
					{
						if(m_mapHelper->IsDRFN(child->m_mapN))
						{
							// 						if(child->m_usrData != "")
							// 						{
							// 							keys = child->m_usrData;
							// 						}
							// 						else
							// 						{
							// 							int count = profile.GetInt("DRFNCOUNT_LASTSTAT",child->m_mapN);
							// 
							// 							if(count == 0)
							// 							{
							// 								profile.Write("DRFNCOUNT_LASTSTAT",child->m_mapN,1);
							// 							}
							// 							else
							// 							{
							// 								profile.Write("DRFNCOUNT_LASTSTAT",child->m_mapN,count + 1);
							// 							}
							// 						}
							int nCount = profile.GetInt("USERDRFN","COUNT");

							if(nCount == 0)
							{
								nCount = 1;

								profile.Write("USERDRFN","COUNT",1);
							}
							else
							{
								nCount++;

								profile.Write("USERDRFN","COUNT",nCount);
							}

							CString usrdata;
							usrdata.Format("USERSCREEN%08d",nCount);

							CString tmp;
							CString strValue;
							
							if(mapDRFN.Lookup(child->m_mapN,tmp))
							{
								int n = atoi(tmp);
								
								tmp.Format("%d",n+1);
								mapDRFN.SetAt(child->m_mapN,tmp);
								
								tmp.Format(",%d%02d",vsN,n+1);
								
								tmp.Insert(2,",");
								tmp.Insert(4,",");
								
								strValue = usrdata + tmp;
							}
							else
							{
								tmp.Format("%d",1);
								mapDRFN.SetAt(child->m_mapN,tmp);
								
								strValue = usrdata + ",0,0,1";
							}
							
							char	wb[256];
							sprintf(wb, strValue);
							base->SendMessage(WM_DLLDATA, 0, (long) &wb);
							if (!data.IsEmpty())	data += ";";
							tmps.Format("%s\t%s", USERDEFSYM, wb);
							data = tmps;
						}
						else
						{
							char	wb[256];
							sprintf(wb, keys);
							base->SendMessage(WM_DLLDATA, 0, (long) &wb);
							if (!data.IsEmpty())	data += ";";
							tmps.Format("%s\t%s", USERDEFSYM, wb);
							data += tmps;
						}
					}
				}

				tmps.Format("%d%02d", m_saveALLVS ? vsN : 0, index++);
				if (child->IsIconic())		// 20070723
				{
					CRect	rctmp;
					rctmp = child->GetRestoreRC();
					wndpl.rcNormalPosition.left = rctmp.left;
					wndpl.rcNormalPosition.right = rctmp.right;
					wndpl.rcNormalPosition.top = rctmp.top;
					wndpl.rcNormalPosition.bottom = rctmp.bottom;
				}
				info.Format("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|",
						mpN,
						0,
						wndpl.length,
						wndpl.flags,
						wndpl.showCmd,
						wndpl.ptMinPosition.x,
						wndpl.ptMinPosition.y,
						wndpl.ptMaxPosition.x,
						wndpl.ptMaxPosition.y,
						wndpl.rcNormalPosition.left,
						wndpl.rcNormalPosition.top,
						wndpl.rcNormalPosition.right,
						wndpl.rcNormalPosition.bottom,
						child->m_xcaption.GetGroup(),
						data);
				profile.Write(keys, tmps, info);
			}
			aryK.RemoveAll();

			for (ii = m_sdiZORDER[vsN].GetSize() - 1; 0 <= ii; ii--)
			{
				key = m_sdiZORDER[vsN].GetAt(ii);
				aryK.Add(key);
			}
			
			for (ii = 0; ii < aryK.GetSize(); ii++)
			{
				key = aryK.GetAt(ii);
				if (!m_arSDI[vsN].Lookup(key, schild))	continue;
				if (ExceptMap(schild->m_mapN))		continue;
				
				mpN.Format("%s", schild->m_mapN.Left(L_MAPN));
				if (!ExistMenu(mpN))	continue;

				data.Empty();
				schild->GetWindowPlacement(&wndpl);
				getScreenData(schild->m_key, data);

				// dll data append.........
				if (m_mapHelper->IsDLL(schild->m_mapN))
				{
					CWnd* base = schild->GetActiveView()->GetWindow(GW_CHILD);
					if (base)
					{
						char	wb[256];
						sprintf(wb, keys);
						base->SendMessage(WM_DLLDATA, 0, (long) &wb);
						if (!data.IsEmpty())	data += ";";
						tmps.Format("%s\t%s", USERDEFSYM, wb);
						data += tmps;
					}
				}

				tmps.Format("%d%02d", vsN, index++);
				info.Format("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|",
						mpN,
						1,
						wndpl.length,
						wndpl.flags,
						wndpl.showCmd,
						wndpl.ptMinPosition.x,
						wndpl.ptMinPosition.y,
						wndpl.ptMaxPosition.x,
						wndpl.ptMaxPosition.y,
						wndpl.rcNormalPosition.left,
						wndpl.rcNormalPosition.top,
						wndpl.rcNormalPosition.right,
						wndpl.rcNormalPosition.bottom,
						schild->m_xcaption.GetGroup(),
						data);
				profile.Write(keys, tmps, info);
			}
			aryK.RemoveAll();
		}
		return true;
	}

	CStringArray	arr;
	for (int ii = 1; ; ii++)
	{
		tmps.Format("%02d", ii);
		if (!tmps.CompareNoCase(keys))
			continue;

		tmps = profile.GetString("ROOT", tmps);
		if (tmps.IsEmpty())
			break;
		arr.Add(tmps);
	}

	profile.WriteSection("ROOT", "");
	
	for (ii = 0; ii < arr.GetSize(); ii++)
		profile.Write("ROOT", Format("%02d", ii + 1), arr.GetAt(ii));

	arr.RemoveAll();
	return true;
}

void CMainFrame::save_laststat()
{	
	int	key, index;
	CString	mpN, tmps, data, info, keys = "LASTSTAT";

	CProfile profile(pkUserSetup);
	profile.Write("ROOT", "00", keys);

	WINDOWPLACEMENT	wndpl;
	CArray	<int, int>	aryK;

	wndpl.length = sizeof(WINDOWPLACEMENT);
	profile.WriteSection(keys, "");
	
	CChildFrame*	child = NULL;
	CSChild*	schild = NULL;
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		if (!m_saveALLVS && vsN != m_vsN)	continue;

		for (int ii = m_hooklist[vsN].GetSize() - 1; 0 <= ii; ii--)
		{
			key = m_hooklist[vsN].GetAt(ii);
			aryK.Add(key);
		}

		CMapStringToString mapDRFN;
		mapDRFN.RemoveAll();

		for (index = 1, ii = 0; ii < aryK.GetSize(); ii++)
		{
			key = aryK.GetAt(ii);
			if (!m_arMDI[vsN].Lookup(key, child))	continue;
			if (!child->GetSafeHwnd())		continue;
			if (ExceptMap(child->m_mapN))		continue;

			mpN = child->m_mapN.Left(L_MAPN);

			if (!m_mapHelper->IsValidMap(mpN) ||!ExistMenu(mpN))
			{
				mpN = mpN.Left(L_MAPN-2)  + "00";
				if (!m_mapHelper->IsValidMap(mpN) || !ExistMenu(mpN))
					continue;
			}

			data.Empty();
			child->GetWindowPlacement(&wndpl);
			getScreenData(child->m_key, data);

			// dll data append.........
// 			if (m_mapHelper->IsDLL(child->m_mapN))
// 			{
// 				CWnd* base = child->GetActiveView()->GetWindow(GW_CHILD);
// 				if (base)
// 				{
// 					if(m_mapHelper->IsDRFN(child->m_mapN))
// 					{
// 
// 					}
// 					char	wb[256];
// 					sprintf(wb, keys);
// 					base->SendMessage(WM_DLLDATA, 0, (long) &wb);
// 					if (!data.IsEmpty())	data += ";";
// 					tmps.Format("%s\t%s", USERDEFSYM, wb);
// 					data += tmps;
// 				}
// 			}
			// dll data append.........
			if (m_mapHelper->IsDLL(child->m_mapN))
			{
				CWnd* base = child->GetActiveView()->GetWindow(GW_CHILD);
				if (base)
				{
					if(m_mapHelper->IsDRFN(child->m_mapN))
					{
						// 						if(child->m_usrData != "")
						// 						{
						// 							keys = child->m_usrData;
						// 						}
						// 						else
						// 						{
						// 							int count = profile.GetInt("DRFNCOUNT_LASTSTAT",child->m_mapN);
						// 
						// 							if(count == 0)
						// 							{
						// 								profile.Write("DRFNCOUNT_LASTSTAT",child->m_mapN,1);
						// 							}
						// 							else
						// 							{
						// 								profile.Write("DRFNCOUNT_LASTSTAT",child->m_mapN,count + 1);
						// 							}
						// 						}
						CString tmp;
						CString strValue;
						
						if(mapDRFN.Lookup(child->m_mapN,tmp))
						{
							int n = atoi(tmp);

							tmp.Format("%d",n+1);
							mapDRFN.SetAt(child->m_mapN,tmp);
							
							tmp.Format(",%d%02d",vsN,n+1);
							
							tmp.Insert(2,",");
							tmp.Insert(4,",");
							
							strValue = "LASTSTAT" + tmp;
						}
						else
						{
							tmp.Format("%d",1);
							mapDRFN.SetAt(child->m_mapN,tmp);
							
							strValue = "LASTSTAT,0,0,1";
						}
						
						char	wb[256];
						sprintf(wb, strValue);
						base->SendMessage(WM_DLLDATA, 0, (long) &wb);
						if (!data.IsEmpty())	data += ";";
						tmps.Format("%s\t%s", USERDEFSYM, wb);
						data = tmps;
					}
					else
					{
						char	wb[256];
						sprintf(wb, keys);
						base->SendMessage(WM_DLLDATA, 0, (long) &wb);
						if (!data.IsEmpty())	data += ";";
						tmps.Format("%s\t%s", USERDEFSYM, wb);
						data += tmps;
					}
				}
			}

			if (child->IsIconic())
			{
				CRect	rctmp;
				rctmp = child->GetRestoreRC();
				wndpl.rcNormalPosition.left = rctmp.left;
				wndpl.rcNormalPosition.right = rctmp.right;
				wndpl.rcNormalPosition.top = rctmp.top;
				wndpl.rcNormalPosition.bottom = rctmp.bottom;
			}	
			
			tmps.Format("%d%02d", m_saveALLVS ? vsN : 0, index++);
			info.Format("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|",
					child->m_mapN,
					0,
					wndpl.length,
					wndpl.flags,
					wndpl.showCmd,
					wndpl.ptMinPosition.x,
					wndpl.ptMinPosition.y,
					wndpl.ptMaxPosition.x,
					wndpl.ptMaxPosition.y,
					wndpl.rcNormalPosition.left,
					wndpl.rcNormalPosition.top,
					wndpl.rcNormalPosition.right,
					wndpl.rcNormalPosition.bottom,
					child->m_xcaption.GetGroup(),
					data);

			profile.Write(keys, tmps, info);
		}
		aryK.RemoveAll();

		for (POSITION spos = m_arSDI[vsN].GetStartPosition(); spos; )
		{
			m_arSDI[vsN].GetNextAssoc(spos, key, schild);
			aryK.Add(key);	
		}

		for (ii = 0; ii < aryK.GetSize(); ii++)
		{
			key = aryK.GetAt(ii);
			if (!m_arSDI[vsN].Lookup(key, schild))	continue;
			if (ExceptMap(schild->m_mapN))		continue;
			
			mpN.Format("%s", schild->m_mapN.Left(L_MAPN));
			if (!ExistMenu(mpN))	continue;

			data.Empty();
			schild->GetWindowPlacement(&wndpl);
			getScreenData(schild->m_key, data);

			// dll data append.........
			if (m_mapHelper->IsDLL(schild->m_mapN))
			{
				CWnd* base = schild->GetActiveView()->GetWindow(GW_CHILD);
				if (base)
				{
					char	wb[256];
					sprintf(wb, keys);
					base->SendMessage(WM_DLLDATA, 0, (long) &wb);
					if (!data.IsEmpty())	data += ";";
					tmps.Format("%s\t%s", USERDEFSYM, wb);
					data += tmps;
				}
			}
			
			tmps.Format("%d%02d", vsN, index++);
			info.Format("%s|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|",
					mpN,
					1,
					wndpl.length,
					wndpl.flags,
					wndpl.showCmd,
					wndpl.ptMinPosition.x,
					wndpl.ptMinPosition.y,
					wndpl.ptMaxPosition.x,
					wndpl.ptMaxPosition.y,
					wndpl.rcNormalPosition.left,
					wndpl.rcNormalPosition.top,
					wndpl.rcNormalPosition.right,
					wndpl.rcNormalPosition.bottom,
					schild->m_xcaption.GetGroup(),
					data);
			profile.Write(keys, tmps, info);
		}
		aryK.RemoveAll();
	}

	// ����ȭ�� �������� mode
	CProfile p(pkEnvironment);
	p.Write("BKNOTICE", "MODE", Format("%d", m_nBkMode));
	
	// scr_report() �Լ��� ��ü��.
	// SendConfig();
}

void CMainFrame::getScreenData(int key, CString& data, BOOL save)
{
	CString		value, tmps, symbol = "1301, 30301, 40401, ed_focod";

	CProfile profile(GetProfileFileName());
	symbol = profile.GetString("LinkEx", "codesymbols");

	CStringArray		ary;
	CMapStringToString	arSymbyData;
	
	parseAry(symbol, ary, ",");
	
	long	rc = 0;
	for (int ii = 0; ii < ary.GetSize(); ii++)
	{
		symbol = ary.GetAt(ii);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(getFDC, key), (long)(const char*)symbol);

		value = (rc ? (char *) rc : _T(""));
		arSymbyData.SetAt(symbol, value);
	}

	if (save)
	{
		for (ii = 0; ii < ary.GetSize(); ii++)
		{
			symbol = ary.GetAt(ii);
			arSymbyData.Lookup(symbol, value);
			value.TrimLeft();value.TrimRight();

			if (value.IsEmpty())	continue;
			tmps.Format("%s\t%s", symbol, value);
			if (!data.IsEmpty())
				data += ";";
			data += tmps;
		}
	}
	else	// link datas
	{
		CMapStringToString	arSymbylink;
		CStringArray		arsym;
		CString			sym;
		for (ii = 0; ii < ary.GetSize(); ii++)
		{
			symbol = ary.GetAt(ii);
			arSymbyData.Lookup(symbol, value);
			value.TrimLeft();value.TrimRight();

			if (value.IsEmpty())	continue;
			arSymbylink.SetAt(symbol, value);
			tmps = profile.GetString("Link", symbol);
			if (!tmps.IsEmpty())
			{
				parseAry(tmps, arsym, ",");
				for (int jj = 0; jj < arsym.GetSize(); jj++)
				{
					sym = arsym.GetAt(jj);
					if (arSymbylink.Lookup(sym, tmps))
						continue;
					arSymbylink.SetAt(sym, value);
				}
				arsym.RemoveAll();
			}
		}

		for (ii = 0; ii < ary.GetSize(); ii++)
		{
			symbol = ary.GetAt(ii);
			if (!arSymbylink.Lookup(symbol, value))
				continue;

			if (value.IsEmpty())	continue;
			tmps.Format("%s\t%s", symbol, value);
			if (!data.IsEmpty())
				data += ";";
			data += tmps;
		}

		arSymbylink.RemoveAll();
	}
	ary.RemoveAll();
}

void CMainFrame::saveImg(int entire)
{
	PostMessage(WM_CANCELMODE);
	PostMessage(WM_AXIS, MAKEWPARAM(axWRITEIMG, entire));
	//writeImg(Axis::home);
}

BOOL CMainFrame::printImg(CString dat)
{	
	if(m_bInit == TRUE)
	{
		m_bInit = FALSE;
		return TRUE;
	}

	CWnd*	pChild;
	CString	title, fontName;

	title.LoadString(ST_TEXT_OK);
	if (!m_bSDI)
	{
		CChildFrame* child = (CChildFrame*) MDIGetActive();
		if (!child)
		{
			Axis::MessageBox(this, "�μ��� ȭ���� �����ϴ�.", MB_ICONINFORMATION);
			return TRUE;
		}

		pChild = child;
	}
	else
	{
		CSChild*	schild;
		if (m_arSDI[m_vsN].Lookup(m_activeKey, schild))
		{
			pChild = schild;
		}
		else
		{
			Axis::MessageBox(this, "�μ��� ȭ���� �����ϴ�.", MB_ICONINFORMATION);
			return TRUE;
		}	
	}	

	// 2011.02.22 �μ����� �߰� by LKM
	{
		CTime tm = CTime::GetCurrentTime();
		
		dat.Format(
			"�μ����� : %s(PC����), %s(%s)-%s\r\n"
			"�� ȭ�鳻���� �����ڷ�θ� Ȱ���Ͻñ� �ٶ��,\r\n"
			"��� ��쿡�� ����å�Ӽ��翡 ���� �����ڷ������ ����Ͻ� �� ������ �˷��帳�ϴ�.", 
			(LPCSTR)tm.Format("%Y.%m.%d %H:%M:%S"), Axis::user, Axis::userID, m_ipAddr
		);
	}
	
	CRect		rect;
	pChild->GetWindowRect(&rect);
	CRect	mRc, rc;
	
	//CString tmp; tmp.Format("width: %d, height: %d", rect.Width(), rect.Height());
	//AfxMessageBox(tmp);
	if (!m_bSDI)
	{
		rc.CopyRect(&rect);
		m_MClient->GetWindowRect(mRc);
		rect.IntersectRect (mRc, rect);
	}
	CSize	szOrg, szRect;
	bool	bResize = false;

	szOrg.cx = rect.Width();
	szOrg.cy = rect.Height();
	szRect = szOrg;
	
	if (szOrg.cx > MAX_XBMP || szOrg.cy > MAX_YBMP)
	{
		szRect.cx = MAX_XBMP;		
		szRect.cy = (int)((double)szOrg.cy * (double)szRect.cx / (double)szOrg.cx);
		if (szRect.cy > MAX_YBMP)
		{
			szRect.cy = MAX_YBMP;
			szRect.cx =  (int)((double)szOrg.cx * (double)szRect.cy / (double)szOrg.cy);
		}

		bResize = true;
	}	
	
	//CString tmp; tmp.Format("cx: %d, cy: %d", szRect.cx, szRect.cy);
	//AfxMessageBox(tmp);
	if (Axis::MessageBox(this, "��� �Ͻðڽ��ϱ�", MB_YESNO) == IDYES)
	{
		if (bResize)
			pChild->SetWindowPos(NULL, 0, 0, szRect.cx, szRect.cy, SWP_NOMOVE|SWP_NOZORDER);

		m_pPRNChild = pChild;
		m_sizePRN = szRect;
		m_sizePRNORG = szOrg;
		m_bPRNResize = bResize;
		m_szPRNData.Format("%s", dat);

		SetTimer(TM_PRNIMG, 1000, NULL);
	}
	return TRUE;
}

BOOL CMainFrame::printOper(CWnd* pChild, CSize size, CSize sizeOrg, CString dat, bool bResize)
{
	CString	title, fontName;	
	title.LoadString(ST_TEXT_OK);

	CString		file;
	CBitmap 	bitmap;
	CWindowDC	dc(pChild);
	CDC 		memDC;

	bitmap.CreateCompatibleBitmap(&dc, size.cx, size.cy);
	memDC.CreateCompatibleDC(&dc); 	
	
	CBitmap* pOldBitmap = memDC.SelectObject(&bitmap);	

	memDC.BitBlt(0, 0, size.cx, size.cy, &dc, 0, 0, SRCCOPY); 
	
	// Create logical palette if device support a palette
	CPalette pal;
	if(dc.GetDeviceCaps(RASTERCAPS) & RC_PALETTE)
	{
		UINT nSize = sizeof(LOGPALETTE) + (sizeof(PALETTEENTRY) * 256);
		LOGPALETTE *pLP = (LOGPALETTE *) new BYTE[nSize];
		pLP->palVersion = 0x300;

		pLP->palNumEntries = GetSystemPaletteEntries(dc, 0, 255, pLP->palPalEntry);

		// Create the palette
		pal.CreatePalette(pLP);

		delete[] pLP;
	}

	memDC.SelectObject(pOldBitmap);

	// Convert the bitmap to a DIB
	HANDLE hDIB = writeDDBToDIB(bitmap, BI_RGB, &pal);
	if(hDIB == NULL)	
		return FALSE;

	file.Format("%s\\%d", Axis::home, (int)pChild);
	writeDIB((LPSTR)(LPCTSTR)file, hDIB);
	GlobalFree(hDIB);

	CNDib*	nDib = new CNDib();
	if (nDib->SetNDIB(file))
	{
		DeleteFile(file);
		delete nDib;
		Axis::MessageBox(this, "Error print", MB_ICONINFORMATION);
		return FALSE;
	}

	HANDLE	pDib = nDib->GetNDIB();
	BITMAP	bm;
	HBITMAP hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(), file,
				IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	(CBitmap::FromHandle(hBitmap))->GetBitmap(&bm);


	CDC	printDC, *pDC = pChild->GetDC();

	m_printsetup->SetThisPrinter();
	AfxGetApp()->CreatePrinterDC(printDC);
	if (!printDC)
	{
		DeleteFile(file);
		ReleaseDC(pDC);
		delete nDib;
		Axis::MessageBox(this, "Error Print", MB_ICONINFORMATION);
		return FALSE;
	}
	
	SetMapMode(printDC.m_hDC, MM_TEXT);
	DOCINFO docinfo = { sizeof(DOCINFO), "Print screen", NULL};
 	if(!StartDoc(printDC.m_hDC, &docinfo))
	{
		DeleteFile(file);
		printDC.DeleteDC();
		ReleaseDC(pDC);
		delete nDib;
		Axis::MessageBox(this, "Error Print", MB_ICONINFORMATION);
		return FALSE;
	}

	int	paperX = GetDeviceCaps(printDC.m_hDC, HORZRES);
	int	paperY = GetDeviceCaps(printDC.m_hDC, VERTRES);

	int	printX = GetDeviceCaps(printDC.m_hDC, LOGPIXELSX);
	int	printY = GetDeviceCaps(printDC.m_hDC, LOGPIXELSY);
	int	deviceX = GetDeviceCaps(pDC->m_hDC, LOGPIXELSX);
	int	deviceY = GetDeviceCaps(pDC->m_hDC, LOGPIXELSY);
	
	int	width  = (int) (bm.bmWidth*printX/deviceX);
	int	height = (int) (bm.bmHeight*printY/deviceY);
	int	pagexN = (int) ((width+paperX-1)/paperX);
	int	pageyN = (int) ((height+paperY-1)/paperY);

	int	xDest, yDest, nDestW, nDestH;
	int	xSrc, ySrc, nSrcW, nSrcH;

	::SetStretchBltMode(printDC.m_hDC, COLORONCOLOR);

	LPBITMAPINFOHEADER lpbi;
	LPSTR        pBuf;
	lpbi = (LPBITMAPINFOHEADER)GlobalLock(pDib);
	if (!lpbi)
	{
		DeleteFile(file);
		printDC.DeleteDC();
		ReleaseDC(pDC);
		delete nDib;

		Axis::MessageBox(this, "Error Print", MB_ICONINFORMATION);
		return FALSE;
	}
	pBuf = (LPSTR)lpbi + (WORD)lpbi->biSize + nDib->PaletteSize(lpbi);

	CFont	Font, *font;
	fontName.LoadString(ST_FONTNAME_DEFAULT);
	int	fontS = 90*printX/deviceX;
	Font.CreatePointFont(fontS, fontName);
	font = printDC.SelectObject(&Font);
	int	ret;
	if (pagexN == 1 && pageyN == 1)
	{
		if(StartPage(printDC.m_hDC))
		{
			xDest = paperX/2 - width/2;
			yDest = paperY/2 - height/2;
			ret = StretchDIBits(printDC.m_hDC, xDest, yDest, width ,height, 0, 0, 
				bm.bmWidth, bm.bmHeight, pBuf, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS, SRCCOPY);
			if (!dat.IsEmpty())
			{
// #if 0
// 				TextOut(printDC.m_hDC, xDest, yDest+height+20, dat, dat.GetLength());
// #else
// 				CRect rc;
// 				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT|DT_CALCRECT);
// 				rc.OffsetRect(xDest, yDest+height-rc.top+20);
// 				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT);
// #endif
				CRect rc;
				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT|DT_CALCRECT);
				rc.OffsetRect(xDest, yDest+height-rc.top+20);
				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT);
			}
			EndPage(printDC.m_hDC);
		}
	} // ��ǻ� ���ڵ�� �ʿ䰡 ����. �̰��� Ǫ�����ȴ�� ȭ���� ũ�� �μ��Ҽ� �ֵ��� �ϱ� ���� �ʿ��ߴ� �ɼ�
	else
	{
		xDest = 0;	yDest = 0;
		for (int ii = 0; ii < pageyN; ii++)
		{
			for (int jj = 0; jj < pagexN; jj++)
			{
				if(!StartPage(printDC.m_hDC))
					break;
				if (jj == pagexN - 1)
				{
					nDestW = width - paperX*jj;
					nSrcW = bm.bmWidth - ((int)(deviceX*paperX/printX))*jj;
					if (ii == pageyN - 1)
					{	// 2 of 2(hori), 2 of 2(vert), 4 of 4
						nDestH = height - paperY*ii;
						xSrc = (int)(deviceX*paperX/printX)*jj;
						ySrc = 0;
						nSrcH = bm.bmHeight - ((int)(deviceY*paperY/printY))*ii;
					}
					else
					{	// 1 of 2(vert), 2 of 4
						nDestH = paperY;
						xSrc = (int)(deviceX*paperX/printX)*jj;
						ySrc = bm.bmHeight - (int)(deviceY*paperY/printY)*(ii+1);
						nSrcH = (int)(deviceY*paperY/printY);
					}
					ret = StretchDIBits(printDC.m_hDC, xDest, yDest,
						nDestW, nDestH, xSrc, ySrc, nSrcW, nSrcH,
						pBuf, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS, SRCCOPY);
				}
				else
				{
					if (ii == pageyN - 1)
					{	// 1 of 2(hori), 3 of 4
						nDestW = paperX;
						nDestH = height - paperY*ii;
						xSrc = (int)(deviceX*paperX/printX)*jj;
						ySrc = 0;
						nSrcW = ((int)(deviceX*paperX/printX));
						nSrcH = bm.bmHeight - ((int)(deviceY*paperY/printY))*ii;
					}
					else
					{	// 1 of 4
						nDestW = paperX;
						nDestH = paperY;
						xSrc = (int)(deviceX*paperX/printX)*jj;
						ySrc = bm.bmHeight - (int)(deviceY*paperY/printY)*(ii+1);
						nSrcW = ((int)(deviceX*paperX/printX));
						nSrcH = (int)(deviceY*paperY/printY);
					}
					ret = StretchDIBits(printDC.m_hDC, xDest, yDest, 
						nDestW, nDestH, xSrc, ySrc, nSrcW, nSrcH,
						pBuf, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS, SRCCOPY);
				}

				if (!dat.IsEmpty())
				{
					// #if 0
					// 				TextOut(printDC.m_hDC, xDest, yDest+height+20, dat, dat.GetLength());
					// #else
					// 				CRect rc;
					// 				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT|DT_CALCRECT);
					// 				rc.OffsetRect(xDest, yDest+height-rc.top+20);
					// 				DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT);
					// #endif
					CRect rc;
					DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT|DT_CALCRECT);
					rc.OffsetRect(xDest, yDest+height-rc.top+20);
					DrawText(printDC.m_hDC, dat, dat.GetLength(), &rc, DT_TOP|DT_LEFT);
				}
				EndPage(printDC.m_hDC);
			}
		}
	}
	EndDoc(printDC.m_hDC);
	m_printsetup->RestorePrinter();

	
	printDC.SelectObject(font);
	DeleteObject(Font);
	DeleteObject(hBitmap);
	DeleteFile(file);
	printDC.DeleteDC();
	ReleaseDC(pDC);
	delete nDib;
	if (bResize)
	{
		pChild->SetWindowPos(NULL, 0, 0, sizeOrg.cx, sizeOrg.cy, SWP_NOMOVE|SWP_NOZORDER);
	}
	return TRUE;
}

BOOL CMainFrame::writeImg(CString dir, int entire)
{
	// 2010.07.21 ȭ��ĸ�Ľ� �޴��ܻ��� ���� ������ �־� Invalidate -> �޼������� �Ŀ� ĸ���Ѵ�. by LKM
	{
		MSG msg;
		Invalidate(TRUE);
		while(PeekMessage(&msg, m_hWnd, 0, 0, PM_REMOVE)==TRUE)
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	CWnd*	pChild = NULL;
	CString	mapN;

	if (entire)	
		pChild = this;
	else
	{
		CChildFrame* child = (CChildFrame*) MDIGetActive();
		if (!child || child->IsWindowVisible() == FALSE)	
		{
			Axis::MessageBox(this, "�������� ȭ���� �����ϴ�.", MB_OK | MB_ICONEXCLAMATION);
			return FALSE;
		}

		mapN = child->m_mapN;
		ASSERT(mapN.GetLength() >= L_MAPN);
		pChild = child;
	}

	if (!pChild) {
		Axis::MessageBox(this, "�������� ȭ���� �����ϴ�.", MB_OK | MB_ICONSTOP);
		return FALSE;
	}

	for (int ii = 0; ii < 10; ii++)	
		Sleep(10);

	CString		file;
	CBitmap 	bitmap;
	CWindowDC	dc(pChild);
	CDC 		memDC;
	CRect		rect;

	memDC.CreateCompatibleDC(&dc); 
	pChild->GetWindowRect(&rect);

	if (!entire)
	{
		CRect	mRc, rc;

		rc.CopyRect(&rect);
		m_MClient->GetWindowRect(mRc);
		rect.IntersectRect (mRc, rect);
	}

	bitmap.CreateCompatibleBitmap(&dc, rect.Width(),rect.Height());
	
	CBitmap* pOldBitmap = memDC.SelectObject(&bitmap);
	memDC.BitBlt(0, 0, rect.Width(), rect.Height(), &dc, 0, 0, SRCCOPY); 

	// Create logical palette if device support a palette
	CPalette pal;
	if(dc.GetDeviceCaps(RASTERCAPS) & RC_PALETTE)
	{
		UINT nSize = sizeof(LOGPALETTE) + (sizeof(PALETTEENTRY) * 256);
		LOGPALETTE *pLP = (LOGPALETTE *) new BYTE[nSize];
		pLP->palVersion = 0x300;

		pLP->palNumEntries = 
			GetSystemPaletteEntries(dc, 0, 255, pLP->palPalEntry);

		// Create the palette
		pal.CreatePalette(pLP);

		delete[] pLP;
	}

	memDC.SelectObject(pOldBitmap);

	// Convert the bitmap to a DIB
	HANDLE hDIB = writeDDBToDIB(bitmap, BI_RGB, &pal);
	if(hDIB == NULL)	
	{
		Axis::MessageBox("bitmap to DIB Failed.", MB_OK | MB_ICONSTOP);
		return FALSE;
	}


	file.Format("%s\\%s.bmp", dir, entire ? "Full_Screen" : m_tMenu->GetMenuName(mapN.Left(L_MAPN)));
	file.Replace("/", "");
	CFileDialog	dlg(FALSE, "bmp", file, OFN_OVERWRITEPROMPT, 
		"BMP Files(*.bmp)|*.bmp||", NULL);

	if (dlg.DoModal() == IDOK)
	{
		file = dlg.GetPathName();
		if (dlg.GetFileName().IsEmpty())
		{
			GlobalFree(hDIB);
			return FALSE;	
		}
	}
	else
	{
		GlobalFree(hDIB);
		return FALSE;
	}

	//szFile = (LPSTR)(LPCTSTR)path;
	// Write it to file
	writeDIB((LPSTR)(LPCTSTR)file, hDIB);

	// Free the memory allocated by DDBToDIB for the DIB
	GlobalFree(hDIB);

	return TRUE;
}

HANDLE CMainFrame::writeDDBToDIB(CBitmap& bitmap, DWORD dwCompression, CPalette* pPal) 
{
	BITMAP			bm;
	BITMAPINFOHEADER	bi;
	LPBITMAPINFOHEADER 	lpbi;
	DWORD			dwLen;
	HANDLE			hDIB;
	HANDLE			handle;
	HDC 			hDC;
	HPALETTE		hPal;

	ASSERT( bitmap.GetSafeHandle() );

	// The function has no arg for bitfields
	if (dwCompression == BI_BITFIELDS)	return NULL;

	// If a palette has not been supplied use defaul palette
	hPal = (HPALETTE) pPal->GetSafeHandle();
	if (hPal == NULL)
		hPal = (HPALETTE) GetStockObject(DEFAULT_PALETTE);

	// Get bitmap information
	bitmap.GetObject(sizeof(bm),(LPSTR)&bm);

	// Initialize the bitmapinfoheader
	bi.biSize		= sizeof(BITMAPINFOHEADER);
	bi.biWidth		= bm.bmWidth;
	bi.biHeight 		= bm.bmHeight;
	bi.biPlanes 		= 1;
	bi.biBitCount		= bm.bmPlanes * bm.bmBitsPixel;
	bi.biCompression	= dwCompression;
	bi.biSizeImage		= 0;
	bi.biXPelsPerMeter	= 0;
	bi.biYPelsPerMeter	= 0;
	bi.biClrUsed		= 0;
	bi.biClrImportant	= 0;

	// Compute the size of the  infoheader and the color table
	int nColors = int(pow(2, bi.biBitCount));
	if (nColors > 256)
		nColors = 0;

	dwLen  = bi.biSize + nColors * sizeof(RGBQUAD);

	// We need a device context to get the DIB from
	hDC = ::GetDC(NULL);
	hPal = SelectPalette(hDC, hPal, FALSE);
	RealizePalette(hDC);

	// Allocate enough memory to hold bitmapinfoheader and color table
	hDIB = GlobalAlloc(GMEM_FIXED, dwLen);
	if (!hDIB)
	{
		SelectPalette(hDC, hPal, FALSE);
		::ReleaseDC(NULL, hDC);
		return NULL;
	}

	lpbi = (LPBITMAPINFOHEADER)hDIB;
	*lpbi = bi;

	// Call GetDIBits with a NULL lpBits param, so the device driver 
	// will calculate the biSizeImage field 
	GetDIBits(hDC, (HBITMAP)bitmap.GetSafeHandle(), 0L, (DWORD)bi.biHeight,
			(LPBYTE)NULL, (LPBITMAPINFO)lpbi, (DWORD)DIB_RGB_COLORS);

	bi = *lpbi;

	// If the driver did not fill in the biSizeImage field, then compute it
	// Each scan line of the image is aligned on a DWORD (32bit) boundary
	if (bi.biSizeImage == 0)
	{
		bi.biSizeImage = ((((bi.biWidth * bi.biBitCount) + 31) & ~31) / 8) 
						* bi.biHeight;
		// If a compression scheme is used the result may infact be larger
		// Increase the size to account for this.
		if (dwCompression != BI_RGB)
			bi.biSizeImage = (bi.biSizeImage * 3) / 2;
	}

	// Realloc the buffer so that it can hold all the bits
	dwLen += bi.biSizeImage;

	if (handle = GlobalReAlloc(hDIB, dwLen, GMEM_MOVEABLE))
	{
		hDIB = handle;
	}
	else
	{
		GlobalFree(hDIB);
		SelectPalette(hDC, hPal, FALSE);	// Reselect the original palette
		::ReleaseDC(NULL,hDC);
		return NULL;
	}

	// Get the bitmap bits
	lpbi = (LPBITMAPINFOHEADER)hDIB;

	// FINALLY get the DIB
	BOOL bGotBits = GetDIBits( hDC, (HBITMAP)bitmap.GetSafeHandle(),
				0L,				// Start scan line
				(DWORD)bi.biHeight,		// # of scan lines
				(LPBYTE)lpbi 			// address for bitmap bits
				+ (bi.biSize + nColors * sizeof(RGBQUAD)),
				(LPBITMAPINFO)lpbi,		// address of bitmapinfo
				(DWORD)DIB_RGB_COLORS);		// Use RGB for color table

	if (!bGotBits)
	{
		GlobalFree(hDIB);
		SelectPalette(hDC, hPal, FALSE);
		::ReleaseDC(NULL, hDC);
		return NULL;
	}

	SelectPalette(hDC, hPal, FALSE);
	::ReleaseDC(NULL, hDC);

	return hDIB;
}

// WriteDIB		- Writes a DIB to file
// Returns		- TRUE on success
// szFile		- Name of file to write to
// hDIB			- Handle of the DIB
BOOL CMainFrame::writeDIB(LPTSTR szFile, HANDLE hDIB)
{
	BITMAPFILEHEADER	hdr;
	LPBITMAPINFOHEADER	lpbi;

	if (!hDIB)
		return FALSE;

	CFile file;
	if(!file.Open(szFile, CFile::modeWrite|CFile::modeCreate))
		return FALSE;

	lpbi = (LPBITMAPINFOHEADER)hDIB;

	int nColors = int(pow(2, lpbi->biBitCount));
	if (nColors > 256)
		nColors = 0;

	// Fill in the fields of the file header 
	hdr.bfType	= ((WORD) ('M' << 8) | 'B');	// is always "BM"
	hdr.bfSize	= GlobalSize (hDIB) + sizeof(hdr);
	hdr.bfReserved1 = 0;
	hdr.bfReserved2 = 0;
	hdr.bfOffBits	= (DWORD) (sizeof(hdr) + lpbi->biSize +	nColors * sizeof(RGBQUAD));

	// Write the file header 
	file.Write(&hdr, sizeof(hdr));

	// Write the DIB header and the bits 
	file.Write(lpbi, GlobalSize(hDIB));
	file.Close();
	return TRUE;
}

LPCTSTR	CMainFrame::getPrintName()
{
	PRINTDLG pd;
	LPCTSTR	name;
	CWinApp* app = AfxGetApp();

	pd.lStructSize = (DWORD) sizeof(PRINTDLG);
	if (!app->GetPrinterDeviceDefaults(&pd))
		return NULL;
	LPDEVMODE pDevMode = (LPDEVMODE)::GlobalLock(pd.hDevMode); 
	if (NULL == pDevMode) 
	{
		::GlobalUnlock(pd.hDevMode);
		return NULL;
	}
	name = (LPCTSTR)pDevMode->dmDeviceName;
	::GlobalUnlock(pd.hDevMode);
	return name;
}

LPDEVMODE CMainFrame::getPrintMode()
{
	PRINTDLG pd;
	CWinApp* app = AfxGetApp();

	pd.lStructSize = (DWORD) sizeof(PRINTDLG);
	if (!app->GetPrinterDeviceDefaults(&pd))
		return NULL;
	LPDEVMODE pDevMode = (LPDEVMODE)::GlobalLock(pd.hDevMode); 
	if (NULL == pDevMode)
	{
		::GlobalUnlock(pd.hDevMode);
		return NULL;
	}
	::GlobalUnlock(pd.hDevMode);
	return pDevMode;
}

void CMainFrame::setUDP()
{
	BOOL		rc;
	char		wb[128];
	int		value;
	CString		tmps = _T("");

	getConnectInfo(tmps, value);
	value = 15900;
	strcpy(wb, tmps);
	m_wizard->InvokeHelper(DI_RUN, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), listenUDP, (long)wb, value);
}

void CMainFrame::beginWait(int key)
{
	int	waitkey;
	for (int ii = 0; ii < m_waitlist.GetSize(); ii++)
	{
		waitkey = m_waitlist.GetAt(ii);
		if (waitkey == key)
			m_waitlist.RemoveAt(ii--);
	}

	if (key & 0x80)
	{
		CMPop*	Mpop;
		CGPop*	Gpop;
		if (m_arMPOP.Lookup(key, Mpop))		Mpop->m_cursor = 1;
		else if (m_arGPOP.Lookup(key, Gpop))	Gpop->m_cursor = 1;
	}
	else
	{
		CChildFrame*	child;
		if (!m_arMDI[m_vsN].Lookup(key, child))
		{
			CSChild*	schild;
			if (!m_arSDI[m_vsN].Lookup(key, schild))
				return;
			schild->m_cursor = 1;
		}
		else	child->m_cursor = 1;
	}

	m_waitlist.Add(key);
	if (key == m_activeKey)
		::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));
}

void CMainFrame::endWait(int key)
{
	int	endkey;
	for (int ii = 0; ii < m_waitlist.GetSize(); ii++)
	{
		endkey = m_waitlist.GetAt(ii);
		if (endkey == key)
			m_waitlist.RemoveAt(ii--);
	}

	if (key & 0x80)
	{
		CMPop*	Mpop;
		CGPop*	Gpop;
		if (m_arMPOP.Lookup(key, Mpop))		Mpop->m_cursor = 0;
		else if (m_arGPOP.Lookup(key, Gpop))	Gpop->m_cursor = 0;
	}
	else
	{
		CChildFrame*	child;
		if (!m_arMDI[m_vsN].Lookup(key, child))
		{
			CSChild*	schild;
			if (!m_arSDI[m_vsN].Lookup(key, schild))
				return;
			schild->m_cursor = 0;
		}
		else	child->m_cursor = 0;
	}

	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
}

void CMainFrame::removeWait(int key)
{
	int	removekey;
	for (int ii = 0; ii < m_waitlist.GetSize(); ii++)
	{
		removekey = m_waitlist.GetAt(ii);
		if (removekey == key)
			m_waitlist.RemoveAt(ii--);
	}
}

bool CMainFrame::IsSelectMap(CString mapN)
{
	CString smapN;

	CProfile profile(GetProfileFileName());
	smapN = profile.GetString("Select", mapN.Mid(2, 4));

	return !smapN.IsEmpty();
}

CString CMainFrame::getSMap(CString mapN)
{
	if (mapN.IsEmpty())	return _T("");

	CProfile profile(GetProfileFileName());
	CString smapN(profile.GetString("Select", m_tMenu->GetDispN(mapN)));
	if (smapN.IsEmpty())
		return mapN;
	else
		return mapN.Left(2) + smapN;
}

void CMainFrame::loadDomino(int key, CString mapN, bool bSDI)
{
	if (bSDI)
	{
		CSChild*	schild;
		if (!m_arSDI[m_vsN].Lookup(key, schild))	return;

		int	size, vwTYPE;
		m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vwTYPE,
					(BYTE *)(VTS_BSTR VTS_I4), getSMap(mapN), &size);

		CRect	rect;
		CView*	view = schild->GetActiveView();

		int	gapX, gapY;
		gapX  = GetSystemMetrics(SM_CXFRAME) * 2;
		gapX += GetSystemMetrics(SM_CXBORDER) * 2;

		gapY  = GetSystemMetrics(SM_CYFRAME) * 2;
		gapY += GetSystemMetrics(SM_CYBORDER) * 2;
		if ((vwTYPE & vtypeMSK ) != vtypeWND)
			gapY += XCAP_HEIGHT;

		switch (vwTYPE)
		{
		case 0:
		default:
			if ((vwTYPE & vtypeMSK) == vtypeSCR)
				((CAxScrollView *)view)->SetInfo(key);//m_key = key;
			else	((CAxisView *)view)->SetInfo(key);//((CAxisView *)view)->m_key = key;
			break;
		}

		BOOL	rc = FALSE;
		m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapN, size, false/*true*/);
		if (!rc)	return;
		//m_bar1->set_Maps(mapN.Left(L_MAPN));
	}
	else
	{
		class CChildFrame* child;
		if (!m_arMDI[m_vsN].Lookup(key, child))	return;

		int	size, vwTYPE;
		m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vwTYPE,
					(BYTE *)(VTS_BSTR VTS_I4), getSMap(mapN), &size);

		CRect	rect;
		CView*	view = child->GetActiveView();

		int	gapX, gapY;
		gapX  = GetSystemMetrics(SM_CXFRAME) * 2;
		gapX += GetSystemMetrics(SM_CXBORDER) * 2;

		gapY  = GetSystemMetrics(SM_CYFRAME) * 2;
		gapY += GetSystemMetrics(SM_CYBORDER) * 2;
		if ((vwTYPE & vtypeMSK ) != vtypeWND)
			gapY += XCAP_HEIGHT;

		switch (vwTYPE)
		{
		case 0:
		default:
			if ((vwTYPE & vtypeMSK) == vtypeSCR)
				((CAxScrollView *)view)->SetInfo(key);//m_key = key;
			else	((CAxisView *)view)->SetInfo(key);//((CAxisView *)view)->m_key = key;
			break;
		}

		BOOL	rc = FALSE;
		m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapN, size, false/*true*/);
		if (!rc)	return;
		m_bar1->set_Maps(mapN.Left(L_MAPN));
	}
}

void CMainFrame::process_ConSee(int option)
{
	CString	code, mapN;
	switch (option)
	{
	case CON_HIDE:	ShowControlBar(m_bar0, FALSE, FALSE);	break;
	default:	return;
	}
}

// control bar code data receive
void CMainFrame::setCodeReg(int cnt, CString dat)
{
	CFile		file;
	CString		path, path_, code, name, string;
	path.Format("%s\\%s\\%s\\regCode", Axis::home, USRDIR, Axis::user);
	path_.Format("%s\\%s\\%s\\regCode.tmp", Axis::home, USRDIR, Axis::user);

	CopyFile(path, path_, FALSE);
	DeleteFile(path);
	if (!file.Open(path, CFile::modeCreate|CFile::modeWrite))
	{
		Axis::MessageBox(this, "Error. Don't save.", MB_ICONASTERISK);
		MoveFile(path_, path);
		return;
	}

	struct _regCode	regCode;
	for (int ii = 0; ii < cnt; ii++)
	{
		int	pos = dat.Find('\n');
		if (pos == -1)	break;
		string = dat.Left(pos++);
		dat = dat.Mid(pos);

		memset(&regCode, ' ', sizeof(regCode));
		pos = string.Find('\t');
		if (pos == -1)	continue;
		code = string.Left(pos++);
		code.TrimRight();
		if (code.IsEmpty())	continue;
		name = string.Mid(pos);
		if (code.GetLength() > 12)
			code = code.Left(12);
		if (name.GetLength() >= 32)
			name = name.Left(31);	// last byte is null terminate
		name.Replace("%", "%%");

		sprintf(regCode.code, code);
		sprintf(regCode.name, name);

		file.Write(&regCode, sizeof(regCode));
	}

	file.Close();
	DeleteFile(path_);

	m_bar0->reload_Code();
	if (!(m_bar0->GetStyle() & WS_VISIBLE))
		ShowControlBar(m_bar0, TRUE, FALSE);
}

void CMainFrame::ChangeUser()
{
	m_bExit = false;
	m_bReconnect = true;

	PostMessage(WM_CLOSE);
}

void CMainFrame::RunWebBrowser(CString HomePage, int cx, int cy)
{
	if (HomePage.Find("@") != -1 && HomePage.Find("@@dev9") == -1)	// ID�� "@@dev9��"����
	{
		ShellExecute(NULL, _T("open"), HomePage, NULL,NULL, SW_SHOWNORMAL);
		return;
	}
	
	//AfxMessageBox(HomePage);
	int find = HomePage.Find('\t');
	CString url;
	
	if (find > 0)
	{
		url = HomePage.Left(find);
		CString str(HomePage.Right(HomePage.GetLength() - (find + 1)));
		int width, height;
		width = height = 0;

		find = str.Find('\t');
		if (find > 0)
		{
			width = atoi(str.Left(find));
			str = str.Right(str.GetLength() - (find + 1));
			height = atoi(str);
		}
		if (width && height)
		{
			cx = width;
			cy = height;
		}
	}
	else
	{
		url = HomePage;
	}

	HomePage = url;
	VARIANT vFlags = {0},
	vTargetFrameName = {0},
	vPostData = {0},
	vHeaders = {0};

	HRESULT hr;
	_bstr_t	bstr(HomePage);
	UINT	nFlag = SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW;
	WINDOWPLACEMENT	pl;

	CRect	CRC = CRect(0, 0, 1, 1);
	ClientToScreen(&CRC);
	CRC.top += 85;
	
	if (::IsWindow(m_WBWnd))
	{
		m_pWBApp->Stop();
		if (HomePage.IsEmpty())
			m_pWBApp->GoHome();
		else
			m_pWBApp->Navigate(bstr, &vFlags, &vTargetFrameName, &vPostData, &vHeaders);

		//m_pWBApp->put_Top(VARIANT_TRUE);
		m_pWBApp->put_Left(CRC.left);
		m_pWBApp->put_Top(CRC.top);
		m_pWBApp->put_Visible(VARIANT_TRUE);
		VariantClear(&vPostData);
		::GetWindowPlacement(m_WBWnd, &pl);
		if (pl.showCmd & SW_SHOWMINIMIZED)
		{
			pl.showCmd = SW_RESTORE;
			::SetWindowPlacement(m_WBWnd, &pl);
		}
		else
		{
			::SetWindowPos(m_WBWnd, HWND_TOP, 0, 0, 0, 0, nFlag);
		}
		::PostMessage(m_WBWnd, WM_SETFOCUS, 0, 0);
		return;
	}

	if (FAILED(hr = CoInitialize(NULL)))	return;
	if (FAILED(hr = CoCreateInstance(CLSID_InternetExplorer,
			NULL, CLSCTX_SERVER, IID_IWebBrowserApp,
			(LPVOID*)&m_pWBApp)))	return;

	cx += GetSystemMetrics(SM_CXFRAME) * 2;
	cx += GetSystemMetrics(SM_CXBORDER) * 4;
	cy += GetSystemMetrics(SM_CYFRAME) * 2;
	cy += GetSystemMetrics(SM_CYBORDER) * 4;
	cy += GetSystemMetrics(SM_CYCAPTION);

	m_pWBApp->put_Width(cx);
	m_pWBApp->put_Height(cy);
//	m_pWBApp->put_Left(VARIANT_TRUE);
//	m_pWBApp->put_Top(VARIANT_TRUE);
	m_pWBApp->put_Left(CRC.left);
	m_pWBApp->put_Top(CRC.top);
	
	//** ���ٿ� ���¹ٸ� ǥ���ϱ�� ��. (IBK)
	//m_pWBApp->put_ToolBar(VARIANT_FALSE);
	//**m_pWBApp->put_StatusBar(VARIANT_FALSE);
//	m_pWBApp->put_Resizable(VARIANT_FALSE);
	CString helpurl = "http://www.ibks.com/HTSHELP/helptrnum.ids?trnum=";
	if (!(HomePage.Compare(helpurl)<0))
		m_pWBApp->put_ToolBar(VARIANT_FALSE);


	hr = m_pWBApp->Navigate(bstr, &vFlags, &vTargetFrameName, &vPostData, &vHeaders);
	if (HomePage.IsEmpty())	m_pWBApp->GoHome();
	m_pWBApp->put_Visible(VARIANT_TRUE);
	VariantClear(&vPostData);

	m_pWBApp->get_HWND((long *)&m_WBWnd);
	::GetWindowPlacement(m_WBWnd, &pl);
	if (pl.showCmd & SW_SHOWMINIMIZED)
	{
		pl.showCmd = SW_RESTORE;
		::SetWindowPlacement(m_WBWnd, &pl);
	}
	else
	{
		::SetWindowPos(m_WBWnd, HWND_TOP, 0, 0, 0, 0, nFlag);
	}

	CoUninitialize();
}

//	cx = 792, cy = 569;
void CMainFrame::PopupWeb(CString url, int cx, int cy)
{
	if (url.Find("@") != -1)
	{
		ShellExecute(NULL, _T("open"), url, NULL,NULL, SW_SHOWNORMAL);
		return;
	}

	CString HomePage = url;
	VARIANT vFlags = {0},
	vTargetFrameName = {0},
	vPostData = {0},
	vHeaders = {0};

	HRESULT hr;
	_bstr_t	bstr(HomePage);
	UINT	nFlag = SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW;
	WINDOWPLACEMENT	pl;

	if (FAILED(hr = CoInitialize(NULL)))
		return;

	struct	IWebBrowserApp* pWEBApp;
	HWND	hWEB;
	if (FAILED(hr = CoCreateInstance(CLSID_InternetExplorer,
			NULL, CLSCTX_SERVER, IID_IWebBrowserApp,
			(LPVOID*)&pWEBApp)))
	{
		return;
	}

	cx += GetSystemMetrics(SM_CXFRAME) * 2;
	cx += GetSystemMetrics(SM_CXBORDER) * 4;
	cy += GetSystemMetrics(SM_CYFRAME) * 2;
	cy += GetSystemMetrics(SM_CYBORDER) * 4;
	cy += GetSystemMetrics(SM_CYCAPTION);

	pWEBApp->put_Width(cx);
	pWEBApp->put_Height(cy);
	pWEBApp->put_Left(VARIANT_TRUE);
	pWEBApp->put_Top(VARIANT_TRUE);
	pWEBApp->put_ToolBar(VARIANT_FALSE);
	pWEBApp->put_StatusBar(VARIANT_FALSE);
	hr = pWEBApp->Navigate(bstr, &vFlags, &vTargetFrameName, &vPostData, &vHeaders);
	if (HomePage.IsEmpty())	pWEBApp->GoHome();
	pWEBApp->put_Visible(VARIANT_TRUE);
	VariantClear(&vPostData);

	pWEBApp->get_HWND((long *)&hWEB);
	::GetWindowPlacement(hWEB, &pl);
	if (pl.showCmd & SW_SHOWMINIMIZED)
	{
		pl.showCmd = SW_RESTORE;
		::SetWindowPlacement(hWEB, &pl);
	}
	else	
		::SetWindowPos(hWEB, HWND_TOPMOST, 0, 0, 0, 0, nFlag);

	CoUninitialize();
}

void CMainFrame::ExitWebBrowser()
{
	if (::IsWindow(m_WBWnd))
	{
		m_WBWnd = NULL;
		m_pWBApp->Stop();
		m_pWBApp->Quit();
		m_pWBApp->Release();
	}
}

void CMainFrame::funcKey(int funcID, int index)
{
	switch (funcID)
	{
	case CTRL_EDITTOOL:	EditTool();	break;
	case CTRL_REGISTER:	toolRegister();	break;
	case CTRL_SCREENPRINT:	printImg();	break;
	case CTRL_LOCK:		LockProg();	break;
	case CTRL_SAVEWORKSPACE:
		saveUserScreen();		break;
	case CTRL_WORKSPACELIST:
		ShowUScreenMenu();		break;
	case CTRL_REGISTERALL:
		toolRegisterAll(index);		break;
	case CTRL_ENVIRONMENT:
		SetTicker();//TotalSetup(); 
		break;
	case CTRL_NEWS:
		ShowNews();
		break;
	case CTRL_FUNC + 14:
		RunTopBanner();
		break;
	default:
		if (funcID >= CTRL_FUNC + 1 && funcID <= CTRL_FUNC + 12)
			DoFunc(funcID);
	}
}

void CMainFrame::RunTopBanner()
{
	CString	Path;
	Path.Format("%s\\%s\\BANNER.INI", Axis::home, "tab");

	char readB[1024];
	int readL;
	
	readL = GetPrivateProfileString("BANNER","url","http://www.ibks.com",readB,sizeof(readB),Path);

	CString url(readB,readL);

	int left,top;

	left = 0;
	top = 0;

	if (url.Find("HTS:") > -1)
	{
		CString mapname = url.Right(8);
		m_mapHelper->CreateChild(mapname,0,0,LtopPOS,CPoint(left,top));
	}
	else
	{
		ShellExecute(NULL, _T("open"), url, NULL,NULL, SW_SHOWNORMAL);
		return;
	}
}

bool CMainFrame::changeMAX(CString mapN)
{
	bool	bMax = false;
	int	vtype = 0, vwTYPE = 0, size = 0, key = 0;
	m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
				(BYTE *)(VTS_BSTR VTS_I4), mapN, &size);

	WINDOWPLACEMENT	pl;
	for (int ii = 0; ii < 4; ii++)
	{
		int		key;
		CChildFrame*	pChild;
		for (POSITION pos = m_arMDI[ii].GetStartPosition(); pos; )
		{
			m_arMDI[m_vsN].GetNextAssoc(pos, key, pChild);
			pChild->GetWindowPlacement(&pl);
			if (pl.showCmd & SW_SHOWMINIMIZED)
			{
				bMax = true;
				if (vtype == vtypeNRM || vtype == vtypeERR)
					continue;
				pl.showCmd = SW_HIDE|SW_RESTORE;
				pChild->GetWindowPlacement(&pl);
			}
		}
	}

	return bMax;
}

////////////////////////////////////////////////
/////  2006. 08. 23 ����ȣ
////////////////////////////////////////////////
CString CMainFrame::Parser(CString &srcstr, CString substr)
{
	if (srcstr.Find(substr) == -1)
	{
		CString temp = srcstr;
		srcstr.Empty();
		return temp;
	}
	else
	{
		CString  temp = srcstr.Left(srcstr.Find(substr));
		srcstr = srcstr.Mid(srcstr.Find(substr) + substr.GetLength());
		return temp;
	}
	return "";
}

void CMainFrame::load_eninfomation(bool first)
{
	CString		file, key, mapN, userN;
	int		value;
	long		rc = 0;

	CProfile profile(pkEnvironment);

	file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, SETUPFILE);
	//ó�� �����ڴ� ����Ʈ�� ��й�ȣ ���� �˾� �ȵǰ� ����Ʈ ������ �ٲ�
	if (!GetPrivateProfileInt("SCREEN", "POPUPACCFIRST", 0, file))
	{
		WritePrivateProfileString("SCREEN", "POPUPACCFIRST", "1", file);
		WritePrivateProfileString("SCREEN", "POPUPACC", "0", file);
	}

	if (m_bCustomer && first && GetPrivateProfileInt("SCREEN", "POPUPACC", 1, file)
			&& Axis::user.CollateNoCase("guest"))
		AcctPasswordConfig();
	//��â���� ���
	m_screenNew = GetPrivateProfileInt("SCREEN", "SCREENNEW", 1, file);

	value = profile.GetInt(szETC, "SELECT", 1);

	if (value < 0 || value > 4)
		value = 1;

	key.Format("%02d", value);

	m_maxChild = profile.GetInt(szETC, key, 16);
	if (m_maxChild > 99)	m_maxChild = 99;
	if (m_maxChild <= 0)	m_maxChild = 1;
	
	value = profile.GetInt(szScreen, "STARTMAP");
	if (first)
	{
		switch (value)
		{
		case 1:	createUserScreen(szLastStat, true);		break;
		case 2: createUserScreen(szStartMap, true);	break;
		default:			break;
		}
	}
	m_posChild = profile.GetInt(szScreen, "CHILDPOS");
	m_fontSize = profile.GetInt(szScreen, "FONTSIZE", 9);
	if (m_fontSize < 8) m_fontSize = 8;
	if (m_fontSize > 12) m_fontSize = 12;

	changeFontSize();

	value = profile.GetInt(szScreen, "UNFLESH") ? 0 : 1;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFCB, 0), value);

//	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
//			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setTRG, 0), MAKELONG(0, 0));	// ���ϱ׷� ����

	value = profile.GetInt(szScreen, "VS_REFLECT", 1) ? 1 : 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setTRG, 1), MAKELONG(0, value));
	
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setVID, m_vsN), MAKELONG(0, 0));

	m_axGuide->SetPos(profile.GetInt(szScreen, "MSGPOS"));

	KillTimer(TM_IDLE);
	m_idletime = profile.GetInt(szScreen, "IDLETIME");

	LoadHotkeySetting();

	//ReadNoticeMap();
}

void CMainFrame::load_mngSetup()
{
	CProfile profile(pkManageSetup);
	CString szTotal, szUnit;

	if (!profile.GetInt(szMessage, "Init"))
	{
		CString	strTotal = _T("");

		static	struct	_msginfo {
			int	val;
			char	desc[20];
		} msgOPEN[] = { 
				{1,	"30����" },
				{21,	"10����" },
				{26,	"5����" },
				{30,	"1����" },
				{33,	"30����" },
				{31,	"10����" }
				};

		static struct _msginfo msgCLOSE[] = 
			{
				{ 121,	"10����" },
				{ 126,	"5����" },
				{ 130,	"1����" },
				{ 133,	"30����" },
				{ 131,	"10����" }
			};

		int	ncnt = sizeof(msgOPEN) / sizeof(_msginfo);
		
		strTotal = _T("");
		for ( int ii = 0 ; ii < ncnt ; ii++ )
		{
			strTotal += Format("%d, ", msgOPEN[ii].val);
		}

		profile.Write(szMessage, "OPEN", strTotal);
		strTotal = _T("");

		ncnt = sizeof(msgCLOSE) / sizeof(_msginfo);
		
		for ( ii = 0 ; ii < ncnt ; ii++ )
		{
			strTotal += Format("%d, ", msgCLOSE[ii].val);
		}

		profile.Write(szMessage, "CLOSE", strTotal);
		profile.Write(szMessage, "INIT", "1");
	}

	// �尳��
	szTotal = profile.GetString(szMessage, "OPEN");
	m_mapAlarmList.RemoveAll();
	while (!szTotal.IsEmpty())
	{
		szUnit = Parser(szTotal, ",");
		Trim(szUnit);
		if (!szUnit.IsEmpty())
			m_mapAlarmList.SetAt(szUnit, "");
	}

	// �帶��
	szTotal = profile.GetString(szMessage, "CLOSE");
	while (!szTotal.IsEmpty())
	{
		szUnit = Parser(szTotal, ",");
		Trim(szUnit);
		if (!szUnit.IsEmpty())
			m_mapAlarmList.SetAt(szUnit, "");
	}	

	m_bSound = profile.GetInt("Setup", "SOUND") == 1;
	m_nInfoPos = profile.GetInt("Setup", "POS", 2);
	m_bUseAlarm = profile.GetInt("Setup", "USE", 1);
	m_nBkMode = profile.GetInt(szBkNotice, "MODE");

	// KOBA ELW �� �˸� ����
	int val = profile.GetInt("Manage", MNG_INFO_KOBAELW, -1);
	if (val==-1)
	{
		m_bKobaElwNotify = true;
	}
	else 
	{
		m_bKobaElwNotify = (val==1) ? true : false;
	}
}

void CMainFrame::load_hkey()
{
	CProfile profile(pkHotKey);

	m_bHome = profile.GetInt(szHKey, "home", 1);
	m_bEnd  = profile.GetInt(szHKey, "end", 1);
}

void CMainFrame::maxChild()
{
	int	key, index, count = 0;
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		count += m_arMDI[vsN].GetCount();
		count += m_arSDI[vsN].GetCount();
	}

	if (count > m_maxChild)
	{
		vsN = m_vsN+1;
		for (int jj = 0; jj <= V_SCREEN6; jj++, vsN++)
		{
			bool sdi = false;
			if (vsN > V_SCREEN6)	vsN = V_SCREEN1;
			if (m_arMDI[vsN].GetCount() <= 0)
			{
				if (m_arSDI[vsN].GetCount() <= 0)
					continue;
				sdi = true;
			}

			if (sdi)
			{
				CSChild*	schild = NULL;
				POSITION pos = m_arSDI[vsN].GetStartPosition();
				m_arSDI[vsN].GetNextAssoc(pos, key, schild);
				if (!schild)	continue;
				schild->PostMessage(WM_CLOSE);
			}
			else
			{
				index = m_hooklist[vsN].GetSize() - 1;
				key = m_hooklist[vsN].GetAt(index);
				
				CChildFrame*	child;
				if (!m_arMDI[vsN].Lookup(key, child))
					continue;
				child->PostMessage(WM_CLOSE);
			}
			break;
		}
	}
}

void CMainFrame::detachChild(int key)
{
	if (key < 0)	return;

	CChildFrame*	pChild = NULL;
	int	vsN;
	for (vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		if (!m_arMDI[vsN].Lookup(key, pChild))
			continue;
		//m_arMDI[vsN].RemoveKey(key);
		//RedrawVS(true);
		// dtitle
		RemoveMdi(vsN, key);
		break;
	}

	if (!pChild)	return;
	m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
			(void *)NULL, (BYTE *)(VTS_I4), (short) key);

	if (MDIGetActive() == NULL)
	{
		if (m_bar1)	m_bar1->set_Maps();
		m_hooklist[m_vsN].RemoveAll();
	}
	if (m_bar2)	m_bar2->del_Button(key, vsN);
	for (int ii = 0; ii < m_hooklist[vsN].GetSize(); ii++)
	{
		if (key != m_hooklist[vsN].GetAt(ii))
			continue;
		m_hooklist[vsN].RemoveAt(ii);
	}
}

void CMainFrame::saveExitMap()
{
	CProfile profile(pkEnvironment);
// 	CString str(profile.GetString(szScreen, "STARTMAP"));
// 	if (atoi(str) != 1) 
// 		return;

	save_laststat();
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	WriteLog("OnTimer Start");
	switch (nIDEvent)
	{
	case TM_AUTOHIDE:
		WriteLog("OnTimer - TM_AUTOHIDE");
		KillTimer(nIDEvent);
		if (m_conAUTOTIME)
			m_conclusion->ShowWindow(SW_HIDE);
		break;
	case TM_AUTOMSN:
		WriteLog("OnTimer - TM_AUTOMSN");
		m_Econclusion->HideSlide();	
		break;
	case TM_AUTOMNGINFO:
		WriteLog("OnTimer - TM_AUTOMNGINFO");
		m_mngInfo->HideSlide();
		KillTimer(TM_AUTOMNGINFO);
		break;
	case TM_IDLE:
		WriteLog("OnTimer - TM_IDLE");
		KillTimer(nIDEvent);
		LockProg();
		break;
	case TM_PURL:
		WriteLog("OnTimer - TM_PURL");
		KillTimer(nIDEvent);
		break;
	case TM_PRNIMG:
		WriteLog("OnTimer - TM_PRNIMG");
		{
			KillTimer(TM_PRNIMG);
			printOper(m_pPRNChild, m_sizePRN, m_sizePRNORG, m_szPRNData, m_bPRNResize);
		}
		break;
	case TM_AUTODCOTOR:
		WriteLog("OnTimer - TM_AUTODCOTOR");
		if (m_pDoctor)	m_pDoctor->HideSlide();
		break;
	case TM_RTSQUEUE:
		WriteLog("OnTimer - TM_RTSQUEUE");
		//checkRTSQueue();
		break;
	case TM_SCRLOG:
		WriteLog("OnTimer - TM_SCRLOG");
		writeOpenedList();
		break;
	case TM_TEST:
		WriteLog("OnTimer - TM_TEST");
		{
			KillTimer(TM_TEST);
		}
		break;
	case TM_INITSIZE:
		WriteLog("OnTimer - TM_INITSIZE");
		{
			KillTimer(TM_INITSIZE);
			CString name = "IBINITSIZE";
			CProfile pout(pkUserConfig);
			int piout = pout.GetInt(name, "OnLoad", 0);
			if (piout == 0)
			{
				InitMapSize();
			}
		}
		break;
	case TM_NOTICE:
		WriteLog("OnTimer - TM_NOTICE");
		{
			KillTimer(TM_NOTICE);
			//ReadNotice();
			ReadNoticeMap();
		}
		break;
	case TM_DNINTEREST:
		WriteLog("OnTimer - TM_DNINTEREST");
		{
			WriteLog("TM_DNINTEREST - Step 1");
			KillTimer(TM_DNINTEREST);
			if (m_info_interest)
			{
				m_info_interest->SetOK();
			}

			WriteLog("TM_DNINTEREST - Step 2");
			SetForegroundWindow();

			WriteLog("TM_DNINTEREST - Step 3");
			if (m_bdnInterest)
			{
				WriteLog("TM_DNINTEREST - Step 4-1");
				load_eninfomation();
				WriteLog("TM_DNINTEREST - Step 4-2");
				const char* trust = "IB820850";
				if (!IsExistMap(trust))
				{
					//CString date(p.GetString(noticeMapName, "DATE", "20080601"));
					//if (atoi(date) < atoi(CTime::GetCurrentTime().Format("%Y%m%d")))
					m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
				}
				WriteLog("TM_DNINTEREST - Step 4-3");
				load_start_notice();
				WriteLog("TM_DNINTEREST - Step 4-4");

				CString	PathCookie;

				PathCookie.Format("%s\\%s\\NOTICECOOKIE.INI", Axis::home, "tab");

				CString date;
				
				CTime time;
				time = CTime::GetCurrentTime();
				
				date.Format("%04d%02d%02d",time.GetYear(),time.GetMonth(),time.GetDay());
				
				char readB[1024];
				int readL;
				
				readL = GetPrivateProfileString("7700","TODAY","",readB,sizeof(readB),PathCookie);
				
				CString strDate(readB,readL);

				strDate.TrimLeft();
				strDate.TrimRight();

				if(strDate != "")
				{
					if(date == strDate)
					{
						int update = GetPrivateProfileInt("7700","FIRST",1,PathCookie);
						
						if(update == 1)
						{
							trust = "IB770000";
							//if (!IsExistMap(trust))
							{
								m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
							}
						}
					}
					else
					{
						WritePrivateProfileString("7700","TODAY",date,PathCookie);
						WritePrivateProfileString("7700","FIRST","1",PathCookie);

						trust = "IB770000";
						//if (!IsExistMap(trust))
						{
							m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
						}
					}
				}
				else
				{
					trust = "IB770000";
					//if (!IsExistMap(trust))
					{
						m_mapHelper->ChangeChild(trust, 1, 0, CenterPOS);
					}
				}

				ReadNoticeMap();
				//�����ְ���
				//MessageBox("�ý��� �����۾����� ���Ͽ� �Ϻνü� ���������� �� �ǰ� �ֽ��ϴ�. \n������ ��� �˼��մϴ�. �����մϴ�.", "IBK��������");
				WriteLog("TM_DNINTEREST - Step 4-5");
			}
		}
		break;
	case TM_SLIDE:
		if(m_slideMsg != "")
		{
			m_mngInfo->SetData(m_slideMsg, 3);
			
			CRect		mRc;
			WINDOWPLACEMENT	pl;
			GetWindowPlacement(&pl);
			switch (pl.showCmd)
			{
			case SW_HIDE:case SW_MINIMIZE:case SW_SHOWMINIMIZED:
				m_mngInfo->ShowWindow(SW_HIDE);
				CMDIFrameWnd::OnTimer(nIDEvent);
				return;
			default:
				break;
			}
			m_mngInfo->ShowWindow(SW_HIDE);
			
			MngInfoPos();
			
			m_slideMsg = "";

			KillTimer(TM_SLIDE);
		}
		break;
	}
	WriteLog("End OnTimer");
	CMDIFrameWnd::OnTimer(nIDEvent);
}

CWnd* CMainFrame::getActiveView(int key)
{
	CChildFrame*	child;
	CSChild*	schild;

	if (m_arMDI[m_vsN].Lookup(key, child))
		return child->GetActiveView();
	if (m_arSDI[m_vsN].Lookup(key, schild))
		return schild->GetActiveView();
	return NULL;
}

void CMainFrame::load_history()
{
	if (!m_tMenu)	return;

	CProfile profile(pkAxisUser);

	m_savelist.RemoveAll();
	CString maps(profile.GetString(szSystem, "maps"));
	//AfxMessageBox(maps);
	if (maps.IsEmpty())
		return;

	CString tmpS;
	

	while (!maps.IsEmpty())
	{
		int pos = maps.Find(',');
		if (pos == -1)
		{
			maps.TrimLeft();
			maps.TrimRight();
			if (maps.GetLength() == L_MAPN)
			{
				add_history(maps);
				addTool_history(maps);
			}
			break;
		}
		tmpS = maps.Left(pos);
		maps = maps.Mid(pos+1);
		tmpS.TrimLeft();	tmpS.TrimRight();
		if (tmpS.GetLength() == L_MAPN)
		{
			add_history(tmpS);
			addTool_history(tmpS);
		}
	}
}

void CMainFrame::save_history()
{
	CProfile profile(pkAxisUser);
	CString str(""), maps;

	for (int i = 0; i < m_savelist.GetSize(); i++)
	{
		if (!i)
			maps = m_savelist.GetAt(i);
		else
			maps.Format(", %s", m_savelist.GetAt(i));

		str += maps;
	}

	profile.Write(szSystem, "maps", str);
}

void CMainFrame::add_history(CString mapN)
{
	if (mapN.GetLength() != L_MAPN)	return;

	CString	file, maps, tmpS, tail;
	for (int ii = 0; ii < m_savelist.GetSize(); ii++)
	{
		maps = m_savelist.GetAt(ii);
		tail = maps.Mid(6, 2);
		if (tail.CompareNoCase("00"))	continue;
		if (!mapN.CompareNoCase(maps))	return;
	}
	m_savelist.Add(mapN);
}

void CMainFrame::addTool_history(CString mapName)
{
	CString	dat, mapN = mapName.Left(L_MAPN);
	CString	tail = mapN.Mid(6);

	if (tail.CompareNoCase("00"))	return;
	dat.Format("%s%s%s", m_tMenu->GetDispN(mapN), mapN, m_tMenu->GetDesc(mapN));
	m_bar1->add_History(dat);
	m_smain->add_History(dat);
}

// for device............
void CMainFrame::view_Hook(int key)
{
return;
	CView* view = (CView *) getActiveView(key);
	if (!view)	return;
	view->SendMessage(WM_VIEWHOOK, 0, 0);
}

void CMainFrame::view_UnHook()
{
	if (m_callproc && m_view)
		SetWindowLong(m_view->GetSafeHwnd(), GWL_WNDPROC, (LONG)m_callproc);

	m_view = NULL;
	m_callproc = NULL;
}

void CMainFrame::load_tabview()
{
	CProfile profile(pkAxisTab);
	CString str, key, dat;

	for (int i = 0; i < 999; i++)
	{
		key.Format("%03d", i);
		str = profile.GetString(szTabView, key);
		if (str.IsEmpty())
			continue;

		while (!str.IsEmpty()) 
		{
			int pos = str.Find(',');
			if (pos == -1)
			{
				Trim(str);
				if (str.GetLength() == L_MAPN)
				{
					if (ExistMenu(str))
						m_tabviewlist.SetAt(str, key);
				}
				break;
			}

			dat = str.Left(pos);
			str = str.Mid(pos+1);
			Trim(dat);
			
			if (dat.GetLength() == L_MAPN)
			{
				if (ExistMenu(dat))
					m_tabviewlist.SetAt(dat, key);
			}
		}
	}
}

bool CMainFrame::IsTabView(CString mapN)
{
	CString	key;
	if (m_tabviewlist.Lookup(mapN, key))
	{
		return ExistMenu(mapN);
	}
	return false;
}

bool CMainFrame::IsTabChange(CString mapN, int &key)
{
	int	childkey;
	CString	tKey, oKey;
	if (!m_tabviewlist.Lookup(mapN, tKey))
		return false;

	CChildFrame*	pChild;
	CSChild*	schild;

	BOOL fromSingleMap = FALSE;
	if (!m_arMDI[m_vsN].Lookup(key, pChild) && m_arSDI[m_vsN].Lookup(key, schild))
		fromSingleMap = TRUE;

	if (!fromSingleMap)
	{
		for (POSITION pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
		{
			m_arMDI[m_vsN].GetNextAssoc(pos, childkey, pChild);
			if (!pChild->IsTabView())		
				continue;
			if (!m_tabviewlist.Lookup(pChild->m_mapN, oKey))
				continue;
			if (tKey != oKey)		
				continue;

			key = childkey;

			return true;
		}
	}
	else
	{
		for (POSITION pos = m_arSDI[m_vsN].GetStartPosition(); pos; )
		{
			m_arSDI[m_vsN].GetNextAssoc(pos, childkey, schild);
			if (!schild->IsTabView())		
				continue;
			if (!m_tabviewlist.Lookup(schild->m_mapN, oKey))
				continue;
			if (tKey != oKey)		
				continue;
			key = childkey;
			return true;
		}
	}
	return false;
}

CString CMainFrame::GetTabKey(CString mapN)
{
	CString	key;
	if (m_tabviewlist.Lookup(mapN, key))
		return key;
	return _T("");
}

void CMainFrame::change_Resource()
{
	CString		skinName = GetSkinName();
	m_resourceHelper->ChangeRES(skinName,true);

	int		key;
	CSChild*	schild;
	CChildFrame*	child;
	for (int ii = V_SCREEN1; ii <= V_SCREEN6; ii++)
	{
		for (POSITION pos = m_arMDI[ii].GetStartPosition(); pos; )
		{
			m_arMDI[ii].GetNextAssoc(pos, key, child);
			child->ChangeSkin(skinName);
			if (!child->IsTabView())	
				continue;
			CView* view = child->GetActiveView();
			((CAxTabView *) view)->ChangeSkin();
		}

		for (pos = m_arSDI[ii].GetStartPosition(); pos; )
		{
			m_arSDI[ii].GetNextAssoc(pos, key, schild);
			schild->ChangeSkin(skinName);
			if (!schild->IsTabView())	
				continue;
			CView* view = schild->GetActiveView();
			((CAxTabView *) view)->ChangeSkin();
		}
	}
}

void CMainFrame::SetConclusion()
{
	CProfile profile(pkOrderSetup);

	m_conKIND = profile.GetInt(szCommon, "CK_RTF", CON_POPUP | CON_SOUND);
	m_conHISTORY = profile.GetInt(szCommon, "CK_HISTORY1", 20);
	m_conAUTOTIME = profile.GetInt(szCommon, "CK_AUTOHIDE", 0);
	m_conPOS = profile.GetInt(szCommon, "CK_POS", 5);

	const char* szSoundFiles[] = 
	{
		"SOUNDFILE_MDORDER", "SOUNDFILE_MSORDER", "SOUNDFILE_JJORDER", "SOUNDFILE_CSORDER",
		"SOUNDFILE_MDCON", "SOUNDFILE_MSCON", "SOUNDFILE_REFUSAL", NULL
	};

	const char* szDefSoundFiles[] =
	{
		"\\image\\�ŵ��ֹ�����.WAV",
		"\\image\\�ż��ֹ�����.WAV",
		"\\image\\�����ֹ�����.WAV",
		"\\image\\����ֹ�����.WAV",
		"\\image\\�ŵ��ֹ�ü��.WAV",
		"\\image\\�ż��ֹ�ü��.WAV",
		"\\image\\�ֹ��ź�.WAV"
	};

	for (int i = 0; szSoundFiles[i]; i++)
	{
		m_waveF[i] = profile.GetString(szCommon, szSoundFiles[i]);

		// 2011.02.23 ���������� ������ �ƴҰ�� Default�� �������ش�.
		WIN32_FIND_DATA wfd;
		memset(&wfd, 0, sizeof(wfd));
		HANDLE handle = FindFirstFile(m_waveF[i], &wfd);
		if (handle==INVALID_HANDLE_VALUE)
		{
			m_waveF[i] = Axis::home + szDefSoundFiles[i];
			profile.Write(szCommon, szSoundFiles[i], (LPCSTR)m_waveF[i]);
		}
		else
		{
			FindClose(handle);
		}
	}

	m_matchToolBar = profile.GetInt(szCommon, "MatchToolBar");
	m_matchToolCount = profile.GetInt(szCommon, "MatchToolCount", 3);

	if (m_tInfo3)
	{
		m_tInfo3->SetCols(m_matchToolCount);
		if (m_matchToolBar == 1)
			ShowControlBar(m_tInfo3, TRUE, FALSE);
		else
			ShowControlBar(m_tInfo3, FALSE, FALSE);
	}
	
	
	// 20070330 �޼���Ȯ��â:ledger���� msgbox ����� field check���ϵ���
	// wizard 0:�⺻�޼���������,1:�޼����ȳ�������
	// file 0:�ȶ��, 1:���
	/**
	long	rc = 0;
	int value = profile.GetInt(szCommon, "ShowMsg2", 1);
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setNOMSG, 0), (value ? 0 : 1));
	**/

	CProfile p(pkEnvironment);
	long	rc = 0;
	int value = p.GetInt(szScreen, "msgbox", 1);
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setNOMSG, 0), (value ? 0 : 1));
}

void CMainFrame::ShowConclusion()
{
	if (m_conclusion)
	{
		if (m_conclusion->GetStyle() & WS_VISIBLE)
			m_conclusion->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
		else
		{
			int	x, y;
			CRect	mRc, wRc;

			mRc = GetWndRect();
			m_conclusion->GetWindowRect(wRc);

			switch (m_conPOS)
			{
			case 0:	// left - top
				x = mRc.left;	y = mRc.top;
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
				break;
			case 1:	// center
				x = mRc.CenterPoint().x - wRc.Width()/2;
				y = mRc.CenterPoint().y - wRc.Height()/2;
				break;
			case 2:	// right - top
				x = mRc.right - wRc.Width() - GetSystemMetrics(SM_CXFIXEDFRAME);
				y = mRc.top;
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
// 				if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
// 					x = GetSystemMetrics(SM_CXSCREEN) - wRc.Width();
				break;
			case 3:	// left - bottom
				x = mRc.left;
				y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
// 				if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
// 					y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				break;
			case 4:	// mouse pos
				{
					CPoint	point(0, 0);
					GetCursorPos(&point);
					x = point.x;	y = point.y;
					if (x < 0)	x = 0;
					if (y < 0)	y = 0;

// 					if (x > GetSystemMetrics(SM_CXSCREEN) - wRc.Width())
// 						x = GetSystemMetrics(SM_CXSCREEN) - wRc.Width();
// 					if (y > GetSystemMetrics(SM_CYSCREEN) - wRc.Height())
// 						y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				}
				break;
			default:
			case 5:	// right - bottom
				x = mRc.right - wRc.Width() - GetSystemMetrics(SM_CXFIXEDFRAME);
				y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
// 				if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
// 					x = GetSystemMetrics(SM_CXSCREEN) - wRc.Width();
// 				if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
// 					y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				break;
			}
			
			m_conclusion->SetWindowPos(NULL, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
			m_conclusion->MoveWindow(x, y, wRc.Width(), wRc.Height());
		}
	}
}

void CMainFrame::ShowEConclusion(CString dat, bool bFail)
{
	
	if (m_Econclusion)
	{
		
		m_Econclusion->StopSlide();
		m_Econclusion->SetData(dat, bFail);

		CRect		mRc;
		WINDOWPLACEMENT	pl;
		GetWindowPlacement(&pl);
		switch (pl.showCmd)
		{
		case SW_HIDE:case SW_MINIMIZE:case SW_SHOWMINIMIZED:
			m_Econclusion->ShowWindow(SW_HIDE);
			return;
		default:
			break;
		}
		m_Econclusion->ShowWindow(SW_HIDE);
		mRc = GetWndRect();
		m_Econclusion->ShowSlide(mRc);

		SetTimer(TM_AUTOMSN, 3000, NULL);
	}
}

void CMainFrame::ShowMngInfo(DWORD* dat)
{
	if (m_mngInfo)
	{
		CString		sym, val, str;
		CString		msgS;
		int		pos = 0, kind = 0;
		CString		wavfile;
	
		if (!dat[601])	// KEY(601)
			return;

		val = (char*)dat[601];

		// KOBA ELW �������� �ȳ�
		if (val==MNG_KOBAELW && m_bKobaElwNotify)
		{
			if (dat[23])
			{
				val = (char*)dat[23];

				int x, y;
				CRect mRc, wRc;
				
				mRc = GetWndRect();
				m_kobanotify->GetWindowRect(wRc);

				x = mRc.left;
				y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
				if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
					y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				
				m_kobanotify->AddNotify(val);
				m_kobanotify->SetWindowPos(NULL, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
				m_kobanotify->MoveWindow(x, y, wRc.Width(), wRc.Height());
			}
		}

		if (atoi(val) <= NO_CHECK)
		{
			if (!m_mapAlarmList.Lookup(val, str))
				return;
		}
		
// 		if (!fms.Lookup(MNG_KIND, sym))	// 0:������,1:�˸�
// 			return;
		if(!dat[47])
			return;
		sym = (char*)dat[47];

		if (!m_bUseAlarm)
			return;

		kind = atoi(sym);
		val = _T("");
		if(dat[23])
			msgS = (char*)dat[23];
		m_mngInfo->StopSlide();
		str = _T("");
		if (m_bSound && dat[600])
		{
			str = (char*)dat[600];
			if (!str.IsEmpty())	
			{
				wavfile.Format("%s\\%s\\%s.wav", Axis::home, IMAGEDIR, str);
				if (!IsFileExist(wavfile))  wavfile.Format("%s\\%s\\%s.wav", Axis::home, IMAGEDIR, "000");
				sndPlaySound(NULL, SND_NODEFAULT|SND_ASYNC);
				sndPlaySound(wavfile, SND_NODEFAULT|SND_ASYNC);
			}
		}

		if(msgS.GetAt(0) == 'X')
		{
// 			OutputDebugString("============================================================\n");
// 			OutputDebugString("Bullon Notice Call\n");
// 			OutputDebugString("============================================================\n");
			msgS = msgS.Mid(1);
			kind = 3;
		}

		ShowMngInfo(msgS, kind);
	}
}

void CMainFrame::ShowMngInfo(CString dat)
{
	// {      2, 802,  "�ֽ� �ð��ܰ���"       },
	// {      3, 803,  "�ֽ� �ð�������"       },
	// {      4, 804,  "�ֽ� �ð��ܰ���"       },
	// {      5, 805,  "�ֽ� ���ϰ�����"       },
	// {      6, 806,  "�ֽ� ���ϰ�����"       },
	// SAMPLE
	// #define SYM_MNG		"XXXXX"
	// #define MNG_KIND		"047"	0:������,1:�˸�
	// #define MSG_MGUBN		"600"	�屸��
	// #define MNG_FLAG		"601"	KEY
	// #define MNG_MSG		"023"	message
	
	// #define NO_CHECK		200
	// XXXXX	047	1	600	000	601	35	023	�尳�� 10����
	// XXXXX	047	0	600	801	601	801	023	�尳�� 
	//AfxMessageBox(dat);



	if (m_mngInfo)
	{
		CMapStringToString	fms;
		CString		sym, val, str;
		CString		msgS;
		int		pos = 0, kind = 0;
		CString		wavfile;

		while(!dat.IsEmpty())
		{
			pos = dat.Find("\t");

			if (pos != -1)
			{
				sym = dat.Left(pos++);
				dat = dat.Mid(pos);
				pos = dat.Find("\t");
				if (pos != -1)
				{
					val = dat.Left(pos++);
					dat = dat.Mid(pos);
				}
				else
				{
					val = dat;
					dat = _T("");
				}
			}
			else
			{
				sym = dat;
				val = _T("");
				dat = _T("");
			}
			
			
			if (sym.IsEmpty())
				break;

			fms.SetAt(sym, val);
		}
	
		if (!fms.Lookup(MNG_FLAG, val))	// KEY(601)
			return;

		// KOBA ELW �������� �ȳ�
		if (val==MNG_KOBAELW && m_bKobaElwNotify)
		{
			if (fms.Lookup("023", val))
			{
				int x, y;
				CRect mRc, wRc;
				
				mRc = GetWndRect();
				m_kobanotify->GetWindowRect(wRc);

				x = mRc.left;
				y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
				if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
					y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				
				m_kobanotify->AddNotify(val);
				m_kobanotify->SetWindowPos(NULL, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOACTIVATE);
				m_kobanotify->MoveWindow(x, y, wRc.Width(), wRc.Height());
			}
		}

		if (atoi(val) <= NO_CHECK)
		{
			if (!m_mapAlarmList.Lookup(val, str))
				return;
		}
		
		if (!fms.Lookup(MNG_KIND, sym))	// 0:������,1:�˸�
			return;
		if (!m_bUseAlarm)
			return;

		kind = atoi(sym);
		val = _T("");
		fms.Lookup(MNG_MSG, msgS);			
		m_mngInfo->StopSlide();
		str = _T("");
		if (m_bSound && fms.Lookup(MSG_MGUBN, str))
		{
			if (!str.IsEmpty())	
			{
				wavfile.Format("%s\\%s\\%s.wav", Axis::home, IMAGEDIR, str);
				if (!IsFileExist(wavfile))  wavfile.Format("%s\\%s\\%s.wav", Axis::home, IMAGEDIR, "000");
				sndPlaySound(NULL, SND_NODEFAULT|SND_ASYNC);
				sndPlaySound(wavfile, SND_NODEFAULT|SND_ASYNC);
			}
		}

		if(msgS.GetAt(0) == 'X')
		{
// 			OutputDebugString("============================================================\n");
// 			OutputDebugString("Bullon Notice Call\n");
// 			OutputDebugString("============================================================\n");
			msgS = msgS.Mid(1);
			kind = 3;
		}

		ShowMngInfo(msgS, kind);
	}
}


BOOL CMainFrame::ConclusionNotice(CString dat, CString& title)
{
	//if ((m_dept == "811") || (m_dept == "812")) return false;
	if (m_chaser && m_chaser->GetSafeHwnd())
	{
		OnCHASER(MAKEWPARAM(dat.GetLength(), x_CONs),
			(LPARAM) (char*)(const char*)dat);
	}
	//TRACE("RD(ORIGINAL): "+dat+"\n");

//	if (m_block)	return FALSE;
	if (!m_runAxis)	return FALSE;

	CString			str, value, jcode;
	CMapStringToString	ary;

	CProfile profile(pkOrderSetup);

	NoticeParse(dat, ary);

	if (!ary.Lookup("902", str))		// user ID
	{
		ary.RemoveAll();
		return FALSE;
	}
	
	if ((m_dept == "811") || (m_dept == "812"))  //���ο��� 1,2���϶���
		if (Axis::userID != str) return FALSE;  //������ �� �ֹ��� �ƴ϶�� ���͸�
	//TRACE("RD: "+str + "]" + Axis::userID+"\n");
	

// ������ �ֹ�ü���뺸�� ����!! for test
#if 1
	if (str.CompareNoCase(Axis::userID))		// check userID
#else
	if (FALSE)
#endif
	{
		ary.RemoveAll();
		return FALSE;
	}

	if (!ary.Lookup("988", str))		// ó������
	{
		ary.RemoveAll();
		return FALSE;
	}

	ary.Lookup("907", jcode);		// jCODE

	dat.Empty();
	bool	bCon = false;
	bool	bFail = false;
	int		priceUnit = 1;

	if (str.Find("ü��") != -1)
		bCon = true;
	else if (str.Find("�ź�") != -1)
		bFail = true;

	if (m_Econclusion && (bFail || (m_conKIND & CON_MSN)))	// �źδ� ������ ó���ϱ� ����
	{
		//����\t�����\t�Ÿű���\tü�����\tü�ᰡ��
		if (bCon)
		{
			if (ary.Lookup("901", value))	// account number
			{
				dat += EncodeAcctNo(value);
			}
			dat += "\t";

			if (ary.Lookup("908", value))	// code Name
				dat += value;
			dat += "\t";

			if (ary.Lookup("912", value))	// ó������(mmgb+data����)
			{
				dat += value;
				if (ary.Lookup("988", value))
					dat += value;
			}
			else	dat += " ";
			dat += "\t";

			if (ary.Lookup("931", value))	// conclusion count
			{
				str.Format("%d", atoi(value));
				dat += str;
			}
			dat += "\t";

			if (ary.Lookup("999", value))
			{
				priceUnit = atoi(value);
				if (priceUnit == 0)
					priceUnit = 1;
			}

			if (ary.Lookup("916", value))	// conclusion price
			{
				double price = atof(value);
				if (jcode.GetLength() == 8)
					str.Format("%.2f", price / priceUnit);
				else	
					str.Format("%d", int(price / priceUnit));
				dat += str;
			}
		}
		else
		{
			if (ary.Lookup("901", value))	// account number
			{
				dat += EncodeAcctNo(value);
			}
			dat += "\t";
			
			if (ary.Lookup("908", value))	// code Name
				dat += value;
			dat += "\t";

			if (ary.Lookup("912", value))	// ó������(mmgb+data����)
			{
				dat += value;
				if (ary.Lookup("988", value))
					dat += value;
			}
			else	dat += " ";
			dat += "\t";

			if (!bFail)
			{
				if (ary.Lookup("931", value))	// amount
				{
					str.Format("%d", atoi(value));
					dat += str;
				}
				dat += "\t";
			}

			if (ary.Lookup("999", value))
			{
				priceUnit = atoi(value);
				if  (priceUnit == 0)
					priceUnit = 1;
			}

			if (ary.Lookup("916", value))	// price
			{
				double price = atof(value);
				if (jcode.GetLength() == 8)
					str.Format("%.2f", price / priceUnit);
				else	
					str.Format("%d", int(price / priceUnit));
				dat += str;
			}
			
			dat += "\t";
			if (ary.Lookup("921", value))	// ��ü��
			{
				str.Format("%d", atoi(value));
				dat += str;
			}
			
		}
		
		if (ary.Lookup("988", str))	// ó������
		{
			
			if (str.Find("����") != -1)
			{
				m_Econclusion->ChangeTitle(2, "�Ÿű���");
				m_Econclusion->ChangeTitle(3, "�ֹ�����");
				m_Econclusion->ChangeTitle(4, "�ֹ��ܰ�");
			}
			else if (str.Find("Ȯ��") != -1)
			{
				m_Econclusion->ChangeTitle(2, "Ȯ�α���");
				m_Econclusion->ChangeTitle(3, "Ȯ�μ���");
				m_Econclusion->ChangeTitle(4, "�ֹ��ܰ�");
			}
			else if (str.Find("ü��") != -1)
			{
				m_Econclusion->ChangeTitle(2, "�Ÿű���");
				m_Econclusion->ChangeTitle(3, "ü�����");
				m_Econclusion->ChangeTitle(4, "ü��ܰ�");
			}
			else if (str.Find("�ź�") != -1)
			{
				m_Econclusion->ChangeTitle(2, "�Ÿű���");
				m_Econclusion->ChangeTitle(3, "�źδܰ�");
			}
		}
		else	m_Econclusion->ChangeTitle();

		if (bCon || bFail)	ShowEConclusion(dat, bFail);
	}

	if (m_conclusion && (bCon || bFail))
	{
		
		// �ֹ�����ó��... filter........
		if (!bFail && !ary.Lookup("992", str))		// conclusion count
		{
			ary.RemoveAll();
			return FALSE;
		}
		
		if (!bFail && atoi(str) <= 0)
		{
			
			ary.RemoveAll();
			return FALSE;
		}

		//ü��ð�\t�ֹ���ȣ\t���ֹ���ȣ\t����\t������\t�����\t��ȣ(1)�Ÿű���\tü�����\tü�ᰡ��
		if (ary.Lookup("923", value))	// time
			dat = value;
		else	dat.Empty();
		dat += "\t";

		if (ary.Lookup("904", value))	// order number
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";

		if (ary.Lookup("905", value))	// original order number
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";

		if (ary.Lookup("901", value))	// account
			dat += value;
		dat += "\t";

		if (ary.Lookup("906", value))	// customer name
			dat += value;
		dat += "\t";

		if (ary.Lookup("908", value))	// code Name
			dat += value;
		dat += "\t";

		if (ary.Lookup("912", value))	// ó������(mmgb+data����)
		{
			if (bCon)
			{
				str = " ";
				if (value.Find("�ŵ�") != -1)	str = "-";
				if (value.Find("�ż�") != -1)	str = "+";
				dat += str + value;
			}
			else	dat += " " + value;
			if (ary.Lookup("988", value))
				dat += value;
		}
		dat += "\t";
		
		if (ary.Lookup("931", value))	// amount
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";

		if (ary.Lookup("999", value))
		{
			priceUnit = atoi(value);
			if (priceUnit == 0)
				priceUnit =  1;
		}

		if (ary.Lookup("916", value))	// price
		{
			double price = atof(value);
			if (jcode.GetLength() == 8)
			{
				int mkgb = atoi(jcode.Mid(1, 2));
				if (mkgb>=85 && mkgb<=99)
					str.Format("%.f", price / priceUnit);
				else if (mkgb>=10 && mkgb<=59)
					str.Format("%.f", price / priceUnit);
				else
					str.Format("%.2f", price / priceUnit);

				
			}
			else	
			{
				str.Format("%d", int(price / priceUnit));
			}
			dat += str;
		}
		
		dat += "\t";
		if (ary.Lookup("921", value))	// ��ü��
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		
		if (bFail)
			m_conclusion->AddFail(dat, m_conHISTORY);
		else
			m_conclusion->AddConclusion(dat, m_conHISTORY, true);

		if (bFail || (m_conKIND & CON_POPUP))
		{
			KillTimer(TM_AUTOHIDE);
			SetTimer(TM_AUTOHIDE, m_conAUTOTIME*1000, NULL);
			ShowConclusion();
		}
	}

	if (m_conKIND & CON_SOUND)
	{
		int	mmgbK  = 0; /* 0 - none, 1 - �ŵ�, 2 - �ż� , 3 - ����, 4 - ���*/
		int	sndIdx = -1;
		if (ary.Lookup("912", value))	// �Ÿű���
		{
			if (value.Find("�ŵ�") != -1)	mmgbK = 1;
			if (value.Find("�ż�") != -1)	mmgbK = 2;
		}

		if (ary.Lookup("988", str))	// ó������
		{
			if (str.Find("����") != -1)
			{
				if (str.Find("����") != -1)	mmgbK = 3;
				if (str.Find("���") != -1)	mmgbK = 4;
				switch (mmgbK)
				{
				case 1:
					if (profile.GetInt(szCommon, "SOUNDON_MDORDER"))
						sndIdx = IDX_MDORDER;
					break;
				case 2:
					if (profile.GetInt(szCommon, "SOUNDON_MSORDER"))
						sndIdx = IDX_MSORDER;
					break;
				case 3:
					if (profile.GetInt(szCommon, "SOUNDON_JJORDER"))
						sndIdx = IDX_JJORDER;
					break;
				case 4:
					if (profile.GetInt(szCommon, "SOUNDON_CSORDER"))
						sndIdx = IDX_CSORDER;
					break;
				}
			}
			else if (str.Find("ü��") != -1)
			{
				switch (mmgbK)
				{
				case 1:
					if (profile.GetInt(szCommon, "SOUNDON_MDCON"))
						sndIdx = IDX_MDCON;
					break;
				case 2:
					if (profile.GetInt(szCommon, "SOUNDON_MSCON"))
						sndIdx = IDX_MSCON;
					break;
				}
			}
			else if (str.Find("�ź�") != -1)
			{
				sndIdx = IDX_REFUSAL;
			}
		}

		if (sndIdx != -1)
		{
			if (m_waveF[sndIdx].IsEmpty())	MessageBeep(MB_OK);
			else
			{
				sndPlaySound(NULL, SND_NODEFAULT|SND_ASYNC);
				sndPlaySound(m_waveF[sndIdx], SND_NODEFAULT|SND_ASYNC);
			}
		}
	}

//#ifdef _DEBUG
	
	//if (!bCon)  //�������� �����͸� ���� ���ٿ� �Ѹ�
	{
		// �ֹ�����ó��... filter........
		/*
		if (!bFail && !ary.Lookup("992", str))		// conclusion count
		{
			ary.RemoveAll();
			return FALSE;
		}
		
		if (!bFail && atoi(str) <= 0)
		{
			
			ary.RemoveAll();
			return FALSE;
		}
		*/
		
		//ü��ð�\t�ֹ���ȣ\t���ֹ���ȣ\t����\t������\t�����\t��ȣ(1)�Ÿű���\tü�����\tü�ᰡ��
		if (ary.Lookup("923", value))	// time
			dat = value;
		else	dat.Empty();
		dat += "\t";
		
		if (ary.Lookup("904", value))	// order number
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";
		
		if (ary.Lookup("905", value))	// original order number
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";
		
		if (ary.Lookup("901", value))	// account
			dat += value;
		dat += "\t";
		// ���� Ȯ�� �޼��� �϶��� ���¸��� �����ͼ� ���ٿ� ǥ�õǹǷ� �ش�κ� ����
		/*
		if (ary.Lookup("906", value))	// customer name
			dat += value;
		*/
		dat += "\t";
		
		if (ary.Lookup("908", value))	// code Name
			dat += value;
		dat += "\t";
		
		if (ary.Lookup("912", value))	// ó������(mmgb+data����)
		{
			if (bCon)
			{
				str = " ";
				if (value.Find("�ŵ�") != -1)	str = "-";
				if (value.Find("�ż�") != -1)	str = "+";
				dat += str + value;
			}
			else	dat += " " + value;
			if (ary.Lookup("988", value))
				dat += value;
		}
		dat += "\t";
		
		if (ary.Lookup("931", value))	// amount
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
		dat += "\t";
		
		if (ary.Lookup("999", value))
		{
			priceUnit = atoi(value);
			if (priceUnit == 0)
				priceUnit =  1;
		}
		
		if (ary.Lookup("916", value))	// price
		{
			double price = atof(value);
			if (jcode.GetLength() == 8)
				str.Format("%.2f", price / priceUnit);
			else	
				str.Format("%d", int(price / priceUnit));
			dat += str;
		}
		
		dat += "\t";
		if (ary.Lookup("921", value))	// ��ü��
		{
			str.Format("%d", atoi(value));
			dat += str;
		}
	}
	
	//AfxMessageBox(dat);
		if (m_tInfo3)
		{
			if ((m_tInfo3->AddData(dat, bFail)) &&
			  !(m_tInfo3->GetStyle() & WS_VISIBLE))
			{
				if (m_matchToolBar == 1)
					ShowControlBar(m_tInfo3, TRUE, FALSE);
				else
					ShowControlBar(m_tInfo3, FALSE, FALSE);
			}
		}
//#endif

	ary.RemoveAll();

	return FALSE;
}

void CMainFrame::NoticeParse(CString dat, CMapStringToString& ary)
{
	int	pos, pos2;
	CString	str, symbol, value;

	pos = dat.Find('\n');
	if (pos != -1)
	{
		str = dat.Left(pos++);
		dat = dat.Mid(pos);
	}

	while (!str.IsEmpty())
	{
		pos = str.Find('\t');
		if (pos == -1)	break;

		symbol = str.Left(pos++);
		str    = str.Mid(pos);

		pos = str.Find('\t');
		if (pos == -1)
		{
			value = str;
			str.Empty();
		}
		else
		{
			pos2 = pos;
			value = str.Left(pos2++);
			pos = value.Find('\r');
			if (pos != -1)
			{
				value = value.Left(pos++);
				str   = str.Mid(pos);
			}
			else
				str = str.Mid(pos2);
		}

		value.TrimRight();
		ary.SetAt(symbol, value);
	}

	while (!dat.IsEmpty())
	{
		pos = dat.Find('\t');
		if (pos == -1)	break;

		symbol = dat.Left(pos++);
		dat    = dat.Mid(pos);

		pos = dat.Find('\t');
		if (pos == -1)
		{
			value = dat;
			dat.Empty();
		}
		else
		{
			value = dat.Left(pos++);
			dat   = dat.Mid(pos);
		}

		value.TrimRight();
		ary.SetAt(symbol, value);
	}
}

BOOL CMainFrame::HideGuide()
{
	if (!m_axGuide)	return FALSE;
	if (m_axGuide->GetStyle() & WS_VISIBLE)
	{
		displayGuide("");
		return TRUE;
	}
	return FALSE;
}

BOOL CMainFrame::ExistMenu(CString mapN)
{
	if (!m_tMenu)	return FALSE;
	if (mapN == "IB985000") return true; //���� ��й�ȣ ���� ȭ���̶�� �޴��� �ִµ� �νĽ�����
	return m_tMenu->ExistMenu(mapN);
}

int CMainFrame::ExceptionProcess(CString mapN)
{
	CString	mapname = mapN.Left(L_MAPN);
	/*
	if (!mapname.CompareNoCase("DH611900"))
	{
		if (IsRunTime())
			return 0;
		else
		{
			MessageBox("�� ���񽺴� ������ 09:00 ~ 17:00 ���� ���� �����մϴ�.", "�˸�", MB_OK);
			return 1;
		}
	}
	*/

	if (!mapname.CompareNoCase(MAPN_REALTIMEJANGO))
		return 1;
	if (!mapname.CompareNoCase(MAPN_SISECATCH1))
		return 1;

/*
	if (!mapname.CompareNoCase("IBNEWSXX"))
	{
		int	vtype = 0, size = 0, nCx, nCy, x, y, key = KEY_NEWSVIEWER;
		BOOL	rc = FALSE;
		CRect	mRc, wRc;
		
		if (m_newsviewer)
		{
			m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
						(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
			m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapN, size, false);
			if (m_newsviewer->GetStyle() & WS_VISIBLE)
			{
				m_newsviewer->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_SHOWWINDOW|SWP_NOSIZE);
				
			}
			else
			{
				mRc = GetWndRect();
				m_newsviewer->GetWindowRect(wRc);

				x = mRc.left;
				y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
				if (x < 0)	x = 0;
				if (y < 0)	y = 0;
				if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
					y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
					
				if (m_newsviewer->GetStyle() & WS_VISIBLE)
					m_newsviewer->ShowWindow(SW_HIDE);
				else	
					m_newsviewer->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);
			}
			m_newsviewer->GetWindowRect(&wRc);
			m_newsviewer->SendMessage(WM_SIZE, 0, MAKELPARAM(wRc.Width(), wRc.Height()));
			m_newsviewer->Invalidate();
		}
		else
		{
			m_newsviewer = new CNewsViewer();
			if (!m_newsviewer->Create(IDD_NEWSVIEWER))
			{
				delete m_newsviewer;
				m_newsviewer = NULL;
			}

			m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
						(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
			m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_newsviewer, vtype, key);
			m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapN, size, false);

			int	ret = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
				(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, 0));

			CSize	frameGap;
			frameGap.cx  = GetSystemMetrics(SM_CXFRAME);
			frameGap.cx += GetSystemMetrics(SM_CXBORDER) * 2;

			frameGap.cy  = GetSystemMetrics(SM_CYFRAME);
			frameGap.cy += GetSystemMetrics(SM_CYBORDER) * 2;
			frameGap.cy += GetSystemMetrics(SM_CYCAPTION);

			nCx = frameGap.cx + LOWORD(size);
			nCy = frameGap.cy + HIWORD(size);
			m_newsviewer->SetWindowPos(&wndTopMost, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_HIDEWINDOW);
			
			mRc = GetWndRect();
			m_newsviewer->GetWindowRect(wRc);

			x = mRc.left;
			y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
			if (x < 0)	x = 0;
			if (y < 0)	y = 0;
			if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
				y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();
				
			m_newsviewer->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);
		}
		return 1;
	}
*/
	return 0;
}

int CMainFrame::CheckMapping(CString mapN)
{
	int	key = -1;
	if (m_tMenu->IsMappinged(mapN))
		return 0;
	return key;
}

void CMainFrame::SetAMap(int key, char* mapN)
{
	if (key & winK_POPUP)
	{
		if (!m_arMPOP.IsEmpty())
		{
			CMPop*	Mpop;
			if (m_arMPOP.Lookup(key, Mpop))
			{
				CopyMemory(mapN, Mpop->m_mapN, L_MAPN);
				return;
			}
		}

		CGPop* Gpop;
		if (!m_arGPOP.Lookup(key, Gpop))
			return;
		CopyMemory(mapN, Gpop->m_mapN, L_MAPN);
	}
	else
	{
		CChildFrame*	child;
		if (!m_arMDI[m_vsN].Lookup(key, child))
		{
			CSChild*	schild;
			if (!m_arSDI[m_vsN].Lookup(key, schild))
			{
				sprintf(mapN, "");
				return;
			}
			CopyMemory(mapN, schild->m_mapN, L_MAPN);
		}
		else	CopyMemory(mapN, child->m_mapN, L_MAPN);
	}
}

void CMainFrame::SetSearchMap(char* mapN)
{
	CTrSearch	dlg(m_tMenu);
	if (dlg.DoModal() == IDOK)
		sprintf(mapN, dlg.getTR());
}

CString CMainFrame::parseData(CString dat)
{
	int	pos = dat.Find(SEP);
	if (pos == -1)	return dat;

	CString	user, string;

	string = dat.Left(pos++);
	dat = dat.Mid(pos);

	while (!string.IsEmpty())
	{
		pos = string.Find(USERSEP);
		if (pos == -1)	break;
		user = string.Left(pos++);
		string = string.Mid(pos);

		if (!user.CompareNoCase(Axis::userID))
			return dat;
	}
	return _T("");
}

void CMainFrame::childAll(CString dat)
{
	CString	mapN = dat.Left(L_MAPN);
	dat = dat.Mid(L_MAPN);

	int		key;
	POSITION	pos;
	CChildFrame*	pChild;
	for (pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
	{
		m_arMDI[m_vsN].GetNextAssoc(pos, key, pChild);
		if (pChild->m_mapN.Left(L_MAPN) != mapN)
			continue;

		key |= 0xff00;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
		(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)dat);
		break;
	}
}

void CMainFrame::HelpLink(int key)
{
	CChildFrame*	child;
	CSChild*	schild;
	CString url = "http://www.ibks.com/HTSHELP/helptrnum.ids?trnum=";
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		if (!m_arSDI[m_vsN].Lookup(key, schild))
		{
			
			return;
		}
		RunWebBrowser(url+CString(schild->m_mapN).Mid(2,4),780,688);

		return;
	}
	RunWebBrowser(url+CString(child->m_mapN).Mid(2,4),780,688);
	
	return;
	CString	mpN;
	
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		HelpLinkS(key);
		return;
	}
	mpN = m_tMenu->GetMapping(child->m_mapN);
	if (mpN.GetLength() != L_MAPN)	return;

	CString	file, link, dat, dispN = mpN.Mid(2, 4);

	if (mpN.CompareNoCase(MAPN_SISECATCH) == 0)
	{
		dispN = "sise";
	}

	file.Format("%s\\help\\help.dat", Axis::home);
	FILE *fp = fopen(file, "r");
	if (!fp)	return;
	char	buf[1024];
	while (fgets(buf, sizeof(buf), fp) != NULL)
	{
		link = buf;
		int pos = link.Find('=');
		if (pos == -1)	continue;
		dat = link.Left(pos++);

		dat.TrimLeft();
		dat.TrimRight();
		if (dispN.CompareNoCase(dat))	continue;

		link = link.Mid(pos);
		link.TrimLeft();
		link.TrimRight();

		RunWebBrowser(link);
		break;
	}
	fclose(fp);
}

void CMainFrame::HelpLinkS(int key)
{
	CString		mpN;
	CSChild*	child;
	if (!m_arSDI[m_vsN].Lookup(key, child))
		return;
	mpN = m_tMenu->GetMapping(child->m_mapN);
	if (mpN.GetLength() != L_MAPN)	return;

	CString	file, link, dat, dispN = mpN.Mid(2, 4);

	if (mpN.CompareNoCase(MAPN_SISECATCH) == 0)
	{
		dispN = "sise";
	}

	file.Format("%s\\help\\help.dat", Axis::home);
	FILE *fp = fopen(file, "r");
	if (!fp)	return;
	char	buf[1024];
	while (fgets(buf, sizeof(buf), fp) != NULL)
	{
		link = buf;
		int pos = link.Find('=');
		if (pos == -1)	continue;
		dat = link.Left(pos++);

		dat.TrimLeft();
		dat.TrimRight();
		if (dispN.CompareNoCase(dat))	continue;

		link = link.Mid(pos);
		link.TrimLeft();
		link.TrimRight();

		RunWebBrowser(link,780,688);
		break;
	}
	fclose(fp);
}

void CMainFrame::SmCall(int idx)
{
	if (m_smcall)
	{
		m_smcall->Show_Environment(idx);
		
		load_eninfomation(false);
		load_mngSetup();
		m_bar1->Refresh();
	}
}

void CMainFrame::toolRegister()
{
	CString	mapN;
	CChildFrame* child = (CChildFrame*) MDIGetActive();

	if (!child)	
		return;

	mapN.Format("%s00", child->m_mapN.Left(L_MAPN-2));

	if (!ExistMenu(mapN))	
		return;

	CProfile profile(pkUserTool);

	CString tmps(profile.GetString(szUserSN, szUserEN, "0, 0")), str;
	int idx = tmps.Find(',');

	if (idx == -1) 
		idx = 0;
	else
	{
		tmps = tmps.Left(idx);
		idx = atoi(tmps);
	}

	tmps.Format("%02d", idx);
	if (profile.GetString(szUserSN, tmps).IsEmpty())
		return;
	if (!profile.GetString(tmps, mapN).IsEmpty())
		return;

	CString ssb;
	char ssb2[1024 * 4];

	ssb = profile.GetSectionLF(tmps);
	str.Format("%s;%s", m_tMenu->GetDesc(mapN), m_tMenu->GetSName(mapN));

	if (ssb.IsEmpty())
		profile.Write(tmps, mapN, str);
	else
	{
		//FillMemory(ssb2, ArraySize(ssb2), ' ');
		ZeroMemory(ssb2, ArraySize(ssb2));	
		CopyMemory(&ssb2[0], ssb, ssb.GetLength());
		//CopyMemory(&ssb2[str.GetLength() + L_MAPN + 2], ssb, ssb.GetLength());
		//sprintf(&ssb2[str.GetLength() + L_MAPN + 2 + ssb.GetLength()], "%s=%s", mapN, str);
		sprintf(&ssb2[ssb.GetLength()], "%s=%s", mapN, str);
		profile.WriteSection(tmps, CString(ssb2, ssb.GetLength() + str.GetLength() + L_MAPN + 2));
	}

	m_bar1->AddItem(mapN + "="+ str);
}

void CMainFrame::toolRegisterAll(int index)
{
	switch (index)
	{
	case 0:		// ���ȭ�� ���ٵ�� --> ���� ����
		EditTool();
		//AllScreenRegister();
		break;
	case 1:		// �����ȭ�� ����
		saveUserScreen();
		break;
	default:
		break;
	}
}

void CMainFrame::AllScreenRegister()
{
	int	key, idx;
	CString ssb;
	DWORD	ssL;
	CString	file, section, str, mpN;
	CMapStringToString	ary;

	CChildFrame* child = (CChildFrame*) MDIGetActive();
	if (!child)	return;

	CProfile profile(pkUserTool);
	section = profile.GetString(szUserSN, szUserEN, "0, 0");
	idx = section.Find(',');

	if (idx == -1)
		idx = 0;
	else
	{
		section = section.Left(idx);
		idx = atoi(section);
	}

	section.Format("%02d", idx);
	ssb = profile.GetString(szUserSN, section);
	ssL = ssb.GetLength();

	if (ssL <= 0)
		return;

	ssb = profile.GetSectionLF(section);
	ssL = ssb.GetLength();

	if (ssL > 0)
	{
		CString item, tmps, mapN, string(ssb, ssL);
		while (!string.IsEmpty())
		{
			idx = string.Find('\0');
			if (idx == -1)
				break;

			item = string.Left(idx++);
			string = string.Mid(idx);

			idx = item.Find('=');
			if (idx == -1)
				continue;
			mapN = item.Left(L_MAPN);
			if (!ary.Lookup(mapN, tmps))
				ary.SetAt(mapN, "1");
		}
	}
	for (POSITION pos = m_arMDI[m_vsN].GetStartPosition(); pos; ) 
	{
		m_arMDI[m_vsN].GetNextAssoc(pos, key, child);
		mpN.Format("%s00", child->m_mapN.Left(L_MAPN-2));
		if (ary.Lookup(mpN, str))
			continue;
		if (!ExistMenu(mpN))
			continue;

		str.Format("%s=%s;%s", mpN, m_tMenu->GetDesc(mpN), m_tMenu->GetSName(mpN));

		m_bar1->AddItem(str);
		ssb += str;
		ssL += str.GetLength() + 1;
		ary.SetAt(mpN, "1");
	}

	profile.WriteSection(section, ssb);
	ary.RemoveAll();
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	//CDebug::Out("=================");
	CMDIFrameWnd::OnSize(nType, cx, cy);
	if (m_runAxis && m_bar0->GetSafeHwnd() && (m_bar0->GetStyle() & WS_VISIBLE))
		ShowControlBar(m_bar0, TRUE, FALSE);	
	CChildFrame*	child;
	if (m_arMDI[m_vsN].Lookup(m_BackGroundKey, child)) child->CenterWindow();
	if (m_tInfo1 && m_tInfo1->IsWindowVisible()) m_tInfo1->RedrawWindow();
	if (m_tInfo2 && m_tInfo2->IsWindowVisible()) m_tInfo2->RedrawWindow();
	
}

void CMainFrame::OnSizing(UINT fwSide, LPRECT pRect) 
{
	CMDIFrameWnd::OnSizing(fwSide, pRect);

	if (!m_bSDI)	return;
	CRect*	prect = (CRect *) pRect;
	if (prect->Height() != m_SDIHEIGHT)
	{
		switch (fwSide)
		{
		case WMSZ_TOP:case WMSZ_TOPLEFT:case WMSZ_TOPRIGHT:
			prect->top = prect->bottom - m_SDIHEIGHT;	break;
		default:prect->bottom = prect->top + m_SDIHEIGHT;	break;
		}
	}
}

void CMainFrame::OnMove(int x, int y) 
{
	CMDIFrameWnd::OnMove(x, y);

	if (m_Nclock && m_Nclock->GetSafeHwnd())
	{
		if (m_Nclock->GetStyle() & WS_VISIBLE)
			m_Nclock->OnMainWndMoved();
	}

	if (m_logodlg && m_logodlg->GetSafeHwnd())
	{
		if (m_logodlg->GetStyle() & WS_VISIBLE)

			if( m_bar1->IsWindowVisible() )
				m_logodlg->OnMainWndMoved();			
	}

}


void CMainFrame::AppendAllMap()
{
	int		key;
	CChildFrame*	child;
	CMapStringToString	arMap;
	CProfile profile(pkScreenReg);
	CString str, buf;

	for (int i = 0; ; i++)
	{
		str.Format("%04d", i);
		buf = profile.GetString(szScreen, str);
		if (buf.IsEmpty())
			break;

		arMap.SetAt(buf, str);
	}

	for (POSITION pos = m_arMDI[m_vsN].GetStartPosition(); pos; ) 
	{
		m_arMDI[m_vsN].GetNextAssoc(pos, key, child);
		if (arMap.Lookup(child->m_mapN.Left(L_MAPN), str))
			continue;

		str.Format("%04d", arMap.GetCount());
		profile.Write(szScreen, str, child->m_mapN.Left(L_MAPN));
		arMap.SetAt(child->m_mapN.Left(L_MAPN), str);
	}
}

bool CMainFrame::axCloseV(int key)
{
// 	if (m_arMDI[vsN].Lookup(key, child))
// 	{
// 		if
// 	}

	CChildFrame*	child;
	removeWait(key);
	if (key & winK_POPUP)
	{
		for (int ii = 0; ii < m_arHide.GetSize(); ii++)
		{
			child = m_arHide.GetAt(ii);
			if (child && child->m_key != key)
				continue;
			m_arHide.RemoveAt(ii);
			m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
					(void *)NULL, (BYTE *)(VTS_I4), (short) key);
			return true;
		}
		
		m_arGPOP.RemoveKey(key);
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) key);
		if (m_arGPOP.IsEmpty())
			SetFocus();
		else
		{
			CGPop*	pop;
			POSITION pos = m_arGPOP.GetStartPosition();
			m_arGPOP.GetNextAssoc(pos, key, pop);
			if (pop != NULL)	// 20070823
			{
				pop->SetFocus();
				m_activeMapN = pop->m_mapN;
			}
		}
	}
	else
	{
		bool		match = false;
		CSChild*	schild = NULL;

		for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
		{
			for (int value = 0; value < m_hooklist[vsN].GetSize(); value++)
			{
				if (key != m_hooklist[vsN].GetAt(value))
					continue;
				m_hooklist[vsN].RemoveAt(value);
			}
		}

		for (vsN = V_SCREEN1; vsN <= V_SCREEN6 && !match; vsN++)
		{
			if (m_arMDI[vsN].Lookup(key, child))
			{
				match = true;

				//m_arMDI[vsN].RemoveKey(key);
				//RedrawVS(true);
				// dtitle
				RemoveMdi(vsN, key);
				m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
					(void *)NULL, (BYTE *)(VTS_I4), (short) key);
				if (m_bar2)	m_bar2->del_Button(key, vsN);
			}
			else if (m_arSDI[vsN].Lookup(key, schild))
			{
				match = true;
				//m_arSDI[vsN].RemoveKey(key);
				//RedrawVS(true);
				// dtitle
				RemoveSdi(vsN, key);
				m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
						(void *)NULL, (BYTE *)(VTS_I4), (short) key);
				if (m_bar2)	m_bar2->del_Button(key, vsN);
			}
			
			if (match && vsN == m_vsN)
			{
				if (MDIGetActive() == NULL)
				{
					m_hooklist[m_vsN].RemoveAll();
					m_activeMapN.Empty();
				}
			}
		}
	}
	return true;
}

bool CMainFrame::axFocus(int key)
{
	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild*	schild;
		if (!m_arSDI[m_vsN].Lookup(key, schild))
			return false;

		if (m_bar2)	m_bar2->change_Button(schild->m_key);

		for (int value = 0; value < m_sdiZORDER[m_vsN].GetSize(); value++)
		{
			key = m_sdiZORDER[m_vsN].GetAt(value);
			if (key == schild->m_key)
			{
				m_sdiZORDER[m_vsN].RemoveAt(value);
				break;
			}
		}
		m_sdiZORDER[m_vsN].InsertAt(0, schild->m_key);
		m_activeMapN = schild->m_mapN;
		return true;
	}
	
	if (m_bar1)	m_bar1->set_Maps(child->m_mapN);
	if (m_bar2)	m_bar2->change_Button(child->m_key);

	for (int value = 0; value < m_hooklist[m_vsN].GetSize(); value++)
	{
		key = m_hooklist[m_vsN].GetAt(value);
		if (key == child->m_key)
		{
			m_hooklist[m_vsN].RemoveAt(value);
			break;
		}
	}
	m_hooklist[m_vsN].InsertAt(0, child->m_key);
	m_activeMapN = child->m_mapN;
	return true;
}


void CMainFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	if(nState == WA_ACTIVE || nState == WA_CLICKACTIVE)
	{
		if(m_slideMsg != "")
			SetTimer(TM_SLIDE,1000,NULL);
	}

	if (Axis::isVista) return;
	CMDIFrameWnd::OnActivate(nState, pWndOther, bMinimized);
	switch( nState )
	{
	case WA_INACTIVE:
		OnNcActivate(FALSE);
		break;
	case WA_ACTIVE:
	case WA_CLICKACTIVE:
		OnNcActivate(TRUE);
		break;
	}
}

void CMainFrame::fullScreenMode(bool full)
{
	m_fullmode = full;

	if (m_fullmode)
	{
		m_toolStatus = 0;
		GetWindowPlacement(&m_pl);
		SetToolStatus();

		ShowControlBar(m_bar1, FALSE, FALSE);
		
		ShowControlBar(m_bar2, FALSE, FALSE);
		ShowControlBar(m_bar3, FALSE, FALSE);
		ShowControlBar(m_tInfo1, FALSE, FALSE);
		ShowControlBar(m_tInfo2, FALSE, FALSE);
		if (m_tInfo3)
			ShowControlBar(m_tInfo3, FALSE, FALSE);

		PostMessage(WM_SYSCOMMAND, SC_MAXIMIZE);
	}
	else
	{	
		if (m_toolStatus & TB_MAINBAR)
		{
			ShowControlBar(m_bar1, TRUE, FALSE);
			
		}
		if (m_toolStatus & TB_LISTBAR)		ShowControlBar(m_bar2, TRUE, FALSE);
		if (m_toolStatus & TB_INFOBAR1)		ShowControlBar(m_tInfo1, TRUE, FALSE);
		if (m_toolStatus & TB_INFOBAR2)		ShowControlBar(m_tInfo2, TRUE, FALSE);
		if (m_toolStatus & TB_INFOBAR3)		
			if (m_tInfo3)
				ShowControlBar(m_tInfo3, TRUE, FALSE);
		
		SetWindowPlacement(&m_pl);
	}
	ChangeLogo();
	
}

void CMainFrame::changeFontSize()
{
	int	key;
	long	rc = 0;
	POSITION pos;

	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, -1), MAKELONG(0, m_fontSize));
//	global font apply

	CChildFrame*	child;
	CSChild*	schild;
	for (int ii = V_SCREEN1; ii <= V_SCREEN6; ii++)
	{
		for (pos = m_arMDI[ii].GetStartPosition(); pos; )
		{
			m_arMDI[ii].GetNextAssoc(pos, key, child);
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));
			child->m_xcaption.SetFontSize(m_fontSize);
			child->Invalidate();
		}

		for (pos = m_arSDI[ii].GetStartPosition(); pos; )
		{
			m_arSDI[ii].GetNextAssoc(pos, key, schild);
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));
			schild->m_xcaption.SetFontSize(m_fontSize);
			schild->Invalidate();
		}
	}

	CGPop*	Gpop;
	for (pos = m_arGPOP.GetStartPosition(); pos; )
	{
		m_arGPOP.GetNextAssoc(pos, key, Gpop);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));
		Gpop->Invalidate();
	}
}

void CMainFrame::processFMX(WPARAM wParam, LPARAM lParam)
{

	int key = LOWORD(wParam);
	int len = HIWORD(wParam);

	if (m_chaser && m_chaser->GetSafeHwnd())
		OnCHASER(MAKEWPARAM(len, x_RCVs), (LPARAM) (char *) lParam);
	switch (key)
	{
	case 'L':	// file list
		if (m_infofile)
			m_infofile->ProcessFMX(wParam, lParam);
		break;
	case 't':	processTICK((char *) lParam);	break;	// ticker fmx
	case 'e':	processETICK((char *) lParam);	break;	// eticker fmx
	case 'I':	processINTER((char *) lParam);	break;	// inter code sise
	case 'r':	processELOG((char *) lParam);	break;	// error log write response
	case 'm':	processRTime((char*)lParam, HIWORD(wParam));	break;
	case 'l':	processNEWS((char*)lParam, HIWORD(wParam)); break;
	case 'k':	if (m_EmpPassChangeDlg) m_EmpPassChangeDlg->processOUB((char *) lParam, HIWORD(wParam)); break;
	case 254:   m_TotalAcc->ProcessAccount((char *) lParam, HIWORD(wParam)); break;
	case 253:   m_TotalAcc->ProcessGroup((char *) lParam, HIWORD(wParam)); break;
	case 'Q':	parsingOubsDN((char *) lParam, HIWORD(wParam)); break;
	case 'P':	processSecureTool((char *) lParam, HIWORD(wParam)); break;
	case 'p':	break;	// (SecureTool ���TR, OS Report TR) �� ó������ �ʴ´�.
	case 'R':   processTran((char*)lParam, len); break;
	default:	TRACE("CMainFrame::processFMX[default]\n");	break;
	}
}

void CMainFrame::processNEWS(char* dat, int len)
{
	WriteLog("ProcessNEWS - Step 1");
	CString sdata(_T(""));
	sdata = (char*) dat;
	//dat = dat+4;
	CString	Path;
	//if (sdata[0] == '1') AfxMessageBox(sdata);

	Path.Format("%s\\%s\\%s\\notice.dat", Axis::home, USRDIR, Axis::user);

	WriteLog("ProcessNEWS - Step 2");
	
	TRY
	{
		WriteLog("ProcessNEWS - Step 3");
		CFile	file;
		if (!file.Open(Path, CFile::modeCreate|CFile::modeWrite))
		{
			TRACE("Create Failed\n");
			return;
		}
		WriteLog("ProcessNEWS - Step 4");
		file.Write(dat, len);
		WriteLog("ProcessNEWS - Step 5");
		file.Close();
		WriteLog("ProcessNEWS - Step 6");
	}
	CATCH (CFileException, e) 
	{
		char emsg[1024];
		e->GetErrorMessage(emsg, 1024);
		WriteLog("ProcessNEWS Error- %s", emsg);
	}
	END_CATCH;

	
	WriteLog("SetTimer -> %d", SetTimer(TM_NOTICE, 1000, NULL));
}

void CMainFrame::processTICK(CString dat)
{
	//OutputDebugString("PROCESSTICK START\n");
	CString tmps, value, sym, yesym;
	int	pos, key;
	//OutputDebugString(dat);
	
	pos = dat.GetLength();
	while (!dat.IsEmpty())
	{
		pos  = dat.Find(0x0a);
		if (pos == -1)	break;
		tmps = dat.Left(pos++);
		dat  = dat.Mid(pos);

		pos  = tmps.Find(0x1F);
		key  = atoi(tmps.Left(pos++));
		tmps = tmps.Mid(pos);

		pos  = tmps.Find(0x09);
		sym  = tmps.Left(pos++);
		tmps = tmps.Mid(pos);
		value.Format("%d", key);
		
		if (sym.IsEmpty())	continue;
		if (value.IsEmpty())	continue;
		//TRACE("\nTick: %d|%s|%s\n", key, sym, tmps);
// 		CString s;
// 		s.Format("\nTick: %d|%s|%s\n", key, sym, tmps);
// 		OutputDebugString(s);
		switch (atoi(value))
		{
		default:
			if (m_tInfo1)	m_tInfo1->SetFmx(true, TKIND_INDEX, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetFmx(true, TKIND_INDEX, key, sym, tmps);
			break;
		case UPDN_KOSPI:case UPDN_KOSDAQ:
			if (m_tInfo1)	m_tInfo1->SetFmx(true, TKIND_UPDOWN, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetFmx(true, TKIND_UPDOWN, key, sym, tmps);
			break;
		case NEWS_BASE:
			if (m_tInfo1)	m_tInfo1->SetFmx(true, TKIND_NEWS, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetFmx(true, TKIND_NEWS, key, sym, tmps);
			break;
		}
	}

	if (m_tInfo1)	m_tInfo1->SetFmx(false);
	if (m_tInfo2)	m_tInfo2->SetFmx(false);

	//OutputDebugString("PROCESSTICK END\n");
}

void CMainFrame::processETICK(CString dat)
{
	CString tmps, value, sym, yesym;
	int	pos, key;

	pos = dat.GetLength();

	while (!dat.IsEmpty())
	{
		pos  = dat.Find(0x0a);
		if (pos == -1)	break;
		tmps = dat.Left(pos++);
		dat  = dat.Mid(pos);

		pos  = tmps.Find(0x1F);
		key  = atoi(tmps.Left(pos++));
		tmps = tmps.Mid(pos);

		pos  = tmps.Find(0x09);
		sym  = tmps.Left(pos++);
		tmps = tmps.Mid(pos);

		value.Format("%d", key);
		if (sym.IsEmpty())	continue;
		if (value.IsEmpty())	continue;

		switch (atoi(value))
		{
		default:
			if (m_tInfo1)	m_tInfo1->SetEFmx(true, TKIND_INDEX, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetEFmx(true, TKIND_INDEX, key, sym, tmps);
			break;
		case UPDN_KOSPI:case UPDN_KOSDAQ:
			if (m_tInfo1)	m_tInfo1->SetEFmx(true, TKIND_UPDOWN, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetEFmx(true, TKIND_UPDOWN, key, sym, tmps);
			break;
		case NEWS_BASE:
			if (m_tInfo1)	m_tInfo1->SetEFmx(true, TKIND_NEWS, key, sym, tmps);
			if (m_tInfo2)	m_tInfo2->SetEFmx(true, TKIND_NEWS, key, sym, tmps);
			break;
		}
	}

	if (m_tInfo1)	m_tInfo1->SetEFmx(false);
	if (m_tInfo2)	m_tInfo2->SetEFmx(false);
}

void CMainFrame::processINTER(char* dat)
{
	struct	_grid {
		char	code[12];		 /* �����ڵ�			 */
		char    hnam[20];                /* �����                       */
		char    curr[8];                 /* ���簡                       */
		char    diff[6];                 /* ���ϴ��      (9999V99)      */
		char    gvol[12];                /* �ŷ���                       */
	};

	struct  _interMod {
		char	keyf[2];		// ticker id
		char	nrec[3];		// count jcode
		struct	_grid	grid[1];	// data
	};
	
	CString		code, name, price, diff, gvol;
	_interMod*	interMod = (struct _interMod*) dat;
	int	cnt = atoi(CString(interMod->nrec, sizeof(interMod->nrec)));
	for (int ii = 0; ii < cnt; ii++)
	{
		code = CString(interMod->grid[ii].code, sizeof(interMod->grid[ii].code));	code.TrimRight();
		name = CString(interMod->grid[ii].hnam, sizeof(interMod->grid[ii].hnam));	name.TrimRight();
		price = CString(interMod->grid[ii].curr, sizeof(interMod->grid[ii].curr));	price.TrimRight();
		diff = CString(interMod->grid[ii].diff, sizeof(interMod->grid[ii].diff));	diff.TrimLeft();
		gvol = CString(interMod->grid[ii].gvol, sizeof(interMod->grid[ii].gvol));	gvol.TrimLeft();
		if (m_tInfo1)	m_tInfo1->SetInter((char*) &interMod->grid[ii]);
		if (m_tInfo2)	m_tInfo2->SetInter((char*) &interMod->grid[ii]);
	}
}

void CMainFrame::processELOG(char* dat)
{
	if (dat[0] == '0')	// error report OK
	{
		::DeleteFile(m_elogfileName);
		PostMessage(WM_ELOG);
	}
}


void CMainFrame::sendTicInfo()
{
	CString	section, keys;
	char	buf[1024*2], ticInfo[255];
	int	len, idx = 0, kk;
	CMapStringToString	interAry;

	ZeroMemory(ticInfo, sizeof(ticInfo));

	CProfile profile(pkAxisTicker);

	CString dval;
	for (int ii = 0; ii < TICKBAR_CNT; ii++)
	{
		keys.Format("BAR%02d", ii);
		int splitN = profile.GetInt(szGeneral, keys, SPLIT_CNT);
		for (int jj = 0; jj < splitN; jj++)
		{
			section.Format("BAR_INFO_%02d", jj + ii*10);
			switch (profile.GetInt(section, "INDEXK", TKIND_INDEX))
			{
			case TKIND_INDEX:
				{
					CString	value;
					for (kk = 0; ; kk++)
					{
						keys.Format("%03d", kk);
						dval = profile.GetString(section, keys);
						/*
						if (dval == "28")
						{
							//AfxMessageBox("27 out");
							//dval = "1";
							continue;
						}
						*/
						strcpy(buf, dval);
						
						if (strlen(buf) < 1)
							break;
						
						len = GetTicKey(atoi(buf));
						/*
						CString tmp;
						tmp.Format("%d",len);	
						AfxMessageBox(tmp);
						*/
						ticInfo[len] = '1';
					}
				}
				break;
			case TKIND_UPDOWN:
				kk = profile.GetInt(section, "SELECT");
				switch (kk)
				{
				case 0:	case 1:
					ticInfo[UPDN_KOSPI+kk] = '1';	// 7 - base updown key
					break;
				case 2:
					ticInfo[UPDN_KOSPI] = '1';		// kospi
					ticInfo[UPDN_KOSDAQ] = '1';		// kosdaq
					break;
				default:
					ticInfo[UPDN_KOSPI] = '1';		// kospi
					break;
				}
				break;
			case TKIND_NEWS:
				ticInfo[NEWS_BASE] = '1';
				break;
			case TKIND_INTER:
				{
					CString	value;
					for (kk = 0; ; kk++)
					{
						keys.Format("%02d", kk);
						strcpy(buf, profile.GetString(section, keys));
						if (strlen(buf) < 1)
							break;
						//if (atoi(buf) == 27) continue;
						if (interAry.Lookup(buf, value))
							continue;
						interAry.SetAt(buf, "reg");
					}
				}
				break;
			case TKIND_INVEST:
				{
					//AfxMessageBox("TKIND_INVEST");
				}
			default:
				continue;
			}
		} 
	}
	
	struct _rtick {
		char	acts[1];	// 0 - unregister, 1- register
		char	code[3];	// ticker info;
	};
	struct _rtick* rtick = (struct _rtick *) buf;
	
	memset(buf, '0', sizeof(buf));
	for (ii = 1 ; ii < sizeof(ticInfo); ii++)
	{
		if (ticInfo[ii] == 0x00)
			continue;
		section.Format("%03d", ii);
		rtick[idx].acts[0] = '1';
		CopyMemory(rtick[idx++].code, section, sizeof(rtick->code));
	}

	if (!idx)
	{
		rtick[idx].acts[0] = '1';
		CopyMemory(rtick[idx++].code, "002", sizeof(rtick->code));
	}
	
	
	len = idx*sizeof(struct _rtick);
	sendTR("PIBOTICK", buf, len, US_PASS, 't');
	if (interAry.GetCount())
	{
		const	int	L_code = 12;
		const	int	codeCnt = 5;/* 2 - key, 3 - code count */
		CString	codes;
		/*
		struct _iSise
		{
			char	keyf[2];	// ticker id
			char	nrec[3];	// count jcode
			char	code[L_code];	// jcode
		};
		*/
		int	cnt = interAry.GetCount();
		int	sndL = codeCnt + L_code*cnt + 1;
		char*	sndB = new char [sndL];
		ZeroMemory(sndB, sndL);
		len = idx = codeCnt;
		sprintf(sndB, "%05d", cnt);
		for (POSITION pos = interAry.GetStartPosition(); pos; )
		{
			interAry.GetNextAssoc(pos, codes, keys);
			
			sprintf(&sndB[idx], "%s", codes.Mid(1));
			idx += L_code;
		}
		sendTR("PIBOSISE", sndB, idx, US_PASS, 'I');
		delete [] sndB;
	}
}

void CMainFrame::ParseSym(CString dat, CMapStringToString& ary)
{
	CString sym, value;
	int	pos;
	while (!dat.IsEmpty())
	{
		pos = dat.Find('\t');
		if (pos == -1)	break;
		sym = dat.Left(pos++);
		dat = dat.Mid(pos);

		pos = dat.Find('\t');
		if (pos == -1)
		{
			value = dat;
			dat.Empty();
		}
		else
		{
			value = dat.Left(pos++);
			dat = dat.Mid(pos);
		}

		ary.SetAt(sym, value);
	}
}

void CMainFrame::actionCaption(int key, int action)
{
	CString s;
	s.Format("ACTIONCAPTION KEY : %d	ACTION : %d\n",key,action);
	OutputDebugString(s);
	if (key == -1)	// for main caption
	{
		switch (action)
		{
		case MIDX_HOME:
			GoHomepage();
			break;
		case MIDX_FULL:		fullScreenMode(!m_fullmode);	break;
		case MIDX_DUAL:		fitDual();	break;
		case MIDX_VS1:case MIDX_VS2:case MIDX_VS3:
		case MIDX_VS4:case MIDX_VS5:case MIDX_VS6:
			change_VirtualScreen(action - MIDX_VS1);
			break;
		case MIDX_MIN:		PostMessage(WM_SYSCOMMAND, SC_MINIMIZE);	break;
		case MIDX_RESTORE:	PostMessage(WM_SYSCOMMAND, SC_RESTORE);		break;
		case MIDX_MAX:
			{

				PostMessage(WM_SYSCOMMAND, SC_MAXIMIZE);	
				/*
				CRect	mRc;
				m_pMain->GetWindowRect(mRc);
				mRc.bottom -= 100;
				
				m_pMain->SetWindowPos(&wndTop, mRc.left, mRc.top, mRc.Width(), mRc.Height(), SWP_SHOWWINDOW);
				*/
				break;
			}
		case MIDX_CLOSE:
		case MIDX_ICON:		PostMessage(WM_SYSCOMMAND, SC_CLOSE);		break;
		default:
			break;
		}
		return;
	}

	CChildFrame*	child  = NULL;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		actionSCaption(key, action);
		return;
	}

	int		value;
	long		rc = 0;
	CRect		sdiRc, mdiRc;
	CPoint		sp(-1, -1);
	CString		mapname;
	WINDOWPLACEMENT	pl;
	
	GetWindowPlacement(&pl);
	switch (action)
	{
	case IDX_SINGLE:	
		convertSDI(key, m_vsN);		
		break;
	case IDX_GROUP:
		value = child->m_xcaption.ChangeGroup();
		if (value >= 0)	set_Trigger(key, value);
		break;
	case IDX_COPY:
		child->GetWindowPlacement(&pl);
		value = GetSystemMetrics(SM_CYCAPTION);
		value += GetSystemMetrics(SM_CXFRAME);
		value += GetSystemMetrics(SM_CXBORDER);
		sp = CPoint(pl.rcNormalPosition.left, pl.rcNormalPosition.top);
		sp.Offset(value, value);

		value = child->m_xcaption.GetGroup();
		switch (value)
		{
		case 0:/*none group*/
		case 99:/*all group*/	break;
		case 1:case 2: case 3:case 4: case 5:
			value++;
			if (value > 5)	value = 1;
			break;
		default:	
			value = 1;	break;
		}		
		m_mapHelper->CopyScreen(child->m_mapN, value, child->m_xcaption.GetFontSize(), sp);
		break;
	case IDX_HELP:	HelpLink(key);	break;
	case IDX_FONTX: //�⺻ũ���
		refleshMap(child->m_key);
		child->m_xcaption.SetFontSize(m_fontSize);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));	// cej
		child->m_xcaption.SetMax(false);
		break;
	case IDX_FONT:
		
		m_preFontSize = child->m_xcaption.GetFontSize();
		value = child->m_xcaption.ChangeFont();	
		
		if (!CheckClientWidth(child, child->m_xcaption.GetFontSize()))
		{
			child->m_xcaption.SetFontSize(m_preFontSize);
			return;
		}
		
		
		
		if (value > 0)
		{
			if (value == INITMAPSIZE)
			{
				//if (m_preFontSize == m_fontSize) return;
				refleshMap(child->m_key);
				//child->m_xcaption.SetFontSize(m_fontSize);
				
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));	// cej
				
				
				
			}
			else
			{
				refleshMap(child->m_key);
				
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, value));
				
			}
			child->m_xcaption.SetMax(false);
		}
		break;
	case IDX_MIN:
		sp = getMinimizePos(child->m_key);
		child->actionCaption(action, sp);
		MDINext();
		break;
	case IDX_RESTORE:
	case IDX_MAX:		child->actionCaption(action, sp);	break;
	case IDX_CLOSE:
	case IDX_ICON:		
		{
			if(child->m_mapN == "IB0000X8")
			{
				child->ShowWindow(SW_HIDE);
			}
			else
			{
				m_mapHelper->closeChild(key);			
			}
		}
		break;
	default:
		break;
	}
}

void CMainFrame::actionSCaption(int key, int action)
{
	CSChild*	schild = NULL;
	if (!m_arSDI[m_vsN].Lookup(key, schild))
		return;

	int		value;
	CRect		wRc;
	long		rc = 0;
	CPoint		sp(-1, -1);
	WINDOWPLACEMENT	pl;
	
	GetWindowPlacement(&pl);
	switch (action)
	{
	case IDX_PIN:
		if (schild->m_xcaption.changePin())
			schild->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		else	schild->SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		break;
	case IDX_SINGLE:	convertMDI(key, m_vsN);		break;
	case IDX_GROUP:
		value = schild->m_xcaption.ChangeGroup();
		if (value >= 0)	set_STrigger(key, value, m_vsN);
		break;
	case IDX_COPY:
		schild->GetWindowPlacement(&pl);
		value = XCAP_HEIGHT;
		value += GetSystemMetrics(SM_CXFRAME);
		value += GetSystemMetrics(SM_CXBORDER);
		sp = CPoint(pl.rcNormalPosition.left, pl.rcNormalPosition.top);
		sp.Offset(value, value);

		value = schild->m_xcaption.GetGroup();
		switch (value)
		{
		case 0:/*none group*/
		case 99:/*all group*/	break;
		case 1:case 2: case 3:case 4: case 5:
			value++;
			if (value > 5)	value = 1;
			break;
		default:	value = 1;	break;
		}		
		m_mapHelper->CopySScreen(schild->m_mapN, value, schild->m_xcaption.GetFontSize(), sp);
		break;
	case IDX_HELP:	HelpLink(key);	break;
	case IDX_FONT:
		value = schild->m_xcaption.ChangeFont();
		if (value > 0)
		{
			if (value == INITMAPSIZE)
			{
				refleshMap(schild->m_key);
				schild->m_xcaption.SetFontSize(m_fontSize);
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, m_fontSize));	// cej
			}
			else
			{
				refleshMap(schild->m_key);
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, value));
			}
			schild->m_xcaption.SetMax(false);
		}
		break;
	case IDX_MIN:
		if (!schild->m_xcaption.IsMax())
		{
			schild->GetWindowRect(wRc);
			schild->m_restoreRc.CopyRect(&wRc);
		}
		schild->PostMessage(WM_SYSCOMMAND, SC_MINIMIZE);
		break;
	case IDX_RESTORE:
		schild->SetRestore();
		break;
	case IDX_MAX:
		schild->SetMax();
		break;
	case IDX_CLOSE:
	case IDX_ICON:	schild->PostMessage(WM_CLOSE);	break;
	default:
		break;
	}
}

void CMainFrame::GetDispN(char* mapN)
{
	if (!m_tMenu)	return;
	CString dispN = m_tMenu->GetDispN(mapN);
	if (dispN.GetLength() >= 16)
		dispN = dispN.Left(15);	// Last byte null terminate
	sprintf(mapN, dispN);
}


int CMainFrame::InputScreenNo(CString dispN)
{
	if (m_tMenu)
	{
		CString mapN = m_tMenu->GetMap(dispN);
		if (!ExistMenu(mapN))	
			return 0;
		if (IsForeignMap(mapN))
			RunForeignMap();
		else if (IsPhonePad(mapN))
			RunPhonePad();
		else
			return m_mapHelper->ChangeChild(mapN);
	}
	return 0;
}

void CMainFrame::ConfigFrame()
{
	SetUserInfo();	
	CString	file, cpfile, port;

	file.Format("%s\\%s\\%s", Axis::home, USRDIR, Axis::user);
	::CreateDirectory(file, NULL);

	file.Format("%s\\%s\\%s", Axis::home, GEXDIR, Axis::user);
	::CreateDirectory(file, NULL);

	file.Format("%s\\%s\\%s\\axisensetup.ini", Axis::home, USRDIR, Axis::user);
	cpfile.Format("%s\\%s\\axisensetup.ini", Axis::home, MTBLDIR);
	CopyFile(cpfile, file, TRUE);

	file.Format("%s\\%s\\%s\\usertool.ini", Axis::home, USRDIR, Axis::user);
	cpfile.Format("%s\\%s\\usertool.ini", Axis::home, MTBLDIR);
	CopyFile(cpfile, file, TRUE);

	file.Format("%s\\%s\\%s\\axisticker.ini", Axis::home, USRDIR, Axis::user);
	cpfile.Format("%s\\%s\\axisticker.ini", Axis::home, MTBLDIR);
	CopyFile(cpfile, file, TRUE);

	file.Format("%s\\%s\\%s\\hkey.ini", Axis::home, USRDIR, Axis::user);
	cpfile.Format("%s\\%s\\hkey.ini", Axis::home, MTBLDIR);
	CopyFile(cpfile, file, TRUE);

	file.Format("%s\\%s\\%s\\ordcfg.ini", Axis::home, USRDIR, Axis::user);
	cpfile.Format("%s\\%s\\ordcfg.ini", Axis::home, MTBLDIR);
	CopyFile(cpfile, file, TRUE);

	CheckSoundConfig();
	CheckNewsSetting();
	m_conclusion = new CConclusion(this);
	if (!m_conclusion->Create(IDD_CONCLUSIONLIST))
	{
		delete m_conclusion;
		m_conclusion = NULL;
	}
	else	m_conclusion->Init();

	
	m_kobanotify = new CKobaElwNotify(this);
	if (!m_kobanotify->Create(IDD_KOBA_NOTIFY))
	{
		delete m_kobanotify;
		m_kobanotify = NULL;
	}
	else
	{
		m_kobanotify->Init();
		//m_kobanotify->ShowWindow(SW_SHOW);
	}

	m_Econclusion = new CEConclusion(this);
	if (!m_Econclusion->Create(IDD_CONCLUSION))
	{
		delete m_Econclusion;
		m_Econclusion = NULL;
	}
	else	m_Econclusion->Init();

	m_mngInfo = new CManageInfo(this);
	if (!m_mngInfo->Create(IDD_MNGINFO))
	{
		delete m_mngInfo;
		m_mngInfo = NULL;
	}

	m_pDoctor = new CDtInfo(this);
	if (!m_pDoctor->Create(IDD_DTINFO))
	{
		delete m_pDoctor;
		m_pDoctor = NULL;
	}
	
	/**if (!m_bCustomer)
	{
		//** ��������.
		m_accTool = new CAccTool(this);
		if (!m_accTool->Create(IDD_ACCTOOLBAR, this))
		{
			delete m_accTool;
			m_accTool = NULL;
		}
	}
	**/

	m_Nclock = new CNClock();
	LPCTSTR className = AfxRegisterWndClass(CS_VREDRAW | CS_HREDRAW, ::LoadCursor(NULL, IDC_ARROW),
			(HBRUSH) ::GetStockObject(WHITE_BRUSH),	m_resourceHelper->GetIcon());
	if (!m_Nclock->CreateEx(WS_EX_TOOLWINDOW, className, _T(""), WS_POPUP,//|WS_BORDER, 
				CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, 0))
	{
		delete m_Nclock;
		m_Nclock = NULL;
	}
	else	
		m_Nclock->Init();

	change_BackGround();
	CreateTB();
}

void CMainFrame::ProcessInitMap()
{
	CString initMap(m_axis->GetProfileString(WORKSTATION, INITMAP, "00000000"));
	
	if (initMap.GetLength() >= L_MAPN && initMap.Left(2) == "IB")
	{
		m_mapHelper->ChangeChild(initMap, 0, 0, CenterPOS);
	}
}

void CMainFrame::EditTool()
{
	TotalSetup(IDD_TSETUP); 
}

void CMainFrame::SetTicker()
{
	TotalSetup(IDD_SETTICKINFO);
}

BOOL CMainFrame::Change_VsKey(int index)
{
	if (0 > index || index >= 6)
		return FALSE;
	change_VirtualScreen(index);
	return TRUE;
}

void CMainFrame::ConfigTicker(bool reconfig/*=false*/)
{
	CProfile profile(pkAxisTicker);

	if (reconfig)
	{
		m_tInfo1->ReConfig(profile.GetInt(szGeneral, "Bar00", SPLIT_CNT));
		m_tInfo2->ReConfig(profile.GetInt(szGeneral, "Bar01", SPLIT_CNT));
	}
	else
	{
		m_tInfo1->Config(profile.GetInt(szGeneral, "Bar00", SPLIT_CNT));
		m_tInfo2->Config(profile.GetInt(szGeneral, "Bar01", SPLIT_CNT));
	}
}

void CMainFrame::CreateChaser()
{
	long	rc = 0;
	if (m_chaser)
	{
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setTRACE, WM_USER), m_chaser->GetSafeHwnd());
		return;
	}

	m_chaser = new CChaser(this);
	if (!m_chaser->Create(NULL, "axis chaser", WS_CHILD, CRect(0), this, (int) m_chaser))
	{
		delete m_chaser;
		m_chaser = NULL;
		return;
	}

	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
	(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setTRACE, WM_USER), m_chaser->GetSafeHwnd());
}

void CMainFrame::DeleteChaser()
{
#ifndef _CHASERDEBUG
	long	rv = 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rv,
			(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setTRACE, WM_USER), NULL);
	CloseChaserAPP();
#endif
}

void CMainFrame::CloseChaserAPP()
{
	CString	winCaption;
	winCaption.Format("AxisChaser for %s", m_regkey);
	CWnd* wnd = CWnd::FindWindow(NULL, winCaption);
	 if (wnd && wnd->GetSafeHwnd())
		::PostMessage(wnd->m_hWnd, WM_CLOSE, 0, 0);
}

void CMainFrame::showChaser()
{
	if (!m_runAxis)	return;
	//	create tracer process
	CString	aps, cmds, exes;
	STARTUPINFO		si;
	PROCESS_INFORMATION	pi;

	ZeroMemory(&si, sizeof(STARTUPINFO));
	ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

	si.cb          = sizeof(STARTUPINFO);
	si.dwFlags     = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_SHOW;

	CAxisApp* app = (class CAxisApp *) AfxGetApp();
	char	buffer[1024];
	GetClassName(m_hWnd, buffer, sizeof(buffer));
	cmds.Format(" /c %s /r \"%s\"", buffer, m_regkey);
	aps.Format("%s\\%s\\AxisChaser.exe", Axis::home, RUNDIR);

	BOOL bRc = CreateProcess(
			aps,				// application name
			(char *)(const char*)cmds,// command line
			NULL,				// process attribute
			NULL,				// thread attribute
			FALSE,				// is inherit handle
			0,					// creation flags
			NULL,				// environment
			NULL,				// current directory
			&si,				// STARTUPINFO
			&pi);				// PROCESS_INFORMATION
}

LONG CMainFrame::OnCHASER(WPARAM wParam, LPARAM lParam)
{
// 	CString	winCaption;
// 	winCaption.Format("AxisChaser for %s", m_regkey);
// 	CWnd* wnd = CWnd::FindWindow(NULL, winCaption);
// 
// 	if (!wnd->GetSafeHwnd())
// 		return 0;

	m_sync.Lock();
	int	len = L_cds + LOWORD(wParam);
	char	bufx[1024*128];

	ZeroMemory(bufx, sizeof(bufx));
	struct _exeCDSS* cds = (struct _exeCDSS *) bufx;

	cds->flag = HIWORD(wParam);
	cds->len  = LOWORD(wParam);
	CopyMemory(&bufx[L_cds], (char *) lParam, len);

	COPYDATASTRUCT cs;
	cs.cbData = len + L_cds;
	cs.dwData = 0;
	cs.lpData = bufx;

// 	CString data(bufx,len+L_cds);
// 	if(data.Find("pijs")>-1)
// 	{
// 		CString s;
// 		s.Format("DRFN : %s\n",data);
// 		OutputDebugString(s);
// 	}

	CString	winCaption;
	winCaption.Format("AxisChaser for %s", m_regkey);
	CWnd* wnd = CWnd::FindWindow(NULL, winCaption);
	 if (wnd->GetSafeHwnd())
		::SendMessage(wnd->m_hWnd, WM_COPYDATA, 0, (LPARAM) &cs);
	m_sync.Unlock();
	return 0;
}

LONG CMainFrame::OnELOG(WPARAM wParam, LPARAM lParam)
{
	WIN32_FIND_DATA FindFileData;
	HANDLE		hFind;
	CFile		cfile;
	CString		allfile, filename;

	allfile.Format("%s\\%s\\%s\\crash\\elog_*", Axis::home, USRDIR, Axis::user);
	hFind = FindFirstFile(allfile, &FindFileData);
	while (hFind != INVALID_HANDLE_VALUE)
	{
		if (FindFileData.dwFileAttributes != FILE_ATTRIBUTE_DIRECTORY)
		{
			filename.Format("%s\\%s\\%s\\crash\\%s", Axis::home, USRDIR, Axis::user, FindFileData.cFileName);
			if (cfile.Open(filename, CFile::modeRead|CFile::typeBinary))
			{
				int	fileL = cfile.GetLength();
				char*	sndB = new char [fileL + 1];

				ZeroMemory(sndB, fileL + 1);
				cfile.Read(sndB, fileL);
				cfile.Close();

				m_elogfileName = filename;
				sendTR("pihoerpt", sndB, fileL, US_PASS, 'r');
				delete [] sndB;
				return 0;
			}
		}
		if (!FindNextFile(hFind, &FindFileData))	break;
	}

	return 0;
}

LONG CMainFrame::OnApplyACC(WPARAM wp, LPARAM lp)
{
	CString	sym, value, data = (char *) lp;

	long	rc = 0;
	int	sndL, command = LOWORD(wp);
	switch (command)
	{
	case 0:		// apply acccout and password for trigger
		{
			int	key = m_activeKey;
			while (!data.IsEmpty())
			{
				int pos = data.Find("\n");
				if (pos == -1)	break;
				value = data.Left(pos++);
				data = data.Mid(pos);

				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)value);
			}
		}
		break;
	case 1:	// save account password for staff
		while (!data.IsEmpty())
		{
			int pos = data.Find('\n');
			if (pos == -1)	break;
			value = data.Left(pos++);
			data  = data.Mid(pos);

			rc = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(saveACC, 0), (long)(const char*)value);
		}
		break;
	case 100:
		sndL = HIWORD(wp);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setACCB, HIWORD(wp)), lp);
		break;
	case 101:	// �ֽ�
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setACCG, 0), (long)(const char*)data);
		break;
	case 102:	// ����
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(setACCG, 1), (long)(const char*)data);
		break;
	}

	return 0;
}

LONG CMainFrame::OnSaveACC(WPARAM wp, LPARAM lp)
{
	int	command = (int) wp;
	long	rc = 0;
	CString	sym, value, data;

	switch (command)
	{
	case 0:	// save acc pass
		data = (char *) lp;
		//**TRACE("SAVE pass [%s]\n", data);

		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(saveACC, 0), (long)(const char*)data);
		break;
	case 1:	// attach map
		{
			int	size, vtype, key = KEY_ACCTOOL;
			CString	mapname = _T(MAPN_ACCTCONFIG);
			
			m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
						(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
			m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_accSave, vtype, key);
			m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);

			CSize	frameGap;
			frameGap.cx  = GetSystemMetrics(SM_CXFRAME);
			frameGap.cx += GetSystemMetrics(SM_CXBORDER) * 2;

			frameGap.cy  = GetSystemMetrics(SM_CYFRAME);
			frameGap.cy += GetSystemMetrics(SM_CYBORDER) * 2;
			frameGap.cy += GetSystemMetrics(SM_CYCAPTION);

			int nCx = frameGap.cx + LOWORD(size);
			int nCy = frameGap.cy + HIWORD(size);
			m_accSave->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_NOZORDER);
		}
		break;
	case 2:	// detach map
		break;
	case 100:	// save password for staff.
		break;
	}
	return 0;
}

LRESULT CMainFrame::OnAxisClose(WPARAM wParam, LPARAM lParam)
{
	CString	str, msg, title, logs;
	
	switch (m_step)
	{
	case axOPENRSM:
		m_axConnect->SetProgress(false);
	case axOPENWSH:
	case axOPENSIGN:
		
		m_step = axNONE;
		m_axConnect->SetStatus(SM_EXIT);
		if (m_axConnect->GetStyle() & WS_VISIBLE)
		{
			m_axConnect->EndDialog(IDCANCEL);
			m_axConnect = NULL;
		}

		msg.LoadString(ST_MSG_DISCONNECT_EXIT);
		title.LoadString(ST_TEXT_PROGRAMEXIT);
		//**::MessageBox(m_hWnd, msg, title, MB_ICONINFORMATION);
		Axis::MessageBox(this, msg, MB_ICONINFORMATION);
		break;
	case axNONE:
		title.LoadString(ST_TEXT_PROGRAMEXIT);
		m_axMisc->MsgBox(str, title);
		if (m_axConnect && IsWindow(m_axConnect->GetSafeHwnd()) && m_axConnect->ContinueModal())
			m_axConnect->EndDialog(IDCANCEL);
		break;
	case axDONE:
		msg.LoadString(ST_MSG_DISCONNECT_RETRY);
		title.LoadString(ST_TEXT_OK);
		if (Axis::MessageBox(msg, MB_OKCANCEL) == IDOK)
		{
			if (!m_axMisc->RunVers(verRETRY, Axis::userID, m_pass, m_cpass))
				return 0;
		}
		else
		{
			if (Axis::MessageBox(this, "���α׷��� �����Ͻ÷��� [Ȯ��] ��ư�� ���� �ּ���", MB_OKCANCEL) == IDCANCEL)
				return 0;
		}
		break;
	}

	m_step = axCLOSE;


	if (GetSafeHwnd())
		PostMessage(WM_CLOSE);
	return 1;
}

LRESULT CMainFrame::OnTrayEvent(WPARAM wParam, LPARAM lParam)
{
	UINT	msg = LOWORD(lParam);
	switch (msg)
	{
	case WM_RBUTTONDOWN:	// display menu
		{
			CPoint pt;
			GetCursorPos(&pt);
			m_tMenu->ShowFullMenu(pt);
		}
		break;
	case WM_LBUTTONDBLCLK:	// restore SDI 
		m_appMode = MODE_SDI;
		TrayCmd(TRAY_HIDEICON);
		ShowWindow(SW_SHOW);
		break;
	}
		
	return 1;
}

void CMainFrame::ProcessInfofile(bool upload)
{
	m_infofile = new CInfofile(m_wizard, upload);
	m_infofile->DoModal();

	if (!upload)
	{
		DWORD bits = m_infofile->GetApplyBits();

		if (bits & APPLY_ENSETUP)	
		{
			load_eninfomation(false);
			load_mngSetup();
			load_hkey();
		}

		if (bits & APPLY_TOOLBAR)	
			m_bar1->Refresh();

		if (bits & APPLY_TICKER)
		{
			ConfigTicker(true);
			sendTicInfo();

			CProfile profile(pkAxisTicker);
			ShowControlBar(m_tInfo1, profile.GetInt(szGeneral, "view1", 1), FALSE);
			ShowControlBar(m_tInfo2, profile.GetInt(szGeneral, "view2", 1), FALSE);
			if (m_tInfo3)
				ShowControlBar(m_tInfo3, profile.GetInt(szGeneral, "view3", 1), FALSE);

			if (m_bSDI)
			{
				saveToolStatus();
				SetSDIChangeHeight();
			}
		}

		if (bits & APPLY_WORKSPACE)	
		{
			makeUserScreenMenu();
		}

		load_dbar2();
	}

	if (m_infofile && m_infofile->GetSafeHwnd())
	{
		delete m_infofile;
		m_infofile = NULL;
	}

	if (m_infofile)	
		delete m_infofile;
}

void CMainFrame::Action(WPARAM wParam, LPARAM lParam)
{
	int	key = LOWORD(wParam);
	int	actK = HIWORD(wParam);
	
	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
		return;

	//	Group(0);Copy(1);Help(2);Font(3);Min(4);Max(5);Close(6)
	switch (actK)
	{
	case 1:	actionCaption(key, 2);	break;
	case 2:	actionCaption(key, 1);	break;
	case 4:	child->PostMessage(WM_SYSCOMMAND, SC_MINIMIZE, 0);	break;
	case 5:	child->PostMessage(WM_SYSCOMMAND, SC_MAXIMIZE, 0);	break;
	case 6:	m_mapHelper->closeChild(child->m_key);		break;
	default:
		if (actK >= GROUPBASE && actK < FONTBASE)
		{
			actK -= GROUPBASE;
			switch (actK)
			{
			case 0:case 1:case 2:case 3: case 4:case 5:case 99:
				set_Trigger(key, actK);	break;
			default:	break;
			}
		}
		else if (actK >= FONTBASE)
		{
			actK -= FONTBASE;
			long	rc = 0;
			switch (actK)
			{
			case 8:case 9:case 10:case 11:case 12:
				child->m_xcaption.SetFontSize(actK);
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFONTx, key), MAKELONG(0, actK));
				break;
			default:
				break;
			}
		}
		return;
	}
}

void CMainFrame::GetCaptionInfo(WPARAM wParam, LPARAM lParam)
{
	int	infoK =  LOWORD(wParam);
	int	key = HIWORD(wParam);
	char*	buf = (char *) lParam;
	
	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		sprintf((char *) lParam, "-1");
		return;
	}

	switch(infoK)
	{
	case 0:	//	group
		sprintf(buf, "%d", child->m_xcaption.GetGroup());
		break;
	case 1:
		sprintf(buf, "%d", child->m_xcaption.GetFontSize());
		break;
	default:
		break;
	}
}

// must to call after call SetMisc (..)
void CMainFrame::HideChildButton(int key)
{
	CString		file;

	CChildFrame*	child;
	CSChild*	schild;
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		if (!m_arMDI[vsN].Lookup(key, child))
		{
			if (!m_arSDI[vsN].Lookup(key, schild))
				continue;
			
			/*
			if (m_mapHelper->IsDLL(schild->m_mapN))
				schild->m_xcaption.HideButton(HIDE_FONT);
			else */
			if (IsWebMenu(schild->m_mapN))
				schild->m_xcaption.HideButton(HIDE_FONT);

			//if (schild->m_mapN.Mid(0,4) == "IB76" || schild->m_mapN.Mid(0,8) == "IB202200")  //����˻� ���� ��Ʈ ��
			if (IsNoFontMenu(schild->m_mapN))
			{
				schild->m_xcaption.HideButton(HIDE_FONT);
			}

			if (IsHelpMenu(schild->m_mapN))
				schild->m_xcaption.ShowButton(HIDE_HELP);
			else
				schild->m_xcaption.HideButton(HIDE_HELP);
			break;
		}
		//TRACE("["+child->m_mapN+"]\n");

		/*if (m_mapHelper->IsDLL(child->m_mapN))
			child->m_xcaption.HideButton(HIDE_FONT);
		else */
		if (IsWebMenu(child->m_mapN))
			child->m_xcaption.HideButton(HIDE_FONT);
		else
			child->m_xcaption.ShowButton(HIDE_FONT);

		if (IsHelpMenu(child->m_mapN))
			child->m_xcaption.ShowButton(HIDE_HELP);
		else
			child->m_xcaption.HideButton(HIDE_HELP);
		//if (child->m_mapN.Mid(0,4) == "IB76" || child->m_mapN.Mid(0,8) == "IB202200")  //����˻� ���� ��Ʈ ��
		if (IsNoFontMenu(child->m_mapN))
		{
			child->m_xcaption.HideButton(HIDE_FONT);
		}
		else
			child->m_xcaption.ShowButton(HIDE_FONT);


		
		
	}
//	file.Format("%s\\%s\\caption.ini", Axis::home, TABDIR);
//	UINT value = GetPrivateProfileInt("BUTTONHIDE", child->m_mapN, 0, file);
//	if (value == SHOW_ALL)	return;
//	child->m_xcaption.HideButton(value);
}

void CMainFrame::SettingEticker(int paneID)
{
	if (m_tInfo1)	m_tInfo1->SettingEticker(paneID);
	if (m_tInfo2)	m_tInfo2->SettingEticker(paneID);

	CProfile profile(pkAxisTicker);

	CString	section, keys;
	char	buf[1024*2], ticInfo[128];
	int	len, idx = 0, kk;
	CMapStringToString	interAry;

	ZeroMemory(ticInfo, sizeof(ticInfo));
	
	for (int ii = 0; ii < TICKBAR_CNT; ii++)
	{
		keys.Format("BAR%02d", ii);
		int splitN = profile.GetInt(szGeneral, keys, SPLIT_CNT);
		for (int jj = 0; jj < splitN; jj++)
		{
			section.Format("BAR_INFO_%02d", jj + ii*10);
			switch (profile.GetInt(section, "INDEXK", TKIND_INDEX))
			{
			case TKIND_INDEX:
				{
					CString	value;
					for (kk = 0; ; kk++)
					{
						value = profile.GetString(section, Format("%02d", kk));
						if (value.IsEmpty())
							break;
						len = atoi(value) + 1;
						if (len >= UPDN_KOSPI)	len += 2;
						if (len >= NEWS_BASE)	len += 1;
						ticInfo[len] = '1';
					}
				}
				break;
			case TKIND_UPDOWN:
				kk = profile.GetInt(section, "SELECT");
				switch (kk)
				{
				case 0:	case 1:
					ticInfo[UPDN_KOSPI+kk] = '1';	// 7 - base updown key
					break;
				case 2:
					ticInfo[UPDN_KOSPI] = '1';		// kospi
					ticInfo[UPDN_KOSDAQ] = '1';		// kosdaq
					break;
				default:
					ticInfo[UPDN_KOSPI] = '1';		// kospi
					break;
				}
				break;
			case TKIND_NEWS:
				ticInfo[NEWS_BASE] = '1';
				break;
			case TKIND_INTER:
				break;
				{
					CString	data, value, codes;
					CProfile inter(Format("%s\\%s\\%s.ins", Axis::home, TABDIR, Axis::user));

					kk = profile.GetInt(section, "SELECT", -1);
					if (kk == -1)	continue;
					
					section.Format("%02d", kk);
					for (kk = 0; ; kk++)
					{
						keys.Format("%02d", kk);
						data = inter.GetString(section, keys);
						if (data.IsEmpty())
							break;
						int	pos = data.Find(':');
						if (pos == -1)	continue;
						codes = data.Left(pos);
						if (interAry.Lookup(codes, value))
							continue;
						interAry.SetAt(codes, "reg");
					}
				}
				break;
			default:
				continue;
			}
		}
	}
	
	
	struct _rtick {
		char	acts[1];	// 0 - unregister, 1- register
		char	code[3];	// ticker info;
	};
	struct _rtick* rtick = (struct _rtick *) buf;

	memset(buf, '0', sizeof(buf));
	for (ii = 1 ; ii < sizeof(ticInfo); ii++)
	{
		if (ticInfo[ii] == 0x00)
			continue;
		section.Format("%03d", ii);
		rtick[idx].acts[0] = '1';
		CopyMemory(rtick[idx++].code, section, sizeof(rtick->code));
	}
	
	len = idx*sizeof(struct _rtick);
	sendTR("PIBOTICK", buf, len, US_PASS, 'e');

	if (interAry.GetCount() > 0)
	{
		const	int	L_code = 12;
		const	int	codeCnt = 5;/* 2 - key, 3 - code count */
		CString	codes;
		/*
		struct _iSise
		{
			char	keyf[2];	// ticker id
			char	nrec[3];	// count jcode
			char	code[L_code];	// jcode
		};
		*/
		ZeroMemory(buf, sizeof(buf));
		int cnt = interAry.GetCount();
		len = idx = codeCnt;
		sprintf(buf, "%05d", cnt);
		for (POSITION pos = interAry.GetStartPosition(); pos; )
		{
			interAry.GetNextAssoc(pos, codes, keys);
			sprintf(&buf[idx], "%s", codes);
			idx += L_code;
		}
		sendTR("PIBOSISE", buf, idx, US_PASS, 'I');
	}
}

void CMainFrame::changePassword(CString newpassword)
{
	newpassword.TrimRight();
	m_pass = newpassword;

	long	rc = 0;
	CString	data = _T("");

	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), loadACC, 0);
	data = (rc ? (char *)rc : _T(""));
	if (data.IsEmpty())	return;

	int		pos;
	Caccount*	acc;
	CString		tmps, tmpx;
	CArray <Caccount*, Caccount* > acs;

	for ( ; !data.IsEmpty(); )
	{
		pos = data.Find('\n');
		if (pos < 0)
			break;

		tmps = data.Left(pos);
		data = (data.GetLength() > pos+1) ? data.Mid(pos+1) : _T("");

		acc = new Caccount;
		for (int ii = 0; ii < 3; ii++)
		{
			pos = tmps.Find('\t');
			if (pos >= 0)
			{
				tmpx = tmps.Left(pos);
				tmps = (tmps.GetLength() > pos+1) ? tmps.Mid(pos+1) : _T("");
			}
			else
			{
				tmpx = tmps;
				tmps = _T("");
			}

			switch (ii)
			{
			case 0:	acc->m_account = tmpx;	break;
			case 1:	acc->m_pass = tmpx;	break;
			case 2:	acc->m_name = tmpx;	break;
			}
		}

		if (acc->m_account.GetLength() != 10)
		{
			delete acc;
			continue;
		}
		acs.Add(acc);
	}
	
	for (int ii = 0; ii < acs.GetSize(); ii++)
	{
		rc = 0;
		acc = acs.GetAt(ii);
		if (acc->m_name.IsEmpty())
			continue;
		data.Format("%s\t%s\t%s", acc->m_account, m_pass, acc->m_name);
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(saveACC, 0), (long)(const char*)data);
	}

	for (ii = 0; ii < acs.GetSize(); ii++)
		delete acs.GetAt(ii);
	acs.RemoveAll();
}

CPoint CMainFrame::getMinimizePos(int childKey)
{
	int		key, cnt;
	CRect		iconicRc, cRc, mRc;
	CPoint		pt;
	POSITION	pos;
	CChildFrame*	child = NULL;
	CArray < CChildFrame*, CChildFrame* > ary;

	m_arMDI[m_vsN].Lookup(childKey, child);
	if (child->m_iconpos.x != -1 || child->m_iconpos.y != -1)
		return child->m_iconpos;

	m_MClient->GetClientRect(cRc);
	int cx = GetSystemMetrics(SM_CXMINIMIZED);
	int cy = GetSystemMetrics(SM_CYMINIMIZED);

	mRc.SetRect(cRc.left, cRc.bottom - cy, cRc.left + cx, cRc.bottom);
	pt = mRc.TopLeft();
	for (pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
	{
		m_arMDI[m_vsN].GetNextAssoc(pos, key, child);
		if (key == childKey)	continue;
		if (!child->m_bIconic)	continue;
		ary.Add(child);
	}

	bool	matchpoint = false;

	cnt = ary.GetSize();
	while (cnt)
	{
		for (int ii = 0; ii < cnt; ii++)
		{
			child = ary.GetAt(ii);
			child->GetWindowRect(iconicRc);

			m_MClient->ScreenToClient(&iconicRc);
			iconicRc.IntersectRect(mRc, iconicRc);
			if (!iconicRc.IsRectEmpty())
			{
				matchpoint = true;
				break;
			}
		}
		
		if (matchpoint)
		{
			mRc.OffsetRect(cx, 0);
			if (mRc.right > cRc.right)
			{
				mRc.OffsetRect(0, -cy);
				mRc.left = cRc.left;
				mRc.right = mRc.left + cx;
			}
			pt = mRc.TopLeft();
			matchpoint = false;
		}
		else	cnt = 0;
	}

	return pt;
}

CView* CMainFrame::GetNewView(int vwKIND)
{
	POSITION pos = m_axis->GetFirstDocTemplatePosition();
	CDocTemplate* pTemplate;
	for (int ii = 0; ii < vwKIND; ii++)
		pTemplate = m_axis->GetNextDocTemplate(pos);

	ASSERT(pTemplate != NULL);
	ASSERT_KINDOF(CDocTemplate, pTemplate);

	CDocument* pDocument = pTemplate->OpenDocumentFile(NULL);
	ASSERT_VALID(pDocument);

	CAxisDoc* doc = (CAxisDoc *) pDocument;
	pos = pDocument->GetFirstViewPosition();
	return pDocument->GetNextView(pos);	
}

CView* CMainFrame::GetSDIView(int vwKIND)
{
	CString strWndClass = AfxRegisterWndClass(CS_VREDRAW | CS_HREDRAW, ::LoadCursor(NULL, IDC_ARROW),
			      (HBRUSH) ::GetStockObject(WHITE_BRUSH), m_resourceHelper->GetIcon());

	int col = m_arSDI[m_vsN].GetCount()/10;
	int row = m_arSDI[m_vsN].GetCount()%10;
	col *= XCAP_HEIGHT;	row *=	XCAP_HEIGHT;
	CSChild*	schild = new CSChild(this);
	if(!schild->Create(strWndClass, AXISKEY, WS_OVERLAPPEDWINDOW, CRect(col+row, row, col+row, row), NULL,NULL,0,NULL))
	{
		delete schild;
		return NULL;
	}

	CCreateContext	context;
	CRuntimeClass*	pNewViewClass;
	switch (vwKIND)
	{
	default:
	case NORMALVIEW:	
		//TRACE("NormalView\n");
		pNewViewClass = RUNTIME_CLASS(CAxisView);	
		break;
	case SCROLLVIEW:	
		//TRACE("ScrollView\n");
		pNewViewClass = RUNTIME_CLASS(CAxScrollView);	
		break;
	case TABLISTVIEW:	
		//TRACE("TabView\n");
		pNewViewClass = RUNTIME_CLASS(CAxTabView);	
		break;
	}

	context.m_pNewViewClass = pNewViewClass;
	context.m_pCurrentDoc = GetActiveDocument();

	return schild->AttachView(context);
}

CSize CMainFrame::GetFrameGap(bool mdichild/*= true*/)
{
	int	gapX  = GetSystemMetrics(SM_CXFRAME) * 2;
	int	gapY  = GetSystemMetrics(SM_CYFRAME) * 2;

	if (mdichild)
	{
		//return CSize(4, 0);
		gapX += GetSystemMetrics(SM_CXBORDER) * 2;
		gapY += GetSystemMetrics(SM_CYBORDER) * 2;
	}
	else
	{
		//**return CSize(4, 0);
		gapX += GetSystemMetrics(SM_CXBORDER) * 4;
		gapY += GetSystemMetrics(SM_CYBORDER) * 4;
	}

	return CSize(gapX, gapY);
}

void CMainFrame::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	if (m_tMenu)
		m_tMenu->MeasureMenuItem(nIDCtl,lpMeasureItemStruct); 
}

void CMainFrame::trouble_shooting( CString strErrMsg )
{	
	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'I';
	memcpy(mid.item.usid, (LPCSTR)Axis::userID, Axis::userID.GetLength());
	memcpy(mid.item.innm, CTime::GetCurrentTime().Format("%Y%m%d hh:mm:ss"), 8);
	memcpy(mid.item.senm, "OS", 2);
	memcpy(mid.item.skey, "ERRORLOG", 8);
	sprintf(mid.item.valu, strErrMsg.Mid(0,500));
	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
}

void CMainFrame::ErrReport(CString eMsg)
{
	//trouble_shooting(eMsg);

	MessageBox(eMsg, "��������");
	return;
	CWnd* wnd = CWnd::FindWindow(NULL, m_reportCaption);
	if (wnd->GetSafeHwnd())
	{
		int	len = L_cds + eMsg.GetLength();
		char	bufx[512];

		ZeroMemory(bufx, sizeof(bufx));
		struct _exeCDSS* cds = (struct _exeCDSS *) bufx;

		cds->flag = 9/*ELOG*/;
		cds->len  = eMsg.GetLength();
		CopyMemory(&bufx[L_cds], eMsg, len);

		COPYDATASTRUCT cs;
		cs.cbData = len + L_cds;
		cs.dwData = 0;
		cs.lpData = bufx;

		::SendMessage(wnd->m_hWnd, WM_COPYDATA, 0, (LPARAM) &cs);
	}
	else
	{
		CString			aps, cmds, exes;
		STARTUPINFO		si;
		PROCESS_INFORMATION	pi;

		ZeroMemory(&si, sizeof(STARTUPINFO));
		ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

		si.cb          = sizeof(STARTUPINFO);
		si.dwFlags     = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_SHOW;

		cmds.Format(" /c %s /d %s /m %s /e \"%s\" /r \"%s\"", m_classN, Axis::devMode ? "s" : "x", m_activeMapN, eMsg, m_regkey);
		aps.Format("%s\\%s\\AXISReport.exe", Axis::home, RUNDIR);
		BOOL bRc = CreateProcess(
				aps,				// application name
				(char *)(const char*)cmds, // command line
				NULL,				// process attribute
				NULL,				// thread attribute
				FALSE,				// is inherit handle
				0,				// creation flags
				NULL,				// environment
				NULL,				// current directory
				&si,				// STARTUPINFO
				&pi);				// PROCESS_INFORMATION
		
		for (int ii = 0; ii < 100; ii++)
		{
			Sleep(100);
			wnd = CWnd::FindWindow(NULL, m_reportCaption);
			if (wnd->GetSafeHwnd())	break;
		}
	}
}

void CMainFrame::ShowUScreenMenu()
{
	if (!m_bar1)	return;

	CProfile profile(pkUserSetup);
	CMenuXP menu;

	menu.CreatePopupMenu();

	CMapStringToString ary;
	CString value, item;

	for (int i = 1; ; i++)
	{
		item = profile.GetString(szRoot, Format("%02d", i));
		if (item.IsEmpty())
			break;

		if (ary.Lookup(item, value))
			continue;

		ary.SetAt(item, "1");
		Trim(item);
		menu.AppendMenuX(MF_STRING | MF_ENABLED, ID_MENU_USER + i, item);
	}

	ary.RemoveAll();

	CPoint	pt = m_bar1->GetPos(2);
	menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, pt.x, pt.y, this);
}

CString CMainFrame::GetSkinName()
{
	CProfile profile(pkPalette);
	CString value(profile.GetString(GENERALSN, "Palette"));

	Trim(value);
	return value;
}

void CMainFrame::AppSwitch()
{
	if (m_bSDI)
		ChangeMDI();
	else	
		ChangeSDI();
}

void CMainFrame::convertSDI(int key, int vsN)
{
	m_mapHelper->TransformMDIChildToSingleWindow(key, vsN);
}

void CMainFrame::convertMDI(int key, int vsN)
{
	m_mapHelper->TransformSingleWindowToMDIChild(key, vsN);
}

void CMainFrame::addScreenList(CString mapN, int key, int vsN)
{
	add_history(mapN);
	addTool_history(mapN);
	m_bar2->add_Button(key, mapN, m_tMenu, vsN);
	m_activeMapN = mapN;
}

bool CMainFrame::FindSDIMap(CString mapName, int vsN)
{
	int		key;
	POSITION	pos;
	WINDOWPLACEMENT	pl;
	CSChild*	schild;

	if (vsN == -1)	vsN = m_vsN;
	for (pos = m_arSDI[vsN].GetStartPosition(); pos; )
	{
		m_arSDI[vsN].GetNextAssoc(pos, key, schild);
		if (getSMap(schild->m_mapN.Left(L_MAPN)) != getSMap(mapName.Left(L_MAPN)))
			continue;
		if (IsSelectMap(mapName))	loadDomino(schild->m_key,  mapName, true);
		schild->GetWindowPlacement(&pl);
		if (pl.showCmd & SW_SHOWMINIMIZED)
		{
			pl.showCmd = SW_RESTORE;
			schild->SetWindowPlacement(&pl);
		}
		else
		{
			CString	data = mapName.Mid(L_MAPN);
			if (!data.IsEmpty())
			{
				while (!data.IsEmpty())
				{
					CString	dat;
					int	po = data.Find('\n');
					if (po == -1)
					{
						dat = data;
						data.Empty();
					}
					else
					{
						dat = data.Left(po++);
						data = data.Mid(po);
					}

					m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
					(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)dat);
				}
			}
			schild->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		}
		return true;
	}
	return false;
}

void CMainFrame::loadToolStatus()
{
	CProfile profile(pkAxisTicker);
	ShowControlBar(m_tInfo1, profile.GetInt(szGeneral, "view1", 1), FALSE);
	ShowControlBar(m_tInfo2, profile.GetInt(szGeneral, "view2", 1), FALSE);
	if (m_tInfo3)
		ShowControlBar(m_tInfo3, profile.GetInt(szGeneral, "view3", 0), FALSE);

	ShowControlBar(m_bar1, profile.GetInt(szGeneral, "ttbar1", 1), FALSE);
	
	ShowControlBar(m_bar2, profile.GetInt(szGeneral, "ttbar2", 1), FALSE);

	ShowControlBar(m_bar3, profile.GetInt(szGeneral, "ttbar3", 1), FALSE);

	RelayoutTicker();
	ChangeLogo();
}

void CMainFrame::saveToolStatus()
{
	CProfile profile(pkAxisTicker);

	profile.Write(szGeneral, "view1", (int)(m_tInfo1->GetStyle() & WS_VISIBLE));
	profile.Write(szGeneral, "view2", (int)(m_tInfo2->GetStyle() & WS_VISIBLE));
	if (m_tInfo3)
		profile.Write(szGeneral, "view3", (int)(m_tInfo3->GetStyle() & WS_VISIBLE));
	profile.Write(szGeneral, "ttbar1", (int)(m_bar1->GetStyle() & WS_VISIBLE));
	profile.Write(szGeneral, "ttbar2", (int)(m_bar2->GetStyle() & WS_VISIBLE));
	profile.Write(szGeneral, "ttbar3", (int)(m_bar3->GetStyle() & WS_VISIBLE));

	RelayoutTicker();

	DrawFrame();
}

void CMainFrame::SetToolStatus()
{
	m_toolStatus = 0;
	if (m_bar0->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_JCONTROLBAR;
	if (m_bar1->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_MAINBAR;
	if (m_bar2->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_LISTBAR;
	if (m_bar3->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_HISTBAR;
	if (m_tInfo1->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_INFOBAR1;
	if (m_tInfo2->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_INFOBAR2;
	if (m_tInfo3 && (m_tInfo3->GetStyle() & WS_VISIBLE))	m_toolStatus |= TB_INFOBAR3;
	if (m_sdibar->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_SDIBAR;
	if (m_smain->GetStyle() & WS_VISIBLE)	m_toolStatus |= TB_SDIMAINBAR;
}

void CMainFrame::SetSDIHeight()
{
	m_SDIHEIGHT = SDIHEIGHT;

	int	width;
	if (m_switchpl.showCmd == SW_SHOWMAXIMIZED)
		width = GetSystemMetrics(SM_CXFULLSCREEN);
	else	
		width = m_switchpl.rcNormalPosition.right - m_switchpl.rcNormalPosition.left;

	SetWindowPos(&wndTop, 0, 0, width, m_SDIHEIGHT, SWP_NOZORDER);
}

void CMainFrame::SetSDIChangeHeight()
{
	if (!m_bSDI)	return;

	m_SDIHEIGHT = SDIHEIGHT;

	WINDOWPLACEMENT pl;
	GetWindowPlacement(&pl);
	int	width = pl.rcNormalPosition.right - pl.rcNormalPosition.left;
	SetWindowPos(&wndTop, 0, 0, width, m_SDIHEIGHT, SWP_NOMOVE|SWP_NOZORDER);
}

void CMainFrame::displayGuide(CString guide, CWnd* owner)
{
	if (m_bSDI)
		m_axGuide->SetGuide(guide, GetDesktopWindow());
	else	
		m_axGuide->SetGuide(guide, this);
}

void CMainFrame::displayMsgBox(CString caption, CString guide)
{
	//**::MessageBox(m_hWnd, guide, caption, MB_OK);
	Axis::MessageBox(this, guide, MB_OK);
}

void CMainFrame::SetHome()
{
	if (!m_bHome)
		return;

	if (m_bSDI)
	{
		if (m_smain)
		{
			m_smain->SetHome();
			m_smain->SetHome();
		}
	}
	else
	{
		if (m_bar1)
		{
			m_bar1->SetHome();
			m_bar1->SetHome();
		}
	}
}

void CMainFrame::appendUserToolMenu()
{
	char	wb[512];
	CString	tmps, str;
	
	CMenuXP*	mainM = (CMenuXP*) m_tMenu->GetPopupMenu(0);
	CMenuXP*	thisM = (CMenuXP*) mainM->GetSubMenu(USERTOOLMENU);	// fix menu position
	if (!thisM)	return;

	CProfile profile(pkUserProgram);

	int count = (int)thisM->GetMenuItemCount();
	for (int ii = 0; ii < count - 2; ii++)
	{
		MENUITEMINFO	info;
		memset(&info, 0, sizeof(MENUITEMINFO));
		info.cbSize = sizeof(MENUITEMINFO);
		info.fMask = MIIM_DATA | MIIM_TYPE;
		thisM->GetMenuItemInfo(thisM->GetMenuItemID(2), &info);
		
		thisM->RemoveMenu(2, MF_BYPOSITION);
		CMenuXPItem *pData = (CMenuXPItem *)info.dwItemData;
		if ((info.fType & MFT_OWNERDRAW) && pData && pData->IsMyData())
			delete pData;
	}


	DWORD dw = GetPrivateProfileSection(szUserTool, wb, ArraySize(wb), profile.GetFileName());

	if (dw > 0)
	{
		for (int ii = 0, idx = 0;; ii++)
		{
			str = &wb[idx];
			if (str.IsEmpty())	break;
			idx += str.GetLength()+1;
			int pos = str.Find('=');
			if (pos == -1)		continue;
			tmps = str.Left(pos);
			tmps.TrimLeft(); tmps.TrimRight();
			thisM->AppendMenuX(MF_STRING|MF_ENABLED, ID_MENU_USERTOOL+ii, tmps);
		}	
	}
}

void CMainFrame::runProgram(int index)
{
	char	buffer[1024*2];
	int	pos, idx = 0, count = 0;
	CString	file, str, tmpS, name;

	CProfile profile(pkUserProgram);
	strcpy(buffer, profile.GetSectionLF(szUserTool));
	DWORD dw = strlen(buffer);

	if (dw <= 0)
	{
		Axis::MessageBox(this, "���α׷��������� �����Դϴ�.", MB_ICONSTOP);
		return;
	}
	CString cstr = CString(buffer, dw);
	for (int ii = 0;; ii++)
	{
		//str = &buffer[idx];
		str = Parser(cstr,"\n");
		//str.TrimLeft(); str.TrimRight();
		
		
		if (str.IsEmpty())	break;
		idx += str.GetLength()+1;
		pos = str.Find('=');
		if (pos == -1)		continue;
		name = str.Left(pos++);
		if (count++ != index)	continue;
		tmpS = str.Mid(pos);
		/*
		int epos = tmpS.Find("\n");
		tmpS.Mid(1,epos);
		*/
		
		tmpS.TrimLeft(); tmpS.TrimRight();
		
		STARTUPINFO		si;
		PROCESS_INFORMATION	pi;
		char	apName[256];

		wsprintf(apName, "%s", tmpS);
		ZeroMemory(&si, sizeof(STARTUPINFO));
		ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

		si.cb = sizeof(STARTUPINFO);
		si.dwFlags = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_SHOW;

		CString	dir;
		tmpS.MakeUpper();
		ii = tmpS.ReverseFind('\\');
		dir = tmpS.Left(ii);
		
		BOOL bRc = CreateProcess(
				apName,			// application name
				NULL,			// command line
				NULL,			// process attribute
				NULL,			// thread attribute
				FALSE,			// is inherit handle
				0,			// creation flags
				NULL,			// environment
				dir,			// current directory
				&si,			// STARTUPINFO
				&pi);			// PROCESS_INFORMATION
		break;
	}
}

void CMainFrame::preload_screen()
{
	if (m_hMNews==NULL) {
		CString path, emsg;
		path.Format("%s\\%s\\%s", Axis::home, DEVDIR, "IBNEWSXX.DLL");
		m_hMNews = LoadLibraryA(path);
		if (!m_hMNews)
		{
			DWORD dwError = GetLastError();
			emsg.Format("GetLastError(%d)", dwError);
			MessageBox(path, emsg);
		}
	}

	if (m_hDRFN == NULL)
	{
		CString path, emsg;
		path.Format("%s\\%s\\%s", Axis::home, DEVDIR, "PCTRMNG.DLL");
		m_hDRFN = LoadLibraryA(path);
		if (!m_hDRFN)
		{
			DWORD dwError = GetLastError();
			emsg.Format("GetLastError(%d)", dwError);
			MessageBox(path, emsg);
		}
	}

	CChildFrame*	child = NULL;

#if 1
	// 2011.01.26 LOGIN��ü�� Push���ִ� ���� �ε��Ѵ�. (�ֹ��븮��/�������Ӿ��ڿ���üũ)
	child = load_hidescreen(MAPN_LOGINSET);
	m_arHide.Add(child);
#endif

	child = load_hidescreen(MAPN_REALTIMEJANGO);
	m_arHide.Add(child);
	// 20070604
//	child = load_hidescreen(MAPN_SISECATCH1);
//	m_arHide.Add(child);

	int vtype = 0, size = 0, key = KEY_CODE;
	//**int ret, nCx, nCy;
	BOOL	rc = FALSE;
	CString mapname;

//	��������� �ڵ���
	/**
	m_category = m_bar0->GetCategoryWnd();
	mapname = _T("IBCBCODE");
	m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
				(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
	m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
			(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_category, vtype, key);
	m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);
	**/

//	��������

	//** temp
	//***m_accTool = FALSE;
	/**
	if (m_accTool)
	{
		key = KEY_ACCTOOL;
		mapname = _T(MAPN_ACCTTOOLBAR);
		m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
					(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
		m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_accTool, vtype, key);
		m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);

		int ret = 0;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
			(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, -1));

		CSize	frameGap;
		frameGap.cx  = GetSystemMetrics(SM_CXFRAME);
		frameGap.cx += GetSystemMetrics(SM_CXBORDER) * 2;

		frameGap.cy  = GetSystemMetrics(SM_CYFRAME);
		frameGap.cy += GetSystemMetrics(SM_CYBORDER) * 2;
		frameGap.cy += GetSystemMetrics(SM_CYCAPTION);

		int nCx = frameGap.cx + LOWORD(size);
		int nCy = frameGap.cy + HIWORD(size);
		int	x = GetSystemMetrics(SM_CXSCREEN);
		m_accTool->SetWindowPos(NULL, x - nCx, 0, nCx, nCy, SWP_NOZORDER|SWP_HIDEWINDOW);
	}
	**/
}

CChildFrame* CMainFrame::load_hidescreen(CString mapname)
{
	int vtype = 0, vwTYPE = 0, size = 0, vwKIND, key = 128;
	m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
				(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
	if (vtype == vtypeERR)	return NULL;
	vwTYPE = vtypeMSK & vtype;
	vwKIND = (vwTYPE == vtypeSCR) ? 2 : 1;
	
	CView	    *view  = GetNewView(vwKIND);
	CChildFrame *child = (CChildFrame *) view->GetParent();

	m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
				(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)view, vtype, key);

	int	nCx, nCy;
	CSize	frameGap = GetFrameGap();

	if (vwTYPE != vtypeWND)	frameGap.cy += XCAP_HEIGHT;
	if (vwTYPE == vtypeSCR)
	{	
		((CAxScrollView *)view)->SetInfo(key);//m_key = key;
		((CAxScrollView *)view)->SetSizeView(LOWORD(size), HIWORD(size));
	}
	else	((CAxisView *)view)->SetInfo(key);

	child->m_key	= key;
	child->m_vwTYPE = vtype;
	child->SetMapName(axiscall, mapname);
	nCx = LOWORD(size) + frameGap.cx;
	nCy = HIWORD(size) + frameGap.cy;
	child->SetSize(nCx, nCy);

	BOOL	rc = FALSE;
	m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false/*true*/);
	if (!rc)
	{
		child->PostMessage(WM_CLOSE);
		return NULL;
	}

	nCx = child->GetSize().cx;
	nCy = child->GetSize().cy;

	set_Trigger(key, 99);
	child->SetMisc(WM_AXIS, this, axiscall, m_fontSize, vwTYPE == vtypeWND ? false : true);
	child->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_HIDEWINDOW);
	child->ModifyStyle(WS_TABSTOP, NULL);

	return child;
}

BOOL CMainFrame::TransKey(int keyboard)
{
	if (!m_runAxis)	return FALSE;
	if (m_activeKey < WK_NORM || m_activeKey > WK_NONE)
		return FALSE;

	if (m_bar1->IsInputFocus())	return FALSE;
	if (m_smain->IsInputFocus())	return FALSE;

	CChildFrame*	child;
	CSChild*	schild;
	BOOL		bFocus = FALSE;

	if (m_arMDI[m_vsN].Lookup(m_activeKey, child))
		bFocus = child->m_xcaption.IsActive();
	else if (m_arSDI[m_vsN].Lookup(m_activeKey, schild))
		bFocus = schild->m_xcaption.IsActive();
	else	return FALSE;

	if (!bFocus)	return FALSE;
	BOOL	value = 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_BOOL, (void *)&value,
				(BYTE *)(VTS_I4 VTS_I4), MAKELONG(keyEV, m_activeKey), keyboard);
	return value;
}

void CMainFrame::displayChild(int vsN, bool show/*=true*/, bool bSDI/*=false*/)
{
	int			key;
	CArray	<int, int>	ary;
	CChildFrame*		child = NULL;
	CSChild*		schild = NULL;
	UINT			nFlags;

	if (show) nFlags = SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER;
	else	nFlags = SWP_HIDEWINDOW|SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER;

	if (bSDI)
	{
		keyArray(ary, vsN, true);
		for (int ii = 0; ii < ary.GetSize(); ii++)
		{
			key = ary.GetAt(ii);
			if (!m_arSDI[vsN].Lookup(key, schild))
				continue;
			//if(schild->m_mapN == "IB820850") continue;
			schild->SetWindowPos(&wndTop, 0, 0, 0, 0, nFlags);
		}
	}
	else
	{
		keyArray(ary, vsN);
		for (int ii = 0; ii < ary.GetSize(); ii++)
		{
			key = ary.GetAt(ii);
			
			
			if (!m_arMDI[vsN].Lookup(key, child))
				continue;
			//if(child->m_mapN == "IB820850") continue;
			/*
			if(child->m_mapN == "IB820850") child->SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_HIDEWINDOW|SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER);
			else 
			*/	
			child->SetWindowPos(&wndTop, 0, 0, 0, 0, nFlags);
		}
	}

	ary.RemoveAll();
}

void CMainFrame::keyArray(CArray <int, int> &ary, int vsN, bool bSDI/*=false*/)
{
	CArray	<int, int>	*aryZ;

	if (bSDI)
		aryZ = &m_sdiZORDER[vsN];
	else	aryZ = &m_hooklist[vsN];

	for (int ii = aryZ->GetSize() - 1; 0 <= ii; ii--)
	{
		int key = aryZ->GetAt(ii);
		ary.Add(key);
	}
}

void CMainFrame::LinkOPEN(int dat, CString mapN)
{
	int	key   = HIWORD(dat);
	int	group = LOWORD(dat);
	CString	data, mapname;

	getScreenData(key, data, FALSE);
	data.Replace(";", "\n");
	mapname.Format("%s%s", mapN, data);
	m_mapHelper->ChangeChild(mapname, group);
}

void CMainFrame::parseAry(CString data, CStringArray& ary, CString separate)
{
	CString	value;
	while (!data.IsEmpty())
	{
		int pos = data.Find(',');
		if (pos == -1)
		{
			data.TrimLeft();
			data.TrimRight();
			ary.Add(data);
			break;
		}
		value = data.Left(pos++);
		data = data.Mid(pos);
		value.TrimLeft();
		value.TrimRight();
		ary.Add(value);
	}
}

CWnd* CMainFrame::refleshMap(int key)
{
	int		size, vwTYPE, nCx, nCy;
	BOOL		rc = FALSE;
	CSize		frameGap;
	CChildFrame*	child;
	CSChild*	schild;
	CString		mapname;

	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		if (!m_arSDI[m_vsN].Lookup(key, schild))	return NULL;

		mapname = schild->m_mapN.Left(L_MAPN);
		if (ExceptionProcess(mapname))	return NULL;

		m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vwTYPE,
				(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
		
		frameGap = GetFrameGap();
		if ((vwTYPE& vtypeMSK) != vtypeWND)	frameGap.cy += XCAP_HEIGHT;

		nCx = LOWORD(size) + frameGap.cx-4;
		nCy = HIWORD(size) + frameGap.cy-6;
		schild->SetSize(nCx, nCy);

		m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
				(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);
		if (!rc)	return NULL;

		nCx = schild->GetSize().cx;
		nCy = schild->GetSize().cy;
		
		schild->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_NOZORDER);
		return schild;
	}
	
	mapname = child->m_mapN.Left(L_MAPN);
	if (ExceptionProcess(mapname))	return NULL;
	
	m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vwTYPE,
				(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);

	frameGap = GetFrameGap();
	if ((vwTYPE& vtypeMSK) != vtypeWND)	frameGap.cy += XCAP_HEIGHT;

	nCx = LOWORD(size) + frameGap.cx-4;
	nCy = HIWORD(size) + frameGap.cy-6;
	//CString tmp; tmp.Format("nCx: %d, nCy: %d\n", nCx, nCy);
	//AfxMessageBox(tmp);
	//TRACE(tmp);
	child->SetSize(nCx, nCy);

	m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);
	if (!rc)	return NULL;

	nCx = child->GetSize().cx;
	nCy = child->GetSize().cy;
	
	child->SetWindowPos(NULL, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_NOZORDER);
	
	return child;
}

void CMainFrame::ChangeMDI()
{
	m_bitmapBtn->ShowWindow(SW_SHOW);
	int			key;
	CArray	<int, int>	ary;
	
	m_bSDI	  = false;
	m_appMode = MODE_MDI;

	//ModifyStyle(0, WS_CAPTION);
	ShowControlBar(m_tMenu, TRUE, FALSE);
	ShowControlBar(m_bar1, TRUE, FALSE);
	ChangeLogo();

	if (m_toolStatus & TB_LISTBAR)
		ShowControlBar(m_bar2, FALSE, FALSE);

#if 0
	DWORD dwStyle = m_axis->GetProfileInt(INFORMATION, "listbar_pos", CBRS_ALIGN_BOTTOM);//m_bar2->GetBarStyle();
#else
	DWORD dwStyle = m_axis->GetProfileInt(INFORMATION, "listbar_pos", 0);
	if (dwStyle==0)
	{
		CProfile p(pkUserSetup);
		dwStyle = (DWORD)p.GetDouble(INFORMATION, "listbar_pos", CBRS_ALIGN_BOTTOM);
	}
	else
	{
		m_axis->WriteProfileInt(INFORMATION, "listbar_pos", 0);
		CProfile(pkUserSetup).Write(INFORMATION, "listbar_pos", (double)dwStyle);
	}
#endif

	m_bar2->EnableDocking(CBRS_ALIGN_BOTTOM|CBRS_ALIGN_TOP);
	m_bar2->SetBarStyle(dwStyle);
	m_bar2->SetMDIMode(TRUE);
	if (m_toolStatus & TB_LISTBAR)
		ShowControlBar(m_bar2, TRUE, FALSE);

	m_bar3->EnableDocking(CBRS_ALIGN_BOTTOM|CBRS_ALIGN_TOP);
	m_bar3->SetBarStyle(dwStyle);
	m_bar3->SetMDIMode(TRUE);
	if (m_toolStatus & TB_HISTBAR)
		ShowControlBar(m_bar3, TRUE, FALSE);

	m_bar0->EnableDocking(CBRS_ALIGN_LEFT);
	DockControlBar(m_bar0, AFX_IDW_DOCKBAR_LEFT);
	
	ShowControlBar(m_sdibar, FALSE, FALSE);
	ShowControlBar(m_smain, FALSE, FALSE);

	SetWindowPlacement(&m_switchpl);
	SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		keyArray(ary, vsN, true);
		for (int ii = 0; ii < ary.GetSize(); ii++)
		{
			key = ary.GetAt(ii);
			convertMDI(key, vsN);
		}
		ary.RemoveAll();
	}
	TrayCmd(TRAY_HIDEICON);
	m_bar1->Refresh();
	ChangeLogo();
}

void CMainFrame::ChangeSDI(bool hide)
{
	m_bitmapBtn->ShowWindow(SW_HIDE);
	int			key;
	CArray	<int, int>	ary;
	CSChild*		schild;
	
	m_bSDI	  = true;
	m_appMode = hide ? MODE_TRAY : MODE_SDI;

	GetWindowPlacement(&m_switchpl);

	ShowWindow(SW_HIDE);
	if (m_switchpl.showCmd == SW_SHOWMAXIMIZED)
	{
		SendMessage(WM_SYSCOMMAND, SC_RESTORE);
		ShowWindow(SW_HIDE);
	}

	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		keyArray(ary, vsN);
		for (int ii = 0; ii < ary.GetSize(); ii++)
		{
			key = ary.GetAt(ii);
			convertSDI(key, vsN);
		}
		ary.RemoveAll();
	}

	for (vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		for (POSITION pos = m_arSDI[vsN].GetStartPosition(); pos; )
		{
			m_arSDI[vsN].GetNextAssoc(pos, key, schild);
			schild->m_xcaption.SetSDI();
		}
	}

	SetToolStatus();

	ModifyStyle(WS_CAPTION, 0);
	ShowControlBar(m_tMenu, FALSE, FALSE);
	ShowControlBar(m_bar0, FALSE, FALSE);
	ShowControlBar(m_bar1, FALSE, FALSE);
	
	ShowControlBar(m_bar2, FALSE, FALSE);
	ShowControlBar(m_bar3, FALSE, FALSE);
	ShowControlBar(m_sdibar, TRUE, FALSE);
	ShowControlBar(m_smain, TRUE, FALSE);


	SetSDIChangeHeight();
	SetSDIHeight();
			
	WINDOWPLACEMENT	pl;
	GetWindowPlacement(&pl);

	CPoint	sdiPt = CPoint(pl.rcNormalPosition.left, m_switchpl.rcNormalPosition.top + m_SDIHEIGHT);
	FloatControlBar(m_bar0, sdiPt);

	m_bar0->EnableDocking(0);

	if (!hide)	
		ShowWindow(SW_SHOW);

	TrayCmd(TRAY_HIDEICON);
	m_smain->Refresh();
	ChangeLogo();
}

void CMainFrame::ChangeTRAY()
{
	PostMessage(WM_CANCELMODE);
	switch (m_appMode)
	{
	case MODE_MDI:	ChangeSDI(true);	break;
	case MODE_SDI:	ShowWindow(SW_HIDE);	break;
	default:	break;
	}

	m_appMode = MODE_TRAY;
	TrayCmd(TRAY_SHOWICON);
}

void CMainFrame::TrayCmd(int cmd)
{
	m_tray.cbSize	= sizeof(NOTIFYICONDATA);
	m_tray.hWnd	= GetSafeHwnd();
	m_tray.uID	= IDI_CLIENT;
	m_tray.hIcon	= m_resourceHelper->GetIcon();
	m_tray.uCallbackMessage = WM_TRAYEVENT;

	switch (cmd)
	{
	case TRAY_SHOWICON:
		m_tray.uFlags	= NIF_MESSAGE | NIF_ICON | NIF_TIP;
		strcpy (m_tray.szTip, m_regkey);

		Shell_NotifyIcon(NIM_ADD, &m_tray);
		break;
	case TRAY_HIDEICON:
		m_tray.uFlags = 0;
		Shell_NotifyIcon(NIM_DELETE, &m_tray);
		break;
	default:return;
	}
}

void CMainFrame::StopLoss()
{
	UnderConstruction();
	return;

	bool onlysise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0) ? TRUE : FALSE;
	if (onlysise)	return;
	if (!m_stoploss)
	{
		CStopWarn	dlg;
		if (dlg.DoModal() != IDOK)	return;
		m_stoploss = new CStoploss(m_bar2);
		if (!m_stoploss->Create(IDD_STOPLOSS))
		{
			delete m_stoploss;
			m_stoploss = NULL;
		}
		else
		{
			BOOL	rc = 0;
			int	vtype = 0, size = 0, ret, key = KEY_STOPLOSS;
			CString mapname = MAPN_STOPLOSS;

			m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
						(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
			m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_stoploss, vtype, key);
			m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);

			ret = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
				(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, 0));

			CSize	frameGap;
			frameGap.cx  = GetSystemMetrics(SM_CXFRAME);
			frameGap.cx += GetSystemMetrics(SM_CXBORDER) * 2;

			frameGap.cy  = GetSystemMetrics(SM_CYFRAME);
			frameGap.cy += GetSystemMetrics(SM_CYBORDER) * 2;
			frameGap.cy += GetSystemMetrics(SM_CYCAPTION);

			int nCx = frameGap.cx + LOWORD(size);
			int nCy = frameGap.cy + HIWORD(size);

			m_stoploss->SetWindowPos(&wndTopMost, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_NOZORDER|SWP_HIDEWINDOW);
		}
	}

	CRect	mRc, wRc;

	mRc = GetWndRect();
	m_stoploss->GetWindowRect(wRc);

	int x = mRc.right - wRc.Width() - GetSystemMetrics(SM_CXFIXEDFRAME);
	int y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
	if (x < 0)	x = 0;
	if (y < 0)	y = 0;
	if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
		x = GetSystemMetrics(SM_CXSCREEN) - wRc.Width();
	if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
		y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();

	if (m_stoploss->GetStyle() & WS_VISIBLE)
		m_stoploss->ShowWindow(SW_HIDE);
	else	m_stoploss->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);
}

void CMainFrame::drawTitle(CDC* pDC)
{
	if (!m_resourceHelper) 
		return;
	
	CDC		memDC;
 	CRect		cRc, iRc, tRc, clipRc;
	int		round;

	cRc = GetCapRect();
	tRc.CopyRect(&cRc);

	const int leftCaptionShapeWidth = 100;

	round		= cRc.Height()/2;

	if (memDC.CreateCompatibleDC(pDC))
	{
		CBitmap	bitmap;
		bitmap.CreateCompatibleBitmap(pDC, cRc.Width(), cRc.Height());
		CBitmap* pbmp = (CBitmap *) memDC.SelectObject(&bitmap);

		if (!DrawCaption(&memDC, cRc))
		{
			COLORREF	sColor, eColor;
		
			CAxDrawHelper painter(&memDC);
			if (m_activeCap)
			{
				sColor = RGB(8, 24, 47);
				eColor = RGB(171, 180, 189);
				painter.DrawGradient(CRect(0, 0, cRc.Width(), cRc.Height()), sColor, eColor, true);
			}
			else
			{
				sColor = RGB(93, 102, 114);
				eColor = RGB(163, 185, 217);
				painter.DrawGradient(CRect(0, 0, cRc.Width(), cRc.Height()), sColor, eColor, true);
			}
		}
// draw icon
		iRc = m_arRc.GetAt(MIDX_ICON);
		if (iRc.IsRectEmpty())
		{
			SetRegion();
			iRc = m_arRc.GetAt(MIDX_ICON);
		}
		//**DrawBitmapByMask(&memDC, MIDX_ICON, iRc);
		//DrawIconEx (memDC.m_hDC, iRc.left, iRc.top, m_resourceHelper->m_hIcon,
		//		iRc.Width(), iRc.Height(), 0, NULL, DI_NORMAL|DI_COMPAT);

// draw system button
		iRc = m_arRc.GetAt(MIDX_CLOSE);	
		DrawBitmapByMask(&memDC, MIDX_CLOSE, iRc);

		if (IsZoomed())
		{
			iRc = m_arRc.GetAt(MIDX_RESTORE);
			DrawBitmapByMask(&memDC, MIDX_RESTORE, iRc);
		}
		else
		{
			iRc = m_arRc.GetAt(MIDX_MAX);
			DrawBitmapByMask(&memDC, MIDX_MAX, iRc);
		}
		iRc = m_arRc.GetAt(MIDX_MIN);	
		DrawBitmapByMask(&memDC, MIDX_MIN, iRc);
// draw user button

		for (int i = MIDX_HOME; i <= MIDX_VS6; i++)
		{
			DrawBitmapByMask(&memDC, i, m_arRc.GetAt(i));
		}
		iRc = m_arRc.GetAt(MIDX_HOME);

// draw text
		CFont*	font = memDC.SelectObject(m_resourceHelper->GetFont());

		if (m_activeCap)
			memDC.SetTextColor(RGB(255, 255, 255));
		else	
			memDC.SetTextColor(RGB(192, 192, 192));
	
		//GetWindowText(title);
		memDC.SetBkMode(TRANSPARENT);

		CString callCenter = (m_rndkey%2) ? CALLCENTER1 : CALLCENTER2;

		CSize sz = memDC.GetTextExtent(m_bOnlySise ? "��ȸ,��ȸ������ "+callCenter : callCenter);
		iRc.OffsetRect(-sz.cx - 20, 0);
		iRc.right = iRc.left + sz.cx;
		memDC.DrawText(m_bOnlySise ? "��ȸ,��ȸ������ "+callCenter : callCenter, iRc, DT_SINGLELINE | DT_VCENTER | DT_LEFT);
	
		CString	title = m_saveTitle; //**m_titleS ;
		tRc.top	  = 0;
		tRc.left  = m_arRc.GetAt(MIDX_ICON).right + GAP;
		tRc.right = m_arRc.GetAt(MIDX_HOME).left - GAP;
		tRc.bottom= tRc.top + cRc.Height();

		/**
		if (m_dev) // paint dev info
		{
			tRc.OffsetRect(leftCaptionShapeWidth, 0);
			memDC.DrawText(m_titleS, tRc, DT_VCENTER|DT_LEFT|DT_SINGLELINE|DT_END_ELLIPSIS);
		}
		**/

		CString caption = "IBK hot Trading";
		if (!Axis::isCustomer)	caption += "(������)";
		if (Axis::devMode)     caption += " - ���߿�";
		memDC.TextOut(100, 4, caption);

		memDC.SelectObject(font);

		pDC->BitBlt(cRc.left, cRc.top, cRc.Width(), cRc.Height(), &memDC, 0, 0, SRCCOPY);

		memDC.SelectObject(pbmp);
		memDC.DeleteDC();
		bitmap.DeleteObject();
	}
}

CRect CMainFrame::GetCapRect()
{
	CRect rc;
	GetWindowRect(&rc);
	rc -= rc.TopLeft();
	rc.top = 1;
	//if (Axis::isVista) rc.top = 0;
	/*
	if (Axis::isVista)
	{
		rc.top = VistaFrame;
		rc.left = VistaFrame;
		if (VistaFrame == 1)
			rc.right -= (VistaFrame);
		else
			rc.right -= (VistaFrame+2);
	}
	*/

	rc.bottom = rc.top + SZ_MAINCAPTION;

	return rc;
}

void CMainFrame::SetRegion()
{
	const int gapVS = -3;
	
	CRect	cRc, iRc, iRc2;
	CPoint	pt;
	BITMAP	bm;
	
	cRc = GetCapRect();
	CBitmap* bmp = Axis::GetBitmap(CBTN_CLOSE);
	if (!bmp || !bmp->m_hObject)
		return;
	
	bmp->GetBitmap(&bm);

	pt = CPoint(cRc.right - bm.bmWidth/2, (cRc.Height() - bm.bmHeight)/2);
	iRc.SetRect(pt.x, pt.y, pt.x + bm.bmWidth/2, pt.y + bm.bmHeight);
	iRc.OffsetRect(-GAP*3, 0);

	for (int ii = MIDX_CLOSE; ii > MIDX_ICON; ii--)
	{
		switch (ii)
		{
		case MIDX_HOME:
			m_arRc.SetAt(MIDX_HOME, iRc);
			iRc.OffsetRect(-1, 0);		break;
		case MIDX_FULL:
			m_arRc.SetAt(MIDX_FULL, iRc);
			iRc.OffsetRect(-1, 0);		break;
		case MIDX_DUAL:
			iRc.InflateRect(1, 0, -1, 1);
			m_arRc.SetAt(MIDX_DUAL, iRc);
			iRc.OffsetRect(-1, 0);		break;

		case MIDX_VS1:
			m_arRc.SetAt(MIDX_VS1, iRc);
			iRc.OffsetRect(-GAP*2, 0);	break;
		case MIDX_VS2:
			m_arRc.SetAt(MIDX_VS2, iRc);
			iRc.OffsetRect(gapVS, 0);		break;
		case MIDX_VS3:
			m_arRc.SetAt(MIDX_VS3, iRc);
			iRc.OffsetRect(gapVS, 0);		break;
		case MIDX_VS4:
			m_arRc.SetAt(MIDX_VS4, iRc);
			iRc.OffsetRect(gapVS, 0);		break;
		case MIDX_VS5:
			m_arRc.SetAt(MIDX_VS5, iRc);
			iRc.OffsetRect(gapVS, 0);		break;
		case MIDX_VS6:
			m_arRc.SetAt(MIDX_VS6, iRc);
			iRc.OffsetRect(gapVS, 0);		break;

		case MIDX_MIN:
			m_arRc.SetAt(MIDX_MIN, iRc);
			iRc.OffsetRect(-GAP*2 + 1, 0);	break;
		case MIDX_MAX:
			m_arRc.SetAt(MIDX_RESTORE, iRc);
			m_arRc.SetAt(MIDX_MAX, iRc);
			iRc.OffsetRect(-1, 0);		
			break;
		case MIDX_CLOSE:
			m_arRc.SetAt(MIDX_CLOSE, iRc);
			iRc.OffsetRect(-1, 0);		
			break;
		default:		
			continue;
		}

		switch (ii)
		{
		case MIDX_HOME:	case MIDX_FULL:	case MIDX_DUAL:
			iRc.OffsetRect(-iRc.Width(), 0);	
			break;
		default:
			if (ii >= MIDX_VS1 && ii <= MIDX_VS6)
			{
				iRc.OffsetRect(-14, 0);
			}
			else
			{
				iRc.OffsetRect(-bm.bmWidth/2, 0);	
			}
			break;
		}
	}

	int	cx = GetSystemMetrics(SM_CXSMICON); 
	int	cy = GetSystemMetrics(SM_CYSMICON);

	pt = CPoint((cRc.Height() - cy)/2 + GAP, (cRc.Height() - cy)/2);
	iRc.SetRect(pt.x, pt.y, pt.x + cx, pt.y + cy);
	
	m_arRc.SetAt(MIDX_ICON, iRc);
}

int CMainFrame::DrawBitmapByMask(CDC* pDC, int index, CRect bRC, bool bDown, int maskcolor)
{
	if (bRC.IsRectEmpty())	return 0;

	BITMAP		bm;
	CBitmap*	bitmap;
	int		bx, by, sx;

	bx = bRC.Width();
	by = bRC.Height();
	sx = bDown ? bx: 0;

	class BitmapBranch
	{
	public:
		BitmapBranch(CBitmap** bmp, const char* skinBmpName, int index, int& sx, BOOL bDown, CRect& rc, BOOL active)
		{
			if (active)
				*bmp = Axis::GetBitmap(skinBmpName);
			else
				*bmp = Axis::GetBitmap(Format("XN_%s", skinBmpName));
			if (!*bmp)
				return;
			BITMAP bm;
			(*bmp)->GetBitmap(&bm);
			sx = bm.bmWidth / 3; 
			if (bDown)
				sx += bm.bmWidth / 3 * 2;

			rc.top += 2;
		}
	};

	switch (index)
	{
	case MIDX_CLOSE:
		if (m_activeCap)
			bitmap = Axis::GetBitmap(CBTN_CLOSE);
		else
			bitmap = Axis::GetBitmap(Format("XN_%s", CBTN_CLOSE));
		if (!bitmap)
			return 0;
		bitmap->GetBitmap(&bm);
		break;
	case MIDX_MAX:
		if (m_activeCap)
			bitmap = Axis::GetBitmap(CBTN_MAX);
		else
			bitmap = Axis::GetBitmap(Format("XN_%s", CBTN_MAX));
		if (!bitmap)
			return  0;
		bitmap->GetBitmap(&bm);
		break;
	case MIDX_MIN:
		if (m_activeCap)
			bitmap = Axis::GetBitmap(CBTN_MIN);
		else
			bitmap = Axis::GetBitmap(Format("XN_%s", CBTN_MIN));
		if (!bitmap)
			return 0;
		bitmap->GetBitmap(&bm);
		break;
	case MIDX_RESTORE:
		if (m_activeCap)
			bitmap = Axis::GetBitmap(CBTN_RESTORE);
		else
			bitmap = Axis::GetBitmap(Format("XN_%s", CBTN_RESTORE));
		if (!bitmap)
			return 0;
		bitmap->GetBitmap(&bm);
		break;
	case MIDX_VS6:case MIDX_VS5: case MIDX_VS4:
	case MIDX_VS3:case MIDX_VS2: case MIDX_VS1:
		{
			int	nIndex = index - MIDX_VS1;

			bitmap = Axis::GetBitmap(IDB_VSCREEN);
			if (!bitmap)
				return 0;
			bitmap->GetBitmap(&bm);

			int buttonWidth = bm.bmWidth / 12;

			nIndex = (nIndex * 2) + ((nIndex == m_vsN) ? 1: 0);

			sx = (nIndex * buttonWidth);
			bx = buttonWidth;
			by = bm.bmHeight;

			//bRC.top += 1;
		}
		break;
	case MIDX_DUAL:
		BitmapBranch(&bitmap, "DUEL", index, sx, bDown, bRC, m_activeCap);
		break;
	case MIDX_FULL:
		BitmapBranch(&bitmap, "FULL", index, sx, bDown, bRC, m_activeCap);
		break;
	case MIDX_HOME:
		BitmapBranch(&bitmap, "HOME", index, sx, bDown, bRC, m_activeCap);
		break;
	case MIDX_ICON:
		bitmap = m_resourceHelper->GetSiteIcon();
		break;
	default:
		return 0;
	}

	if (!bitmap)
		return 0;

	CAxDrawHelper painter(pDC);
	/*
	if (Axis::isVista)
	{
		bRC.left    += VistaFrame;
		bRC.right   += VistaFrame;
		bRC.top     += VistaFrame;
		bRC.bottom  += VistaFrame;
	}
	*/
	painter.DrawIndexedBitmap(bRC.left, bRC.top, bitmap, maskcolor, bx, by, sx);

	return bx;
}

int CMainFrame::GetSelectItem(CPoint pt)
{
	CRect	bRc, wRc;

	GetWindowRect(wRc);
	
	pt.x -= wRc.left;// + XGAP;
	pt.y -= wRc.top ;// + YGAP;

	CWindowDC	dc(this);

	
	for (int ii = 0; ii < m_arRc.GetSize(); ii++)
	{
		bRc = m_arRc.GetAt(ii);
		/*
		if (Axis::isVista)
		{
			bRc.left    += VistaFrame;
			bRc.right   += VistaFrame;
			bRc.top     += VistaFrame;
			bRc.bottom  += VistaFrame;
		}
		*/
		//***bRc.OffsetRect(XGAP, YGAP);
		if (!bRc.PtInRect(pt))
			continue;

		if (ii == MIDX_MAX && IsZoomed())
			return MIDX_RESTORE;
		else	return ii;
	}
	return -1;
}

CString CMainFrame::GetConnectIP(CString dns)
{
	CString	file;
	char	glbIP[32];

	file.Format("%s\\exe\\EnMsgOem.dll", Axis::home);
	HMODULE hMod = LoadLibrary(file);
	if (hMod)
	{
		typedef struct hostent * (*fnGetHostByName) (const char * name);
		fnGetHostByName egethostbyname = (fnGetHostByName) GetProcAddress(hMod, "egethostbyname");
		struct hostent *hp = egethostbyname(dns);
		if (hp)
			sprintf(glbIP, "%s", inet_ntoa(*((struct in_addr*)hp->h_addr)));
		else	sprintf(glbIP, dns);
		FreeLibrary(hMod);

		return glbIP;
	}
	return dns;
}

void CMainFrame::RunHelpCom()
{
	/**
	if (m_siteID != 'D')
	{
		char	buf[512];
		CString	file;
		file.Format("%s\\tab\\axis.ini", Axis::home);
		DWORD dw = GetPrivateProfileString("WebLinkHN", "remote", "", buf, sizeof(buf), file);
		if (dw > 0)	ShellExecute(NULL, _T("open"), buf, NULL,NULL, SW_SHOWNORMAL);
		return;
	}
	**/
	
	CHelpOK	dlg;
	if (dlg.DoModal() != IDOK)
		return;
	
	CString	aps, cmds, exes;
	STARTUPINFO		si;
	PROCESS_INFORMATION	pi;

	ZeroMemory(&si, sizeof(STARTUPINFO));
	ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

	si.cb          = sizeof(STARTUPINFO);
	si.dwFlags     = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_SHOW;

	//cmds.Format("%s\\exe\\HelpCom.exe type:2/aip:210.107.66.228/aport:6090/eip:210.107.66.228/eport:6080/t1:%s",
	//			Axis::home, Axis::user);
	//cmds.Format("%s\\exe\\HCUser.exe 210.107.66.228 6080 %s 123-1234 none 0000", Axis::home, Axis::user);
	//aps.Format("%s\\exe\\HCUser.exe", Axis::home);
	cmds.Format("%s\\exe\\AHCUser.exe 210.107.66.228 6080 %s 123-1234 none 0000 0 none", Axis::home, Axis::userID);
	aps.Format("%s\\exe\\AHCUser.exe", Axis::home);
	

	BOOL bRc = CreateProcess(
			NULL/*aps*/,				// application name
			(char*)(const char*)cmds,	// command line
			NULL,						// process attribute
			NULL,						// thread attribute
			FALSE,						// is inherit handle
			0,							// creation flags
			NULL,						// environment
			NULL,						// current directory
			&si,						// STARTUPINFO
			&pi);						// PROCESS_INFORMATION
}

void CMainFrame::fitDual()
{
	int moniterN = GetSystemMetrics(SM_CMONITORS);

	if (moniterN <= 1)
	{
		Axis::MessageBox(this, "������Ͱ� �ƴմϴ�.", MB_ICONINFORMATION);
		return;
	}
	

	WINDOWPLACEMENT	pl;
	

	GetWindowPlacement(&pl);
	g_monRc.SetRectEmpty();
	EnumDisplayMonitors(NULL, NULL, MyInfoEnumProc, 0);
	
	if (m_bfitdual) m_bfitdual = false;
	else m_bfitdual = true;
	
	if (m_bfitdual) 
	{
		GetWindowPlacement(&m_predual);
		pl.showCmd = SW_RESTORE;
		pl.rcNormalPosition.left   = g_monRc.left;
		pl.rcNormalPosition.top    = g_monRc.top;
		pl.rcNormalPosition.right  = g_monRc.right;
		pl.rcNormalPosition.bottom = GetSystemMetrics(SM_CYMAXIMIZED) -5;//g_monRc.bottom;
		SetWindowPlacement(&pl);
	}
	else
	{
		SetWindowPlacement(&m_predual);
	}
	/*
	if (pl.showCmd & SW_SHOWMAXIMIZED)
	{
		pl.showCmd = SW_RESTORE;
		pl.rcNormalPosition.left   = g_monRc.left;
		pl.rcNormalPosition.top    = g_monRc.top;
		pl.rcNormalPosition.right  = g_monRc.right;
		pl.rcNormalPosition.bottom = g_monRc.bottom;
		SetWindowPlacement(&pl);

	}
	else	
		SetWindowPos(NULL, g_monRc.left, g_monRc.top, g_monRc.Width(), g_monRc.Height(), SWP_NOZORDER|SWP_SHOWWINDOW);
	*/
	
}

//���� �ؿ� ����
// const int indexKey[] = {
// 	1, 2, 3, 4, 5, 6, 9, 10, 13, 14, 15, 16, 17, 18, 19, 20,
// 		21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33 
// };
//���ο� �ؿ� ����
const int indexKey[] = {
	1, 2, 3, 4, 5, 6, 9, 10, 13, 14, 15, 16, 17, 18, 19, 20,
		21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49
};

const int indexKeyCount = ArraySize(indexKey);

int CMainFrame::GetTicKey(int index)
{
	if (index >= 0 && index < indexKeyCount)
		return indexKey[index];
	else
		return 0;

}

int CMainFrame::ConvertIndexKey(int index)
{
	for (int i = 0; i < indexKeyCount; i++)
	{
		if (indexKey[i] == index)
			return i;
	}

	return 0;
}

void CMainFrame::convertIndex()
{
	CString		section, keys, value;
	CStringArray	ary;

	CProfile profile(pkAxisTicker);

	for (int ii = 0; ii < TICKBAR_CNT; ii++)
	{
		for (int jj = 0; jj < SPLIT_CNT; jj++)
		{
			section.Format("BAR_INFO_%d%d", ii, jj);
			int tKIND = profile.GetInt(section, "INDEXK", TKIND_INDEX);
			if (tKIND != TKIND_INDEX)	continue;

			keys = _T("00");
			value = profile.GetString(section, keys);
			if (value.IsEmpty())
				continue;

			ary.RemoveAll();
			for (int idx = 0; ; idx++)
			{
				keys.Format("%02d", idx);
				value = profile.GetString(section, keys);
				if (value.IsEmpty())
					break;
				ary.Add(value);
			}

			profile.WriteSection(section, "");
			profile.Write(section, "INDEXK", "0");

			for (idx = 0; idx < ary.GetSize(); idx++)
			{
				keys.Format("%03d", idx);
				value.Format("%02d", ConvertIndexKey(atoi(ary.GetAt(idx))));
				profile.Write(section, keys, value);
			}
			ary.RemoveAll();
		}
	}
}

void CMainFrame::deleteNewsfile()
{
	WIN32_FIND_DATA FindFileData;
	HANDLE		hFind;
	CFile		cfile;
	CString		allfile, filename;

	allfile.Format("%s\\%s\\*.html", Axis::home, USRDIR);
	hFind = FindFirstFile(allfile, &FindFileData);
	while (hFind != INVALID_HANDLE_VALUE)
	{
		filename.Format("%s\\%s\\%s", Axis::home, USRDIR, FindFileData.cFileName);
		if (!(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			DeleteFile(filename);
		if (!FindNextFile(hFind, &FindFileData))	break;
	}
}

void CMainFrame::OpenAnnouncement()
{
	CString		keys, value;

	CProfile profile(GetProfileFileName());

//	check popup
	for (int ii = 0; ; ii++)
	{
		keys.Format("open%02d", ii);
		value = profile.GetString(szDTAccouncement, keys);
		if (value.IsEmpty())
			break;

		if (!isOpenAnnouncement(value))
			continue;
#if 0
		m_mapHelper->CreatePopup(value, 1, WK_POPUP, CenterPOS);
#else
		m_mapHelper->CreateChild(value, 0, 0, CenterPOS);
#endif
	}

//	absolute popup
	for (ii = 0; ; ii++)
	{
		keys.Format("absopen%02d", ii);
		value = profile.GetString(szDTAccouncement, keys);
		if (value.IsEmpty())
			break;
		m_mapHelper->CreatePopup(value, 1, WK_POPUP, CenterPOS);
	}

//	webbrowser link ex) webopen00=0300(cx)0400(cy)|www.naver.com
	for (ii = 0; ; ii++)
	{
		keys.Format("webopen%02d", ii);
		value = profile.GetString(szDTAccouncement, keys);
		if (value.IsEmpty())
			break;

		CString	urls, tmps;
		int	cx, cy, pos;
		
		urls = value;
		pos = urls.Find('|');
		if (pos == -1)
		{
			cx = 800;
			cy = 600;
		}
		else
		{
			cx = atoi(urls.Left(4));
			cy = atoi(urls.Mid(4, 4));
			urls = urls.Mid(pos+1);
		}

		PopupWeb(urls, cx, cy);
	}
// ���ȭ�� ��������

	keys.Format("bknotice%02d", m_nBkMode);
	value = profile.GetString(szDTAccouncement, keys);
	if (!value.IsEmpty() && isOpenAnnouncement(value))
		m_mapHelper->CreateBkNotice(value, 0, 0, CenterPOS);
}

bool CMainFrame::isOpenAnnouncement(CString mapName)
{
	CProfile profile(pkUserConfig);
	CString		times, keys;
	SYSTEMTIME	tm;

	GetLocalTime(&tm);
	times.Format("%04d%02d%02d", tm.wYear, tm.wMonth, tm.wDay);

	CString value(profile.GetString(mapName, "DATE", "00000000"));
	if (!times.CompareNoCase(value))	
		return false;
	else
		return true;
}

bool CMainFrame::ExceptMap(CString mapN)
{
	CString mapname = mapN.Left(L_MAPN);
	if (!mapname.CollateNoCase("DH000099"))
		return true;
	if (!mapname.CollateNoCase(MAPN_GONGJI))
		return true;
	if (mapname.Find("IB7700")>=0)
		return true;
	return false;
}


#include <nb30.h>
#include <Iphlpapi.h>

#pragma comment (lib, "IpHlpApi.lib")

int CMainFrame::GetMacAddr(char* ipaddr, char* data)
{
	int returnL = 12;
	CString	ip = _T("");
	CString	checkIP;
	FillMemory(data, returnL, ' '); data[returnL] = 0x00;
	ip.Format("%s", ipaddr);
	ip.TrimLeft(), ip.TrimRight();
	IP_ADAPTER_INFO AdapterInfo[16];
	DWORD dwBufLen = sizeof(AdapterInfo);
	DWORD dwStatus = GetAdaptersInfo(AdapterInfo, &dwBufLen);
	if (dwStatus == ERROR_SUCCESS)
	{
		for (int ii = 0; ii < 16; ii++)
		{
			checkIP = (((AdapterInfo[ii]).IpAddressList).IpAddress).String;
			checkIP.TrimLeft(), checkIP.TrimRight();
			if (checkIP.CompareNoCase(ip))
				continue;
			
			sprintf(data, "%.2X%.2X%.2X%.2X%.2X%.2X",
					AdapterInfo[ii].Address[0], 
					AdapterInfo[ii].Address[1], 
					AdapterInfo[ii].Address[2], 
					AdapterInfo[ii].Address[3], 
					AdapterInfo[ii].Address[4], 
					AdapterInfo[ii].Address[5]);
			m_macaddr.Format("%.2X-%.2X-%.2X-%.2X-%.2X-%.2X",
					AdapterInfo[ii].Address[0], 
					AdapterInfo[ii].Address[1], 
					AdapterInfo[ii].Address[2], 
					AdapterInfo[ii].Address[3], 
					AdapterInfo[ii].Address[4], 
					AdapterInfo[ii].Address[5]);
			break;
		}
	}
	else
	{
		sprintf(data, "NOT FOUND   ");
	}
	return returnL;
}

void CMainFrame::SetEncriptFile()
{
	CProfile profile(pkAxis);
	CString value(profile.GetString(szSecure, "file"));
	if (value.IsEmpty())
	{
		value.Format("dev/dt_crypt.dll");
		profile.Write(szSecure, "file", value);
	}
}

typedef void (CALLBACK* LPFNDestory)();

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();

	if (m_hMRadar)
	{
		LPFNDestory ldes = (LPFNDestory)GetProcAddress(m_hMRadar, "AllDestory");
		if(ldes) 
			ldes();
		FreeLibrary(m_hMRadar);		
	}
}

void CMainFrame::MRFrame(CChildFrame* child)
{
	// 2006.10.26 �ǽð����� ȭ���� ���������ư�� �����ư ������ ���Ͽ�
	if (child->m_mapN.CompareNoCase("DH150700") == 0)
	{  
		child->HideButton(HIDE_SINGLE|HIDE_GROUP|HIDE_COPY|HIDE_FONT|HIDE_HELP);
	}
	else if (child->m_mapN.CompareNoCase("DH205700") == 0)
	{
		child->HideButton(HIDE_COPY|HIDE_FONT);
	}
}

void CMainFrame::MngInfoPos()
{
	if (m_mngInfo)
	{
		
		int	x, y;
		CRect	mRc;
		int	width = 0, height = 0;

		mRc = GetWndRect();
		m_mngInfo->GetSize(width, height);
		/*
		CString tmp; tmp.Format("%d", m_nInfoPos);
		AfxMessageBox(tmp);
		*/
		switch (m_nInfoPos)
		{
		case 0:	// left - top
			x = mRc.left;	y = mRc.top;
			if (x < 0)	x = 0;
			if (y < 0)	y = 0;
			break;
		case 1:	// center
			x = mRc.CenterPoint().x - width/2;
			y = mRc.CenterPoint().y - height/2;
			break;
		
		case 3:	// left - bottom
			x = mRc.left;
			y = mRc.bottom - height - GetSystemMetrics(SM_CYFIXEDFRAME);
			if (x < 0)	x = 0;
			if (y < 0)	y = 0;
			/*
			if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
				y = GetSystemMetrics(SM_CYSCREEN) - height;
			*/
			break;			
		case 4:	// right - bottom
			x = mRc.right - width - GetSystemMetrics(SM_CXFIXEDFRAME);
			y = mRc.bottom - height - GetSystemMetrics(SM_CYFIXEDFRAME);
			if (x < 0)	x = 0;
			if (y < 0)	y = 0;
			/*
			if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
				x = GetSystemMetrics(SM_CXSCREEN) - width;
			if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
				y = GetSystemMetrics(SM_CYSCREEN) - height;
			*/
			break;
		case 2:	// right - top
		default:
			x = mRc.right - width - GetSystemMetrics(SM_CXFIXEDFRAME);
			y = mRc.top;
			if (x < 0)	x = 0;
			if (y < 0)	y = 0;
			
			/*
			if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
				x = GetSystemMetrics(SM_CXSCREEN) - width;
			*/
			break;
		}
		
		CRect	rect;
		rect = mRc;
		rect.left = x;
		rect.top = y;
		rect.right = rect.left + width;
		rect.bottom = rect.top + height;
		m_mngInfo->ShowSlide(rect);
	}
}

/////////////////////////////////////////////////////////////////////////////////
	// ����ð��� ���߾� ��ֽŰ��� ������ �ֵ��� ������ ���� 2006.12.06


void CMainFrame::sendRTime()
{
	CString	str, gdatS, inputStr = _T(""), gData;

	str.Format("1301%c005930\t", 0x7f);
	gdatS.Format("?%s%c", "2500", 0x7F);

	_dataH	dataH;

	memset(&dataH, 0x20, sizeof(dataH));
	memcpy(dataH.count, "000001", 6);
	dataH.dkey = 0x39;
	dataH.dunit = 0x01;
	dataH.dindex = 0x05;
	memcpy(dataH.lgap, "0001", 4);
	dataH.option1 = 0x21;

	gData.Format("2302%c%c", 0x0A, 0x09);

	inputStr.Format("%s%s%.*s%s", str, gdatS, sizeof(dataH), (char*)&dataH, gData);
	sendTR("GOOPPOOP", (char*)(const char*)inputStr, inputStr.GetLength(), US_OOP, 'm');
}

void CMainFrame::processRTime(char* ptr, int len)
{
	int	nSize = sizeof(struct _dataH);
	struct _dataH*	dataH = NULL;
	if (len <= nSize)
	{
		m_szRTime = _T("");
		return;
	}

	ptr += nSize;
	CString	str;
	str.Format("%s", ptr);
	if (str.GetLength() < 8)
		return;
	m_szRTime = str.Left(8);
}

BOOL CMainFrame::IsRunTime()
{
	if (m_szRTime.IsEmpty())
		return FALSE;
	CTime	time;
	time = time.GetCurrentTime();

	CString	szDate, szTime;
	szDate.Format("%04d%02d%02d", time.GetYear(), time.GetMonth(), time.GetDay());
	if (m_szRTime.CompareNoCase(szDate) != 0)
		return FALSE;

	szTime.Format("%02d%02d%02d", time.GetHour(), time.GetMinute(), time.GetSecond());
	if (90000 > atoi(szTime) || atoi(szTime) > 170000)
		return FALSE;

	return TRUE;
}

void CMainFrame::AddMdi(int vsn, int key, CChildFrame* pChild)
{
// 	CString s;
// 	s.Format("MAP NAME : %s	GROUP : %d\n",pChild->m_mapN,pChild->m_xcaption.GetGroup());
// 	OutputDebugString(s);
// 	m_groupBymapN.SetAt(pChild->m_mapN,CString(pChild->m_xcaption.GetGroup()));

	m_arMDI[vsn].SetAt(key, pChild);
	RedrawVS();
}

void CMainFrame::RemoveMdi(int vsn, int key)
{
	CChildFrame* child = NULL;
	POSITION pos;
	int nTmpKey;
	bool flag = FALSE;

 	if(m_arMDI[vsn].Lookup(key,child))
	{
		CChildFrame*	pChild;
		for (pos = m_arMDI[vsn].GetStartPosition(); pos; )
		{
			m_arMDI[vsn].GetNextAssoc(pos, nTmpKey, pChild);

			if(nTmpKey != key && pChild->m_mapN == child->m_mapN)
			{
				flag = TRUE;
			}
		}
		
		if(flag == FALSE)
			m_groupBymapN.RemoveKey(child->m_mapN);
	}

	m_arMDI[vsn].RemoveKey(key);	

	RedrawVS(true);

	if (!m_bLastClose)
		writeOpenedList();	// 20070627 kwon
}

void CMainFrame::AddSdi(int vsn, int key, CSChild* pChild)
{
	//m_groupBymapN.SetAt(pChild->m_mapN,CString(pChild->m_xcaption.GetGroup()));

	m_arSDI[vsn].SetAt(key, pChild);
	RedrawVS();
}

void CMainFrame::RemoveSdi(int vsn, int key)
{
	CSChild* child = NULL;
	POSITION pos;
	int nTmpKey;
	bool flag = FALSE;
	
	if(m_arSDI[vsn].Lookup(key,child))
	{
		CSChild*	pChild;
		for (pos = m_arMDI[vsn].GetStartPosition(); pos; )
		{
			m_arSDI[vsn].GetNextAssoc(pos, nTmpKey, pChild);
			
			if(nTmpKey != key && pChild->m_mapN == child->m_mapN)
			{
				flag = TRUE;
			}
		}
		
		if(flag == FALSE)
			m_groupBymapN.RemoveKey(child->m_mapN);
	}

	m_arSDI[vsn].RemoveKey(key);	
	RedrawVS(true);

	if (!m_bLastClose)
		writeOpenedList();	// 20070627 kwon
}

void CMainFrame::RemoveAllChild(int vsn, bool bSdi)
{
	if (bSdi)
		m_arSDI[vsn].RemoveAll();
	else
		m_arMDI[vsn].RemoveAll();

	m_groupBymapN.RemoveAll();
	
	RedrawVS(true);
}

CString CMainFrame::GetScreenList(int vsn)
{
	CString	ret = "";
	int	key = 0;
	CSChild*	schild = NULL;
	CChildFrame*	pchild = NULL;
	POSITION	pos = m_arSDI[vsn].GetStartPosition();
	while (pos)
	{
		ret += "\n";
		m_arSDI[vsn].GetNextAssoc(pos, key, schild);
		ret += schild->GetTitle();
	}

	pos = m_arMDI[vsn].GetStartPosition();
	while (pos)
	{
		ret += "\n";
		m_arMDI[vsn].GetNextAssoc(pos, key, pchild);
		ret += pchild->GetTitle();
	}

	return ret;
}

// cej
void CMainFrame::DeleteAllScreen(bool all /*= true*/)
{
	int		key;
	CSChild*	schild;
	for (int vsN = V_SCREEN1; vsN <= V_SCREEN6; vsN++)
	{
		for (POSITION pos = m_arSDI[vsN].GetStartPosition(); pos; )
		{
			m_arSDI[vsN].GetNextAssoc(pos, key, schild);
			schild->SendMessage(WM_CLOSE);
		}
		RemoveAllChild(vsN, true);
	}
	m_mapHelper->closeAll(false);
}

void CMainFrame::ShowDoctorInfo(DWORD* data)
{
	//	TRACE("ôô�ڻ�[%s]\n", dat);
	CString dat;
	
	if (!m_pDoctor)		return;
	if (m_bCustomer)	return;		// ������ popup�ȳ���
	
	// popup 0:����, 1:�Ⱥ���
	
	CProfile profile(pkEnvironment);
	
	if (profile.GetInt("DOCTORQNA", "CHKPOPUP", 0) != 0)	return;	// 0:����
	
	CString symS, tmpS;
	
	int	idx = 0;
	
	
	m_pDoctor->StopSlide();
	//#define	SYM_NUM			14			// �Ϸù�ȣ
	//#define	SYM_DATE		48			// �����
	//#define	SYM_TIME		44			// ��Ͻð�
	//#define	SYM_ID			13			// ID
	//#define	SYM_TITLE		15			// ����
	//#define	SYM_RES			46			// �亯�Ǽ�
	//#define	SYM_SEQ			47			// ��������
	
	CString idS, titleS, resS;
	if (!data[46])		return;
	resS = (char*)data[46];
	if (!data[13])		return;
	idS = (char*)data[13];
	if (!data[15])	return;
	titleS = (char*)data[15];
	if (atoi(resS) > 0)			return;			// �������븸 tooltip 
	int len = min(titleS.GetLength(), 30);
	dat.Format("%s:%s", idS, titleS.Left(len));
	
	m_pDoctor->SetData(dat);
	
	CRect		mRc;
	WINDOWPLACEMENT	pl;
	GetWindowPlacement(&pl);
	switch (pl.showCmd)
	{
	case SW_HIDE:case SW_MINIMIZE:case SW_SHOWMINIMIZED:
		m_pDoctor->ShowWindow(SW_HIDE);
		return;
	default:
		break;
	}
	m_pDoctor->ShowWindow(SW_HIDE);
	doctorInfoPos(true);
	SetTimer(TM_AUTODCOTOR, 3000, NULL);
}

void CMainFrame::ShowDoctorInfo(CString dat)
{
//	TRACE("ôô�ڻ�[%s]\n", dat);

	if (!m_pDoctor)		return;
	if (m_bCustomer)	return;		// ������ popup�ȳ���

	// popup 0:����, 1:�Ⱥ���

	CProfile profile(pkEnvironment);

	if (profile.GetInt("DOCTORQNA", "CHKPOPUP", 0) != 0)	return;	// 0:����

	CString symS, tmpS;
	CString dataS = dat;

	CMap <int, int, CString, LPCTSTR>	rtmStore;
	int	idx = 0;

	rtmStore.RemoveAll();
	for (; !dataS.IsEmpty(); )
	{
		idx = dataS.Find('\t');
		if (idx < 0)
			break;
		symS = dataS.Left(idx);
		
		dataS = dataS.Mid(idx+1);
		idx = dataS.Find('\t');
		if (idx < 0)
			idx = dataS.GetLength();
		tmpS = dataS.Left(idx);
		rtmStore.SetAt(atoi(symS), tmpS);

		if (dataS.GetLength() <= idx)
			break;
		dataS = dataS.Mid(idx+1);
	}
	

	m_pDoctor->StopSlide();
	//#define	SYM_NUM			14			// �Ϸù�ȣ
	//#define	SYM_DATE		48			// �����
	//#define	SYM_TIME		44			// ��Ͻð�
	//#define	SYM_ID			13			// ID
	//#define	SYM_TITLE		15			// ����
	//#define	SYM_RES			46			// �亯�Ǽ�
	//#define	SYM_SEQ			47			// ��������

	CString idS, titleS, resS;
	if (!rtmStore.Lookup(46, resS))		return;
	if (!rtmStore.Lookup(13, idS))		return;
	if (!rtmStore.Lookup(15, titleS))	return;
	if (atoi(resS) > 0)			return;			// �������븸 tooltip 
	int len = min(titleS.GetLength(), 30);
	dat.Format("%s:%s", idS, titleS.Left(len));

	m_pDoctor->SetData(dat);

	rtmStore.RemoveAll();

	CRect		mRc;
	WINDOWPLACEMENT	pl;
	GetWindowPlacement(&pl);
	switch (pl.showCmd)
	{
	case SW_HIDE:case SW_MINIMIZE:case SW_SHOWMINIMIZED:
		m_pDoctor->ShowWindow(SW_HIDE);
		return;
	default:
		break;
	}
	m_pDoctor->ShowWindow(SW_HIDE);
	doctorInfoPos(true);
	SetTimer(TM_AUTODCOTOR, 3000, NULL);
}


void CMainFrame::doctorInfoPos(bool bDoctor)
{
	if (!m_pDoctor)	return;
	
	int	x, y;
	CRect	mRc;
	int	width = 0, height = 0;

	mRc = GetWndRect();
	m_pDoctor->GetSize(width, height);

	x = mRc.right - width - GetSystemMetrics(SM_CXFIXEDFRAME);
	y = mRc.top;
	if (x < 0)	x = 0;
	if (y < 0)	y = 0;
	if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
		x = GetSystemMetrics(SM_CXSCREEN) - width;
	
	m_pDoctor->SetGubn(bDoctor); 
	
	CRect	rect;
	rect = mRc;
	rect.left = x;
	rect.top = y;
	rect.right = rect.left + width;
	rect.bottom = rect.top + height;
	m_pDoctor->ShowSlide(rect);

}

void CMainFrame::showMisuAlarm()
{
	if (!m_misuAlarm)
	{
		m_misuAlarm = new CDlgMisuAlarm(this);
		if (!m_misuAlarm->Create(IDD_DLGMISU))
		{
			delete m_misuAlarm;
			m_misuAlarm = NULL;
		}
	}
	
	if (m_misuAlarm)
	{
		m_misuAlarm->Init();
		m_misuAlarm->ShowWindow(SW_SHOW);
	}
}

void CMainFrame::RunBrowser(CString url)
{
	ShellExecute(NULL, _T("open"), url, NULL,NULL, SW_SHOWNORMAL);
}

void CMainFrame::checkRTSQueue()
{
	if (!m_wizard || !IsWindow(m_wizard->GetSafeHwnd()))
		return;
	CString tmpS;
	long	rc = 0;
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
						(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(getRTS, 0), 0);
	int cnt = (int)rc;
	int cpuuse = 0;//m_cpu.GetCpuUsage();

	if (m_bDelayIn && m_nDelayPeak < cnt)
		m_nDelayPeak = cnt;

	if (m_bDelayIn && m_nCpuPeak < cpuuse)
		m_nCpuPeak = cpuuse;

	if (!m_bDelayIn && cnt > 100)
	{
		m_tmDelayStart = CTime::GetCurrentTime();
		m_sDelayData.Format("%s\t%d ~ ", m_tmDelayStart.Format("%H:%M:%S"), cnt);
		m_bDelayIn = !m_bDelayIn;
		m_nDelayPeak = cnt;
		m_nCpuPeak = cpuuse;
	}

	if (m_bDelayIn && cnt < 100)
	{
		CTimeSpan timeDelta;
		CString sPath;
		m_tmDelayEnd = CTime::GetCurrentTime();
		sPath.Format("%s\\%s\\%s\\delayinfo", Axis::home, USRDIR, Axis::user);
		tmpS.Format("%s%s\t%d,P=%d,C=%d<br>", m_sDelayData, m_tmDelayEnd.Format("%H:%M:%S"), cnt, m_nDelayPeak, m_nCpuPeak);
		timeDelta = m_tmDelayEnd - m_tmDelayStart;
		if (timeDelta.GetTotalSeconds() > 2 || m_nDelayPeak > 300)
			WriteFileData(sPath, tmpS);
		m_bDelayIn = !m_bDelayIn;
	}

	if (Axis::devMode)
	{
		m_titleS.Format("CPU[%d%%] �����Ǽ�[%d��]", cpuuse, cnt);
		DrawFrame();
		return;
	}
	
	if (cnt > 500 || cpuuse > 98)	// �����Ǽ�, CPU����� �������� title�� ǥ��
	{
		m_bRTSQueue = true;
		tmpS.Format("%s    CPU[%d%%] �����Ǽ�[%d��]", m_saveTitle, cpuuse, cnt);
		m_titleS = tmpS;
		DrawFrame();
	}
	else
	{
		if (m_bRTSQueue)
		{
			m_bRTSQueue = false;
			m_titleS = m_saveTitle;
			DrawFrame();
		}
	}
}

//===================================================================================
void CMainFrame::checkOpenedList()
{
	CString	Path;
	Path.Format("%s\\%s\\%s\\dinfo", Axis::home, USRDIR, Axis::user);

	CProfile profile(pkUserSetup);
	CString value;
	value = profile.GetString(szLogCheck, "CLOSE");
	profile.Write(szLogCheck, "CLOSE", "0");

	((CAxisApp*)m_axis)->m_logPath = profile.GetFileName();

	if (atoi(value) != 1)
	{
		TRY
		{
			CFile file;
			if (file.Open(Path, CFile::modeRead)) 
			{
				int len = file.GetLength();
				if (len > 0 && len < 2000)	// �������� �α׸� 2000 �����ϰ�
				{
					char	*pBuf = new char[len];
					file.Read(pBuf, len);
					bool bret = sendTR("pihoerpt", pBuf, len, US_PASS, 'd');

					delete[] pBuf;
				}
				file.Close();
			}
		}
		CATCH (CFileException, e) 
		{
		}
		END_CATCH;
	}

	m_bFirstOpen = false;
	writeOpenedList(true);
	//SetTimer(TM_SCRLOG, 120000, NULL);	ȭ�� �����ɶ��� ����ɶ� ����⶧���� �ϴ� �ּ�ó��
}

struct _errmid {
	char	usid[24];		// user id
	char	optn[4];		// 0 - ȸ���籸��( 'H' - hana, 'D' - daetoo), 1 - ( 1 - ����, 2- ����), 2~3 : filler 
	char	yymd[8];		// YYYYMMDD
	char	hmss[6];		// HHMMSS
	char	mapn[8];		// map name
	char	ipad[15];		// local ip-addr
	char	fill[80];		// filler
	char	info[512];		// error information
	char	cont[1];		// user situation
};
#define	sz_errmid	sizeof(_errmid)

void CMainFrame::writeOpenedList(bool bFirst /*= false*/)
{
	if (m_bFirstOpen)	return;

	CString	mpN, tmps, info;

	CArray	<int, int>	aryK;

	CString		sMap = m_sLastMapInfo;
	int		cnt = 0;
	
	sMap.Replace(MAPN_REALTIMEJANGO, "");
	sMap.Replace(MAPN_SISECATCH1, "");
	
	CString	Path, sData;
	Path.Format("%s\\%s\\%s\\dinfo", Axis::home, USRDIR, Axis::user);
	CTime curr = CTime::GetCurrentTime();

	if (m_sWin.IsEmpty())
	{
		m_sWin = m_sysInfo->GetWindowInfo();
		m_sCpu = m_sysInfo->GetCPUInfo();	m_sCpu.TrimLeft();
		m_sMem = m_sysInfo->GetMemoryInfo();
		m_sIE  = m_sysInfo->GetIEInfo();
	}

	int	dLen = sz_errmid;
	char	*pBuf = new char[dLen];
	memset(pBuf, ' ', dLen);
	_errmid	*errmid = (_errmid*)pBuf;
	int	infoL = sizeof(errmid->info);		// 512
	cnt = sMap.GetLength() / 9;

	sData.Format("%s\t%s\t%s\tIEV:%s\t[%d��:%s] %s ", m_sWin, m_sCpu, m_sMem, m_sIE, cnt, (bFirst ? "F" : "C"), sMap/*, getProcessList()*/);
	
	if (sData.GetLength() > infoL)
		sData = sData.Left(infoL-1);

	sprintf(errmid->usid, Axis::userID);
	strcpy(errmid->optn, "110");
	sprintf(errmid->yymd, "%04d%02d%02d", curr.GetYear(), curr.GetMonth(), curr.GetDay());
	sprintf(errmid->hmss, "%02d%02d%02d", curr.GetHour(), curr.GetMinute(), curr.GetSecond());

	if (m_ipAddr.IsEmpty())
	{
		::gethostname(errmid->ipad, sizeof(errmid->ipad));
		if (lstrcmp(errmid->ipad, "") != 0)
		{
			HOSTENT FAR* lphostent = ::gethostbyname(errmid->ipad);
			if(lphostent)
			{
				sprintf(errmid->ipad, "%s", inet_ntoa(*((struct in_addr*)lphostent->h_addr)));
			}
		}
		m_ipAddr.Format("%s", errmid->ipad);
	}
	int ipadL = min(sizeof(errmid->ipad), m_ipAddr.GetLength());
	sprintf(errmid->ipad, "%s", m_ipAddr.Left(ipadL));
	sprintf(errmid->info, sData);

	TRY
	{
		CFile	file;
		if (!file.Open(Path, CFile::modeCreate|CFile::modeWrite))
		{
			TRACE("Create Failed\n");
			delete[] pBuf;
			return;
		}
		file.Write(pBuf, dLen);
		file.Close();
	}
	CATCH (CFileException, e) 
	{
	}
	END_CATCH;
	
	delete[] pBuf;
}

void CMainFrame::removeOpenedList()
{
	CProfile profile(pkUserSetup);

	profile.Write("LOGCHECK", "CLOSE", "1"); // �������� 1


	CString	Path;
	Path.Format("%s\\%s\\%s\\dinfo", Axis::home, USRDIR, Axis::user);
	TRY 
	{
		CFile::Remove(Path);
	}
	CATCH(CFileException, e) 
	{
	}
	END_CATCH;
}

CString CMainFrame::getProcessList()
{
	if (m_winVer == WIN9X || m_winVer == UNKNOWN)
		return _T("");

	HANDLE hProcessSnap = NULL;
	PROCESSENTRY32	pe32 = {0};

	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); 
	if (hProcessSnap == INVALID_HANDLE_VALUE) 
		return _T(""); 

	CStringArray arProcess;
	arProcess.RemoveAll();

	int pos = 0;
	CString proS;
	pe32.dwSize = sizeof(PROCESSENTRY32); 
	if (Process32First(hProcessSnap, &pe32)) 
	{ 
		DWORD		dwPriorityClass; 
		BOOL		bGotModule = FALSE; 
		MODULEENTRY32	me32 = {0}; 
		DWORD		Code = 0;
		int		cnt = 0;
		do 
		{ 
			HANDLE hProcess; 
			hProcess = OpenProcess (PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID); 
			dwPriorityClass = GetPriorityClass (hProcess); 

			proS = CString(pe32.szExeFile);
			proS.MakeLower();
			if ((pos = proS.Find(".exe")) != -1)
				proS = proS.Left(pos);
			arProcess.Add(proS);
			if (proS != "mfnt")
				CloseHandle(hProcess);
		} while (Process32Next(hProcessSnap, &pe32)); 
	}
	CloseHandle (hProcessSnap); 

	// ŷ�� : kdrmgr
	// nProtect(��ī), np�� ���� : npkcmsvc, npmon, npkagt
	// ��ö�� Ű���� : mkd20tray
	//       V3 2007 : AcAis.exe,acaegmgr.exe,acaas.exe,acals.exe, msProxy
	//       V3 : AhnSd, AhnSDsv, monsvcnt, monsysnt
	//       ��ȭ�� : mfnt
	// �̴��� : INISafeWeb
	CString tmpS, allS = _T("");
	for (int ii = 0, idx = 0; ii < arProcess.GetSize(); ii++)
	{
		tmpS.Format("%s  ", arProcess.GetAt(ii)); 
		if (tmpS.Find("conime") != -1			// �������ܼ� ����, �����带 ��������,16��Ʈ ����DOS��带 ����
			|| tmpS.Find("csrss") != -1		// ����������Ʈ���� �ѱ��Է��̳� �׿� ������Ʈ�� ����ϴ� ���α׷��� ����
			|| tmpS.Find("ctfmon") != -1		// ���� ȭ���� �Է� ������ ���� ���Ϸμ� ���� �Է��� �����ϴ� �ؽ�Ʈ ����
			|| tmpS.Find("explore") != -1 
			|| tmpS.Find("jusched") != -1		// �ڹپ�����Ʈ �����ٷ�
			|| tmpS.Find("lsass") != -1		// Winlogon ���񽺿� �ʿ��� ���� ���μ����� ���
			|| tmpS.Find("mdm") != -1		// Machine Debug Manager
			|| tmpS.Find("mstask") != -1		// �۾� �����췯 ����
			|| tmpS.Find("process") != -1 
			|| tmpS.Find("rundll32") != -1		// 32bit ���α׷�
			|| tmpS.Find("services") != -1		// �ý��� ���񽺵��� ����/������Ű��, �׵鰣�� ��ȣ�ۿ��ϴ� ���
			|| tmpS.Find("smss") != -1		// ����� ������ �����ϴ� ���
			|| tmpS.Find("spoolsv") != -1		// ������ �� �ѽ��� Spooling ���
			|| tmpS.Find("svchost") != -1		// DLL�κ��� ����Ǵ� �ٸ� ���μ������� host ����
			|| tmpS.Find("system") != -1		// ��κ��� Ŀ�θ�� ��������� �������� �Ǵ� ���μ���
			|| tmpS.Find("taskmgr") != -1		// �۾�������
			|| tmpS.Find("usnsvc") != -1		// Messenger Sharing USN Journal Reader Service 
			|| tmpS.Find("winmgmt") != -1		// Ŭ���̾�Ʈ ������ �ٽ�
			|| tmpS.Find("winlogon") != -1		// ����� �α���/�α׿����� ����ϴ� ���μ���
			|| tmpS.Find("wuauclt") != -1		// ������ ������Ʈ

			// vista
			|| tmpS.Find("wininit") != -1		// ������ ������Ʈ
			|| tmpS.Find("lsm") != -1		// ���� ���� ������
			|| tmpS.Find("audiodg") != -1		// �������ġ
			|| tmpS.Find("slsvc") != -1		// Microsoft Software Licensing Service 
			|| tmpS.Find("taskeng") != -1		// �۾� �����ٷ��� ���� ����
			|| tmpS.Find("dwm") != -1		// ���� ȭ�� â ������
			|| tmpS.Find("sidebar") != -1		// side bar
			)
			continue;
		allS += tmpS;
		idx++;
	}
	arProcess.RemoveAll();
	return allS;
}

void CMainFrame::show_Ticker(int nID)
{
	switch (nID)
	{
	case 1:		// info1
		{
			ShowControlBar(m_tInfo1, FALSE, FALSE);
		}
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	case 2:
		{
			ShowControlBar(m_tInfo2, FALSE, FALSE);
		}
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	case 3:		// info3
		if (!(m_tInfo2 && m_tInfo2->GetStyle() & WS_VISIBLE))
			ShowControlBar(m_tInfo2, TRUE, FALSE);
		else if (!(m_tInfo1 && m_tInfo1->GetStyle() & WS_VISIBLE))
			ShowControlBar(m_tInfo1, TRUE, FALSE);
		else
		{
			ShowControlBar(m_tInfo1, FALSE, FALSE);
			ShowControlBar(m_tInfo2, FALSE, FALSE);
		}
		
		saveToolStatus();
		SetSDIChangeHeight();
		break;
	}
}

void CMainFrame::hide_Ticker(int nID)
{
	switch (nID)
	{
	case 5:
		ShowControlBar(m_tInfo3, FALSE, FALSE);
		saveToolStatus();
	}
}

CGPop*	CMainFrame::getGPOP( CString strMapName )
{
	POSITION pos = m_arGPOP.GetStartPosition();
	while( pos )
	{
		int key;
		CGPop* p;
		m_arGPOP.GetNextAssoc( pos, key, p );		

		if( p->m_mapN == strMapName.Left(8) )
			return p;
	}

	return NULL;
}

CRect CMainFrame::GetFullRect()
{
	CRect rc;
	int moniterN = GetSystemMetrics(SM_CMONITORS);

	if (moniterN <= 1)
	{
		rc.SetRect(0, 0, GetSystemMetrics(SM_CXFULLSCREEN), GetSystemMetrics(SM_CYFULLSCREEN));
		return rc;
	}

	g_monRc.SetRectEmpty();
	EnumDisplayMonitors(NULL, NULL, MyInfoEnumProc, 0);
	rc = g_monRc;
	return rc;
}

BOOL CMainFrame::IsNewLoginImage(BOOL bStaff)
{
	CString	imgN;
	CWinApp* app = AfxGetApp();

	/**
	if (!bStaff)
	{
		imgN.Format("%s\\%s\\axis.bmp", Axis::home, IMAGEDIR);
	}
	else
	{
		imgN.Format("%s\\%s\\saxis.bmp", Axis::home, IMAGEDIR);
	}
	**/
	imgN.Format("%s\\%s\\LOGIN_BG_BAGIC.bmp", Axis::home, IMAGEDIR);

	HBITMAP hBitmap = (HBITMAP)LoadImage(AfxGetApp()->m_hInstance,
			imgN,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);

	if (hBitmap)
	{
		BITMAP bm;
		GetObject(hBitmap, sizeof(BITMAP), &bm);
		::DeleteObject(hBitmap);
		if (!(bm.bmWidth == 370 && bm.bmHeight == 621))	// �� �̹���
			return TRUE;
	}
	return FALSE;
}

BOOL CMainFrame::IsNewExitImage()
{
	return TRUE;
	/**
	CString	path, path_;
	path.Format("%s\\%s\\exitdlg.bmp", Axis::home, IMAGEDIR);
	HBITMAP hBitmap = (HBITMAP)LoadImage(AfxGetApp()->m_hInstance,
			path,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);

	if (hBitmap)
	{
		BITMAP bm;
		GetObject(hBitmap, sizeof(BITMAP), &bm);
		::DeleteObject(hBitmap);
		if (!(bm.bmWidth == 279 && bm.bmHeight == 525))	// �� �̹���
			return TRUE;
	}
	return FALSE;
	**/
}

void CMainFrame::VoidRect(CRect *pRect)
{
	if (pRect)
	{
		CRect fullRc = GetFullRect();
		CRect iRc;
		if (iRc.IntersectRect(fullRc, pRect))
		{
			CRect deltaRc;
			deltaRc.SubtractRect(iRc, *pRect);
			pRect->OffsetRect((iRc.right < pRect->right? (iRc.right - pRect->right):(iRc.left - pRect->left)),
				(iRc.bottom < pRect->bottom? (iRc.bottom - pRect->bottom):(iRc.top - pRect->top)));
		}
	}
}

void CMainFrame::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	if (!m_bSDI)
	{
		
		lpncsp->rgrc[0].top    += SZ_MAINCAPTION - 2;  
		lpncsp->rgrc[0].bottom += 2 ;
		
		
		
		if(Axis::isVista)
		{
			int interFrame = GetSystemMetrics(SM_CXFRAME) - 4;
			lpncsp->rgrc[0].top -=interFrame;
			lpncsp->rgrc[0].bottom +=interFrame;
			lpncsp->rgrc[0].left -=interFrame;
			lpncsp->rgrc[0].right +=interFrame;
			
		}
		
		
	}
	else
	{
		lpncsp->rgrc[0].top -= 3;
		lpncsp->rgrc[0].bottom += 2;
	}
	if(Axis::isVista)	Invalidate(false);

	CMDIFrameWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

UINT CMainFrame::OnNcHitTest(CPoint point) 
{
	if (m_bSDI)
		return CMDIFrameWnd::OnNcHitTest(point);
	UINT nHitTest = HTNOWHERE;

	CPoint tPnt = point;
	CRect iconRc(4, 0, 20, 12);
	CRect captionRc;
	CRect rightBottomRc;

	GetClientRect(&captionRc);
	captionRc.top = -(14+ 4);
	captionRc.bottom = 0;
	/*captionRc.left  -= 4;
	captionRc.right += 4;*/
	ScreenToClient(&tPnt);

	if (iconRc.PtInRect(CPoint(tPnt.x, tPnt.y + 12 + GetSystemMetrics(SM_CYFRAME))))
		nHitTest = HTSYSMENU;
	else if (captionRc.PtInRect(tPnt))
	{
		return HTCAPTION;
	}
	else
		nHitTest = CMDIFrameWnd::OnNcHitTest(point);

	return nHitTest;
	return CMDIFrameWnd::OnNcHitTest(point);
}

bool CMainFrame::IsAgreeDuplicate(CString mapN)
{
	if (mapN.IsEmpty())	return false;
	CString smapN, key = m_tMenu->GetDispN(mapN);

	CProfile profile(pkAxis);

	smapN = profile.GetString("Select"	, key);
	if (!smapN.Compare("980000")) // Web Link Map.
	{
		return !IsExistMap(mapN, m_vsN);
	}
	//AfxMessageBox(szAgreeDuplicate);
	smapN = profile.GetString(szAgreeDuplicate, key);
	return !smapN.IsEmpty();
}

void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	long nMaxHeight = GetSystemMetrics(SM_CYMAXIMIZED);
	long nMaxWidth = GetSystemMetrics(SM_CXMAXIMIZED);
	CPoint pt;
	CRect rc;
	GetWindowRect(&rc);

	WINDOWPLACEMENT	pl;
	GetWindowPlacement(&pl);
	if (pl.showCmd == SW_SHOWMINIMIZED && m_minSaveRC.IsRectEmpty())
	{
		m_minSaveRC = pl.rcNormalPosition;
	}
	else
	{
		if (!m_minSaveRC.IsRectEmpty())
		{
			rc = m_minSaveRC;
			m_minSaveRC.SetRectEmpty();
		}
	}

	pt = rc.CenterPoint();
	MONITORINFO mi;
	mi.cbSize = sizeof(mi);
	HMONITOR hMonitor = MonitorFromPoint(pt, MONITOR_DEFAULTTOPRIMARY);
	if (GetMonitorInfo(hMonitor, &mi))
	{
		nMaxHeight = mi.rcWork.bottom - mi.rcWork.top;
		nMaxWidth = mi.rcWork.right - mi.rcWork.left;
	}
	lpMMI->ptMaxSize.y = nMaxHeight + GetSystemMetrics(SM_CYFRAME)-3;
	lpMMI->ptMaxSize.x = nMaxWidth + GetSystemMetrics(SM_CXFRAME);
	//if (Axis::isVista)	lpMMI->ptMaxPosition.y += VistaFrame;
	
	CMDIFrameWnd::OnGetMinMaxInfo(lpMMI);
}

void CMainFrame::FOStopLoss()
{
	bool onlysise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0) ? TRUE : FALSE;
	if (onlysise)	return;
	if (!m_foStoploss)
	{
		CStopWarn	dlg;
		if (dlg.DoModal() != IDOK)	return;
		m_foStoploss = new CStoploss(m_bar2);
		if (!m_foStoploss->Create(IDD_STOPLOSS))
		{
			delete m_foStoploss;
			m_foStoploss = NULL;
		}
		else
		{
			BOOL	rc = 0;
			int	vtype = 0, size = 0, ret, key = KEY_FOSTOPLOSS;
			CString mapname = MAPN_FOSTOPLOSS;

			m_wizard->InvokeHelper(DI_FORMI, DISPATCH_METHOD, VT_I4, (void *)&vtype,
						(BYTE *)(VTS_BSTR VTS_I4), mapname, &size);
			m_wizard->InvokeHelper(DI_ATTACH, DISPATCH_METHOD, VT_I4, (void *)&key,
					(BYTE *)(VTS_I4 VTS_I4 VTS_I4), (long)m_foStoploss, vtype, key);
			m_wizard->InvokeHelper(DI_FORMS, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
					(BYTE *)(VTS_I4 VTS_BSTR VTS_I4 VTS_BOOL), key, mapname, size, false);

			ret = 0;
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&ret,
				(BYTE *)(VTS_I4 VTS_I4), setGID, (long)MAKELONG(key, 0));

			CSize	frameGap;
			frameGap.cx  = GetSystemMetrics(SM_CXFRAME);
			frameGap.cx += GetSystemMetrics(SM_CXBORDER) * 2;

			frameGap.cy  = GetSystemMetrics(SM_CYFRAME);
			frameGap.cy += GetSystemMetrics(SM_CYBORDER) * 2;
			frameGap.cy += GetSystemMetrics(SM_CYCAPTION);

			int nCx = frameGap.cx + LOWORD(size);
			int nCy = frameGap.cy + HIWORD(size);

			m_foStoploss->SetWindowPos(&wndTopMost, 0, 0, nCx, nCy, SWP_NOMOVE|SWP_NOZORDER|SWP_HIDEWINDOW);
		}
	}

	CRect	mRc, wRc;

	mRc = GetWndRect();
	m_foStoploss->GetWindowRect(wRc);

	int x = mRc.right - wRc.Width() - GetSystemMetrics(SM_CXFIXEDFRAME);
	int y = mRc.bottom - wRc.Height() - GetSystemMetrics(SM_CYFIXEDFRAME);
	if (x < 0)	x = 0;
	if (y < 0)	y = 0;
	if (mRc.right > GetSystemMetrics(SM_CXSCREEN))
		x = GetSystemMetrics(SM_CXSCREEN) - wRc.Width();
	if (mRc.bottom > GetSystemMetrics(SM_CYSCREEN))
		y = GetSystemMetrics(SM_CYSCREEN) - wRc.Height();

	if (m_foStoploss->GetStyle() & WS_VISIBLE)
		m_foStoploss->ShowWindow(SW_HIDE);
	else	m_foStoploss->SetWindowPos(&wndTopMost, x, y, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW);
}


void CMainFrame::RelayoutTicker()
{
	/**
	if (m_tInfo3)
	{
		if ((m_tInfo2 && m_tInfo2->GetStyle() & WS_VISIBLE) && (m_tInfo1 && m_tInfo1->GetStyle() & WS_VISIBLE))
			m_tInfo3->ChangeMode(TICKERMODE_DOWN);
		else
			m_tInfo3->ChangeMode(TICKERMODE_UP);
	}
	**/
	if (m_tInfo3 && !(m_tInfo3->GetStyle() & WS_VISIBLE))
	{
		if (m_tInfo2 && m_tInfo2->GetStyle() & WS_VISIBLE)
		{
			m_tInfo2->SetBase(TRUE);
			m_tInfo1->SetBase(FALSE);
		}
		else
		{
			m_tInfo2->SetBase(FALSE);
			m_tInfo1->SetBase(TRUE);
		}
	}
	else
	{
		m_tInfo2->SetBase(FALSE);
		m_tInfo1->SetBase(FALSE);
	}
}


void CMainFrame::MDINextChild()
{
	int key;
	if (m_hooklist[m_vsN].GetSize() > 1)
	{
		key = m_hooklist[m_vsN].GetAt(1);
		int firstKey = m_hooklist[m_vsN].GetAt(0);
		m_hooklist[m_vsN].RemoveAt(0);
		m_hooklist[m_vsN].Add(firstKey);	// ó�� key�� last��
		m_hooklist[m_vsN].RemoveAt(0);
		m_hooklist[m_vsN].InsertAt(0, key);	// �ι�° key�� first��
	}

	CChildFrame*	child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild*	schild;
		if (!m_arSDI[m_vsN].Lookup(key, schild))
			return;
		MDIActivate(schild);
		return;
	}
	MDIActivate(child);
}

void CMainFrame::WriteFileData(CString sPath, CString sData, BOOL bCreate)
{
	TRY
	{
		CFile file;
		CString filename = sPath;
		CFileFind finder;
		if (!bCreate && finder.FindFile(filename))
		{
			if (!file.Open(filename, CFile::modeReadWrite|CFile::modeReadWrite|CFile::typeBinary))
			{
				TRACE("File Create Error!!");
				return;
			}
		}
		else
		{
			if (!file.Open(filename, CFile::modeCreate|CFile::modeReadWrite|CFile::typeBinary))
			{
				TRACE("File Create Error!!");
				return;
			}
		}
		if (!bCreate)
			finder.Close();
		file.SeekToEnd();
		file.Write((void*)(const char*)sData, sData.GetLength());
		file.SeekToEnd();
		file.Write("\r\n", 2);
		file.Close();
	}
	CATCH (CFileException, e) 
	{
	}
	END_CATCH;
}

void CMainFrame::checkDelayList()
{
	CFileFind finder;
	CString sPath;
	sPath.Format("%s\\%s\\%s\\delayinfo", Axis::home, USRDIR, Axis::user);
	if (finder.FindFile(sPath))
	{
		TRY
		{
			CFile file;
			CString sBuf;
			if (file.Open(sPath, CFile::modeRead)) 
			{
				long len = file.GetLength();
				file.Read(sBuf.GetBuffer(len + 1), len);
				sBuf.ReleaseBuffer();
				file.Close();
				::DeleteFile(sPath);
			}

			CTime curr = CTime::GetCurrentTime();
			int	dLen = sz_errmid;
			char	*pBuf = new char[dLen];
			memset(pBuf, ' ', dLen);
			_errmid	*errmid = (_errmid*)pBuf;
			int	infoL = sizeof(errmid->info);		// 512

			CString sData = "**Delay Mon**<br>";
			CString sMap = m_sLastMapInfo;
			sMap.Replace(MAPN_REALTIMEJANGO, "");
			sMap.Replace(MAPN_SISECATCH1, "");
			sMap.Replace("IB", "");
			if (m_sWin.IsEmpty())
			{
				m_sCpu = m_sysInfo->GetCPUInfo();	m_sCpu.TrimLeft();
				m_sMem = m_sysInfo->GetMemoryInfo();
			}

			sData += sMap + "<br>" + m_sCpu + "<br>" + m_sMem + "<br>";
			sData += sBuf;

			if (sData.GetLength() >= infoL)
				sData = sData.Left(infoL-1);
			
			sprintf(errmid->usid, Axis::userID);
			strcpy(errmid->optn, "111");
			sprintf(errmid->yymd, "%04d%02d%02d", curr.GetYear(), curr.GetMonth(), curr.GetDay());
			sprintf(errmid->hmss, "%02d%02d%02d", curr.GetHour(), curr.GetMinute(), curr.GetSecond());
			
			if (m_ipAddr.IsEmpty())
			{
				::gethostname(errmid->ipad, sizeof(errmid->ipad));
				if (lstrcmp(errmid->ipad, "") != 0)
				{
					HOSTENT FAR* lphostent = ::gethostbyname(errmid->ipad);
					if(lphostent)
					{
						sprintf(errmid->ipad, "%s", inet_ntoa(*((struct in_addr*)lphostent->h_addr)));
					}
				}
				m_ipAddr.Format("%s", errmid->ipad);
			}
			int ipadL = min(sizeof(errmid->ipad), m_ipAddr.GetLength());
			sprintf(errmid->ipad, "%s", m_ipAddr.Left(ipadL));
			sprintf(errmid->info, sData);

			bool bret = sendTR("pihoerpt", pBuf, dLen, US_PASS, 'd');
			delete[] pBuf;
		}
		CATCH (CFileException, e) 
		{
		}
		END_CATCH;
	}
	finder.Close();
}

void CMainFrame::SetLastMaps(CString sRemoveMap, CString sInsertMap)
{
	//if (sRemoveMap == sInsertMap) return;//sInsertMap sRemoveMap = "";
	
	if (!sRemoveMap.IsEmpty())
	{
		int pos = m_sLastMapInfo.Find(sRemoveMap, 0);
		if (pos >= 0)
			m_sLastMapInfo.Delete(pos, sRemoveMap.GetLength() + 1);
	}
	if (!sInsertMap.IsEmpty())
	{
		m_sLastMapInfo += sInsertMap + " ";
	}
}

BOOL CMainFrame::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	CString data((const char*)pCopyDataStruct->lpData, pCopyDataStruct->cbData);

	// for WTS Interface
	int find = data.Find('\t');

	if (find > 0)
	{
		CString account, password;
		account = data.Left(find);
		password = data.Right(data.GetLength() - (find + 1));

		//** send trigger account and password to some order map.

	}
	
	return CMDIFrameWnd::OnCopyData(pWnd, pCopyDataStruct);
}


BOOL CMainFrame::IsForeignMap(const char* map)
{
	const char* foreignMapName = "IB780100";

	return !strcmp(foreignMapName, map);
}

void CMainFrame::RunForeignMap()
{
	CString cmdLine;

	cmdLine.Format("IBK,IBK,A,%d", m_hWnd);
	//MessageBox(Axis::home);
	//SetWorkingDirectory(Axis::home);
	SetCurrentDirectory(Axis::home + "\\exe");
	ShellExecute(NULL, _T("open"), "RTV.EXE", cmdLine,NULL, SW_SHOWNORMAL);
}

//** macho add begin

bool CMainFrame::GetScrButtonPos(int key, LPRECT lpRect)
{
	if (!m_bar2)
		return false;

	CRect rc = m_bar2->GetScrButtonPos(key);

	m_bar2->ClientToScreen(rc);
	if (rc.left < 0)
		::SystemParametersInfo (SPI_GETWORKAREA, 0, lpRect, 0);    
	else
		memcpy(lpRect, (LPRECT)rc, sizeof(RECT));

	return true;
}

/** 
void CMainFrame::AccSetting()
{
	if (m_bCustomer)
	{
		int onlysise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0);
		if (onlysise)	return;

#if 1
		CAccSave	dlg(this);
		m_accSave = &dlg;
		dlg.DoModal();
		m_wizard->InvokeHelper(DI_DETACH, DISPATCH_METHOD, VT_EMPTY,
				(void *)NULL, (BYTE *)(VTS_I4), (short) KEY_ACCTOOL);
		m_accSave = NULL;
#else
		CPassDlg* passDlg = new CPassDlg();
		passDlg->SetData(data);
		if (passDlg->DoModal() == IDOK)
		{
			Caccount* ac;
			data.Empty();
			for (int ii = 0; ii < passDlg->m_acs.GetSize(); ii++)
			{
				rc = 0;
				ac = passDlg->m_acs.GetAt(ii);
				data.Format("%s\t%s\t%s", ac->m_account, ac->m_pass, ac->m_name);
				m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
							(BYTE *)(VTS_I4 VTS_I4), MAKEWPARAM(saveACC, 0), (long)data.operator LPCTSTR());
			}
		}
		delete passDlg;
#endif
	}
	else	
		CreateModal("IBXXXX02", 0, 0x9f-4, 99);
}
**/

void CMainFrame::AcctGroupConfig()
{
	if (Axis::isCustomer)
	{
		int onlysise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0);
		if (!Axis::devMode && onlysise) 
			return;
	}
	if (Axis::isCustomer)
	{
		m_mapHelper->CreateChild("IB0000A4", 0);
	}
	else
		m_mapHelper->CreateChild("IB0000A2", 0);
	//m_mapHelper->CreateModal("IB0000A2", 0x9f-5, 97);
}

void CMainFrame::AcctPasswordConfig()
{
	int onlysise = m_axis->GetProfileInt(WORKSTATION, "OnlySise", 0);

	if (!Axis::devMode && onlysise)
		return;
	
	m_mapHelper->CreateModal("IB0000A1", 0, 0x9f-4, 99);
}

void CMainFrame::AcctAliasConfig()
{
	AcctConfig();
}

void CMainFrame::AcctConfig()
{
	CAccountConfig config;

	config.DoModal();
}

void CMainFrame::TotalSetup(UINT id)
{
	if (!id)
		id = IDD_ESETUP;
	
	CTotalSetup dlg(m_tMenu, id, 0);
	dlg.DoModal();

	if (dlg.IsApplied(IDD_ESETUP))
	{
		load_eninfomation(false);
		SetConclusion();

	//	load_start_notice(true);
	//	change_BackGround();
	}

	if (dlg.IsApplied(IDD_MNGSETUP))
		load_mngSetup();

	if (dlg.IsApplied(IDD_ORDER_SETUP))
		SetConclusion();

	if (dlg.IsApplied(IDD_IMAGESETUP))
		change_Skin();

	if (dlg.IsApplied(IDD_SETTICKINFO))
	{
		load_tickInfo();
	}

	if (dlg.IsApplied(IDD_HOTKEY))
		load_hkey();

	if (dlg.IsApplied(IDD_TSETUP))
	{
		m_bar1->Refresh();
		m_smain->Refresh();
	}

	if (dlg.IsApplied(IDD_FUNCTIONS))
		m_bar1->RefreshFunc();
}

LRESULT CMainFrame::ApplySetup(UINT id)
{
	switch (id)
	{
	case IDD_ESETUP:
		load_eninfomation(false);
		break;
	case IDD_MNGSETUP:
		load_mngSetup();
		break;
	case IDD_ORDER_SETUP:
		SetConclusion();
		break;
	case IDD_IMAGESETUP:
		change_Skin();
		break;
	case IDD_SETTICKINFO:
		load_tickInfo();
		break;
	case IDD_HOTKEY:
		load_hkey();
		break;
	case IDD_TSETUP:
		m_bar1->Refresh();
		m_smain->Refresh();
		break;
	case IDD_FUNCTIONS:
		m_bar1->RefreshFunc();
		break;
	}
	return 0;
}

void CMainFrame::load_tickInfo()
{
	ConfigTicker(true);
	sendTicInfo();
	/**
	ShowControlBar(m_tInfo1, dlg.m_bTickView[0], FALSE);
	ShowControlBar(m_tInfo2, dlg.m_bTickView[1], FALSE);
	ShowControlBar(m_bar2, dlg.m_bScreenBar, FALSE);
	**/

	CProfile profile(pkAxisTicker);
	ShowControlBar(m_tInfo1, profile.GetInt(szGeneral, "view1", 1), FALSE);
	ShowControlBar(m_tInfo2, profile.GetInt(szGeneral, "view2", 1), FALSE);
	//ȭ���Ϲ� ����
	ShowControlBar(m_bar2, profile.GetInt(szGeneral, "screenbar", 1), FALSE);
	if (profile.GetInt(szGeneral, "screenbar", 1) && (m_bar0->GetStyle() & WS_VISIBLE))
		ShowControlBar(m_bar0, TRUE, FALSE);
	saveToolStatus();
	SetSDIChangeHeight();
	//ȭ���Ϲ� ���� ��
	
	if (m_bSDI)
	{
		saveToolStatus();
		SetSDIChangeHeight();
	}
}

void CMainFrame::processMapVersionInfo(WPARAM wParam, LPARAM lParam)
{
	/**
	��ȭ�� �ǽð� Update
  : FEV_VERS �޽����� ����
    lParam   : ȭ��� \t ȭ��� \t ...
    wParam : lParam length 
	**/

	CStringArray maps;
	CString buffer((const char*)lParam), str;
	while (TRUE) {
		str = Parse(buffer);
		if (str.IsEmpty())
			break;

		if (str.GetLength() == L_MAPN)
		{
			str = str.Mid(2, 4);
			BOOL exist = FALSE;

			for (int i = 0; i < maps.GetSize(); i++)
			{
				if (maps[i] == str)
				{
					exist = TRUE;
					break;
				}
			}
			if (!exist)
				maps.Add(str);
		}
	}

	if (maps.GetSize() > 0)
	{
		//**CDebug::Out(Format("%d maps changed. first map name is %s", maps.GetSize(), maps[0]));
		for (int i = 0; i < maps.GetSize(); i++)
		{
			if (IsExistMap(maps[i]))
			{
				ShowMngInfo(
					Format("[%s] %s ȭ���� ����Ǿ����ϴ�.", maps[i], GetMapName(maps[i])), 0);
			}
		}
	}
}

void CMainFrame::ShowMngInfo(CString msg, int kind)
{
	m_mngInfo->SetData(msg, kind);

	CRect		mRc;
	WINDOWPLACEMENT	pl;
	GetWindowPlacement(&pl);
	switch (pl.showCmd)
	{
	case SW_HIDE:case SW_MINIMIZE:case SW_SHOWMINIMIZED:
		m_mngInfo->ShowWindow(SW_HIDE);
		if(kind == 3)
		{
			m_slideMsg = msg;
		}
		return;
	default:
		break;
	}
	m_mngInfo->ShowWindow(SW_HIDE);

	MngInfoPos();
	
	if (kind!=3) SetTimer(TM_AUTOMNGINFO, 3000, NULL);
}

BOOL CMainFrame::IsExistMap(const char* mapName)
{
	const int vsCount = 6;
	
	for (int i = 0; i < vsCount; i++)
	{
		if (IsExistMap(mapName, i))
			return TRUE;
	}
	return FALSE;
}

BOOL CMainFrame::IsExistMap(const char* mapName, int vs)
{
	int key;
	CChildFrame* pChild;
	CSChild* sChild;

	POSITION pos = m_arMDI[vs].GetStartPosition();
	while (pos)
	{
		m_arMDI[vs].GetNextAssoc(pos, key, pChild);
		ASSERT(pChild->m_mapN.GetLength() == L_MAPN);
		if (pChild->m_mapN.Mid(2, 4) == mapName)
			return TRUE;
	}

	pos = m_arSDI[vs].GetStartPosition();
	while (pos)
	{
		m_arSDI[vs].GetNextAssoc(pos, key, sChild);
		ASSERT(sChild->m_mapN.GetLength() == L_MAPN);
		if (sChild->m_mapN.Mid(2, 4) == mapName)
			return TRUE;
	}
	return FALSE;
}

CString CMainFrame::GetMapName(const char* mapName)
{
	return m_tMenu->GetDesc(Format("IB%s00", mapName));
}

CString CMainFrame::get_glb_addr(char* macaddr, char* ip)
{
	typedef long (WINAPI *GETGLBFUNC)(char*, char*, int, char*, int, bool);
	HMODULE hModule = LoadLibrary("axisglb.dll");
	CString ips("");
	
	if (hModule)
	{
		GETGLBFUNC func = (GETGLBFUNC)GetProcAddress(hModule, "axGetGLB");
		if (func)
		{
			typedef struct {
				char user[12];
				char pass[8];
				char dats[10];
				char cpas[30];
				char uips[15];
				char madr[16];
				char cNull;
			} axglbM;

			typedef struct {
				char result;  // R: ok  X: failed (ip�� �ش�) ===> X, R �̿��� �÷����� ��� ���� �޽��� ó�� ����.
				char ip[32];
				char cNull;
			} axglbRcv; 

			axglbM mid;
			axglbRcv mod;
			CString str = m_axConnect->GetSignInfo();

			Axis::userID = m_axConnect->GetUserID();
			m_pass = m_axConnect->GetPassword();
			m_cpass  = m_axConnect->GetCPass();

			memset(&mid, ' ', sizeof(mid));
			memset(&mod, ' ', sizeof(mod));

			FormatCopy(mid.user, Axis::userID);
			FormatCopy(mid.pass, m_pass);
			CopyMemory(mid.dats, str, str.GetLength());
			FormatCopy(mid.cpas, m_cpass);
			FormatCopy(mid.uips, ip);
			FormatCopy(mid.madr, macaddr);

			int len =  func((char*)(const char*)(Axis::home + "\\" + TABDIR), 
				(char*)&mid, sizeof(axglbM), (char*)&mod, sizeof(axglbRcv), (bool)!Axis::isCustomer);

			ips = CString(mod.ip, sizeof(mod.ip));
			ips.TrimRight();

			m_axis->WriteProfileString(INFORMATION, "Server", ips);	
		}
		FreeLibrary(hModule);
	}

	return ips;
}

CString CMainFrame::GetChildWindowCaption(int key)
{
	CString caption("");

	CChildFrame* child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild*	schild;
		if (m_arSDI[m_vsN].Lookup(key, schild))
		{
			schild->GetWindowText(caption);
		}
	}
	else
	{
		child->GetWindowText(caption);
	}

	return caption;
}

LRESULT CMainFrame::SetChildMinMaxInfo(int key, MINMAXINFO* lpMinMaxInfo)
{
	CChildFrame* child;
	if (!m_arMDI[m_vsN].Lookup(key, child))
	{
		CSChild* schild;
		if (m_arSDI[m_vsN].Lookup(key, schild))
		{
			schild->SetMinMaxInfo(lpMinMaxInfo);
		}
	}
	else
	{
		child->SetMinMaxInfo(lpMinMaxInfo);
	}

	return 0L;
}

BOOL CMainFrame::DrawCaption(CDC* dc, CRect rc, int height)
{
	CBitmap* bmpHead, * bmpBack, * bmpBackEnd;

	if (m_activeCap)
	{
		if (m_bar1)
		{
			if (m_bar1->IsWindowVisible())
			{
				bmpHead = (Axis::GetSkinBitmap("TITLE",true));
				bmpBack = (Axis::GetBitmap("FRAME_MIDDLE"));
				bmpBackEnd = (Axis::GetSkinBitmap("FRAME_SIDE"));
			}
			else
			{
				bmpHead = (Axis::GetSkinBitmap("TITLE2",true));
				bmpBack = (Axis::GetBitmap("FRAME_MIDDLE"));
				bmpBackEnd = (Axis::GetSkinBitmap("FRAME_SIDE"));
			}
		}
		else
		{
			bmpHead = (Axis::GetSkinBitmap("TITLE",true));
			bmpBack = (Axis::GetBitmap("FRAME_MIDDLE"));
			bmpBackEnd = (Axis::GetSkinBitmap("FRAME_SIDE"));
		}
	}
	else
	{
		if (m_bar1)
		{
			if (m_bar1->IsWindowVisible())
			{
				bmpHead = (Axis::GetSkinBitmap("XN_TITLE",true));
				bmpBack = (Axis::GetBitmap("XN_FRAME_MIDDLE"));
				bmpBackEnd = (Axis::GetBitmap("XN_FRAME_SIDE"));
			}
			else
			{
				bmpHead = (Axis::GetSkinBitmap("XN_TITLE2",true));
				bmpBack = (Axis::GetBitmap("XN_FRAME_MIDDLE"));
				bmpBackEnd = (Axis::GetBitmap("XN_FRAME_SIDE"));
			}
		}
		else
		{
			bmpHead = (Axis::GetSkinBitmap("XN_TITLE",true));
			bmpBack = (Axis::GetBitmap("XN_FRAME_MIDDLE"));
			bmpBackEnd = (Axis::GetBitmap("XN_FRAME_SIDE"));
		}
		
	}

	if (!bmpHead || !bmpBack)
		return FALSE;

	CBitmap *oldBmp;
	CDC mdc;

	rc.bottom = rc.top + height;

	BITMAP bmHead, bmBack;
	bmpHead->GetBitmap(&bmHead);
	bmpBack->GetBitmap(&bmBack);

	mdc.CreateCompatibleDC(dc);

	oldBmp = mdc.SelectObject(bmpHead);
	
	//if (Axis::isVista)
	//	dc->BitBlt(/*rc.left, rc.top, */-1, 0, bmHead.bmWidth, bmHead.bmHeight, &mdc, 0, 0, SRCCOPY);
	//else
		dc->BitBlt(rc.left, rc.top-1, bmHead.bmWidth, bmHead.bmHeight, &mdc, 0, 0, SRCCOPY);

	rc.left += bmHead.bmWidth;
	//if (Axis::isVista) rc.left--;

	mdc.SelectObject(bmpBack);
	//if (Axis::isVista)
	//	dc->StretchBlt(/*rc.left, rc.top,*/rc.left-(VistaFrame+1), 0, rc.Width(), rc.Height(), &mdc, 0, 0, bmBack.bmWidth, bmBack.bmHeight, SRCCOPY);
	//else
		dc->StretchBlt(rc.left, rc.top-1, rc.Width(), rc.Height(), &mdc, 0, 0, bmBack.bmWidth, bmBack.bmHeight, SRCCOPY);

	/*if (bmpBackEnd)
	{
		mdc.SelectObject(bmpBackEnd);
		BITMAP bm;
		bmpBackEnd->GetBitmap(&bm);
		
		dc->BitBlt(rc.right - bm.bmWidth - 1, rc.top, bm.bmWidth, bm.bmHeight, &mdc, 0, 0, SRCCOPY);
	}*/

	mdc.SelectObject(oldBmp);

	return TRUE;
}

LRESULT CMainFrame::SetMenuMode(int menuMode, int height)
{
	RecalcLayout();
	return 0;
}

void CMainFrame::DrawFrame(CDC* dc)
{
	CRect rc;
	GetWindowRect(&rc);

	rc.OffsetRect(-rc.TopLeft());

	const int szFrame = 3;
	COLORREF frameColor = RGB(198, 207, 216);
	COLORREF borderColor = RGB(0, 0, 0);

	if (!m_bSDI)
	{
		CBitmap* bmpBgPattern  = Axis::GetSkinBitmap("BG_PATERN");

		CDC mdc;
		mdc.CreateCompatibleDC(dc);
		CBitmap* oldBmp = mdc.SelectObject(bmpBgPattern);

		BITMAP bm;
		bmpBgPattern->GetBitmap(&bm);

		rc.top += CAPTION_HEIGHT;
		rc.bottom += 2;
		rc.left++;
		rc.right--;
		
		dc->StretchBlt( rc.left, rc.top, 2, rc.Height(), &mdc, 0,0, bm.bmWidth, bm.bmHeight, SRCCOPY );
		dc->StretchBlt( rc.right-2, rc.top, 2, rc.Height(), &mdc, 0,0, bm.bmWidth, bm.bmHeight, SRCCOPY );
		

		/*rc.top += CAPTION_HEIGHT;
		rc.bottom += 2;
		rc.left += 1;
		rc.right -= 2;
		for (int i = 3; i <= 4; i++)
		{
			CPen* oldPen;
			CPen pen(PS_SOLID, 1, Axis::GetColor(i));
			oldPen = dc->SelectObject(&pen);

			dc->MoveTo(rc.left, rc.top);
			dc->LineTo(rc.left, rc.bottom);

			dc->MoveTo(rc.right, rc.top);
			dc->LineTo(rc.right, rc.bottom);
			dc->SelectObject(oldPen);

			rc.left++;
			rc.right--;
		}*/
	}
	else
	{
		rc.left++;
		rc.right--;
		
		for (int i = 0; i < szFrame; i++)
		{
			CPen* oldPen;
			CPen pen(PS_SOLID, 1, Axis::GetColor(3));
			oldPen = dc->SelectObject(&pen);

			dc->MoveTo(rc.left, rc.top);
			dc->LineTo(rc.left, rc.bottom);

			dc->MoveTo(rc.right, rc.top);
			dc->LineTo(rc.right, rc.bottom);
			dc->SelectObject(oldPen);

			rc.left++;
			rc.right--;
		}
	}

}

void CMainFrame::DrawBorder(CDC* dc)
{
	CRect rc;
	GetWindowRect(&rc);

	rc.OffsetRect(-rc.TopLeft());

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, Axis::GetColor(1));

	CPen* oldPen = dc->SelectObject(&pen);

	dc->MoveTo(rc.left, rc.top);
	dc->LineTo(rc.left, rc.bottom - 1);
	dc->LineTo(rc.right - 1, rc.bottom - 1);
	dc->LineTo(rc.right - 1, rc.top);
	dc->LineTo(rc.left, rc.top);

	dc->SelectObject(oldPen);
}

void CMainFrame::SetUserInfo()
{
	Axis::userID = m_axis->GetProfileString(WORKSTATION, SIGNONID);
	m_axis->WriteProfileInt(WORKSTATION, "HTS", 1);
	int pos = Axis::userID.Find('|');
	if (pos >= 0)
	{
#if 0
		// ������ ���丮 ��ȣȭ ����
		if (Axis::isCustomer)
		{
			Axis::userNM = Axis::userID.Mid(pos + 1);
			Axis::userID = Axis::userID.Left(pos);
			Axis::user   = Axis::userNM;
		}
		else
#endif
		{
			Axis::userNM = Axis::userID.Mid(pos + 1);
			Axis::userID = Axis::userID.Left(pos);
			Axis::user.Format("%08u", HashKey<LPCSTR>(Axis::userNM));
		}
		
		//m_axis->WriteProfileString(WORKSTATION, SIGNONID, Axis::userID +"|");

		if (!Axis::userID.CompareNoCase("guest") && !m_axis->GetProfileString(WORKSTATION, "BackUserID").IsEmpty())
		{
			Axis::userID = m_axis->GetProfileString(WORKSTATION, "BackUserID");
		}
	}
	else
	{
		Axis::user = "Anonymous";
	}
}

void CMainFrame::DoFunc(int funcID)
{
	switch (funcID - CTRL_FUNC)
	{
	case 1: // ȯ�漳��
		TotalSetup();
		break;
	case 2: // �μ�
		printImg();
		break;
	case 3: // ȭ�����
		LockProg();
		break;
	case 4: // ���º�й�ȣ����
		AcctPasswordConfig();
		break;
	case 5: // ����� WORKSPACE
		//ShowUScreenMenu();
		saveUserScreen();
		break;
	case 6: // ���ǰ���
		ExecuteCalculator();
		break;
	case 7: // �ؿ����� �ǽð�ƼĿ
		RunForeignMap();
		break;
	case 8: // �̹�������(����ȭ��)
		saveImg();
		break;
	case 9: // �����ü�����
		m_mapHelper->ChangeChild(MAPN_LINKEXCEL);
		break;
	case 12: // reserved..
		break;
	}
}

void CMainFrame::ExecuteCalculator()
{
	ShellExecute(NULL, _T("open"), "SecCalc.exe", NULL,NULL, SW_SHOWNORMAL);
}

void CMainFrame::GoHomepage()
{
	CProfile profile(GetProfileFileName());
	CString web(profile.GetString(szWebLink, "home", IBK_HOME_URL));
	if (web.IsEmpty())
		return;
	ShellExecute(NULL, _T("open"), web, NULL, NULL, SW_SHOWNORMAL);
}

void CMainFrame::UnderConstruction()
{
	Axis::MessageBox(this, "�غ����Դϴ�.", MB_ICONINFORMATION);
}

void CMainFrame::RecalcFrame()
{
	RecalcLayout();
	DrawFrame();
}

void CMainFrame::ShowSingleWindows(BOOL bShow)
{
	CSChild* schild;
	int key;
	for (POSITION pos = m_arSDI[m_vsN].GetStartPosition(); pos; )
	{
		m_arSDI[m_vsN].GetNextAssoc(pos, key, schild);
		schild->ShowWindow(bShow ? SW_SHOW: SW_HIDE);
	}
}

CString CMainFrame::GetUserPassword()
{
	return m_pass;
}

CString CMainFrame::GetCertPassword()
{
	return m_cpass;
}

CRect CMainFrame::GetWndRect()
{
	CRect rc;
	if (m_bSDI)
		GetDesktopWindow()->GetWindowRect(&rc);
	else
		m_MClient->GetWindowRect(&rc);

	return rc;
}

CWnd* CMainFrame::GetClock()
{
	return m_Nclock;
}

void CMainFrame::GetLocalIP()
{
	//m_ipAddr = "172.17.2.74";
	//return;
	char szHostName[64] = {0};

	::gethostname(szHostName, sizeof(szHostName));

	if(lstrcmp(szHostName, "") != 0)
	{
		HOSTENT FAR* lphostent = ::gethostbyname(szHostName);
		CString	tmps, serverips = m_ip;

		tmps = m_axis->GetProfileString(INFORMATION, "Port", 
			Format("%d", m_bCustomer? portProxy: portEmployee));
		UINT	port = atoi(tmps);

		CSocket	sock;
		sock.Create();

		if (sock.Connect(serverips, port))
		{
			IN_ADDR	in;
			SOCKADDR_IN sockAddr;
			int nSize = sizeof(SOCKADDR_IN);
			getsockname(sock.m_hSocket, (PSOCKADDR)&sockAddr, &nSize);
			sock.Close();

			CopyMemory(&in, &sockAddr.sin_addr.s_addr, sizeof(IN_ADDR));
			tmps = inet_ntoa(in);
			tmps.TrimRight();
			m_ipAddr = tmps;
		}
		else
		{
			for (int ii = 0; lphostent; ii++)
			{
				if (!lphostent->h_addr_list[ii])
					break;
				sprintf(szHostName, "%u.%u.%u.%u",
					0xff & lphostent->h_addr_list[ii][0],
					0xff & lphostent->h_addr_list[ii][1],
					0xff & lphostent->h_addr_list[ii][2],
					0xff & lphostent->h_addr_list[ii][3]);
				m_ipAddr = szHostName;
			}
		}
	}
}

//** FIRE WALL (INCA)
void CMainFrame::InitFirewall()
{
	OutputDebugString("InitFirewall\n");
	if (m_Npnx.IsExecute()) return;
	m_Npnx.m_strCurrentPath =	Axis::home + "\\exe";

//	m_Npnx.m_strCustomerID =	"ibkistest";
	m_Npnx.m_strCustomerID =	"ibkis";					//** npn_��ü��.conf
	
	m_Npnx.m_strModulePath =	Axis::home + "\\exe";
	m_Npnx.m_hWnd = GetSafeHwnd();
	//m_Npnx.Init();
	m_Npnx.Quick();
}

void CMainFrame::FreeFirewall()
{
	if (m_Npnx.m_hModule)
		m_Npnx.CloseNetizen();
}

//** macho add end


LRESULT CMainFrame::OnPhonePad(WPARAM wParam, LPARAM lParam)
{

	//MessageBox((char*)lParam);

	SetForegroundWindow();
	//m_mapHelper->ChangeChild(m_activeMapN);
	CChildFrame* child = (CChildFrame *) MDIGetActive();

	Setfocus_Child(m_activeKey);
	//child->SetFocus();
	int len = wParam;
	int ii = 0;
	CString ddd;
	ddd.Format("%d",lParam);
	for(ii=0;ii<(len-ddd.GetLength());ii++)
		ddd = "0"+ddd;

	//AfxMessageBox(ddd);
	
	if (!m_mapHelper->IsDLL(m_activeMapN))
	{
		//TRACE("MAP\n");
		CString dat = ddd;
		CString sdat;
		sdat = "zPwd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		sdat = "pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		sdat = "ed_pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		/*
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		*/	
	}else
	{
		
		stopDllMessage = false;
		CString dat;
		dat = (char*) lParam;
		sendDllMessage(child->m_hWnd, (long) ddd.operator LPCTSTR());
		if (!stopDllMessage)
		{
			//MessageBox("��й�ȣ �Է¶��� ã�� �� �����ϴ�.");
		}
		
	}	

	return 1;
}

LRESULT CMainFrame::OnRefresh813(WPARAM wParam, LPARAM lParam)
{
	if (m_TotalAcc) m_TotalAcc->Refresh813((int)lParam);
	return 1;
}

void CMainFrame::sendDllMessage(HWND sdm, LPARAM lparam)
{
	HWND sub_cont_hwnd=0;
	int dd;
	do
	{
		dd = 0;
		sub_cont_hwnd = FindWindowEx(sdm, sub_cont_hwnd, NULL, NULL);
		
		if ((int)sub_cont_hwnd > 32 )
		{
			//::GetClassName(sub_cont_hwnd, test, 255);
			//MessageBox(test);
			dd = ::SendMessage(sub_cont_hwnd, WM_USER+1111, 0,lparam);
			if (dd == 1)
			{
				//MessageBox("Find it");
				stopDllMessage = true;
			}
			if (stopDllMessage) break;
			sendDllMessage(sub_cont_hwnd, lparam);
		}
	}while( (int)sub_cont_hwnd > 32 );
}

void CMainFrame::ReadPhonePad(int fill)
{
	CPhonePad* m_phone_dlgs;
	m_phone_dlgs = new CPhonePad(this);
	m_phone_dlgs->main_hwnd = m_hWnd;
	//m_phone_dlgs->ShowWindow(SW_SHOWNORMAL);
	m_phone_dlgs->DoModal();
	
	//m_phone_dlgs->SetWindowPos(&wndTopMost,0,0,0,0, SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
	return;
			

	//==============��Ʈ ����============
	if(PHONEPAD_PortOpen(0))
	{
		PHONEPAD_InitDevice();
		PHONEPAD_SetConfig(0,10);	
		PHONEPAD_GetPWSignalWindow(m_hWnd);
		
		
		//if (m_phone_dlgs)
		{
			m_phone_dlgs = new CPhonePad(this);
			m_phone_dlgs->ShowWindow(SW_SHOWNORMAL);
			
			m_phone_dlgs->SetWindowPos(&wndTopMost,0,0,0,0, SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
			
			//m_phone_dlgs->BringWindowToTop();
			
		}
		
		MessageBox("���е� ���� ����(Port Open Success)!!","IBK��������");
	}
	else
	{
		//char * tmp = "0423";
		//PostMessage(WM_PHONEPAD,0,(long)tmp);
		MessageBox("���е� ���� ����(Port Open Failure)!!","IBK��������");
		return;
	}
	//==============��й�ȣ �о���� ����============
	// TODO: Add your control notification handler code here
	char * temp = NULL;
	int  loop=1;
	int  limit = 0;

	
	while(loop)
	{			
		//temp = PHONEPAD_GetPassWDSTR();
		//if(temp != NULL) break;		
		Sleep(300);
		
		switch(PHONEPAD_Status())
		{
		case 0: 
			break;     // normal
			
		case 1: 
			loop = 0; 
			temp = PHONEPAD_GetPassWDSTR();
			break;     //  ��й�ȣ �Է¿Ϸ�
			
		case 2: 
			MessageBox("�ð��� �ʰ��Ͽ����ϴ�.","IBK��������");
			m_phone_dlgs->CloseWindow();
			//m_phone_dlgs = NULL;
			return; 
			break;       //  ��й�ȣ �Է����
		}
		Sleep(300);
		
		limit++;
		if (limit>=20) break;
	}
	if (limit == 20)
	{
		m_phone_dlgs->CloseWindow();
		//m_phone_dlgs = NULL;
		MessageBox("�Է� �ð��� �ʰ��Ǿ����ϴ�.","IBK��������");
		
	}	
	//�޾ƿ� ��й�ȣ
	//AfxMessageBox((LPCTSTR)temp);
	CString g_pwd = temp;
	//AfxMessageBox(g_pwd);
	g_pwd.TrimLeft(); g_pwd.TrimLeft();
	//g_pwd.Delete(g_pwd.GetLength()-1);
	//AfxMessageBox("g_pwd: "+g_pwd);
	SetPwd(g_pwd);
	//PostMessage(WM_PHONEPAD,0,(long)g_pwd.operator LPCTSTR());
	//m_stpw.SetWindowText((LPCTSTR)temp);
	
	//==============��й�ȣ �о���� ��============
	
	//==============��Ʈ �ݱ�============
	PHONEPAD_PortClose();

}

void CMainFrame::SetPwd(CString strpwd)
{

	//MessageBox((char*)lParam);
	
	

	SetForegroundWindow();
	//m_mapHelper->ChangeChild(m_activeMapN);
	CChildFrame* child = (CChildFrame *) MDIGetActive();

	Setfocus_Child(m_activeKey);
	//child->SetFocus();
	CString ddd;

	if (!m_mapHelper->IsDLL(m_activeMapN))
	{
		//TRACE("MAP\n");
		CString dat = strpwd;
		CString sdat;
		sdat = "zPwd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		sdat = "pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		sdat = "ed_pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		/*
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		*/	
	}else
	{
		stopDllMessage = false;
		CString dat;
		dat = strpwd;
		sendDllMessage(child->m_hWnd, (long) dat.operator LPCTSTR());
		if (!stopDllMessage)
		{
			//MessageBox("��й�ȣ �Է¶��� ã�� �� �����ϴ�.");
		}
	}	

//	return 1;
}

bool CMainFrame::CheckClientWidth(CChildFrame*	child, int preFontSize)
{
	CRect rt, crt;
	GetWindowRect(rt);
	child->GetWindowRect(crt);
	CString tmp;
	double rate;
	if (((m_preFontSize == 8) || (m_preFontSize == 9)) && ((preFontSize == 8) || (preFontSize == 9))) rate = 1;
	else if (((m_preFontSize == 8) || (m_preFontSize == 9)) && ((preFontSize == 10) || ((preFontSize == 11)))) rate = 1.1647;
	else if (((m_preFontSize == 8) || (m_preFontSize == 9)) && (preFontSize == 12)) rate = 1.32915;
	else if (((m_preFontSize == 10) || (m_preFontSize == 11)) && ((preFontSize == 12))) rate = 1.1413;
	else if (((preFontSize == 8) || (preFontSize == 9)) && ((m_preFontSize == 8) || (m_preFontSize == 9))) rate = 1;
	else if (((preFontSize == 8) || (preFontSize == 9)) && ((m_preFontSize == 10) || ((m_preFontSize == 11)))) rate = 1/1.1647;
	else if (((preFontSize == 8) || (preFontSize == 9)) && (m_preFontSize == 12)) rate = 1/1.32915;
	else if (((preFontSize == 10) || (preFontSize == 11)) && ((m_preFontSize == 12))) rate = 1/1.1413;
	else return true;

	int nCx = int(crt.Width()*rate);
	//tmp.Format("%d<=>%d(%d)\n",crt.left+nCx,rt.right,nCx);
	//TRACE(tmp);
	
	if (crt.left+nCx > rt.right)
	{
		//refleshMap(child->m_key);
		long rc = 0;
		int value = m_preFontSize;
		if(value>0)
		{
			int ret = MessageBox("ǥ���Ҽ� �ִ� ������ ���� �����ϴ�.\n��������Ͻðڽ��ϱ�?","IBK��������",MB_YESNO);
			if (ret == IDNO)
				return false;
		}
	}
	return true;
}

void CMainFrame::CheckSoundConfig()
{
#if 1
	// �Ʒ� ��ƾ�� ���� ���������� Path�� ���Դµ� �ϴ�!
	return;
#else
	CString ordcfg_path = Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, "ordcfg.ini");
	if (IsFileExist(ordcfg_path))
	{
		CProfile profile(ordcfg_path);
		CString	m_waveF[MAXSOUND];
		CString section = "Common";
		m_waveF[IDX_MDORDER] = profile.GetString(section, "SOUNDFILE_MDORDER", m_waveF[IDX_MDORDER]);
		m_waveF[IDX_MSORDER] = profile.GetString(section, "SOUNDFILE_MSORDER", m_waveF[IDX_MSORDER]);
		m_waveF[IDX_JJORDER] = profile.GetString(section, "SOUNDFILE_JJORDER", m_waveF[IDX_JJORDER]);
		m_waveF[IDX_CSORDER] = profile.GetString(section, "SOUNDFILE_CSORDER", m_waveF[IDX_CSORDER]);
		m_waveF[IDX_MDCON]   = profile.GetString(section, "SOUNDFILE_MDCON",   m_waveF[IDX_MDCON]);
		m_waveF[IDX_MSCON]   = profile.GetString(section, "SOUNDFILE_MSCON",   m_waveF[IDX_MSCON]);
		m_waveF[IDX_REFUSAL] = profile.GetString(section, "SOUNDFILE_REFUSAL", m_waveF[IDX_REFUSAL]);
		
		//�ʱ� ������ ����
		for(int i=0; i<7;i++)
		{
			if (m_waveF[i].Find("C:\\Program Files\\IBKS\\HTS"))
			{
				if (Axis::home != "C:\\Program Files\\IBKS\\HTS")
				{
					if (!IsFileExist(m_waveF[i]))
					{
						if(m_waveF[i].Find("image\\"))
						{
							m_waveF[i].Delete(0,m_waveF[i].Find("image\\"));
							m_waveF[i] = Axis::home +"\\"+ m_waveF[i];
						}
					}
				}
			}
		}
		profile.Write(section, "SOUNDFILE_MDORDER", m_waveF[IDX_MDORDER]);
		profile.Write(section, "SOUNDFILE_MSORDER", m_waveF[IDX_MSORDER]);
		profile.Write(section, "SOUNDFILE_JJORDER", m_waveF[IDX_JJORDER]);
		profile.Write(section, "SOUNDFILE_CSORDER", m_waveF[IDX_CSORDER]);
		profile.Write(section, "SOUNDFILE_MDCON",	m_waveF[IDX_MDCON]);
		profile.Write(section, "SOUNDFILE_MSCON",	m_waveF[IDX_MSCON]);
		profile.Write(section, "SOUNDFILE_REFUSAL", m_waveF[IDX_REFUSAL]);
	}
#endif
}

void CMainFrame::CheckNewsSetting()
{
	//return;
	
	CString	file, section, keys, value;
	bool m_bHk = false;
	bool m_bMk = false;
	bool m_bAs = false; //�ƽþư���
	bool m_bHr = false; //�췲�����
	int idx = -1;
	int bx = -1; int by = -1;

	file.Format("%s\\user\\%s\\%s", Axis::home, Axis::user, TICKSETUP);
	if(!IsFileExist(file)) return;
	//if (GetPrivateProfileInt("InitNewsVer", "VER", 0, file)>0) return;
	_tickitem* item = new _tickitem;
	for (int ii = 0; ii < TICKBAR_CNT; ii++)
	{
		for (int jj = 0; jj < SPLIT_CNT; jj++)
		{
			

			section.Format("BAR_INFO_%d%d", ii, jj);
			item->kind = GetPrivateProfileInt(section, "INDEXK", 0, file);
			switch (item->kind)
			{
			case TKIND_NEWS:
				{
					bx = ii; by = jj;
					item->aux = 0;
					item->sAry.RemoveAll();
					item->selectN = 0;
					for (int kk = 0, hh; ; kk++)
					{
						keys.Format("%02d", kk);
						hh = GetPrivateProfileInt(section, keys, -1, file);
						idx = kk;
						if (hh == -1)	break;
						value.Format("%d", hh);
						if (hh == 12) m_bHr = true;
						if (hh == 11) m_bAs = true;
						if (hh == 10) m_bMk = true;
						if (hh == 9) m_bHk = true;
						item->sAry.Add(value);
					}
					//keys = _T("AUX");
					//item->aux = GetPrivateProfileInt(section, keys, 0, file);

					//if (!item->sAry.GetSize())	item->sAry.Add("1");
				}
				break;

			default:
				//AfxMessageBox("Tick infomation load Error!");
				continue;
			}
		}
	}
	// 2011.07.22 leak! by warship
	delete item; item = NULL;

	if ((bx==-1) ||(by==-1)||(idx==-1)) return;
	if (GetPrivateProfileInt("InitNewsVer", "VER", 0, file)<=0)
	{
		if(!m_bAs)
		{
			section.Format("BAR_INFO_%d%d", bx, by);
			keys.Format("%02d", idx);
			value = "11";//item->sAry.GetAt(kk);
			//AfxMessageBox(section +"]["+keys+"]["+ value);
			WritePrivateProfileString(section, keys, value, file);
			WritePrivateProfileString("InitNewsVer", "VER", "1", file);
			idx++;
		}
		if(!m_bHk)
		{
			section.Format("BAR_INFO_%d%d", bx, by);
			keys.Format("%02d", idx);
			value = "9";//item->sAry.GetAt(kk);
			//AfxMessageBox(section +"]["+keys+"]["+ value);
			WritePrivateProfileString(section, keys, value, file);
			WritePrivateProfileString("InitNewsVer", "VER", "1", file);
			idx++;
		}
	}
	if (GetPrivateProfileInt("InitNewsVer", "VER_ASIA", 0, file)<=0)
	{
		if(!m_bMk)
		{
			section.Format("BAR_INFO_%d%d", bx, by);
			keys.Format("%02d", idx);
			value = "10";//item->sAry.GetAt(kk);
			//AfxMessageBox(section +"]["+keys+"]["+ value);
			WritePrivateProfileString(section, keys, value, file);
			WritePrivateProfileString("InitNewsVer", "VER_ASIA", "1", file);
			idx++;
		}
	}
	
	if (GetPrivateProfileInt("InitNewsVer", "VER_HERALD", 0, file)<=0)
	{
		if(!m_bHr)
		{
			section.Format("BAR_INFO_%d%d", bx, by);
			keys.Format("%02d", idx);
			value = "12";//item->sAry.GetAt(kk);
			//AfxMessageBox(section +"]["+keys+"]["+ value);
			WritePrivateProfileString(section, keys, value, file);
			WritePrivateProfileString("InitNewsVer", "VER_HERALD", "1", file);
		}
	}
	
}

BOOL CMainFrame::IsWebMenu(const char *MapName)
{
	CProfile profile(Format("%s\\%s\\WEBINFO.INI", Axis::home, TABDIR));

	return !profile.GetString(CString(MapName).Mid(2, 4), "Type").IsEmpty();
}

BOOL CMainFrame::IsHelpMenu(const char *MapName)
{
	CProfile profile(Format("%s\\%s\\HELPLIST.INI", Axis::home, TABDIR));
	
	return !profile.GetString("SCREENLIST",CString(MapName).Mid(0, 8)).IsEmpty();
}


CString CMainFrame::Variant(int nComm, CString strData)
{
	//������� ���� �������� ��Ʈ���� ���� ������ ���н� �÷��� ����ڿ� ���� �ؾ���
	CString strRet(_T(""));
	char* pRet = NULL;
		
	long rc = 0;
	
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_I4, (void *)&rc,
		(BYTE *)(VTS_I4 VTS_I4), nComm, 0);
	strRet = rc ? (char *)rc : _T("");
	
	/*
	pRet = (char*)m_wizard->SendMessage(WM_USER, MAKEWPARAM(variantDLL, nComm), (LPARAM)(LPCTSTR)strData);
	
	if ((long)pRet > 1)
		strRet = pRet;
	*/	
	return strRet;
}

void CMainFrame::ChangeLogo()
{
	if (m_bSDI)
	{
		m_bitmapBtn->ShowWindow(SW_HIDE);
		return;
	}
	else
	{
		if (!m_bitmapBtn->IsWindowVisible())
			m_bitmapBtn->ShowWindow(SW_SHOW);
	}
	if (m_bar1->IsWindowVisible())
	{
		//m_bitmapBtn->MoveWindow(5,0, 71,55);
		m_bitmapBtn->SetWindowPos( NULL, 5,0, 71,55, SWP_NOZORDER );
		m_bitmapBtn->SetImgBitmap(Axis::GetSkinBitmap("LOGO", true), 1);
	}
	else
	{
		//m_bitmapBtn->MoveWindow(4,-1, 71,22);
		m_bitmapBtn->SetWindowPos( NULL, 5,0, 71,24, SWP_NOZORDER );
		m_bitmapBtn->SetImgBitmap(Axis::GetSkinBitmap("LOGO2", true), 1);
	}
}

bool CMainFrame::IsFileExist(CString filename)
{
     CFileFind   finder;

     if(!finder.FindFile(filename))
            return FALSE;

     return TRUE;
}

BOOL CMainFrame::IsNoFontMenu(const char *MapName)
{
	CProfile profile(Format("%s\\%s\\HELPLIST.INI", Axis::home, TABDIR));
	
	return !profile.GetString("NOFONTLIST",CString(MapName).Mid(0, 8)).IsEmpty();
}

void CMainFrame::InitMapSize()
{
	CString name = "IBINITSIZE";
	CProfile pout(pkUserConfig);
	pout.Write(name, "OnLoad", 1);
	int	key = 0;
	CChildFrame*	pChild = NULL;
	CSChild*	sChild = NULL;
	for ( int ii = 0 ; ii < 6 ; ii++ )
	{
		POSITION	pos = m_arMDI[ii].GetStartPosition();
		while (pos)
		{
			m_arMDI[ii].GetNextAssoc(pos, key, pChild);
			actionCaption(pChild->m_key, IDX_FONTX);
		}

		pos = m_arSDI[ii].GetStartPosition();
		while (pos)
		{
			m_arSDI[ii].GetNextAssoc(pos, key, sChild);
			actionCaption(sChild->m_key, IDX_FONTX);
		}
	}
}

bool CMainFrame::SetToolAccount(CString acnt, int wparam)
{
	CChildFrame* child = (CChildFrame *) MDIGetActive();
	if (m_activeMapN.Mid(0,6)=="IB7700")	return true;
	Setfocus_Child(m_activeKey,TRUE);
	//child->SetFocus();
	CString ddd;
	CStringArray sary;
	
	sary.Add("AN10"); sary.Add("AN30"); sary.Add("AN11"); sary.Add("AN12"); sary.Add("AN13");
	sary.Add("AN14"); sary.Add("AN15"); sary.Add("AN24");  sary.Add("AN50");
	sary.Add("AN99"); sary.Add("AN01"); sary.Add("AN16"); sary.Add("AN17"); 
	sary.Add("AN22"); sary.Add("AN19"); sary.Add("AN18"); sary.Add("AN31"); sary.Add("AN32");
	sary.Add("AN33"); sary.Add("AN34"); sary.Add("AN1A"); sary.Add("AN1B"); sary.Add("AN00");
	sary.Add("AN97"); sary.Add("AN98"); sary.Add("AN51");
	
	sary.Add("AN20");sary.Add("AN21");
	

	//if (!m_mapHelper->IsDLL(m_activeMapN))
	{
		//TRACE("MAP\n");
		CString dat = acnt;
		CString sdat;
		/*
		sdat = "AN20\t"+dat;
		
		int		key;
		POSITION	pos;
		CChildFrame*	pChild;
		
		for (pos = m_arMDI[m_vsN].GetStartPosition(); pos; )
		{
			m_arMDI[m_vsN].GetNextAssoc(pos, key, pChild);
			//if (m_mapHelper->IsDLL(pChild->m_mapN)) continue;
			if (key != m_activeKey)	key |= 0xff00;

			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, key), (LPARAM)(const char*)sdat);
			break;
		}
		*/
		
		
		for (int jj = 0; jj<sary.GetSize(); jj++)
		{
			sdat = sary.GetAt(jj)+"\t"+dat;//+"\nACNM\t\"������";
			
			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
								(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		}
		/*
		for (int jj = 0; jj<sary.GetSize(); jj++)
		{
			sdat = sary.GetAt(jj)+"\t"+dat;//+"\nACNM\t\"������";

			m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
								(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		}
		*/
		/*
		sdat = "pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		sdat = "ed_pswd\t"+dat;
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)sdat);
		/*
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		dat = "zPwd\t0423";
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
							(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setFDC, m_activeKey), (LPARAM)(const char*)dat);
		*/	
	}
	/*
	else
	{
		//DLL�ΰ�� ���� �ɻ����ó��
		stopDllMessage = false;
		CString dat;
		dat = acnt;
		
		//sendDllMessage(child->m_hWnd, (long) dat.operator LPCTSTR());
		if (!stopDllMessage)
		{
			//MessageBox("��й�ȣ �Է¶��� ã�� �� �����ϴ�.");
		}
	}	
	*/
	return true;
}

void CMainFrame::PopupPosWeb(CString url, int left, int top, int cx, int cy)
{
	if (url.Find("@") != -1)
	{
		ShellExecute(NULL, _T("open"), url, NULL,NULL, SW_SHOWNORMAL);
		return;
	}
	
	//CString tmp;
	

	CString HomePage = url;
	VARIANT vFlags = {0},
	vTargetFrameName = {0},
	vPostData = {0},
	vHeaders = {0};

	HRESULT hr;
	_bstr_t	bstr(HomePage);
	UINT	nFlag = SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW;
	WINDOWPLACEMENT	pl;

	if (FAILED(hr = CoInitialize(NULL)))
		return;

	struct	IWebBrowserApp* pWEBApp;
	HWND	hWEB;
	if (FAILED(hr = CoCreateInstance(CLSID_InternetExplorer,
			NULL, CLSCTX_SERVER, IID_IWebBrowserApp,
			(LPVOID*)&pWEBApp)))
	{
		return;
	}

	cx += GetSystemMetrics(SM_CXFRAME) * 2;
	cx += GetSystemMetrics(SM_CXBORDER) * 4;
	cy += GetSystemMetrics(SM_CYFRAME) * 2;
	cy += GetSystemMetrics(SM_CYBORDER) * 4;
	cy += GetSystemMetrics(SM_CYCAPTION);
	pWEBApp->put_Width(cx);
	pWEBApp->put_Height(cy);
	pWEBApp->put_Left(left);//VARIANT_TRUE);
	pWEBApp->put_Top(top);//VARIANT_TRUE);
	pWEBApp->put_ToolBar(VARIANT_FALSE);
	pWEBApp->put_StatusBar(VARIANT_FALSE);
	//pWEBApp->put_Title("IBK�������� ����");
	hr = pWEBApp->Navigate(bstr, &vFlags, &vTargetFrameName, &vPostData, &vHeaders);
	if (HomePage.IsEmpty())	pWEBApp->GoHome();
	pWEBApp->put_Visible(VARIANT_TRUE);
	VariantClear(&vPostData);

	pWEBApp->get_HWND((long *)&hWEB);
	::GetWindowPlacement(hWEB, &pl);
	if (pl.showCmd & SW_SHOWMINIMIZED)
	{
		pl.showCmd = SW_RESTORE;
		::SetWindowPlacement(hWEB, &pl);
	}
	else	
		::SetWindowPos(hWEB, HWND_TOPMOST, 0, 0, 0, 0, nFlag);
	
	::SetWindowLong(hWEB, GWL_EXSTYLE, ::GetWindowLong(hWEB, GWL_EXSTYLE) | WS_EX_TOPMOST);
	
	CoUninitialize();
	//SendMessage(WM_ACTIVATE);
	//SetActivateWindow(m_hWnd);
	SetForegroundWindow();

	
}

void CMainFrame::ReadNotice()
{
	CString	Path;
	Path.Format("%s\\%s\\%s\\notice.dat", Axis::home, USRDIR, Axis::user);
	int nrec, grec; nrec = grec = 0;
	int pos  = 0;
	CString gpid, gpnm;

	bool find = false;
	struct	_grid {
		char	url[255];		 /* �����ڵ�			 */
		char    width[5];                /* �����                       */
		char    height[5];                 /* ���簡                       */
		char    use[1];                 /* ���ϴ��      (9999V99)      */
		char	cookie[20];				//��Ű��
	};

	struct  _urlData {
		char	nrec[4];		// count jcode
		struct	_grid	grid[1];	// data
	};
	
	CString		url, width, height, use, cookie;
	
	TRY
	{
		CFile file;
		if (file.Open(Path, CFile::modeRead)) 
		{
			int len = file.GetLength();
			if (len > 0)	
			{
				char	*dat = new char[len];
				file.Read(dat, len);
		
				_urlData*	urlData = (struct _urlData*) dat;
				
				int	cnt = atoi(CString(urlData->nrec, sizeof(urlData->nrec)));
				int left, top; left = top = 0;
				DWORD dwSize = 1024;
				TCHAR szData[1024]; 
				CString value;

				bool bRet, find;
				int ipos;
				for (int ii = 0; ii < cnt; ii++)
				{
					//FillMemory(urlData->grid[ii].url, sizeof(urlData->grid[ii].url), ' ');
					url    = CString(urlData->grid[ii].url, sizeof(urlData->grid[ii].url));	url.TrimRight();
					width  = CString(urlData->grid[ii].width, sizeof(urlData->grid[ii].width));	width.TrimRight();
					height = CString(urlData->grid[ii].height, sizeof(urlData->grid[ii].height));	height.TrimRight();
					use    = CString(urlData->grid[ii].use, sizeof(urlData->grid[ii].use));	use.TrimRight();
					cookie = CString(urlData->grid[ii].cookie, sizeof(urlData->grid[ii].cookie));	cookie.TrimRight();
					width.Remove(',');
					height.Remove(',');

					bRet = false;
					find = false;
					bRet = (bool)InternetGetCookie(url,NULL, szData, &dwSize);//szData, &dwSize);
					
					if (bRet) 
					{
						value = szData;
						ipos = value.Find(cookie+"=");
						//CString tmp; tmp.Format("ipos: [%d], cookie: [%s=]\n%s",ipos, cookie, szData);
						//AfxMessageBox(tmp);
						if (ipos!=-1) find = true;
					}

					if (!find)
					PopupPosWeb(url, left, top, atoi(width), atoi(height));
					
					left += atoi(width);
					left += 10; //����
					
				}				
				delete[] dat;
			}
			file.Close();
		}
	}
	CATCH (CFileException, e) 
	{
	}
	END_CATCH;
	
	
	//HttpQueryInfo(hURL, HTTP_QUERY_EXPIRES, &dwCertSize, &dwSize, 0);
	/*
	CInternetSession m_Session;
	CInternetFile * pInternetFile = NULL;

	char bufQuery[256];
	ZeroMemory(bufQuery, sizeof(bufQuery));
	BOOL bQuery = FALSE;
	CString strUrl;
	strUrl.Format("http://www.ibks.com/");
	DWORD dwLengthBufQuery;
	pInternetFile = (CInternetFile*)m_Session.OpenURL(strUrl, 1, INTERNET_FLAG_TRANSFER_BINARY, NULL, 0);
	CHttpFile *pHttpFile = (CHttpFile *)pInternetFile;
	bQuery = pHttpFile->QueryInfo(HTTP_QUERY_EXPIRES, bufQuery, &dwLengthBufQuery);
	AfxMessageBox(bufQuery);
	*/
	
}

void CMainFrame::ReadNoticeMap()
{
	CString	PathConf,PathCookie;
	PathConf.Format("%s\\%s\\NOTICECONF.INI", Axis::home, "tab");
	PathCookie.Format("%s\\%s\\NOTICECOOKIE.INI", Axis::home, "tab");

	int nrec, grec; nrec = grec = 0;
	int pos  = 0;
	CString gpid, gpnm;
	
	bool find = false;

// 	OutputDebugString(Path);
// 	OutputDebugString("\n");
	CString		url;
	
	TRY
	{
		nrec = GetPrivateProfileInt("BANNER","imgCount",0,PathConf);
		CString s;
		s.Format("[NREC : %d]",nrec);
		//OutputDebugString(s);

		for(int i=0;i<nrec;i++)
		{
			CString strKey;
			strKey.Format("B%d",i);
// 			s.Format("[KEY : %s]",strKey);
// 			OutputDebugString(s);
			int nomore = GetPrivateProfileInt(strKey,"nomore",1,PathConf);
			int showlayer = GetPrivateProfileInt(strKey,"showlayer",1,PathConf);

			int user = GetPrivateProfileInt(strKey,"USER",1,PathConf);

			if(Axis::isCustomer && user == 1)
			{
				continue;
			}
			else if(!Axis::isCustomer && user == 2)
			{
				continue;
			}

			if(nomore == 0)
			{
				int left = GetPrivateProfileInt(strKey,"LEFT",0,PathConf);
				int top = GetPrivateProfileInt(strKey,"TOP",0,PathConf);

				CString date;

				CTime time;
				time = CTime::GetCurrentTime();

				date.Format("%04d%02d%02d",time.GetYear(),time.GetMonth(),time.GetDay());

				char readB[1024];
				int readL;

				readL = GetPrivateProfileString(strKey,"FROM",date,readB,sizeof(readB),PathConf);

				CString strFrom(readB,readL);
// 				s.Format("[FROM : %s]",strFrom);
// 				OutputDebugString(s);
				readL = GetPrivateProfileString(strKey,"TO",date,readB,sizeof(readB),PathConf);
				
				CString strTo(readB,readL);
// 				s.Format("[TO : %s]",strTo);
// 				OutputDebugString(s);

// 				s.Format("[DATE : %s]",date);
// 				OutputDebugString(s);
				if(atoi(date) < atoi(strFrom) || atoi(date) > atoi(strTo))
				{
					OutputDebugString("[Out Of Date]\n");
					continue;
				}
				
				int update = GetPrivateProfileInt(strKey,"update",0,PathConf);

				if(update == 1)
				{
					WritePrivateProfileString(strKey,"nomore","0",PathCookie);
					WritePrivateProfileString(strKey,"update","0",PathConf);
				}

				int type = GetPrivateProfileInt(strKey,"readtype",0,PathConf);

				if(type == 0)
				{
					int cookie_nomore = GetPrivateProfileInt(strKey,"nomore",0,PathCookie);
					
					if(cookie_nomore != 0)
					{
// 						readL = GetPrivateProfileString(strKey,"TO",date,readB,sizeof(readB),PathCookie);
// 
// 						CString cookieTo(readB,readL);
// 
// 						if(atoi(date) <= atoi(cookieTo))
// 						{
// 							OutputDebugString("[Cookie Out Of Date]\n");
// 							continue;
// 						}
// 						else
// 						{
// 							WritePrivateProfileString(strKey,"nomore","0",PathCookie);
// 						}
						continue;
					}
				}

				if(showlayer == 1)
				{
					if(strKey == "B0")
					{
						left = 50;
						top = 50;
					}
					else if(strKey == "B1")
					{
						left = 400;
						top = 400;

					}
					else if(strKey == "B2")
					{
						left = 200;
						top = 200;
					}
				}

// 				s.Format("[X : %d Y : %d]\n",left,top);
// 				OutputDebugString(s);
				
				if(strKey == "B0")
					m_mapHelper->CreateChild("AM080101",0,0,LtopPOS,CPoint(left,top));
				else if(strKey == "B1")
					m_mapHelper->CreateChild("AM080201",0,0,CenterPOS,CPoint(left,top));
				else if(strKey == "B2")
					m_mapHelper->CreateChild("AM080301",0,0,RbottomPOS,CPoint(left,top));
			}
		}

		if(!Axis::isCustomer)
		{
			CString strStaffKey;
			strStaffKey = "STAFF";
	// 			s.Format("[KEY : %s]",strKey);
	// 			OutputDebugString(s);
			int nomore = GetPrivateProfileInt(strStaffKey,"nomore",1,PathConf);

			if(nomore == 0)
			{
				int left = GetPrivateProfileInt(strStaffKey,"LEFT",0,PathConf);
				int top = GetPrivateProfileInt(strStaffKey,"TOP",0,PathConf);

				CString date;

				CTime time;
				time = CTime::GetCurrentTime();

				date.Format("%04d%02d%02d",time.GetYear(),time.GetMonth(),time.GetDay());
				
				char readB[1024];
				int readL;

				readL = GetPrivateProfileString(strStaffKey,"FROM",date,readB,sizeof(readB),PathConf);

				CString strFrom(readB,readL);
	// 				s.Format("[FROM : %s]",strFrom);
	// 				OutputDebugString(s);
				readL = GetPrivateProfileString(strStaffKey,"TO",date,readB,sizeof(readB),PathConf);
				
				CString strTo(readB,readL);
	// 				s.Format("[TO : %s]",strTo);
	// 				OutputDebugString(s);

	// 				s.Format("[DATE : %s]",date);
	// 				OutputDebugString(s);
				if(atoi(date) < atoi(strFrom) || atoi(date) > atoi(strTo))
				{
					OutputDebugString("[Out Of Date]\n");
					return;
				}
				
				int update = GetPrivateProfileInt(strStaffKey,"update",0,PathConf);

				if(update == 1)
				{
					WritePrivateProfileString(strStaffKey,"nomore","0",PathCookie);
					WritePrivateProfileString(strStaffKey,"update","0",PathConf);
				}

				int type = GetPrivateProfileInt(strStaffKey,"readtype",0,PathConf);

				if(type == 0)
				{
					int cookie_nomore = GetPrivateProfileInt(strStaffKey,"nomore",0,PathCookie);
					
					if(cookie_nomore != 0)
					{
	// 						readL = GetPrivateProfileString(strKey,"TO",date,readB,sizeof(readB),PathCookie);
	// 
	// 						CString cookieTo(readB,readL);
	// 
	// 						if(atoi(date) <= atoi(cookieTo))
	// 						{
	// 							OutputDebugString("[Cookie Out Of Date]\n");
	// 							continue;
	// 						}
	// 						else
	// 						{
	// 							WritePrivateProfileString(strKey,"nomore","0",PathCookie);
	// 						}
						return;
					}
				}
				
				m_mapHelper->CreateChild("AM080401",0,0,RtopPOS,CPoint(6,0));
			}
		}
	}
	CATCH (CFileException, e) 
	{
	}
	END_CATCH;
}

CString CMainFrame::GetMyThemeName()
{
	/*
	WCHAR szThemeName[MAXARRAY] = { 0 };
	WCHAR szColorBuff[MAXARRAY] = { 0 };
	WCHAR szSizeBuff[MAXARRAY] = { 0 }; 
	HRESULT hr = GetCurrentThemeName(szThemeName, MAXARRAY,
	szColorBuff, MAXARRAY, 
	szSizeBuff, MAXARRAY ); 
	TCHAR tmp[MAXARRAY]; 
	TCHAR tmp2[MAXARRAY]; 
	CString stheme;
	

	if (SUCCEEDED( hr )) 
	{
		 //WidecharToMultibyte(
		wcstombs(tmp,szThemeName,MAXARRAY);
		wcstombs(tmp2,szSizeBuff,MAXARRAY);
		
		stheme = tmp;  stheme.TrimRight();
		if (!stheme.IsEmpty())
		{
			int FindPos = -1;
			int FindPos2 = -1;
			for(int dd = stheme.GetLength(); dd>1;dd--)
			{
				if(stheme[dd] == '\\')
				{
					FindPos = dd;
					break;
				}
				if (stheme[dd] == '.') FindPos2 = dd;
			}
			if (FindPos > 0) stheme = stheme.Mid(FindPos+1, FindPos2-FindPos-1); 

		}
		stheme.MakeUpper();
		return stheme;
		
	}
	
	*/
	return "";
}

void CMainFrame::RunPhonePad()
{
	CString	aps, cmds, exes;
	STARTUPINFO		si;
	PROCESS_INFORMATION	pi;

	ZeroMemory(&si, sizeof(STARTUPINFO));
	ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

	si.cb          = sizeof(STARTUPINFO);
	si.dwFlags     = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_SHOW;

	CAxisApp* app = (class CAxisApp *) AfxGetApp();
	char	buffer[1024];
	GetClassName(m_hWnd, buffer, sizeof(buffer));
	cmds.Format(" %d", m_hWnd);
	aps.Format("%s\\%s\\PhonePadDlg.exe", Axis::home, RUNDIR);

	BOOL bRc = CreateProcess(
			aps,				// application name
			(char *)(const char*)cmds,// command line
			NULL,				// process attribute
			NULL,				// thread attribute
			FALSE,				// is inherit handle
			0,					// creation flags
			NULL,				// environment
			NULL,				// current directory
			&si,				// STARTUPINFO
			&pi);				// PROCESS_INFORMATION
}

BOOL CMainFrame::IsPhonePad(const char *map)
{
	const char* foreignMapName = "IB877700";

	return !strcmp(foreignMapName, map);
}

void CMainFrame::dnloadAction()
{
	CString filePath, fileTemp, m_root, m_name;
	m_root = Axis::home;
	m_name = Axis::user;
	filePath.Format("%s/%s/%s/%s", m_root, USRDIR, m_name, saveFILE);
	/*
	if (IsFileExist(filePath))
	  ::DeleteFile(filePath);
	*/
	WritePrivateProfileString("GROUPORDER", "00", "", filePath);
	struct	_uinfo	uinfo;
	
	FillMemory((char*) &uinfo, sizeof(_uinfo), ' ');
	
	CopyMemory(uinfo.gubn, "MY", sizeof(uinfo.gubn));
	uinfo.dirt[0] = 'D';
	uinfo.cont[0] = 'F';
	CopyMemory(uinfo.nblc, "00000", sizeof(uinfo.nblc));
	
	sendTR("pihomyst", (char*)&uinfo, sz_uinfo, 0, 'Q');
	ChangeLogo();
	m_info_interest = new CInfo_Interest(this);
	m_info_interest->DoModal();

}

void CMainFrame::parsingOubsDN(char *datB, int datL)
{
	if (datL < sz_updn)
	{
		TRACE("dnload : response length error....[%d]\n", datL);
		//updnWaitAction(1); 
		SetTimer(TM_DNINTEREST, 1000, NULL);
		return;
	}
	
	int	parseL = 0;
	struct _updn* updn = (struct _updn *) &datB[0];
	parseL += sz_updn;
	
	if (updn->uinfo.retc[0] == 'E')
	{
		TRACE("dnload : response error....[%s]\n", CString(updn->uinfo.emsg, sizeof(updn->uinfo.emsg)));
		//updnWaitAction(1); 
		//load_tabview();
		SetTimer(TM_DNINTEREST, 1000, NULL);
		return;
	}
	
	CString	gnox, gnam, jcnt;
	
	gnox = CString(updn->ginfo.gnox, sizeof(updn->ginfo.gnox)); 
	gnox.TrimRight();
	
	gnam = CString(updn->ginfo.gnam, sizeof(updn->ginfo.gnam)); 
	gnam.TrimRight();
	jcnt = CString(updn->ginfo.jrec, sizeof(updn->ginfo.jrec)); 
	jcnt.TrimRight();
	
	//TRACE("kwon [%s] [%s] [%s] [%c]\n", gnox, gnam, jcnt, updn->uinfo.cont[0]);
	//CString tmp; tmp.Format("kwon [%s] [%s] [%s] [%c] [%d] [%d]\n", gnox, gnam, jcnt, updn->uinfo.cont[0] , parseL + (atoi(jcnt) * sz_jinfo) , datL);
	
	if (parseL + (atoi(jcnt) * sz_jinfo) <= datL)
		SetDnloadData(atoi(gnox), gnam, atoi(jcnt), &datB[parseL]);

	if (updn->uinfo.cont[0] != 'L')
	{
		struct	_uinfo	uinfo;
		FillMemory((char*)&uinfo, sz_uinfo, ' ');
		
		CopyMemory((char *)&uinfo, (char*) &updn->uinfo, sz_uinfo);
		sendTR("pihomyst", (char *)&uinfo, sz_uinfo, 0, 'Q');
		TRACE("kwon Upload\n");
		return;
	}

	if (m_bdnInterest)
	{
		//load_tabview();
		SetTimer(TM_DNINTEREST, 1000, NULL);
	}
	
	//m_updown = 0; 
	//updnWaitAction(2); 
	//m_guide = idTOstring(IDS_GUIDE6); 

}

int CMainFrame::SetDnloadData(int gno, CString gname, int count, char *datB)
{
	int	readL = 0;
	char	readB[512];
	CString	string = _T("");
	
	CString filePath, fileTemp, m_root, m_name;
	m_root = Axis::home;
	m_name = Axis::user;
	filePath.Format("%s/%s/%s/%s", m_root, USRDIR, m_name, saveFILE);
	fileTemp.Format("%s/%s/%s/%s", m_root, USRDIR, m_name, tempFILE);
	
	CString	section; 
	section.Format("%02d", gno);
	
	readL = GetPrivateProfileString("GROUPORDER", "00", "", readB, sizeof(readB), filePath);
	string = CString(readB, readL); string += section; string += ";"; 
	WritePrivateProfileString("GROUPORDER", "00", string, filePath);
	WritePrivateProfileString("GROUPORDER", "00", string, fileTemp);
	
	WritePrivateProfileString("GROUPNAME", section, gname, filePath); WritePrivateProfileString(NULL, NULL, NULL, filePath);
	WritePrivateProfileString("GROUPNAME", section, gname, fileTemp); WritePrivateProfileString(NULL, NULL, NULL, fileTemp);
	
	filePath.Format("%s/%s/%s/portfolio.i%02d", m_root, USRDIR, m_name, gno);
	CString fileBook;
	fileBook.Format("%s/%s/%s/bookmark.i%02d", m_root, USRDIR, m_name, gno);
	
	struct  _bookmarkinfo* bInfo;
	bool isfile = false;
	CFile	fileB;
	if (IsFileExist(fileBook))
	{
		fileB.Open(fileBook, CFile::modeRead);
				
		if (fileB.m_hFile != CFile::hFileNull) 
		{
			isfile = true;
		}
	}
	
	
	CFile	fileH(filePath, CFile::modeWrite|CFile::modeCreate);
	if (fileH.m_hFile == CFile::hFileNull) return 0;
	
	int	parseL = 0;
	CString	code(_T(""));
	CString name(_T(""));
	
	//090101 ..�����...������ ���۸� �̷��� ��Ƴ��� ���� �Ҿ����ݾƤ� 
	//	char	wB[64] = {' ', };
	CString wB;
	
	//	char*	xxP;
	CString xxP;
	
	struct	_inters	inters;
	struct	_jinfo* jinfo;
	CString cname;
	for (int ii = 0; ii < count; ii++)
	{
		jinfo = (struct _jinfo *) &datB[parseL];
		parseL += sz_jinfo;
		
		memset((void*)&inters, 0, sz_inters);
		
		inters.gubn[0] = jinfo->gubn[0];
		CopyMemory(inters.code, jinfo->code, sizeof(jinfo->code));
		CopyMemory(inters.xprc, jinfo->xprc, sizeof(jinfo->xprc));
		CopyMemory(inters.xnum, jinfo->xnum, sizeof(jinfo->xnum));
		//CopyMemory(inters.name, jinfo->hnam, sizeof(jinfo->hnam));
		
		code = CString(inters.code, sizeof(inters.code)); 
		
		if(code.Left(1) != " ")
		{
			code.TrimRight();
		}
		
		//		strncpy(wB, (char*)code.operator LPCTSTR(), code.GetLength());
		//		xxP = (char *)m_parent->SendMessage(WM_USER, MAKEWPARAM(nameDLL, 0), (LPARAM)wB);
		//		xxP = m_parent->SendMessage(WM_USER, MAKEWPARAM(nameDLL, 0), (LPARAM)(LPSTR)(LPCTSTR)code.operator LPCTSTR());	
		xxP = GetCodeName(code);
		
		name = xxP; 
		name.TrimLeft(); 
		name.TrimRight();
		
		if(code.Left(1) == " ")
		{
			name = "      ";
		}
		if (isfile)
		{
			
			bInfo = (_bookmarkinfo *) new char[sizeof(_bookmarkinfo)];
			ZeroMemory(bInfo, sizeof(_bookmarkinfo));

			readL = fileB.Read(bInfo, sizeof(_bookmarkinfo));

			if(readL < sizeof(_bookmarkinfo))
			{
							delete bInfo;
			}
			else
			{
				CString temp = CString((jinfo->code));
				
				temp = temp.Left(12);
				temp.TrimRight();
				CString temp2 = CString(bInfo->code, sizeof(bInfo->code));
				
				temp2.TrimRight();
				/*
				if(code.Left(1) == 'm')
				{
					if (temp2.GetLength() != 6)
					{
						CString tmp; tmp.Format("[%d][%d][%s][%s]",temp.GetLength(), temp2.GetLength(), temp, temp2);
						MessageBox(tmp);
					}
				}
				*/				

				if(strcmp(temp, temp2) == 0)
				{
					if (code.Left(1) == 'm')
					{
						//CopyMemory(pinter->name, bInfo->name, sizeof(bInfo->name));
						//AfxMessageBox("");
						name = CString(bInfo->name, sizeof(bInfo->name));
					}
					//inters.bookmark[0] = bInfo->bookmark[0];
					//pinter->bookmark[0] = bInfo->bookmark[0];
				}
			}
		}	
		
		strncpy(inters.name, (LPSTR)(LPCTSTR)name, name.GetLength());
		
		fileH.Write(&inters, sz_inters);
	}
	
	fileH.Close(); 
	return count;
}

void CMainFrame::UploadFile()
{
	CString		file, fileN, str, zipfile;
	CFile		hFile;
	char		sndB[UPMAXSIZE];
	bool m_wait = false;
	zipfile = Compress("ordcfg.ini");
		if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	/*	
	zipfile = Compress("axisensetup.ini");
	if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	zipfile = Compress("usertool.ini");
	if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	zipfile = Compress("axisticker.ini");
	if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	str.Format("%s.ini", Axis::user);
	zipfile = Compress(str);
	if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	zipfile = Compress("memo.mmo");
	if (!zipfile.IsEmpty())
	{
		m_sfilelist.Add(zipfile);
		str.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, zipfile);
		m_removelist.Add(str);
	}
	
	str.Format("%s\\gex\\%s", Axis::home, Axis::user);
	CompressChart(str);
	//m_sfilelist.Add(Compress(str));
	*/
	
	for (;;)
	{
		//str.Format("size : %d", m_sfilelist.GetSize());
		//AfxMessageBox(str);
		if (m_sfilelist.GetSize() <= 0)
		{
			m_wait = false;
			::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
			str.LoadString(ST_USEINFO_TEXT_ENDWORK);
			/*
			for (int ii = 0; ii < m_removelist.GetSize(); ii++)
				::DeleteFile(m_removelist.GetAt(ii));
			m_removelist.RemoveAll();
			*/
			removeCompressfile();
			return;
		}
		fileN = m_sfilelist.GetAt(0);
		m_sfilelist.RemoveAt(0);
		
		
		
		if (fileN.Find(".ini") >= 0 || fileN.Find(".mmo") >= 0)
			file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, fileN);
		else
		{
			if (fileN.Find("IB7") >= 0 || fileN.Find("ib7") >= 0)
				file.Format("%s\\gex\\%s\\%s", Axis::home, Axis::user, fileN);
			else if(fileN.Find("dat") >= 0 || fileN.Find("cht") >= 0)
				file.Format("%s\\user\\%s\\Chart\\%s", Axis::home, Axis::user, fileN);
		}
			//file.Format("%s\\gex\\%s\\%s", Axis::home, Axis::user, fileN);
		
		if (!hFile.Open(file, CFile::modeRead | CFile::typeBinary))
			continue;
		
		int fileL = hFile.GetLength();
		int fSize = L_usr+fileL;
		if (fileL > UPMAXSIZE)
		{
			hFile.Close();
			str.Format("%s�� ���� ����� �ʰ� �Ͽ����ϴ�.", fileN);
			Axis::MessageBox(this, str, MB_ICONSTOP);
			continue;
		}
		
		_userTH*	userTH = (_userTH *) sndB;
		usrinfo*	info = (usrinfo *) &sndB[L_userTH];
		
		memset(sndB, ' ', fSize);
		hFile.Read(&sndB[L_userTH + L_usr], fileL);
		hFile.Close();
		
		sprintf(userTH->trc, "PIDOUPDN");
		userTH->key = 'L';
		userTH->stat = US_PASS;
		
		sprintf(info->gubn, "UD");
		info->dirt[0] = 'U';	// pc -> host
		CopyMemory(info->name, fileN, fileN.GetLength());
		sprintf(info->nblc, "%05d", fileL);
		info->retc[0] = '0';
		
		BOOL	rc = FALSE;
		m_wizard->InvokeHelper(DI_TRX, DISPATCH_METHOD, VT_BOOL, (void *)&rc,
			(BYTE *)(VTS_I4 VTS_I4), (long)sndB, fSize);
		
	}
}

CString CMainFrame::Compress(CString target, CString path)
{
	//if (!m_upload)	return target + ".zip";
	
	CString		zipFile, srcFile;
	
	if (path.IsEmpty())
		srcFile.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, target);
	else
		srcFile.Format("%s\\%s", path, target);
	
	// does zip source file exist?
	if (_taccess(srcFile, 04))	// can read?
	{
		CString	str;
		str.Format("%s\t%s", srcFile, "������ ã�� �� �����ϴ�.");
		//m_errfile.Add(str);
		return _T("");
	}
	
	// use only the file name for zip file entry
	TCHAR * cp = _tcsrchr(srcFile, _T('\\'));
	if (cp == NULL)
		cp = (TCHAR *)(const char *)srcFile;
	else
		cp++;
	
	zipFile.Format("%s.zip", srcFile);
	HZIP hz = CreateZip((void *)(const char *) zipFile, 0, ZIP_FILENAME);
	if (hz)
	{
		ZRESULT zr = ZipAdd(hz, cp, (void *)(const char *)srcFile, 0, ZIP_FILENAME);
		CloseZip(hz);
		
		// did add work?
		if (zr != ZR_OK)
			zipFile.Empty();
		else	zipFile.Format("%s.zip", target);
	}
	
	return zipFile;
}

void CMainFrame::CompressChart(CString path)
{
	/*
	if (!m_upload)
	{
		int	ncnt = m_chartlist.GetSize();
		CString	filename, temp;

		if (!ncnt)
		{
			m_sfilelist.Add(CHART_OLD);
			filename.Format("%s\\%s", path, CHART_OLD);
			m_removelist.Add(filename);
		}
		else
		{
			for ( int ii = 0 ; ii < ncnt ; ii++ )
			{
				temp = m_chartlist.GetAt(ii);
				m_sfilelist.Add(temp);
				filename.Format("%s\\%s", path, temp);
				m_removelist.Add(filename);				
			}
		}
		return;
	}
	*/
	
	CString		zipfile;
	WIN32_FIND_DATA FindFileData;
	HANDLE		hFind;
	
	CString		allfile, filename;

	allfile.Format("%s\\*.zip", path);
	hFind = FindFirstFile(allfile, &FindFileData);
	
	while (hFind != INVALID_HANDLE_VALUE)
	{
		filename.Format("%s\\%s", path, FindFileData.cFileName);
		::DeleteFile(filename);
		if (!FindNextFile(hFind, &FindFileData))	break;
	}

	//**allfile.Format("%s\\*.c*", path);
	allfile.Format("%s\\IB7*.*", path);
	hFind = FindFirstFile(allfile, &FindFileData);
	
	while (hFind != INVALID_HANDLE_VALUE)
	{
		filename.Format("%s\\%s", path, FindFileData.cFileName);
		if (!(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
		{
			TCHAR * cp = _tcsrchr(filename, _T('\\'));
			
			if (cp == NULL)
				cp = (TCHAR *)(const char*)filename;
			else
				cp++;

			zipfile = Compress(cp, path);		// ����� ȯ�漳��
			
			if (!zipfile.IsEmpty())
			{
				m_sfilelist.Add(zipfile);				
				m_removelist.Add(filename + ".zip");	
			}	
		}

		if (!FindNextFile(hFind, &FindFileData))	break;
	}	
}

void CMainFrame::removeCompressfile()
{
	CString	file;
	
	for (int ii = 0; ii < m_removelist.GetSize(); ii++)
		::DeleteFile(m_removelist.GetAt(ii));
	m_removelist.RemoveAll();
}

void CMainFrame::SendConfig()
{

	struct	_pidouini_mid	uini;
	
	FillMemory((char*) &uini, sizeof(_pidouini_mid), ' ');
	CString sval, sdat;
	CString str(""), maps;
	
	for (int i = m_savelist.GetSize()-1; i >= 0; i--)
	{
		if (str.Find(m_savelist.GetAt(i))!=-1) continue;
		if (i==m_savelist.GetSize()-1)
			maps = m_savelist.GetAt(i);
		else
			maps.Format(", %s", m_savelist.GetAt(i));
		
		str += maps;
	}
	sval = str;
	//==================================================
		
	CTime	time;
	time = time.GetCurrentTime();
	sdat.Format("%04d%02d%02d", time.GetYear(), time.GetMonth(), time.GetDay());
	CString fname = Axis::user + ".ini";
	CopyMemory(uini.gubn, "I", sizeof(uini.gubn));
	CopyMemory(uini.item.usid, Axis::userID, sizeof(uini.item.usid));
	CopyMemory(uini.item.innm, fname, sizeof(uini.item.innm));
	CopyMemory(uini.item.senm, "LASTSTAT", sizeof(uini.item.senm));
	CopyMemory(uini.item.skey, "maps", sizeof(uini.item.skey));
	CopyMemory(uini.item.valu, sval, sizeof(uini.item.valu));
	CopyMemory(uini.item.date, sdat, sizeof(uini.item.date));
	
	sendTR("pidouini", (char*)&uini, sz_pidouini, 0, 'N');
}

void CMainFrame::RotateView(int tp)
{
	CString sdat;
	sdat.Format("ROTATEVIEW\t%d", tp);
	m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setNDC, 0), (LPARAM)(const char*)sdat);
	//OutputDebugString(sdat);
	/*
	if (tp==1)
	{
		m_wizard->InvokeHelper(DI_WIZARD, DISPATCH_METHOD, VT_EMPTY, (void *)NULL,
			(BYTE *)(VTS_I4 VTS_I4), MAKELONG(setNDC, 0), (LPARAM)(const char*)sdat);

	}
	else
	{

	}
	*/
}

CString CMainFrame::GetCodeName(CString code)
{
	code = code.Left(12);
	code.TrimRight();
	code.TrimLeft();
	code.Remove(0);
	
	int codeL = code.GetLength();

	if (codeL == 6)					// kospi code
	{
		_shjcode   hjcode; 
		for (int ii = 0; ii < m_hjcode.GetSize(); ii++)
		{
			hjcode = m_hjcode.GetAt(ii);
			if (code != hjcode.code)
				continue;

			switch (hjcode.kosd)
			{
			case jmKOSPI:
			case jmKOSDAQ:
			case jm3RD:
				if (hjcode.ssgb == jmELW)
					return hjcode.name;
				break;
			}
			return hjcode.name.Mid(1);
		}

	}
	else if (codeL == 9)				// �����μ��� �߰�
	{
		_shjcode   hjcode; 
		for (int ii = 0; ii < m_hjcode.GetSize(); ii++)
		{
			hjcode = m_hjcode.GetAt(ii);
			if (code != hjcode.code)
				continue;
			
			switch (hjcode.kosd)
			{
			case jmSINJU:
				if (hjcode.ssgb == jmSINJU)
					return hjcode.name;
				break;
			}
			return hjcode.name.Mid(1);
		}
	}
	else if (codeL <= 3)				// upjong code
	{
		struct	upcode	upcode;
		for (int ii = 0 ; ii < m_upcode.GetSize() ; ii++)
		{
			upcode = m_upcode.GetAt(ii);
			
			CString upCodeStr;
			int upCodeInt;
			upCodeStr.Format("%d%02d", upcode.jgub, upcode.ucod);
			upCodeInt = atoi(upCodeStr);
			
			if (atoi(code) != upCodeInt)
				continue;
			
			return CString(upcode.hnam, UNameLen);
		}
	}
	else if (code[0] == '1' || code[0] == '4')	// future code
	{
		_sjcode   sjcode;
		for (int ii = 0; ii < m_fjcode.GetSize(); ii++)
		{
			sjcode = m_fjcode.GetAt(ii);
			if (code != sjcode.code)
				continue;
			
			return sjcode.name;
		}
		
	}
	else if (code[0] == '2' || code[0] == '3')
	{
		if (code[1] == '0')			// future option code
		{
			struct ojcode	ojcode;
			for (int ii = 0; ii < m_ojcode.GetSize(); ii++)
			{
				ojcode = m_ojcode.GetAt(ii);
				
				for (int jj = 0; jj < 4; jj++)
				{
					if (ojcode.call[jj].yorn != '1')
						continue;
					if (code != CString(ojcode.call[jj].cod2, OCodeLen))
						continue;
					
					return CString(ojcode.call[jj].hnam, ONameLen);
				}
				for (jj = 0; jj < 4; jj++)
				{
					if (ojcode.put[jj].yorn != '1')
						continue;
					if (code != CString(ojcode.put[jj].cod2, OCodeLen))
						continue;
					
					return CString(ojcode.put[jj].hnam, ONameLen);
				}
			}
		}
		else					// 
		{
			struct	pjcode pjcode;
			for (int ii = 0; ii < m_pjcode.GetSize(); ii++)
			{
				pjcode = m_pjcode.GetAt(ii);
				if (code != CString(pjcode.codx, PCodeLen))
					continue;
				
				return CString(pjcode.hnam, sizeof(pjcode.hnam));
			}
		}
	}
	
	return _T("");
}


void CMainFrame::loadingHJcode()
{
	if (m_hjcode.GetSize() > 0) return;
	
	CFile	fileH;
	CString	filePath;
	struct  hjcode  hjcode;
	struct	_shjcode s_hjcode;
	
	filePath.Format("%s/%s/%s", Axis::home, TABDIR, HJCODE);
	if (!fileH.Open(filePath, CFile::modeRead|CFile::typeBinary))
	{
		//AfxMessageBox(idTOstring(IDS_EM_HJCODE));
		return;
	}
	
	int countC = fileH.GetLength() / sizeof(struct hjcode);
	
	for (int ii = 0; ii < countC; ii++)
	{
		fileH.Read(&hjcode, sizeof(struct hjcode));
		
		s_hjcode.name = CString(hjcode.hnam, HNameLen);
		int idx = s_hjcode.name.Find('\0');
		if (idx != -1) s_hjcode.name = s_hjcode.name.Left(idx);
		s_hjcode.name.MakeUpper(); s_hjcode.name.TrimRight();
		//		s_hjcode.name = s_hjcode.name.Mid(1, s_hjcode.name.GetLength());
		
		s_hjcode.symb = CString(hjcode.symb, HSymbolLen);
		s_hjcode.symb.TrimRight();
		
		s_hjcode.ecng = hjcode.ecng;
		s_hjcode.size = hjcode.size;
		s_hjcode.ucdm = hjcode.ucdm;
		s_hjcode.ucds = hjcode.ucds;
		s_hjcode.jjug = hjcode.jjug;
		s_hjcode.kpgb = hjcode.kpgb;
		s_hjcode.ucmd = hjcode.ucmd;
		s_hjcode.kosd = (char)hjcode.kosd;
		s_hjcode.ssgb = hjcode.ssgb;
		s_hjcode.wsgb = hjcode.wsgb;
		s_hjcode.jsiz = hjcode.jsiz;
		s_hjcode.itgb = hjcode.itgb;
		s_hjcode.star = hjcode.star;
		s_hjcode.unio = hjcode.unio;
		s_hjcode.prmr = hjcode.prmr;
		
		switch (hjcode.ssgb)
		{
		case jmSINJU:
		case jmSINJS:
		case jmHYFND:
			s_hjcode.code = CString(hjcode.code, HCodeLen + 2);
			break;
		default:
			s_hjcode.code = CString(hjcode.code, HCodeLen + 2).Mid(1);
			break;
		}
		
		switch (s_hjcode.ssgb)
		{
		case jmHYFND:
			//			continue;
		default:
			m_hjcode.Add(s_hjcode);
			break;
		}
    }
	
	//�̺κ� �߰�
	//QSortCArray( m_hjcode, CompareChar ); 
	fileH.Close();
}


void CMainFrame::loadingFJcode()
{
	if (m_fjcode.GetSize() > 0) return;
	
	CFile	fileH;
	CString	filePath;
	struct  fjcode  fjcode;
	struct	_sjcode s_jcode;
	
	filePath.Format("%s/%s/%s", Axis::home, TABDIR, FJCODE);
	if (!fileH.Open(filePath, CFile::modeRead|CFile::typeBinary))
	{
		//AfxMessageBox(idTOstring(IDS_EM_FJCODE));
		return;
	}
	
	int countC = fileH.GetLength() / sizeof(struct fjcode);
	for (int ii = 0; ii < countC; ii++)
	{
		fileH.Read(&fjcode, sizeof(struct fjcode));
		
		s_jcode.code = CString(fjcode.cod2, FCodeLen);
		s_jcode.name = CString(fjcode.hnam, FNameLen);
		
		m_fjcode.Add(s_jcode);
	}
	
	fileH.Close();
}
void CMainFrame::loadingOJcode()
{
	if (m_ojcode.GetSize() > 0) return;
	
	CFile	fileH;
	CString	filePath;
	
	struct  ojcodh  ojcodH;
	struct  ojcode  ojcode;
	
	filePath.Format("%s/%s/%s", Axis::home, TABDIR, OJCODE);
	if (!fileH.Open(filePath, CFile::modeRead|CFile::typeBinary))
	{
		//AfxMessageBox(idTOstring(IDS_EM_OPCODE));
		return;
	}
	
	fileH.Read(&ojcodH, sizeof(struct ojcodh));
	
	int countC = (fileH.GetLength() - sizeof(struct ojcodh)) / sizeof(struct ojcode);
	for (int ii = 0; ii < countC; ii++)
	{
		fileH.Read(&ojcode, sizeof(struct ojcode));
		m_ojcode.Add(ojcode);
	}
	
	fileH.Close();
}
void CMainFrame::loadingPJcode()
{
	if (m_pjcode.GetSize() > 0) return;
	
	CFile	fileH;
	CString	filePath;
	struct  pjcode  pjcode;
	
	filePath.Format("%s/%s/%s", Axis::home, TABDIR, PJCODE);
	if (!fileH.Open(filePath, CFile::modeRead|CFile::typeBinary))
	{
		//AfxMessageBox(idTOstring(IDS_EM_PJCODE));
		return;
	}
	
	int countC = fileH.GetLength() / sizeof(struct pjcode);
	for (int ii = 0; ii < countC; ii++)
	{
		fileH.Read(&pjcode, sizeof(struct pjcode));
		m_pjcode.Add(pjcode);
	}
	
	fileH.Close();
}
void CMainFrame::loadingUPcode()
{
	if (m_upcode.GetSize() > 0) return;
	
	CFile	fileH;
	CString	filePath;
	struct  upcode  upcode;
	
	filePath.Format("%s/%s/%s", Axis::home, TABDIR, UPCODE);
	if (!fileH.Open(filePath, CFile::modeRead|CFile::typeBinary))
	{
		//AfxMessageBox(idTOstring(IDS_EM_UPCODE));
		return;
	}
	
	int countC = fileH.GetLength() / sizeof(struct upcode);
	for (int ii = 0; ii < countC; ii++)
	{
		fileH.Read(&upcode, sizeof(struct upcode));
		m_upcode.Add(upcode);
	}
	
	fileH.Close();
}
void CMainFrame::loadingELWcode()
{
	if (m_elwbase.GetSize() > 0)
		return;
	
	int	codeN;
	CFile	file;
	_sjcode	sjcode;
	struct  elwcode  ELWCode;
	
	CString path = Axis::home + "\\tab\\elwcod.dat";
	if (!file.Open(path, CFile::modeRead|CFile::typeBinary))	return;
	
	codeN = file.GetLength() / sizeof(struct elwcode);
	
	bool	bFound;
	for (int ii = 0; ii < codeN; ii++)
	{
		file.Read(&ELWCode, sizeof(struct elwcode));
		
		for (int jj = 0; jj < 5; jj ++)
		{
			CString bcode = CString((char*)ELWCode.gcjs[jj], 12);
			bcode.TrimRight();
			if (bcode == "") break;
			
			bcode = bcode.Mid(1);
			bFound = false;
			for (int kk = 0; kk < m_elwbase.GetSize(); kk++)
			{
				if (bcode.CompareNoCase(m_elwbase.GetAt(kk).code) == 0)
				{
					bFound = true;
					break;
				}
			}
			
			if (!bFound)
			{
				CString	bname = GetCodeName(bcode);
				if (!bname.IsEmpty())	
					;
				else if (bcode.CompareNoCase("OSPI200") == 0)
					continue;
				else if (bcode.CompareNoCase("ASKET") == 0)
					break;
				
				sjcode.code = bcode;
				sjcode.name = bname;
				sjcode.name.TrimRight();
				
				m_elwbase.Add(sjcode);
			}
		}
	}
	
	file.Close();
}

void CMainFrame::RunFOConfig()
{
	m_mapHelper->CreateChild("IB0000B2", 0);
}

void CMainFrame::load_secure_agree(BOOL bFirewall, BOOL bKeysecure)
{
	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'Q';
	memcpy(mid.item.usid, (LPCSTR)Axis::userID, Axis::userID.GetLength());
	memcpy(mid.item.innm, "AGREEMENT", 9);
	memcpy(mid.item.senm, "SECURETOOLS", 11);
	memcpy(mid.item.skey, "DISABLE", 7);

	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'P');
}

void CMainFrame::processSecureTool(char *data, int dlen)
{
	struct _pidouini_item *mod = (struct _pidouini_item*)data;

	// �������α׷��� ������� �ʰٴٰ� �������� �ʾ�����! (Disable�� ���� OK)
	if (memcmp(mod->valu, "OK", 2)!=0)
		PostMessage(WM_SECUREDLG, 0, 0);
}

LRESULT CMainFrame::OnSecureDlg(WPARAM wParam, LPARAM lParam)
{
	BOOL pcFirewall = AfxGetApp()->GetProfileInt(INFORMATION,   "PCFirewall", 0);
	BOOL pcKeyProtect = AfxGetApp()->GetProfileInt(ENVIRONMENT, "KeyProtect", 0);
	CSecureDlg dlg(this, pcFirewall, pcKeyProtect);
	if (dlg.DoModal()==IDOK)
	{
		if (!pcFirewall) InitFirewall();
		if (!pcKeyProtect) ((CAxisApp*)m_axis)->InitKings();

		AfxGetApp()->WriteProfileInt(INFORMATION, "PCFirewall", 1);
		AfxGetApp()->WriteProfileInt(ENVIRONMENT, "KeyProtect", 1);
	}
	else
	{
		if (dlg.m_bNoRetry)
		{
			CTime time = CTime::GetCurrentTime();
			struct	_pidouini_mid mid;
			memset(&mid, 0, sizeof(mid));
			mid.gubn[0] = 'I';
			memcpy(mid.item.usid, (LPCSTR)Axis::userID, Axis::userID.GetLength());
			memcpy(mid.item.innm, "AGREEMENT", 9);
			memcpy(mid.item.senm, "SECURETOOLS", 11);
			memcpy(mid.item.skey, "DISABLE", 7);
			sprintf(mid.item.valu, "OK - %s", time.Format("[%Y/%m/%d][%H:%M:%S]"));
			sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
		}
	}
	return 0;
}

void CMainFrame::os_report()
{
	OSVERSIONINFO info;
	info.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&info);
	
	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'I';
	memcpy(mid.item.usid, (LPCSTR)Axis::userID, Axis::userID.GetLength());
	memcpy(mid.item.innm, "INFO", 8);
	memcpy(mid.item.senm, "OS", 10);
	memcpy(mid.item.skey, "VERSION", 7);
	sprintf(mid.item.valu, "VER[%d.%d] BUILD[%d] PLATFORM[%d] CSD[%s]", 
		info.dwMajorVersion, info.dwMinorVersion, info.dwBuildNumber,
		info.dwPlatformId, info.szCSDVersion);
	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
}

void CMainFrame::checkFirewall()
{
	CRegKey reg;

	LPCTSTR keys[]  = {
		_T("Software\\IBK_STAFF\\AXIS Workstation V03.00\\Information"),			// ���� ������ 
		_T("Software\\IBKMAC_STAFF\\AXIS Workstation V03.00\\Information"),			// ���� ������
		NULL
	};

	/* ������ HTS�� ��ġ�Ǿ� ������� ��ȭ�������� ���� �����Ѵ� */
	for(int n=0; keys[n]!=NULL; ++n)
	{
		if (reg.Open(HKEY_CURRENT_USER, keys[n])==ERROR_SUCCESS)
		{
			AfxGetApp()->WriteProfileInt(INFORMATION, "PCFirewall", 0);
			reg.Close();
			return;
		}
	}

	/* ������ �α����� ��� ��ȭ�� ������ ���� �����Ѵ� */
	if (!Axis::isCustomer)
	{
		AfxGetApp()->WriteProfileInt(INFORMATION, "PCFirewall", 0);
		return;
	}
}

LONG CMainFrame::OnHotKey(WPARAM wp, LPARAM lp)
{
	if  (IsWindowVisible())
	{
		if (!m_arSDI[m_vsN].IsEmpty())
		{
			int key;
			CSChild *pChild;
			POSITION pos = m_arSDI[m_vsN].GetStartPosition();
			while(pos!=NULL)
			{	
				m_arSDI[m_vsN].GetNextAssoc(pos, key, pChild);
				pChild->ShowWindow(SW_HIDE);
			}
		}
		if (!m_arMPOP.IsEmpty())
		{
			int key;
			CMPop *pPop;
			POSITION pos = m_arMPOP.GetStartPosition();
			while(pos!=NULL)
			{
				m_arMPOP.GetNextAssoc(pos, key, pPop);
				pPop->ShowWindow(SW_HIDE);
			}
		}
		ShowWindow(SW_HIDE);
	}
	else
	{
		if (!m_arSDI[m_vsN].IsEmpty())
		{
			int key;
			CSChild *pChild;
			POSITION pos = m_arSDI[m_vsN].GetStartPosition();
			while(pos!=NULL)
			{	
				m_arSDI[m_vsN].GetNextAssoc(pos, key, pChild);
				pChild->ShowWindow(SW_SHOW);
			}
		}
		if (!m_arMPOP.IsEmpty())
		{
			int key;
			CMPop *pPop;
			POSITION pos = m_arMPOP.GetStartPosition();
			while(pos!=NULL)
			{
				m_arMPOP.GetNextAssoc(pos, key, pPop);
				pPop->ShowWindow(SW_SHOW);
			}
		}
		ShowWindow(SW_SHOW);
	}
	return 0;
}

void CMainFrame::LoadSecureTools()
{
	BOOL pcFirewall = AfxGetApp()->GetProfileInt(INFORMATION, "PCFirewall", 0);
	(pcFirewall && Axis::isCustomer) ? InitFirewall() : FreeFirewall();

	CAxisApp *app = (CAxisApp*)m_axis;
	BOOL pcKeyProtect = AfxGetApp()->GetProfileInt(ENVIRONMENT, "KeyProtect", 0);
	(pcKeyProtect) ? app->InitKings() : app->FreeKings();
}

LONG CMainFrame::OnSecureChange( WPARAM wp, LPARAM lp )
{
	LoadSecureTools();
	return 0;
}

void CMainFrame::LoadHotkeySetting()
{
	FreeHotkeySetting();
	CString file;
	file.Format("%s\\%s\\%s\\%s", Axis::home, USRDIR, Axis::user, SETUPFILE);

	m_bUseHideHotkey = (BOOL)::GetPrivateProfileInt("HOTKEY", "UseHideHotkey", 0, file);
	if (m_bUseHideHotkey)
	{
		char buff[16];
		int pos = ::GetPrivateProfileString("HOTKEY", "HideHotkey", "", buff, sizeof(buff)-1, file);
		buff[pos] = NULL;
		if (buff[0]=='F')
		{
			UINT keycode = VK_F1 + (atoi(&buff[1])-1);
			if (!RegisterHotKey(m_hWnd, 0x1212, 0, keycode))
			{
				CString msg;
				msg.Format("�ٸ� ���α׷����� �̹� ����ϰ� �ִ� Ű[%s]�Դϴ�.\r\n������ �Ͻñ� �ٶ��ϴ�.", buff);
				MessageBox(msg, "IBK��������", MB_OK|MB_ICONINFORMATION);
			}
		}
	}
}

void CMainFrame::FreeHotkeySetting()
{
	UnregisterHotKey(m_hWnd, 0x1212);
}

BOOL CMainFrame::OnCreateClient( LPCREATESTRUCT lpcs, CCreateContext* pContext )
{
	return CreateClient(lpcs, NULL);
}

BOOL CMainFrame::IsSuperUser()
{
	if (!Axis::isCustomer)
		return (Axis::userID=="071006" || Axis::userID=="081394" || Axis::userID=="091120" || Axis::userID=="##ibk9" || Axis::userID=="890307");
	else
	{
		if(Axis::userID == "dundas")
		{
			return TRUE;
		}
		return FALSE;
	}
}

void CMainFrame::mac_report()
{
	if (m_macaddr.IsEmpty()) return;

	CTime tm = CTime::GetCurrentTime();
	CString data;
	data.Format("%s;%s;%s", (LPCSTR)tm.Format("%Y/%m/%d %H:%M:%S"), (LPCSTR)m_macaddr, (LPCSTR)m_ipAddr);

	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'I';
	sprintf(mid.item.usid, (LPCSTR)Axis::userID);
	sprintf(mid.item.innm, "INFO");
	sprintf(mid.item.senm, "HTS");
	sprintf(mid.item.skey, "CONNECTION");
	sprintf(mid.item.valu, (LPCSTR)data);
	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
}

void CMainFrame::scr_counter_report()
{
	CTime now = CTime::GetCurrentTime();
	CString yymmdd = now.Format("%Y%m%d");

	CString &cdat = m_mapHelper->GetCountData();
	if (cdat.IsEmpty()) return;

	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'I';
	sprintf(mid.item.usid, (LPCSTR)Axis::userID);
	sprintf(mid.item.innm, "INFO");
	sprintf(mid.item.senm, "HTS");
	sprintf(mid.item.skey, "SCREEN");
	if (cdat.GetLength() > sizeof(mid.item.valu)) 
		cdat = cdat.Mid(0, sizeof(mid.item.valu));
	sprintf(mid.item.valu, (LPCSTR)cdat);
	memcpy(mid.item.date, (LPCSTR)yymmdd, min(yymmdd.GetLength(), sizeof(mid.item.date)));

	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
}

void CMainFrame::save_scr_counter()
{
	CTime now = CTime::GetCurrentTime();
	CString yymmdd = now.Format("%Y%m%d");
	
	CString file, usnm = Axis::user;
	file.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, usnm, usnm); 
	WritePrivateProfileString("TRCounter", "Date", (LPCSTR)yymmdd, file);
	WritePrivateProfileString("TRCounter", "Data", (LPCSTR)m_mapHelper->GetCountData(), file);
}

void CMainFrame::load_scr_counter()
{
	CTime now = CTime::GetCurrentTime();
	CString yymmdd = now.Format("%Y%m%d");

	CString file, usnm = Axis::user;
	file.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, usnm, usnm); 

	char date[16], data[1024*16];
	GetPrivateProfileString("TRCounter", "Date", "", date, sizeof(date), file);

	if (yymmdd.Compare(date)==0)
	{
		int dlen = GetPrivateProfileString("TRCounter", "Data", "", data, sizeof(data), file);
		m_mapHelper->SetCountData(data, dlen);
	}
}

void CMainFrame::SplitStr( LPCSTR st, LPCSTR ed, CHAR del, std::vector<CString> *pResult )
{
	if (st==NULL || ed==NULL) return;
	if (st>=ed) return;

	pResult->clear();
	while(st<ed)
	{
		LPCSTR pos = std::find(st, ed, del);
		pResult->push_back(CString(st, pos-st));
		pResult->back().TrimLeft();
		pResult->back().TrimRight();
		st = pos + 1;
	}
}

void CMainFrame::SplitStr( CString *data, CHAR del, std::vector<CString> *pResult )
{
	LPCSTR st = (LPCSTR)(*data);
	LPCSTR ed = st + data->GetLength();
	SplitStr( st, ed, del, pResult );
}

void CMainFrame::ProcessRexp( struct rexp_mid *mid )
{
	char buff[32];
	sprintf(buff, "%.4s", mid->nrec);
	int nrec = atoi(buff);
	
	for(int n=0; n<nrec; ++n)
	{
		m_rexp.push_back( mid->item[n] );
	}
	
	StartRexp();
}

void CMainFrame::StartRexp()
{
	if (m_rexp.empty()) return;
	
	CString type(m_rexp[0].type, sizeof(m_rexp[0].type)); type.TrimLeft(); type.TrimRight();
	CString path(m_rexp[0].path, sizeof(m_rexp[0].path)); path.TrimLeft(); path.TrimRight();
	CString size(m_rexp[0].size, sizeof(m_rexp[0].size)); size.TrimLeft(); size.TrimRight();
	
	struct pibotran_mid mid;
	sprintf(mid.seqn, "000001");
	sprintf(mid.start, "00000000");
	sprintf(mid.file, (LPCSTR)path);
	
	sendTR("pibotran", (char*)&mid, sizeof(mid), 0, 'R');
}

void CMainFrame::processTran( char *data, int dlen )
{
	if (m_rexp.empty()) return;
	
	struct pibotran_mod *mod = (struct pibotran_mod*)data;
	
	CString dstpath;
	CString type(m_rexp[0].type, sizeof(m_rexp[0].type)); type.TrimLeft(); type.TrimRight();
	CString path(m_rexp[0].path, sizeof(m_rexp[0].path)); path.TrimLeft(); path.TrimRight();
	CString size(m_rexp[0].size, sizeof(m_rexp[0].size)); size.TrimLeft(); size.TrimRight();
	
	
	CString seqn(mod->seqn, sizeof(mod->seqn));
	CString max_seqn(mod->max_seqn, sizeof(mod->max_seqn));
	CString data_size(mod->size, sizeof(mod->size));
	
// 	CString emsg;
// 	emsg.Format("pibotran seqn(%s/%s) size(%s)\n", seqn, max_seqn, data_size);
// 	OutputDebugString(emsg);
	
	if (type=="MAP")
	{
		std::vector<CString> sp_path;
		SplitStr(&path, '/', &sp_path);
		
		dstpath.Format("%s\\map\\%.2s\\%.3s\\%s.exp", (LPCSTR)Axis::home, (LPCSTR)sp_path.back(), (LPCSTR)sp_path.back(), (LPCSTR)sp_path.back());
		
		FILE *fp = fopen((LPCSTR)dstpath, "a+b");
		if (fp)
		{
			fwrite(mod->data, 1, atoi(data_size), fp);
			fclose(fp);
			
			if (atoi(seqn)==atoi(max_seqn))	// ���Ϲޱ� �Ϸ�
			{
				CString newpath = dstpath;
				newpath.Replace(".exp", "");
				DeleteFile(newpath);
				MoveFile((LPCSTR)dstpath, (LPCSTR)newpath);
			}
			else
			{
				struct pibotran_mid mid;
				sprintf(mid.seqn, "%06d", atoi(seqn)+1);
				memcpy(mid.start, mod->start, sizeof(mod->start));
				sprintf(mid.file, (LPCSTR)path);
				sendTR("pibotran", (char*)&mid, sizeof(mid), 0, 'R');
				return;
			}
		}
	}
	
	m_rexp.erase(m_rexp.begin());
	StartRexp();
}

const CWnd* CMainFrame::GetBkWnd()
{
	return m_MClient->m_pBkMapWnd;
}

void CMainFrame::OutputWaitList()
{
	return;
	/*
	OutputDebugString("OutputWaitList ----------------------\r\n");
	int size = m_waitlist.GetSize();
	for(int ii=0; ii<size; ++ii)
	{
		int key = m_waitlist.GetAt(ii);
		
		BOOL bFind = FALSE;
		CString dmsg, caption;
		CChildFrame *frame = NULL;
		CSChild *child = NULL;
		for(int jj=0; jj<6; ++jj)
		{
			if (m_arMDI[jj].Lookup(key, frame))
			{
				frame->GetWindowText(caption);
				dmsg.Format("MDI [%s] %s\r\n", (LPCSTR)frame->m_mapN, (LPCSTR)caption);
				OutputDebugString((LPCSTR)dmsg);
				bFind = TRUE;
				break;
			}
			else if (m_arSDI[jj].Lookup(key, child))
			{
				child->GetWindowText(caption);
				dmsg.Format("SDI [%s] %s\r\n", (LPCSTR)child->m_mapN, (LPCSTR)caption);
				OutputDebugString((LPCSTR)dmsg);
				bFind = TRUE;
				break;
			}
		}
		if (!bFind)
		{
			dmsg.Format("Can't found key(%d) info\r\n", key);
			OutputDebugString(dmsg);
		}
	}
	OutputDebugString("-------------------------------------\r\n");
	*/
}

BOOL CMainFrame::ChangeTabView( LPCSTR mapN, int key )
{
//  	OutputWaitList();
	for(int n=0; n<m_waitlist.GetSize(); ++n)
	{
		if (m_waitlist.GetAt(n)==key) return FALSE;
	}
	m_mapHelper->ChangeTabView(mapN, 0, key);
	return TRUE;
}

BOOL CMainFrame::ClearGex()
{
	if (MessageBox(
		"��� ��Ʈ������ �ʱ�ȭ �˴ϴ�.\n"
		"(���� ����ȭ���� ������� �ʽ��ϴ�)\n\n"
		"�ʱ�ȭ �Ͻðڽ��ϱ�?", "IBK��������", MB_YESNO)==IDYES)
	{
		CString org_path = Axis::home + "\\gex\\" + Axis::user;
		CString new_path = Axis::home + "\\gex\\" + Axis::user + "." + CTime::GetCurrentTime().Format("%Y%m%d_%H%M%S");
		return MoveFile(org_path, new_path);
	}
	return FALSE;
}

void CMainFrame::ini_report(LPCSTR innm, LPCSTR senm, LPCSTR skey, LPCSTR valu)
{
	struct	_pidouini_mid mid;
	memset(&mid, 0, sizeof(mid));
	mid.gubn[0] = 'I';
	memcpy(mid.item.usid, (LPCSTR)Axis::userID, Axis::userID.GetLength());
	memcpy(mid.item.innm, innm, min(strlen(innm), sizeof(mid.item.innm)));
	memcpy(mid.item.senm, senm, min(strlen(senm), sizeof(mid.item.senm)));
	memcpy(mid.item.skey, skey, min(strlen(skey), sizeof(mid.item.skey)));
	memcpy(mid.item.valu, valu, min(strlen(valu), sizeof(mid.item.valu)));
	sendTR("pidouini", (char*)&mid, sizeof(mid), 0, 'p');
}

void CMainFrame::ClearRepositoryLog()
{
	CTime tm = CTime::GetCurrentTime() + CTimeSpan(-1, 0, 0, 0);
	
	CString strPath = Axis::home + "\\log????????_??????.trc";
	CString strToday = Axis::home + "\\log" + tm.Format("%Y%m%d");

	WIN32_FIND_DATA wfd;
	HANDLE hFind = FindFirstFile(strPath, &wfd);
	while(hFind!=INVALID_HANDLE_VALUE)
	{
		CString strFile = Axis::home + "\\" + wfd.cFileName;
		if (strToday>strFile)
		{
			DeleteFile(strFile);
		}

		if (!FindNextFile(hFind, &wfd)) 
		{
			FindClose(hFind);
			break;
		}
	}
}

void CMainFrame::load_dbar2()
{
	DWORD dwListBarStyle = m_axis->GetProfileInt(INFORMATION, "listbar_pos", 0);

	if (dwListBarStyle==0)
	{
		CProfile p(pkUserSetup);
		dwListBarStyle = (DWORD)p.GetDouble(INFORMATION, "listbar_pos", CBRS_ALIGN_BOTTOM);
	}
	else
	{
		m_axis->WriteProfileInt(INFORMATION, "listbar_pos", 0);
		CProfile(pkUserSetup).Write(INFORMATION, "listbar_pos", (double)dwListBarStyle);
	}	
	if (m_bar2)
	{
		if      (dwListBarStyle&CBRS_ALIGN_BOTTOM) m_bar2->MoveBar(MB_BOTTOM);
		else if (dwListBarStyle&CBRS_ALIGN_TOP)    m_bar2->MoveBar(MB_TOP);
	}
	
}


void CMainFrame::FixUserConfigDirectory()
{
	CString gexPath, usrPath, emsg;
	gexPath.Format("%s\\%s\\*.*", Axis::home, GEXDIR);

	BOOL bFind;
	CFileFind ffGex, ffUsr;
	
	CStringArray delList;
	bFind = ffGex.FindFile(gexPath);
	while(bFind)
	{
		bFind = ffGex.FindNextFile();

		usrPath = ffGex.GetFilePath();
		usrPath.Replace(GEXDIR, USRDIR);
		if  (!ffUsr.FindFile(usrPath))
		{
			delList.Add(ffGex.GetFilePath());
		}
	}

	for(int n=0; n<delList.GetSize(); ++n)
	{
		DeleteDirectory(delList[n]);
	}
}

void CMainFrame::CheckEncryptDirectory()
{
	SetUserInfo();

	CString src, dst, enc;
	enc.Format("%08u", HashKey<LPCSTR>(Axis::userNM));

#if 0
	if (Axis::isCustomer)
	{
		gAPIHook.StopHook();
		src.Format("%s/%s/%s", Axis::home, USRDIR, enc);
		dst.Format("%s/%s/%s", Axis::home, USRDIR, Axis::userNM);
		MoveFile(src, dst);
		
		src.Format("%s/%s/%s", Axis::home, GEXDIR, enc);
		dst.Format("%s/%s/%s", Axis::home, GEXDIR, Axis::userNM);
		MoveFile(src, dst);

		src.Format("%s/%s/%s/%s.ini", Axis::home, USRDIR, Axis::userNM, enc);
		dst.Format("%s/%s/%s/%s.ini", Axis::home, USRDIR, Axis::userNM, Axis::userNM);
		MoveFile(src, dst);
		OutputDebugString("APIHOOK Stop!!!!!!!!!!!!!!!!!!!!!\n");
	}
	else
#endif
	{	
		gAPIHook.StopHook();

		src.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, Axis::userNM, Axis::userNM);
		dst.Format("%s\\%s\\%s\\%s.ini", Axis::home, USRDIR, Axis::userNM, enc);
		MoveFile(src, dst);
		
		src.Format("%s\\%s\\%s", Axis::home, USRDIR, Axis::userNM);
		dst.Format("%s\\%s\\%s", Axis::home, USRDIR, enc);
		MoveFile(src, dst);
		
		src.Format("%s\\%s\\%s", Axis::home, GEXDIR, Axis::userNM);
		dst.Format("%s\\%s\\%s", Axis::home, GEXDIR, enc);
		MoveFile(src, dst);
		
		src.Format("%s\\%s\\%s", Axis::home, USRDIR, Axis::userNM);
		RemoveDirectory(src);
		
		src.Format("%s\\%s\\%s", Axis::home, GEXDIR, Axis::userNM);
		RemoveDirectory(src);

		gAPIHook.SetInfo(Axis::home, Axis::userNM);
		gAPIHook.StartHook();
	}
}

#ifdef USE_AHNLAB_SECUREBROWSER

int __stdcall SBSDK_Callback(long lCode, void* pParam, long lParamSize)
{
	switch(lCode)
	{
	case SBSDK_CALLBACK_DRIVERFAILED :
		AfxMessageBox(_T("����̹��� ���������� �������� ���߽��ϴ�."));
		break;
	case SBSDK_CALLBACK_DETECT_DEBUG :
		AfxMessageBox(_T("����� ������ Ž���߽��ϴ�."));
		
		// ���α׷� ���� �ڵ�
		//theApp.quitApplication();
		break;
	case SBSDK_CALLBACK_ABNORMAL_MEMORY_ACCESS :
		{
			if(pParam)
			{
				PST_SBSDK_PROCESS_PATH phpf = (PST_SBSDK_PROCESS_PATH)pParam;
				
				USES_CONVERSION;
				TRACE(_T("[SBSDK_Callback] SBSDK_CALLBACK_ABNORMAL_MEMORY_ACCESS(#%ld,'%s')\n"),  
					phpf->ulPID, A2T(phpf->szProcessName));
			}
			
			AfxMessageBox(_T("�޸𸮿� �㰡���� ���� ������ �õ��߽��ϴ�."));
			
			// ���α׷� ���� �ڵ�
			//theApp.quitApplication();
		}
		break;
	case SBSDK_CALLBACK_BLACKLIST :
		AfxMessageBox(_T("�Ǽ��ڵ�� �ǽɵǴ� ���α׷��� �����߽��ϴ�."));
		break;
	default :
		{
			//theApp.messageBoxFormat(_T("��ŷ ���� ��ɿ� ������ �߻��߽��ϴ�(lCode=0x%x)"), lCode);
		}
		break;
	} // end of switch
	
	return 0;
}

BOOL CMainFrame::initAOSSDK()
{
	if(isVerifyTrustSDK() == FALSE)
	{
		AfxMessageBox(_T("[SB] �޸𸮺�ȣ��� ������ �����Ͽ����ϴ�."));
		return FALSE;
	}

	// ������Ʈ ���� â�� ���̵��� ����
	Aossdk_SetModeUI(TRUE);

	// ������Ʈ ���� ���(Sync Mode) ����: AOS Secure Browser �ݵ�� ���� ���� ���� �ؾ� �� 
	Aossdk_SetModeAsync(FALSE);

	DWORD dwErrorCode = 0;
	BOOL bResult = FALSE;

	// AOS Secure Browser ������Ʈ
	bResult = Aossdk_StartAosSDKA( 
					"e9",
					"20A06A69C9F10BAF6E0DCF83D240DDB2ECA45143CA8E4910",
					GetSafeHwnd(),
					&dwErrorCode
				);
	if(bResult == FALSE)
	{
		CString emsg;
		emsg.Format(_T("[SB] �޸𸮺�ȣ��� ������Ʈ�� �����Ͽ����ϴ�. [0x%X])"), dwErrorCode);
		MessageBox(emsg);
		return FALSE;
	}

	m_pAosSB = Aossdk_GetSBObject(&dwErrorCode);
	if(m_pAosSB == NULL)
	{
		CString emsg;
		emsg.Format(_T("[SB] �޸𸮺�ȣ��� ������ �����Ͽ����ϴ�. (0x%X)"), dwErrorCode);
		MessageBox(emsg);
		return FALSE;
	}

	return TRUE;
}

void CMainFrame::uninitAOSSDK()
{
	//Aossdk_TerminateSDKA("id:test_sb_sdk");
}

BOOL CMainFrame::initSBSDK()
{
	if(m_pAosSB == NULL)
	{
		//AfxMessageBox(_T("[aossdk] SBSDK object error"));
		return FALSE;
	}
	
	CString strPath;
	DWORD dwSize = GetModuleFileName(NULL, strPath.GetBuffer(MAX_PATH), MAX_PATH);
	strPath.GetBufferSetLength(dwSize);
	strPath.Replace("axis.exe", "axis.ndg");
	strPath.ReleaseBuffer();
	
	DWORD dwOption;
	CFileFind ff;
	if (ff.FindFile(strPath)) dwOption = NULL;
	else                      dwOption = SBSDK_ACTIVATE_ANTIDEBUG|SBSDK_ACTIVATE_SHILD;
	//dwOption = NULL;

	DWORD dwResult = m_pAosSB->Initialize(dwOption, SBSDK_Callback);
	if(dwResult != SBSDK_ERROR_SUCCESS && dwResult != SBSDK_ERROR_COMPATIBILITY_MODE)
	{
		CString csmsg;
		if(dwResult == SBSDK_ERROR_DETECT_DEBUG)
		{
			csmsg = _T("[SB] �޸𸮺�ȣ����� ��������� �����Ͽ����ϴ�.");
			
			// ���α׷� ���� �ڵ�
			//theApp.quitApplication();
		}
		else
		{
			csmsg.Format(_T("[SB] �޸𸮺�ȣ��� ���࿡ �����Ͽ����ϴ� (0x%X)"), dwResult);
		}
		
		AfxMessageBox(csmsg);
		return FALSE;
	}
	
	return TRUE;
}

void CMainFrame::uninitSBSDK()
{
	if(m_pAosSB)
	{
		m_pAosSB->Uninitialize();
		m_pAosSB = NULL;
	}
}

BOOL CMainFrame::isVerifyTrustSelf( LPCTSTR szSignedName )
{
	BOOL bResult = FALSE;
	
	IAosVerify*	pAosVerify = getAosVerify();
	if(pAosVerify)
	{
		// AOS SDK�� ȣ���ϴ� ���� ������ Code Sign �Ǿ� ���� ��� ���� �����
		// �������� �ʾҴ��� ��ü �˻�
#ifdef _UNICODE
		bResult = pAosVerify->VerifyTrustSelfW(szSignedName);
#else
		bResult = pAosVerify->VerifyTrustSelfA(szSignedName);
#endif
	}
	
	return bResult;
}

BOOL CMainFrame::isVerifyTrustSDK()
{
	BOOL bResult = FALSE;
	
	IAosVerify*	pAosVerify = getAosVerify();
	if(pAosVerify)
	{
		// AOS SDK ����� �������� �ʾҴ��� �˻�
		bResult = pAosVerify->VerifyTrustSDK();
	}
	
	return bResult;
}

BOOL CMainFrame::isRunningSDKPd( DWORD dwServiceCode )
{
	BOOL bResult = FALSE;
	
	IAosVerify*	pAosVerify = getAosVerify();
	if(pAosVerify)
	{
		// AOS SDK ����� ���� ���� ������ �˻�
		bResult = pAosVerify->IsRunningPd(dwServiceCode);
	}
	
	return bResult;
}

IAosVerify* CMainFrame::getAosVerify()
{
	static IAosVerify *_pAosVerify = NULL;
	
	if(_pAosVerify == NULL)  
	{
		DWORD dwErrorCode = 0;
		
		// Get IAosVerify Object
		_pAosVerify = Aossdk_GetVerifyObject(&dwErrorCode);
	}
	
	return _pAosVerify;
}

#endif

